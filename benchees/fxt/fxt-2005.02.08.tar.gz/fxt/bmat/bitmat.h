#if !defined  HAVE_BITMAT_H__
#define       HAVE_BITMAT_H__

#include "fxttypes.h"
#include "restrict.h"

#include "bmat/bitmatinline.h"


// bmat/bitmatmult.cc:
ulong bitmat_mult_Mv(const ulong *M, ulong n, ulong v);
ulong bitmat_mult_vM(const ulong *M, ulong n, ulong v);
void bitmat_transpose(const ulong *M, ulong n, ulong *T);
void bitmat_mult(const ulong *M1, const ulong *M2, ulong n, ulong *P);

// bmat/bitmatnullspace.cc:
ulong bitmat_nullspace(const ulong *M, ulong n, ulong *Ns);
ulong bitmat_test_nullspace(const ulong *M, ulong n, const ulong *Ns, ulong r);

// bmat/bitmatinverse.cc:
bool bitmat_inverse_q(const ulong *M, ulong n, const ulong *Mi);
ulong bitmat_inverse(const ulong *M, ulong n, ulong * restrict Mi,
                     const ulong * restrict B=0);

// bmat/bitmathessenberg.cc:
bool bitmat_is_hessenberg(const ulong *H, ulong n);
void bitmat_hessenberg(const ulong *M, ulong n, ulong *H);

// bmat/bitmatcharpoly.cc:
ulong bitmat_hessenberg2charpoly(const ulong *H, ulong n);
ulong bitmat_charpoly(const ulong *M, ulong n);

// bmat/bitmatcompanion.cc:
void bitmat_companion(ulong p, ulong n, ulong *M);

// bmat/bitmatprint.cc:
void bitmat_print(const char *bla, const ulong *M, ulong n, ulong nv=0);

// bmat/bitmatkronecker.cc:
void bitmat_kronecker(const ulong *M1, ulong n1, const ulong *M2, ulong n2, ulong *K);


#endif  // !defined HAVE_BITMAT_H__
