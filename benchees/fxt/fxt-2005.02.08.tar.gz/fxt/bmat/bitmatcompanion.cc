
#include "fxttypes.h"

void
bitmat_companion(ulong p, ulong n, ulong *M)
// Companion matrix for the binary polynomial
// p(x) = x^n + \sum_{i=0}^{n-1}{c_i*x^i}
{
    ulong h = 1UL << (n-1);
    ulong r = 0;
    if ( p & 1UL )  r |= h;
    M[0] = r;
    ulong d = 1UL;
    for (ulong i=1; i<n; ++i)
    {
        r = d;
        d <<= 1;
        p >>= 1;
        if ( p & 1UL )  r |= h;
        M[i] = r;
    }
}
// -------------------------
