
#include "bits/parity.h"
#include "bmat/bitmat.h"

#include "fxtalloca.h"
#include "fxttypes.h"


ulong
bitmat_mult_Mv(const ulong *M, ulong n, ulong v)
// Return m*v where
// m is a binary (n x n) matrix, v is a binary vector
{
    ulong p = 0;
    for (ulong j=0; j<n; ++j)
    {
        ulong t = M[j] & v;
        t = parity(t);
        p |= (t<<j);
    }
    return p;
}
// -------------------------

ulong
bitmat_mult_vM(const ulong *M, ulong n, ulong v)
// Return v*m where
// m is a binary (n x n) matrix, v is a binary vector
{
    ulong p = 0;
    for (ulong j=0; j<n; ++j)
    {
        ulong t = parity( M[j] );
        p |= (t<<j);
    }
    p &= v;
    return p;
}
// -------------------------

void
bitmat_transpose(const ulong *M, ulong n, ulong *T)
// Transpose binary (n x n) matrix:  t = transpose(m)
{
    ALLOCA(ulong, A, n);
    for (ulong i=0; i<n; ++i)  A[i] = 0;
    for (ulong i=0; i<n; ++i)
    {
        ulong z = M[i];
        for (ulong j=0; j<n; ++j)
        {
            ulong u = z & 1UL;
            z >>= 1;
            A[j] |= (u << i);
        }
    }
    for (ulong k=0; k<n; ++k)  T[k] = A[k];
}
// -------------------------


void
bitmat_mult(const ulong *M1, const ulong *M2, ulong n, ulong *P)
// Multiply binary (n x n) matrices:  p = m1 * m2
{
    ALLOCA(ulong, T, n);
    ALLOCA(ulong, T2, n);
    bitmat_transpose(M2, n, T2);
    for (ulong i=0; i<n; ++i)
    {
        ulong v1 = M1[i];
        ulong pi = 0;
        for (ulong j=0; j<n; ++j)
        {
            ulong v2 = T2[j];
            ulong p = parity( v2 & v1 );
            pi |= (p << j);
        }
        T[i] = pi;
    }
    for (ulong k=0; k<n; ++k)  P[k] = T[k];
}
// -------------------------
