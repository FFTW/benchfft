
#include "bmat/bitmat.h"

#include "fxtalloca.h"
#include "jjassert.h"
#include "fxttypes.h"  // ulong


// defines to make the code less cryptic:
#define mGET(M, i, j)  ((M[i]>>j) & 1UL)
//
ulong
bitmat_hessenberg2charpoly(const ulong *H, ulong n)
// Compute from (Hessenberg-) matrix H
//  the characteristic polynomial.
//.
// cf. Cohen p.55
{
    // 5 [Initialize characteristic polynomial]:
    ALLOCA(ulong, vp, n+1);
    vp[0] = 1;
    for (ulong m=1; m<=n; ++m)
    {
        ulong m1 = m - 1; // 0,...,n-1

        // 6 [Initialize computation]:
        ulong Hmm = mGET(H, m1, m1);
        ulong p = vp[m1];
        vp[m] = (p<<1) ^ ( Hmm ? p : 0 );
        ulong t = 1;

        // 7 [Compute p_m]:
        for (ulong i=1; i<m; ++i)
        {
            ulong x = m1 - i;  // m-2, ..., 0
            ulong q1 = mGET(H, x+1, x);
            t &= q1;
            if ( 0==t )  break;
            ulong q2 = mGET(H, x, m1);
            q2 &= t;
            if ( q2 )  vp[m] ^= vp[x];
        }
    }
    return vp[n];
}
// -------------------------


ulong
bitmat_charpoly(const ulong *M, ulong n)
// Return the characteristic polynomial of M.
//.
// cf. Cohen p.55
{
    ALLOCA(ulong, H, n);
    bitmat_hessenberg(M, n, H);
    ulong cp = bitmat_hessenberg2charpoly(H, n);
    return  cp;
}
// -------------------------



//#if 0  // only for reals:
//ulong
//bitmat_charpoly(const ulong *M, ulong n, ulong *T=0)
//// Cohen p.53
//{
//    ulong a = 1UL;  // a_0 = 0
//    ALLOCA(ulong, C, n);
//    bitmat_unit(C, n);
////    bitmat_set(M, n, C);
//    for (ulong i=1; i<n; ++i)
//    {
//        bitmat_mult(M, C, n, C); // C = M*C
//        ulong ai = bitmat_trace(C, n);  // a_i = -tr(C)/i  // !
//        a |= (ai<<i);
//        if ( ai )  bitmat_add_unit(C, n); //  C += a_i * Id_n
//    }
//
//    if ( T )  bitmat_set(C, n, T);  // C = (-1)^{n-1} * C
//
//    bitmat_mult(M, C, n, C);
//    ulong an = bitmat_trace(C, n); // a_n = -tr(M*C)/n  // !
//    a |= (an << n);
//    return  a;
//}
//// -------------------------
//#endif // 0

