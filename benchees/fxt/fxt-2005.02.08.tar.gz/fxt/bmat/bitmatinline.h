#if !defined  HAVE_BITMATINLINE_H__
#define       HAVE_BITMATINLINE_H__

#include "fxttypes.h"


inline void bitmat_set(const ulong *M1, ulong n, ulong *M2)
// M2 = M1 (for binary matrices)
{
    for (ulong k=0; k<n; ++k)  M2[k] = M1[k];
}
// -------------------------

inline void bitmat_unit(ulong *M, ulong n)
// M = unity
{
    for (ulong k=0, b=1UL;  k<n;  ++k, b<<=1)  M[k] = b;
}
// -------------------------


inline bool bitmat_is_unit(const ulong *M, ulong n)
// return ( M == unity )
{
    for (ulong k=0, b=1UL;  k<n;  ++k, b<<=1)
    {
        if ( M[k] != b )  return  false;
    }
    return  true;
}
// -------------------------

inline bool bitmat_is_zero(const ulong *M, ulong n)
// return ( M == 0 )
{
    ulong t = 0;
    for (ulong k=0;  k<n;  ++k)  t |= M[k];
    return  ( 0==t );
}
// -------------------------


inline void bitmat_add_unit(ulong *M, ulong n)
// M += unity
{
    for (ulong k=0, b=1UL;  k<n;  ++k, b<<=1)  M[k] ^= b;
}
// -------------------------


inline ulong bitmat_trace(const ulong *M, ulong n)
{
    ulong t = 0;
    for (ulong i=0; i<n; ++i)  t ^= (M[i] >> i);
    return  t & 1UL;
}
// -------------------------

inline ulong bitmat_cmp(const ulong *M1, const ulong *M2, ulong n)
{
    for (ulong i=0; i<n; ++i)  if( M1[i] ^ M2[i] )  return 1;
    return  0;
}
// -------------------------


#endif  // !defined HAVE_BITMATINLINE_H__
