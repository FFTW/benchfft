
#include "bmat/bitmat.h"
#include "bits/bitlow.h"
#include "bits/bitsperlong.h"
#include "aux0/swap.h"

#include "fxtalloca.h"
#include "fxttypes.h"
#include "restrict.h"
//#include "jjassert.h"
//#include "fxtio.h"


bool bitmat_inverse_q(const ulong *M, ulong n, const ulong *Mi)
{
    ALLOCA(ulong, T, n);
    bitmat_mult(M, Mi, n, T);
    return bitmat_is_unit(T, n);
}
// -------------------------


// defines to make the code less cryptic:
#define mGET(M, i, j)  ((M[i]>>j) & 1UL)
#define mSET(M, i, j, s) { ulong bj=1UL<<j; if (s) {M[i]|=bj;}  else { M[i]&=~bj; } }
#define vGET(v, j)  ((v>>j) & 1UL)
#define vSET(v, j, s) { ulong bj=1UL<<j; if (s) {v|=bj;}  else {v&=~bj;} }

ulong
bitmat_inverse(const ulong *M, ulong n,
               ulong * restrict Mi,
               const ulong * restrict B/*=0*/)
//
// Compute Mi=M^(-1)*B or Mi=M^(-1) if B not given.
// Return 0 if M is not invertible.
//.
// Algorithm as in Cohen p.48
{
//    cout << "+++++++++++++++++++++++++++++++++++++++" << endl;

    ALLOCA(ulong, T, n);
    // 1 [Initialize]:
    if ( B )  bitmat_set(B, n, T);  // supplied value
    else      bitmat_unit(T, n);


    for (ulong k=0; k<n; ++k)  Mi[k] = M[k];  // Don't modify M
    ulong c = 0;  // auxiliary vector

#define M M_is_GONE
#define B B_is_GONE

    for (ulong j=0; j<n; ++j)
    {
        // 3 [Find non-zero entry]:
        ulong i = j;
        do  { if ( 0!=mGET(Mi, i, j) )  break; }  while ( ++i < n );
//        jjassert ( i>=j );

        if ( i==n )  return 0;  // M is not invertible

        // 4 [Swap?]:
        if ( i>j )
        {
            for (ulong l=j; l<n; ++l)
            {
                ulong si = mGET(Mi, i, l);
                ulong sj = mGET(Mi, j, l);
                mSET(Mi, j, l, si);
                mSET(Mi, i, l, sj);
            }

            swap2(T[i], T[j]);
        }
//        bitmat_print(" [4] Mi == ", Mi, n);
//        bitmat_print(" [4] T  == ", T, n);

        // 5 [Eliminate]:  // d==1
//        jjassert ( 1UL==mGET(Mi,j,j) );
        for (ulong k=j+1; k<n; ++k)  vSET(c, k, mGET(Mi, k, j));

        for (ulong k=j+1; k<n; ++k)
        {
            ulong ck = vGET(c, k);
            for (ulong l=j+1; l<n; ++l)
            {
                ulong s = mGET(Mi, k, l);
                ulong sp = mGET(Mi, j, l) & ck;
                s ^= sp;
                mSET(Mi, k, l, s);
            }
        }
//        bitmat_print(" [5] Mi == ", Mi, n);
        for (ulong k=j+1; k<n; ++k)  if ( vGET(c, k) )  T[k] ^= T[j];
    }

    // 6 [Solve triangular system]:
    ulong *X = T;
    ulong i = n;
    do
    {
        --i;
        // X[i] = T[i];
        ulong v = 0;
        for (ulong j=i+1; j<n; ++j)  if ( mGET(Mi, i, j) )  v ^= X[j];
        X[i] ^= v;
    }
    while ( i );

    for (ulong k=0; k<n; ++k)  Mi[k] = X[k];
    return  1;
}
// -------------------------
