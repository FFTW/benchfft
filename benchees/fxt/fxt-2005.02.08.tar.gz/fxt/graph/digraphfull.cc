
#include "graph/digraph.h"

#include "fxttypes.h"
//#include "jjassert.h"


digraph
make_full_digraph(ulong n)
// Initialization for the full graph.
{
    ulong ng = n, ne = n*(n-1);

    ulong *ep, *e;
    digraph dg(ng, ne, ep, e);

    ulong j = 0;
    for (ulong k=0; k<ng; ++k)  // for all nodes
    {
        ep[k] = j;
        for (ulong i=0; i<n; ++i)  // connect to all nodes
        {
            if ( k==i )  continue;  // no loops
            e[j++] = i;
        }
    }
    ep[ng] = j;
//    jjassert( j<=ne );

    return  dg;
}
// -------------------------

