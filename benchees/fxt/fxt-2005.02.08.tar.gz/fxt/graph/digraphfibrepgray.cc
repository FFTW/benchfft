
#include "graph/digraph.h"

#include "comb/fibrep.h"  // bin2fibrep()
#include "bits/bit2pow.h"  // one_bit_q()
#include "aux1/copy.h"  // copy()

//#include "jjassert.h"

#include "fxttypes.h"


digraph
make_fibrepgray_digraph(ulong n)
{
    ulong *f = new ulong[n];
    for (ulong k=0; k<n; ++k)  f[k] = bin2fibrep(k);

    ulong nc = 0;
    for (ulong k=0; k<n; ++k)
    {
        ulong fk = f[k];
        for (ulong j=0; j<n; ++j)
        {
            if ( j==k )  continue;
            ulong fj = f[j];
            if ( one_bit_q( fj^fk ) )  ++nc;
        }
    }

    ulong *c = new ulong[nc];
    ulong *cp = new ulong[n+1];
    nc = 0;
    for (ulong k=0; k<n; ++k)
    {
        cp[k] = nc;
        ulong fk = f[k];
        for (ulong j=0; j<n; ++j)
        {
            if ( j==k )  continue;
            ulong fj = f[j];
            if ( one_bit_q( fj^fk ) )  c[nc++] = j;
        }
    }
    cp[n] = nc;

//    digraph(ulong ng, ulong ne, ulong *&ep, ulong *&e, bool vnq=false)
    ulong *ep, *e;
    digraph dg(n, nc, ep, e, 1);

    copy(f, dg.vn_, n);
    copy(c, dg.e_, nc);
    copy(cp, dg.ep_, n+1);

    delete [] c;
    delete [] cp;
    delete [] f;

    return  dg;
}
// -------------------------
