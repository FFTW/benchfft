#if !defined  HAVE_DIGRAPHSPECIAL_H__
#define       HAVE_DIGRAPHSPECIAL_H__

#include "graph/digraphpaths.h"
#include "graph/digraph.h"
#include "fxttypes.h"

//: Auxiliary routines for special graphs

// graph/digraphfull.cc:
digraph make_full_digraph(ulong n);


// graph/digraphdebruijn.cc:
digraph make_debruijn_digraph(ulong n);
digraph make_complement_shift_digraph(ulong n);


// graph/digraphgray.cc:
digraph make_gray_digraph(ulong n, bool rq=0);
ulong start_monotonic_gray_path(digraph_paths &dp, ulong n);


// graph/digraphparengray.cc:
digraph make_parengray_digraph(ulong nb, ulong pcd);

// graph/digraphfibrepgray.cc:
digraph make_fibrepgray_digraph(ulong n);


// graph/digraphmtl.cc:
digraph make_mtl_digraph(ulong k, bool rq=0);


// graph/digraphlyndongray.cc:

class lyngray_dat
// Data needed for Gray paths through Lyndon words.
{
public:
    ulong *ww;  // Lyndon words (==sv[] in digraph)
    uchar *rr;  // rotations of Lyndon word in Gray path
    uchar *dd;  // delta sequence of Gray path
    ulong nbits;  // number of bits of Lyndon words

public:
    lyngray_dat(ulong ng, ulong nb, ulong *tww);
    ~lyngray_dat();

    ulong get(ulong *&w, uchar *&r, uchar *&d)
    { w = ww; r = rr; d = dd; return  nbits; }
};
// -------------------------

void print_lyndon_gray_digraph(digraph &dg, lyngray_dat *ldat);
bool lyndon_gray_rot_delta(const ulong *rv, ulong ng, lyngray_dat *ldat);
void print_lyndon_gray_path(digraph_paths &dp, lyngray_dat *ldat);
digraph make_lyndon_gray_digraph(ulong n, lyngray_dat *&ldat, ulong rot0q=0);

// graph/lyndoncmp.cc:
int lyndon_cmp0(const ulong &a, const ulong &b);
int lyndon_cmp1(const ulong &a, const ulong &b);
int lyndon_cmp2(const ulong &a, const ulong &b);
int lyndon_cmp3(const ulong &a, const ulong &b);
int lyndon_cmp4(const ulong &a, const ulong &b);
int lyndon_cmp5(const ulong &a, const ulong &b);
int lyndon_cmp6(const ulong &a, const ulong &b);
int lyndon_cmp7(const ulong &a, const ulong &b);



#endif  // !defined HAVE_DIGRAPHSPECIAL_H__
