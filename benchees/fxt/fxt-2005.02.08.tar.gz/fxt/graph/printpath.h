#if !defined  HAVE_PRINTPATH_H__
#define       HAVE_PRINTPATH_H__

#include "fxttypes.h"

// graph/printpath.cc:
void print_path(const ulong *rv, ulong ng);
void print_bin_path(const ulong *rv, ulong ng, ulong ngbits);
void print_bin_horiz_path(const ulong *rv, ulong ng, ulong ngbits, const char *c01=0);


#endif  // !defined HAVE_PRINTPATH_H__
