#if !defined HAVE_MIXEDRADIX_GRAY_H__
#define      HAVE_MIXEDRADIX_GRAY_H__

#include "fxttypes.h"


class mixedradix_gray
// Gray code for mixed radix numbers
// Implementation following Knuth
{
public:
    ulong n_;  // number of digits
    ulong j_;  // aux pointer
    ulong *a_;  // digits
    ulong *m1_; // radix minus one ('nines')
    ulong *f_;  // focus pointer
    ulong *d_;  // direction
    int dm_;  // direction of last move

public:
    mixedradix_gray(const ulong *m, ulong n, ulong mm=0)
        : n_(n)
    {
        a_ = new ulong[4*n_+1];
        m1_ = a_ + n_;
        d_ = m1_ + n_;  // m1_[j] == m[j] - 1 in Knuth
        f_ = d_ + n_;   // n_ + 1 elements

        // if mm given it is used as radix for all digits:
        if ( 0==mm )  for (ulong k=0; k<n_; ++k)  m1_[k] = m[k] - 1;
        else          for (ulong k=0; k<n_; ++k)  m1_[k] = mm - 1;

        first();
    }

    ~mixedradix_gray()  { delete [] a_; }

    const ulong *data()  const  { return a_; }


    void first()
    {
        for (ulong k=0; k<n_; ++k)  a_[k] = 0;
        for (ulong k=0; k<n_; ++k)  d_[k] = 1;
        for (ulong k=0; k<=n_; ++k)  f_[k] = k;
        dm_ = 0;
        j_ = n_;
    }

    bool next()
    {
        j_ = f_[0];
        f_[0] = 0;

        if ( j_>=n_ )  { first(); return 0; }
        a_[j_] += d_[j_];
        dm_ = (int)d_[j_];

        ulong aj = a_[j_];
        if ( (0==aj) || (aj==m1_[j_]) )
        {
            d_[j_] = -d_[j_];
            f_[j_] = f_[j_+1];
            f_[j_+1] = j_ + 1;
        }

        return 1;
    }

    ulong pos()  const  { return j_; }  // position of last change
    int dir()  const  { return dm_; }
};
// -------------------------


#endif  // !defined HAVE_MIXEDRADIX_GRAY_H__
