
#include "comb/composition-rank.h"

#include "fxtiomanip.h"
#include "fxttypes.h"


void
composition_rank::print(const ulong *x, ulong k)  const
{
    print_x(x, k);
    print_set(x, k);
}
// -------------------------

void
composition_rank::print_x(const ulong *x, ulong k)  const
{
    cout << "   ";
    cout << "x[  ";
    for (ulong j=0; j<k; ++j)
    {
        ulong xj = x[j];
        if ( xj )  cout << xj;  else cout << '.';
        cout << "  ";
    }
    cout << "]";
}
// -------------------------

void
composition_rank::print_set(const ulong *x, ulong k)  const
{
    cout << "    ";
    cout << "b[  ";
    for (ulong j=0; j<k; ++j)
    {
        ulong xj = x[j];
        while ( xj-- )  cout << "1 ";
        if ( j<k-1 )  cout << ". ";
    }
    cout << " ]";
}
// -------------------------

void
composition_rank::print_nset(const ulong *x, ulong k)  const
{
    cout << "    ";
    cout << "n[  ";
    for (ulong j=0,z=0; j<k; ++j)
    {
        ulong xj = x[j];
        while ( xj-- )  cout << (z++) << " ";
        if ( j<k-1 )  cout << ". ";
    }
    cout << " ]";
}
// -------------------------


//void
//composition_rank::print_digits(ulong k)  const
//{
//    cout << "    ";
//    cout << "d[";
//    for (ulong j=1; j<=k; ++j)
//    {
//        cout << setw(2) << d_[j];
//        if ( j<k )  cout << ", ";
//    }
//    cout << " ]";
//}
//// -------------------------

