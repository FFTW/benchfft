#if !defined  HAVE_SUBSET_DEBRUIJN_H__
#define       HAVE_SUBSET_DEBRUIJN_H__


#include "fxttypes.h"
#include "comb/debruijn.h"
#include "aux1/shift.h"


class subset_debruijn : public debruijn
// Subsets of the set {0,1,2,...,n-1} in an order
// determined by a De Bruijn sequence.
{
protected:
    ulong *x;   // subset as delta set
    ulong el_;  // new element to be shifted in
    ulong num_; // number of elements in subset

public:
    subset_debruijn(ulong nn)
        : debruijn(2, nn)
    {
        x = new ulong[nmax_];
        init();
    }

    ~subset_debruijn()  { delete [] x; }


    void init(ulong nn=0)
    {
        if ( 0!=nn )  n_ = nn;
        fill(x, nmax_, 1UL);  // sequence end = 1111
        num_ = n_;

//        el_ = 0;
        debruijn::init(2, n_);  // use binary shift register sequence

//        // forward to empty set:
//        while ( next() )  { ; }
    }


    ulong next()  // return  numbert of elements
    {
        el_ = debruijn::next();
        sync_x();
        return  num_;
    }

    const ulong * data()  const  { return x; }


protected:
    void sync_x()
    {
        num_ -= x[n_-1];
        shift_right(x, n_, 1);
        x[0] = el_;
        num_ += el_;
    }

private:
    int done()  const;  // forbidden (exists in base class)
};
// -------------------------



#endif  // !defined HAVE_SUBSET_DEBRUIJN_H__
