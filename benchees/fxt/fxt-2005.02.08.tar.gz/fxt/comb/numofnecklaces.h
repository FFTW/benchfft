#if !defined  HAVE_NUMOFNECKLACES_H__
#define       HAVE_NUMOFNECKLACES_H__

#include "fxttypes.h"
//#include "bits/bitsperlong.h"

// comb/numofnecklaces.cc:

//: num_necklaces_tab[n] == number of binary n-bit necklaces
extern const ulong num_necklaces_tab[/*0,...,BITS_PER_LONG*/];

//: num_lyndon_tab[n] == number of binary n-bit Lyndon words
extern const ulong num_lyndon_tab[/*0,...,BITS_PER_LONG*/];


#endif  // !defined HAVE_NUMOFNECKLACES_H__
