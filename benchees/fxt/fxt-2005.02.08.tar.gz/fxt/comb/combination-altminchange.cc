
#include "fxttypes.h"
#include "fxtiomanip.h"

#include "comb/combination-altminchange.h"


std::ostream & operator << (std::ostream &os, const combination_altminchange &x)
{
    os << setw(2) << x.x_[0];
    for (ulong i=1; i<x.k_; ++i)
    {
        os << " " << setw(2) << x.x_[i];
    }
    return os;
}
// -------------------------
