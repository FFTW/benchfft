#if !defined  HAVE_COMBINATION_REVDOOR_H__
#define       HAVE_COMBINATION_REVDOOR_H__


#include "fxttypes.h"
//#include "jjassert.h"


class combination_revdoor
// Combinations (n choose k) in minimal-change order.
//.
// "Revolving door" algorithm following Knuth (ascribed to W.H.Payne)
{
public:
    ulong n_;  // (n choose k)  n>=1
    ulong k_;  // 1<=k<=n
    ulong *c_; // data

public:
    combination_revdoor(ulong n, ulong k)
    {
        n_ = (n ? n : 1);
        k_ = k;
        if ( k>n_ )  k=n;
        else { if ( k==0 )  k=n; }

        c_ = new ulong[n_+1];
        init();
    }

    ~combination_revdoor()  { delete [] c_; }

    void init()
    {
        for (ulong j=0; j<k_; ++j)  c_[j] = j;
        c_[k_] = n_;
    }

    const ulong* get()  const  { return c_; }

    bool next()
    {
        ulong j = 1;
        // R3: [Easy case?]
        if ( k_ & 1 )  // odd k (try to increase)
        {
            ulong c = c_[0] + 1;
            if ( c<c_[1] )  { c_[0] = c;  return true; }
            else goto R4;
        }
        else  // even k (try to decrease)
        {
            ulong c = c_[0];
            if ( c )  { c_[0] = c-1;  return true; }
            else goto R5;
        }

    R4:  // R4: [Try to decrease]
        if ( j==k_ )  return false;

//        jjassert( c_[j] == c_[j-1]+1 );
        if ( c_[j] > j )
        {
            c_[j] = c_[j-1];
            c_[j-1] = j-1;
            return true;
        }
        ++j;

    R5:  // R5: [Try to increase]
        if ( j==k_ )  return false;

//        jjassert( c_[j-1] == j-1 );
        {
            ulong c = c_[j] + 1;
            if ( c < c_[j+1] )
            {
                c_[j-1] = c - 1;
                c_[j] = c;
                return true;
            }
        }
        ++j;
        goto R4;
    }
};
// -------------------------


#endif  // !defined HAVE_COMBINATION_REVDOOR_H__
