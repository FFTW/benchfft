#if !defined  HAVE_BINARYPRIMESTRING_H__
#define       HAVE_BINARYPRIMESTRING_H__


#include "fxttypes.h"
#include "bits/bitsperlong.h"
#include "aux1/copy.h"


class binary_prime_string
// (pre-) prime string for the special case m==2
// Specialization of routine given by Knuth
{
public:
    ulong *a_;
    ulong n_;
    ulong j_;
    ulong nmax_;

public:
    binary_prime_string(ulong n)
    {
        nmax_ = BITS_PER_LONG;
        a_ = new ulong[nmax_+1];
        init(n);
    }

    ~binary_prime_string()  { delete [] a_; }

    void init(ulong n=0)
    {
        if ( 0!=n )  n_ = n;
        null(a_, nmax_+1);
        j_ = 1;
    }

    const ulong * data() const { return  a_ + 1; }

    ulong current() const { return j_; }

    ulong next()  // return j (zero when finished)
    {
        // F3: // prepare to increase
        j_ = n_;
        if ( 0!=a_[j_] )  do  { --j_; }  while ( 0!=a_[j_] );

        // F4: // add one
        if ( 0==j_ )  { init(n_);  return 0; }
        a_[j_] = 1;

        // F5: make n-extension
        for (ulong k=j_+1; k<=n_; ++k)  a_[k] = a_[k-j_];

        return  j_;
    }
};
// -------------------------


#endif  // !defined HAVE_BINARYPRIMESTRING_H__
