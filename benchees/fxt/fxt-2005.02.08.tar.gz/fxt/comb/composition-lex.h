#if !defined HAVE_COMPOSITION_LEX_H__
#define      HAVE_COMPOSITION_LEX_H__


#include "fxttypes.h"


class composition_lex
// k-compositions of n, (reversed) lex order
{
public:
    ulong n_, k_;  // n is the sum of k elements
    ulong *x_;  // data

public:
    composition_lex(ulong n, ulong k)
    {
        n_ = (n ? n : 1);  // not zero
        k_ = (k ? k : 1);  // not zero
        x_ = new ulong[k_];
        first();
    }

    ~composition_lex()  { delete [] x_; }

    const ulong *data()  const  { return x_; }

    void first()
    {
        x_[0] = n_;
        for (ulong k=1; k<k_; ++k)  x_[k] = 0;
    }

    void last()
    {
        for (ulong k=0; k<k_; ++k)  x_[k] = 0;
        x_[k_-1] = n_;
    }

    ulong next()
    // Nijenhuis, Wilf
    {
        // return zero if current comp. is last:
        if ( n_==x_[k_-1] )  return 0;

        ulong j = 0;
        while ( 0==x_[j] )  ++j;
        ulong v = x_[j];  // first nonzero
        x_[j] = 0;
        x_[0] = v - 1;
        ++x_[j+1];

        return  1;
    }

    ulong prev()
    {
        // return zero if current comp. is first:
        if ( n_==x_[0] )  return 0;

        ulong v0 = x_[0];
        x_[0] = 0;
        ulong j = 1;
        while ( 0==x_[j] )  ++j;
        --x_[j];
        x_[j-1] = 1 + v0;

        return  1;
    }
};
// -------------------------

#endif  // !defined HAVE_COMPOSITION_LEX_H__
