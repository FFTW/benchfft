#if !defined  HAVE_GRAY_H__
#define       HAVE_GRAY_H__

#include "fxttypes.h"

// comb/testgray.cc:
ulong test_gray_path(const ulong *f, ulong n);
bool is_gray_path(const ulong *f, ulong n);
ulong test_canonical_gray(const ulong *f, ulong n);
bool is_canonical_gray(const ulong *f, ulong n);
bool is_monotonic_gray(const ulong *f, ulong n);
bool is_complementary_gray(const ulong *rv, ulong ng);

// comb/printgray.cc:
void print_gray(const ulong *f, ulong n);
void print_gray_delta(const ulong *f, ulong n, ulong lb=0);

// comb/delta2gray.cc:
void delta2gray(const unsigned char *d, ulong ldn, ulong *g, ulong g0=0);
void gray2delta(ulong ldn, const ulong *g, unsigned char *d);

// comb/monotonicgray.cc:
void monotonic_gray_delta(unsigned char *d, ulong ldn);
void monotonic_gray(ulong *g, ulong ldn);

// comb/acgray.cc:
void ac_gray_delta(uchar *d, ulong ldn);
ulong test_ac_gray(ulong *g, ulong n);
void ac_gray(ulong *g, ulong ldn);


#endif  // !defined HAVE_GRAY_H__
