
#include "comb/catalan.h"

#include "fxtio.h"
#include "fxttypes.h"


int
catalan::next_rec(ulong k)
{
    if ( k<1 )  return 0;  // current is last

    int d = d_[k];
    int as = as_[k] + d;
    bool ovq = ( (d>0) ? (as>as_[k-1]+1) : (as<0) );
    if ( ovq )  // have to recurse
    {
        ulong ns1 = next_rec(k-1);
        if ( 0==ns1 )  return 0;

        d = ( xdr_ ? -d : dr0_ );
        d_[k] = d;

        as = ( (d>0) ? 0 : as_[k-1]+1 );
    }
    as_[k] = as;

    return 1;
}
// -------------------------


void
catalan::print_internal()  const
{
    cout << "as[ ";
    for (ulong j=0; j<n_; ++j)  cout << as_[j] << ", ";
    cout << "]";
    cout << "    ";
    cout << "d[ ";
    for (ulong j=0; j<n_; ++j)  cout << (d_[j]>0 ? '+' : '-') << ", ";
    cout << "]";
}
// -------------------------

