#if !defined  HAVE_DEBRUIJN_H__
#define       HAVE_DEBRUIJN_H__


#include "fxttypes.h"
#include "comb/primestring.h"
#include "bits/tinyfactors.h"


class debruijn : public prime_string
// (lex minimal) De Bruijn sequence
// Implementation following Knuth
{
public:
    ulong nt_, k_;
    ulong dq_;
    ulong tfb_; // tiny factor bits

public:
    debruijn(ulong m, ulong n)
        : prime_string(m, n)
    {
        init(m, n);
    }

    ~debruijn()  { ; }

    void init(ulong m=0, ulong n=0)
    {
        prime_string::init(m, n);
        nt_ = 1;
        k_ = 0;
        dq_ = 0;
        tfb_ = tiny_factors_tab[n_];
    }

    int done()  const  { return  dq_; }

    ulong next()  // return new element (\in 0..m-1)
    {
        if ( 0==nt_ )  next_string();

        --nt_;
        ++k_;
        return  a_[ k_ ];
    }

    void next_string()  // make new string
    {
        do
        {
            prime_string::next();
            if ( 0==j_ )  { dq_ = 1; return; }
        }
//        while ( (n_/j_)*j_ != n_ );  // slow
//        while ( ! is_tiny_factor(n_, j_) );  // faster
        while ( 0 == ( (tfb_>>j_) & 1 ) );  // fastest

        nt_ = j_;
        k_ = 0;
    }

    void make_seq(ulong *f, ulong n)
    {
        init();
        for (ulong k=0; k<n; ++k)  f[k] = next();
    }
};
// -------------------------


#endif  // !defined HAVE_DEBRUIJN_H__
