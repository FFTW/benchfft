#if !defined  HAVE_BINARYDEBRUIJN_H__
#define       HAVE_BINARYDEBRUIJN_H__


#include "fxttypes.h"
#include "comb/binaryprimestring.h"
#include "bits/tinyfactors.h"


class binary_debruijn : public binary_prime_string
// binary De Bruijn sequence
{
public:
    ulong nt_, k_;
    ulong dq_;
    ulong tfb_; // tiny factor bits

public:
    binary_debruijn(ulong n)
        : binary_prime_string(n)
    { init(n); }

    ~binary_debruijn()  { ; }

    void init(ulong n=0)
    {
        binary_prime_string::init(n);
        nt_ = 1;
        k_ = 0;
        dq_ = 0;
        tfb_ = tiny_factors_tab[n_];
    }

    int done()  const  { return  dq_; }

    ulong next_bit()  // return new element (0 or 1)
    {
        if ( 0==nt_ )  next_string();
        --nt_;
        ++k_;
        return  a_[ k_ ];
    }

    void next_string()  // make new string
    {
        do
        {
            binary_prime_string::next();
            if ( 0==j_ )  { dq_ = 1; return; }
        }
        while ( 0 == ( (tfb_>>j_) & 1 ) );  // fastest

        nt_ = j_;
        k_ = 0;
    }

    ulong word()  const
    {
        ulong t = 0;
        ulong ib = 1UL << (n_ - 1);
        for (ulong i=1;  i<=n_;  ++i, ib>>=1)  if ( a_[i] )  t |= ib;
        return t;
    }

    void make_seq(ulong *f, ulong n)
    {
        init();
        for (ulong k=0; k<n; ++k)  f[k] = next_bit();
    }

    ulong next_bit_into_word(ulong x)
    {
        x = ( (x<<1) & (n_-1) );
        x |= next_bit();
        return  x;
    }
};
// -------------------------


#endif  // !defined HAVE_BINARYDEBRUIJN_H__
