#if !defined HAVE_COMPOSITION_RANK_H__
#define      HAVE_COMPOSITION_RANK_H__


#include "comb/numof-compositions.h"

#include "fxttypes.h"
//#include "jjassert.h"
//#include "aux0/binomial.h"



class composition_rank : public numof_compositions
// Ranking and unranking compositions in
//   lexicographic-- minimal-change-- or near-perfect order.
// Note: the near-perfect order is in general
//       _not_ identical to Chase's sequence.
// The routines rank_*(x,n,k) have complexity k*k.
// The routines unrank_*(x,n,k) have complexity k * X
//   where X is the complexity of unrank_get_xk();
//   X=n as given but can be reduced to log(n).
{
public:
//    ulong *d_;  // record of 'digits' in unranking (optional)

public:
    composition_rank(ulong n, ulong k)
        : numof_compositions(n, k)
    {
//        d_ = new ulong[k_+1];
//        d_[0] = 0;
//        d_[1] = 0;
    }

    ~composition_rank()
    {
//        delete [] d_;
    }


    bool is_comp(const ulong *x, ulong n, ulong k)  const
    // Return whether x contains a k-composition of n
    {
        ulong s = 0;
        for (ulong j=0; j<k; ++j)  s += x[j];
        return  (s==n);
    }

    ulong rank_lex(const ulong *x, ulong n, ulong k)  const
    // Return rank of k-composition of n for lex order
    //  0 <= rank < binomial(n+k-1, n)
    {
        if ( 1==k )  return 0;
        ulong r = 0;
        ulong xk = x[k-1];
        for (ulong j=1; j<=xk; ++j)  r += num_comp(n+1-j, k-1);
        r += rank_lex(x, n-xk, k-1);  // recurse
        return r;
    }


    ulong rank_gray(const ulong *x, ulong n, ulong k)  const
    // Return rank of k-composition of n for minimal-change order
    //  0 <= rank < binomial(n+k-1, n)
    {
        if ( 1==k )  return 0;
        ulong r = 0;
        ulong xk = x[k-1];
        for (ulong j=1; j<=xk; ++j)  r += num_comp(n+1-j, k-1);
        // recurse:
        ulong ri = rank_gray(x, n-xk, k-1);
        if ( xk&1 )  r += num_comp(n-xk, k-1)-1 - ri;
        else         r += ri;
        return r;
    }

    ulong rank_nearperfect_rev(const ulong *x, ulong n, ulong k)  const
    // Return rank of k-composition of n for reversed near-perfect order
    //  0 <= rank < binomial(n+k-1, n)
    {
        if ( 1==k )  return 0;
        ulong r = 0;
        ulong xk = x[k-1];
        for (ulong j=1; j<=xk; ++j)  r += num_comp(n+1-j, k-1);
        // recurse:
        ulong ri = rank_nearperfect_rev(x, n-xk, k-1);
        if ( !(xk&1) )  r += num_comp(n-xk, k-1)-1 - ri;
        else            r += ri;
        return  r;
    }

    ulong rank_nearperfect(const ulong *x, ulong n, ulong k)  const
    // Return rank of k-composition of n for near-perfect order
    //  0 <= rank < binomial(n+k-1, n)
    {
        return  num_comp(n,k) - 1 - rank_nearperfect_rev(x,n,k);
    }


    ulong unrank_get_xk(ulong n, ulong k, ulong &r)  const
    // Get element k of the rank-r k-composition of n
    // Rank r is modified.
    // Must have:  r < binomial(n+k-1,n)
    // Used in all unranking routines.
    // Complexity is n, could be reduced to log(n)
    //   via cumulative values and binary search.
    {
        if ( 1==k )  { r=0; return n; }
        ulong nc = num_comp(n, k);
//        jjassert( r<nc );  // else out of range
        ulong xk;
        for (xk=0; xk<=n; ++xk)
        {
            nc = num_comp(n-xk, k-1);
            if ( nc > r )   break;
            r -= nc;
        }

//        jjassert( xk<=n );  // else internal error
        return  xk;  // unreached
    }

    void unrank_lex(ulong *x, ulong n, ulong k, ulong r)  const
    // Write the lex order rank-r k-composition of n into x[]
    // Must have:  r < binomial(n+k-1,n)
    {
        ulong j = k;
        while ( j-- )
        {
//            d_[j+1] = r;
            ulong xj = unrank_get_xk(n, j+1, r);  // r modified
            x[j] = xj;
            n -= xj;
        }
    }

    void unrank_gray(ulong *x, ulong n, ulong k, ulong r)  const
    // Write the minimal-change order rank-r k-composition of n into x[]
    // Must have:  r < binomial(n+k-1,n)
    {
        for (ulong j=k-1; j!=0; --j)
        {
//            d_[j+1] = r;
            ulong xj = unrank_get_xk(n, j+1, r);  // r modified
            if ( xj & 1 )  r = num_comp(n-xj, j) -1 -r;
            x[j] = xj;
            n -= xj;
        }
        x[0] = n;
    }

    void unrank_nearperfect(ulong *x, ulong n, ulong k, ulong r)  const
    // Write the near-perfect order rank-r k-composition of n into x[]
    // Must have:  r < binomial(n+k-1,n)
    {
        r = num_comp(n,k) -1 -r;
        for (ulong j=k-1; j!=0; --j)
        {
//            d_[j+1] = r;
            ulong xj = unrank_get_xk(n, j+1, r);  // r modified
            if ( !(xj & 1) )  r = num_comp(n-xj, j) -1 -r;
            x[j] = xj;
            n -= xj;
        }
        x[0] = n;
    }

    void print(const ulong *x, ulong k)  const;
    void print_x(const ulong *x, ulong k)  const;
    void print_set(const ulong *x, ulong k)  const;
    void print_nset(const ulong *x, ulong k)  const;
    void print_digits(ulong k)  const;  // of last unrank
};
// -------------------------


#endif  // !defined HAVE_COMPOSITION_RANK_H__
