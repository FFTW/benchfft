#if !defined HAVE_SUBSET_GRAY_DELTA_H__
#define      HAVE_SUBSET_GRAY_DELTA_H__


#include "bits/bitlow.h"
//#include "bits/bitsperlong.h"
#include "fxttypes.h"

class subset_gray_delta
// Subsets of the set {0,1,2,...,n-1} in minimal-change (Gray code) order
{
public:
    ulong *x_;  // current subset as delta-set
    ulong n_;   // number of elements in set <= BITS_PER_LONG
    ulong k_;   // number of elements in current subset
    ulong ch_;  // element that was changed with latest call to next()
    ulong ct_;  // gray_code(ct_) corresponds to the current subset
    ulong mct_; // max value of ct.

public:
    subset_gray_delta(ulong nn)
    {
        n_ = (nn ? nn : 1);  // not zero
        x_ = new ulong[n_];
        mct_ = (1UL<<nn) - 1;
        empty();
    }

    ~subset_gray_delta()  { delete [] x_; }


    ulong empty()
    {
        ct_ = 0;
        k_ = 0;
        ch_ = n_ - 1;
        for (ulong j=0; j<n_; ++j)  x_[j] = 0;
        return  k_;
    }

    const ulong * data() const { return x_; }
    ulong current()  const  { return ct_; }
    ulong num()  const  { return k_; }

    ulong next()
    {
        if ( ct_ == mct_ )
        {
            ct_ = 0;
            x_[n_-1] = 0;
            ch_ = n_ - 1;
            return 0;
        }

        ++ct_;
        ch_ = lowest_bit_idx( ct_ );
        x_[ch_] = 1 - x_[ch_];
        k_ += (x_[ch_] ? 1 : -1);
        return  k_;
    }

    ulong prev()
    {
        if ( ct_ == 0 )
        {
            ct_ = mct_;
            k_ = 1;
            x_[n_-1] = 1;
            ch_ = n_ - 1;
            return 1;
        }

        ch_ = lowest_bit_idx( ct_ );
        x_[ch_] = 1 - x_[ch_];
        k_ += (x_[ch_] ? +1 : -1);
        --ct_;
        return  k_;
    }
};
// -------------------------



#endif  // !defined HAVE_SUBSET_GRAY_DELTA_H__
