#if !defined  HAVE_PRIMESTRING_H__
#define       HAVE_PRIMESTRING_H__


#include "fxttypes.h"
#include "bits/bitsperlong.h"
#include "aux1/copy.h"


class prime_string
// (pre-) prime strings
// implementation following Knuth
{
public:
    ulong *a_;
    ulong n_;
    ulong m_, m1_;
    ulong j_;
    ulong nmax_;

public:
    prime_string(ulong m, ulong n)
    {
        nmax_ = BITS_PER_LONG;
        a_ = new ulong[nmax_+1];
        if ( 0==n )  n = 1;
        if ( m<2 )  m = 2;
        init(m, n);
    }

    ~prime_string()  { delete [] a_; }

    void init(ulong m=0, ulong n=0)
    {
        if ( 0!=m )  m_ = m;
        if ( 0!=n )  n_ = n;
        m1_ = m_ - 1;
        null(a_, nmax_+1);
        j_ = 1;
    }

    const ulong * data() const { return  a_ + 1; }

    ulong current() const { return j_; }

    ulong next()  // return j (zero when finished)
    {
        // F3: // prepare to increase
        j_ = n_;
        if ( a_[j_] == m1_ )  do  { --j_; }  while ( a_[j_] >= m1_ );

        // F4: // add one
        if ( 0==j_ )  { init(m_, n_);  return 0; }
        ++a_[j_];

        // F5: make n-extension
        for (ulong k=j_+1; k<=n_; ++k)  a_[k] = a_[k-j_];

        return  j_;
    }
};
// -------------------------


#endif  // !defined HAVE_PRIMESTRING_H__
