#if !defined HAVE_COMP2COMB_H__
#define      HAVE_COMP2COMB_H__

#include "perm/reverse.h"
#include "fxttypes.h"

//: Conversion between combinations and compositions

// A k-composition of n corresponds to
// a combination of K=n parts from N=n+k-1 elements:
//   C(n, k)  <-->  (n+k-1 choose n)
//
// A combination of K elements out of N
// corresponds to a k-composition of n where
// k=N-K+1 and n=K:
//   (N choose K)  <-->  C(K, N-K+1)

inline void
comp2comb(const ulong *c, ulong k, ulong *m)
// Convert k-composition in c[] to combination in m[]
{
    for (ulong j=0,i=0,z=0; j<k; ++j)
    {
        ulong cj = c[j];
        for (ulong w=0; w<cj; ++w)   m[i++] = z++;
        ++z;
    }
}
// -------------------------

inline void
comb2comp(const ulong *m, ulong N, ulong K, ulong *c)
// Convert combination (N choose K) in m[] to k-composition in c[]
// Must have: K>0
{
    ulong k = N-K+1;
    for (ulong z=0; z<k; ++z)  c[z] = 0;
    --k;
    ulong m1 = N;
    while ( K-- )
    {
        ulong m0 = m[K];
        ulong d = m1 - m0;
        k -= (d-1);
        ++c[k];
        m1 = m0;
    }
}
// -------------------------

inline void
reverse_combination(ulong *m, ulong N, ulong K)
// Reverse order and complement values in combination m[]
// Equivalent to order reversion of the corresponding composition:
//   M <--> C  ==>  reverse_combination(M) <--> reverse(C)
{
    for (ulong z=0; z<K; ++z)  m[z] = N-1-m[z];
    reverse(m, K);
}
// -------------------------


#endif  // !defined HAVE_COMP2COMB_H__
