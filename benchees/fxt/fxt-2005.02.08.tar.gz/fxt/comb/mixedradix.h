#if !defined HAVE_MIXEDRADIX_H__
#define      HAVE_MIXEDRADIX_H__

#include "fxttypes.h"


class mixedradix
// Mixed radix counting sequence
{
public:
    ulong n_;
    ulong *a_;
    ulong *m1_;

public:
    mixedradix(const ulong *m, ulong n, ulong mm=0)
        : n_(n)
    {
        a_ = new ulong[2*n_];
        m1_ = a_ + n_;

        // if mm given it is used as radix for all digits:
        if ( 0==mm )  for (ulong k=0; k<n_; ++k)  m1_[k] = m[k] - 1;
        else          for (ulong k=0; k<n_; ++k)  m1_[k] = mm - 1;

        first();
    }

    ~mixedradix()  { delete [] a_; }

    const ulong *data()  const  { return a_; }

    void first()
    {
        for (ulong k=0; k<n_; ++k)  a_[k] = 0;
    }

    void last()
    {
        for (ulong k=0; k<n_; ++k)  a_[k] = m1_[k];
    }


    bool next()
    {
        ulong c = 1;
        ulong j;
        for (j=0;  (0!=c) && (j<n_);  ++j)
        {
            ulong aj = a_[j] + 1;
            c = 0;
            if ( aj>m1_[j] )  { c = 1; aj = 0; }
            a_[j] = aj;
        }

        return  (c==0);
    }

    bool prev()
    {
        ulong c = 1;
        long j;
        for (j=n_-1;  (0!=c) && (j>=0);  --j)
        {
            ulong aj = a_[j];
            c = 0;
            if ( aj==0 )  { c = 1; aj = m1_[j]; }
            else            --aj;
            a_[j] = aj;
        }

        return  (c==0);
    }
};
// -------------------------


#endif  // !defined HAVE_MIXEDRADIX_H__
