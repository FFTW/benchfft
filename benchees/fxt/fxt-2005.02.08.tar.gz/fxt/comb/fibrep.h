#if !defined  HAVE_FIBREP_H__
#define       HAVE_FIBREP_H__

#include "fxttypes.h"


inline ulong fibonacci(ulong n)
// Return the n-th Fibonacci number
// Limitation:  F(n) must fit into ulong
// 32 bit:  n<=47, F(47)=2971215073 [F(48)=4807526976 > 2^32]
// 64 bit:  n<=93  F(93)=12200160415121876738 [F(94) > 2^64]
//
{
    if ( n<=1 )  return n;
    ulong f0=0, f1=1;
    for (ulong k=1; k<n; ++k)  { ulong t=f0+f1;  f0=f1;  f1=t; }
    return f1;
}
// -------------------------

inline ulong bin2fibrep(ulong b)
// Return Fibonacci representation of b
// Limitation: the first Fibonacci number greater
//  than b must be representable as ulong.
// 32 bit:  b < 2971215073=F(47) [F(48)=4807526976 > 2^32]
// 64 bit:  b < 12200160415121876738=F(93) [F(94) > 2^64]
{
    ulong f0=1, f1=1, s=1;
    while ( f1<=b )  { ulong t = f0+f1;  f0=f1;  f1=t;  s<<=1; }
    ulong f = 0;
    while ( b )
    {
        s >>= 1;
        if ( b>=f0 )  { b -= f0;  f^=s; }
        { ulong t = f1-f0;  f1=f0;  f0=t; }
    }
    return f;
}
// -------------------------

inline ulong fibrep2bin(ulong f)
// Return binary representation of f
// Inverse of bin2fibrep().
{
    ulong f0=1, f1=1;
    ulong b = 0;
    while ( f )
    {
        if ( f&1 )   b += f1;
        { ulong t=f0+f1;  f0=f1;  f1=t; }
        f >>= 1;
    }
    return b;
}
// -------------------------

inline bool is_fibrep(ulong f)
// Return whether f is a valid Fibonacci representation
// i.e. whether it does not contain two adjacent bits
{
    return  ( 0==(f&(f>>1)) );
}
// -------------------------


#endif  // !defined HAVE_FIBREP_H__
