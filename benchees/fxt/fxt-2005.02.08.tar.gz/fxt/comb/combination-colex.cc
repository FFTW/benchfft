
#include "fxttypes.h"
#include "comb/combination-colex.h"

#include "fxtio.h"


std::ostream & operator << (std::ostream &os, const combination_colex &x)
{
    cout.width(2);
    os << x.x_[0];
    for (ulong i=1; i<x.k_; ++i)
    {
        os << " ";
        cout.width(2);
        cout << x.x_[i];
    }
    return os;
}
// -------------------------

