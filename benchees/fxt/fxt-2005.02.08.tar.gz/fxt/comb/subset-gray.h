#if !defined HAVE_SUBSET_GRAY_H__
#define      HAVE_SUBSET_GRAY_H__

#include "fxttypes.h"


class subset_gray
// Subsets of the set {1,2,...,n} in minimal-change (Gray code) order
// Algorithm following Jenkyns ("Loopless Gray Code Algorithms")
{
public:
    ulong *x_;  // data k-subset of {1,2,...,n} in x[1,...,k]
    ulong n_;   // subsets of n-set
    ulong k_;   // number of elements in subset

public:
    subset_gray(ulong n)
        : n_(n)
    {
        x_ = new ulong[n_+1];
        x_[0] = 0;
        empty();
    }

    ~subset_gray()  { delete [] x_; }

    ulong empty()  { k_ = 0;  return k_; }
    ulong first()  { x_[1] = n_;  k_ = 1;  return k_; }
    ulong last()  { x_[1] = 1;  k_ = 1;  return k_; }

    const ulong * data() const { return x_+1; }
    const ulong num() const { return k_; }

    ulong next_even()
    { // either remove or add n to the (end of the) set
        if ( x_[k_]==n_ )   --k_;
        else  { ++k_; x_[k_] = n_; }
        return  k_;
    }

    ulong next_odd()
    {  // either remove x[k]-1 (from position k-1) or insert it as second last element
        if ( x_[k_]-1==x_[k_-1] )   { x_[k_-1] = x_[k_];  --k_; }
        else  { x_[k_+1] = x_[k_];  --x_[k_];  ++k_; }
        return  k_;
    }

    ulong next()
    {
        if ( 0==(k_&1 ) ) return next_even();
        else              return next_odd();
    }

    ulong prev()
    {
        if ( 0==(k_&1 ) )  // k even
        {
            if ( 0==k_ )  return last();
            return next_odd();
        }
        else  return next_even();
    }
};
// -------------------------

#endif  // !defined HAVE_SUBSET_GRAY_H__

