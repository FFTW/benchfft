
#include "bpol/lhca.h"
#include "bpol/bitpolirred.h"
//#include "bpol/minweightlhcarule.cc"

#include "bpol/bitpolprimitive.h"  // test needs factorization
#include "bpol/gf2n.h"  // for factorization of mersenne numbers

#include "bits/printbin.h"

#include "jjassert.h"
#include "fxtiomanip.h"

#include "fxttypes.h"
#include "bits/bitsperlong.h"

#include <cstdlib>  // atol()

//% Convert LHCA rules to binary polynomials.

void
print_rules(ulong rr, ulong cc, ulong pn)
{
    print_bin_nn("  r=", rr, pn);
    print_bin_nn("  c=", cc, pn);
    print_idx_seq_nn("  r= ", rr);
//    print_idx_seq_nn("  c= ", cc);
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = BITS_PER_LONG - 1;
    if ( argc>1 )  n = atol(argv[1]);
    ulong pn  = n + 1;

    cout.width(pn);  cout << "LHCA rule";
    cout.width(pn);  cout << "polynomial";
    cout << endl;

    ulong h = 1;
    for (ulong k=1; k<=n; ++k)
    {
        GF2n::init(k);  // for factorization of Mersenne number
        cout.width(2);  cout << k << ":  ";

        ulong r = minweight_lhca_rule[k];

        ulong c = lhca2poly(r, k);
        print_rules(r, c, pn);

        jjassert( bitpol_irreducible_q(c, h) );
        jjassert( 0==test_bitpol_primitive(c, h, GF2n::mfact_) );

        h <<= 1;
    }

    return 0;
}
// -------------------------

