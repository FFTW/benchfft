
#include "bmat/bitmat.h"
#include "bits/bitnecklace.h"
#include "bpol/bitpol.h" // bitpol_gcd()

#include "bits/revbin.h"
#include "bits/bitcount.h"

#include "bits/bitrotate.h" // bit_rotate_left()
#include "bits/printbin.h" // print_bin()
#include "aux1/copy.h" // null()

#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"  // ulong

#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxtalloca.h"


//% Invertible circulant matrices over GF(2).
//% cf. A027362 and A003473 of the OEIS.


int
main(int argc, char **argv)
{
    ulong n = 6;
    NXARG(n, "  n x n - matrices");

    ulong wh = 2;
    NXARG(wh, "What to do: 0==>just count  1==>print words  2==>also print matrix");
    // 4==> also print nullspace

    ALLOCA(ulong, T, n);
    ALLOCA(ulong, M, n);
    null(M, n);
    null(T, n);

    ulong nct = 0;  // count invertible matrices
    ulong sct = 0;  // count singular matrices
    ulong cn = (1UL<<n)+1;
    bit_necklace bn(n);
    do
    {
        ulong v0 = bn.data();
        if ( 0==bn.is_lyndon_word() )  continue;
        if ( 0==(bit_count(v0) & 1) )  continue;
        v0 = revbin(v0, n);  // want minimum
        ulong v = v0;
        for (ulong j=0; j<n; ++j)
        {
            M[j] = v;
            v = bit_rotate_left(v, 1, n);
        }

        ulong nn = bitmat_nullspace(M, n, T);
        if ( 0==nn )  ++nct;
        else          ++sct;

        if ( wh<1 )  continue;  // just count

        print_binv_nn("v0 = ", v0, n);
        if ( 0==nn )  cout << "  I";
        else          cout << "  S";

        // check equivalence with gcd(v0, x^n-1):
        ulong gn = bitpol_gcd(v0, cn);  // gcd(L,x^n-1)
//        print_binv_nn("  gcd=",gn, n);  cout << " ";
        jjassert( ((nn)&&(gn!=1)) || ((0==nn)&&(gn==1)) );

        cout << endl;

        if ( wh<2 )  continue;  // only print word

        bitmat_print("M=", M, n);
        cout << endl;

        if ( wh<3 )  continue;  // do not print nullspace
        for (ulong k=0; k<nn; ++k)  print_bin("   N: ",T[k],n);
        cout << endl;

//        if ( 0!=nn )  continue;
//        bitmat_inverse(M, n, T);
//        bitmat_print("  ", T, n);
    }
    while ( bn.next() );

    cout << "n=" << n;
    cout << "   #invertible=" << nct;
    cout << "   #singular=" << sct;
//    cout << "   sum=" << (nct+sct);
    cout << endl;

    return 0;
}
// -------------------------


//  n = 1   #invertible = 1  #singular = 1  sum = 2
//  n = 2   #invertible = 1  #singular = 0  sum = 1
//  n = 3   #invertible = 1  #singular = 1  sum = 2
//  n = 4   #invertible = 2  #singular = 1  sum = 3
//  n = 5   #invertible = 3  #singular = 3  sum = 6
//  n = 6   #invertible = 4  #singular = 5  sum = 9
//  n = 7   #invertible = 7  #singular = 11  sum = 18
//  n = 8   #invertible = 16  #singular = 14  sum = 30
//  n = 9   #invertible = 21  #singular = 35  sum = 56
//  n = 10   #invertible = 48  #singular = 51  sum = 99
//  n = 11   #invertible = 93  #singular = 93  sum = 186
//  n = 12   #invertible = 128  #singular = 207  sum = 335
//  n = 13   #invertible = 315  #singular = 315  sum = 630
//  n = 14   #invertible = 448  #singular = 713  sum = 1161
//  n = 15   #invertible = 675  #singular = 1507  sum = 2182
//  n = 16   #invertible = 2048  #singular = 2032  sum = 4080
//  n = 17   #invertible = 3825  #singular = 3885  sum = 7710
//  n = 18   #invertible = 5376  #singular = 9156  sum = 14532
//  n = 19   #invertible = 13797  #singular = 13797  sum = 27594
//  n = 20   #invertible = 24576  #singular = 27801  sum = 52377
//  n = 21   #invertible = 27783  #singular = 72075  sum = 99858
//  n = 22   #invertible = 95232  #singular = 95325  sum = 190557
//  n = 23   #invertible = 182183  #singular = 182539  sum = 364722

// odd bitcount only:
//  n = 1   #invertible = 1  #singular = 0  sum = 1
//  n = 2   #invertible = 1  #singular = 0  sum = 1
//  n = 3   #invertible = 1  #singular = 0  sum = 1
//  n = 4   #invertible = 2  #singular = 0  sum = 2
//  n = 5   #invertible = 3  #singular = 0  sum = 3
//  n = 6   #invertible = 4  #singular = 1  sum = 5
//  n = 7   #invertible = 7  #singular = 2  sum = 9
//  n = 8   #invertible = 16  #singular = 0  sum = 16
//  n = 9   #invertible = 21  #singular = 7  sum = 28
//  n = 10   #invertible = 48  #singular = 3  sum = 51
//  n = 11   #invertible = 93  #singular = 0  sum = 93
//  n = 12   #invertible = 128  #singular = 42  sum = 170
//  n = 13   #invertible = 315  #singular = 0  sum = 315
//  n = 14   #invertible = 448  #singular = 137  sum = 585
//  n = 15   #invertible = 675  #singular = 416  sum = 1091
//  n = 16   #invertible = 2048  #singular = 0  sum = 2048
//  n = 17   #invertible = 3825  #singular = 30  sum = 3855
//  n = 18   #invertible = 5376  #singular = 1904  sum = 7280
//  n = 19   #invertible = 13797  #singular = 0  sum = 13797
//  n = 20   #invertible = 24576  #singular = 1638  sum = 26214
//  n = 21   #invertible = 27783  #singular = 22146  sum = 49929
//  n = 22   #invertible = 95232  #singular = 93  sum = 95325
//  n = 23   #invertible = 182183  #singular = 178  sum = 182361
