
#include "bpol/lhca.h"
#include "bits/bitcombcolex.h"
#include "bpol/bitpolirred.h"
#include "bpol/bitpolprimitive.h"
#include "bpol/gf2n.h"  // for factorization of mersenne numbers

#include "bits/printbin.h"

#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong
#include "bits/bitsperlong.h"

#include <cstdlib>  // atol()


//% Generate minimal-weight low-bit LHCA rules (LHCA:= Linear Hybrid Cellular Automaton).



void
print_rules(ulong rr, ulong cc, ulong pn)
{
    print_bin_nn("  r=", rr, pn);
    print_bin_nn("  c=", cc, pn);
    print_idx_seq_nn("  r= ", rr);
//    print_idx_seq_nn("  c= ", cc);
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong nn = BITS_PER_LONG - 1;
    if ( argc>1 )  nn = atol(argv[1]);
    ulong pn = nn + 1;

    ulong m = 3;  // search rules of weight 1,2,...,m
    if ( argc>2 )  m = atol(argv[2]);

    cout.width(pn);  cout << "LHCA rule";
    cout.width(pn);  cout << "polynomial";
    cout << endl;

    for (ulong n=1; n<=nn; ++n)
    {
        ulong r=0, c=0;
        cout.width(2);  cout << n << ":  ";
        ulong h = 1UL << (n-1);
        ulong n2 = h<<1;
        GF2n::init(n);  // for factorization of Mersenne number
        for (ulong nb=1; nb<=m; ++nb)  // nb := Number of Bits
        {
            c = 0;
            r = first_comb(nb);
            do  // Try all combinations of nb bits
            {
                c = lhca2poly(r, n);
                if ( 0==bitpol_irreducible_q(c, h) )  goto next;
                if ( 0!=test_bitpol_primitive(c, h, GF2n::mfact_ ) )  goto next;

                goto print;  // (minimal weight rule only)

            next:
                r = next_colex_comb(r);
            }
            while ( r<n2 );
        }

    print:
        print_rules(r, c, pn);
    }

    return 0;
}
// -------------------------

