
#include "bpol/lhca.h"

#include "bits/bitcombcolex.h"  // first_comb() for mask

#include "fxttypes.h"
#include "bits/printbin.h"
#include "jjassert.h"
#include "fxtiomanip.h"
#include "demo/nextarg.h"


//% Linear Hybrid Cellular Automata (LHCA).


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Number of bits");

    int wq = 0;
    NXARG(wq, "Whether to generate SRS words");

    ulong c = minweight_lhca_rule[n];
    ulong pn  = n;

    print_bin_nn("rule = ", c, pn);
    cout << "  == 0x" << hex << c << dec;// << endl;
    cout << "  length=" << (n) << endl;
    cout << endl;

    const ulong end = (1UL<<n)-1;

    const ulong m = first_comb(n);
    ulong x = 1;

    ulong w = 0;
    if ( wq )
    {
        for (ulong k=0; k<n; ++k)
        {
            w <<= 1;  w |= (x&1);  w &= m;
            x = lhca_next(x, c, m);
        }
    }

    const ulong x1 = x;
    for (ulong k=1; k<=end+1; ++k)
    {
        cout << setw(4) << k;
        print_bin_nn("   ", x, pn);

        w <<= 1;  w |= (x&1);  w &= m;
        if ( wq )  print_bin_nn("   ", w, pn);

        cout << endl;

        x = lhca_next(x, c, m);
        if ( x==x1 )  jjassert( k==end );
    }

    return 0;
}
// -------------------------

