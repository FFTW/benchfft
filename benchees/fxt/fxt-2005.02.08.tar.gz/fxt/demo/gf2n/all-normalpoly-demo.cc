
#include "bpol/allirredpol.h"
// demo-include "bits/bitnecklace.h"
// demo-include "bpol/necklace2bitpol.h"
#include "bpol/normalbasis.h"
// demo-include "bpol/bitpolnormal.cc"
#include "bmat/bitmat.h"

#include "bits/printbin.h"
#include "bits/bitcount.h"

#include "fxttypes.h"  // ulong
#include "demo/nextarg.h" // NXARG()

#include "fxtio.h"
#include "jjassert.h"
#include "fxtalloca.h"


//% Find all normal binary polynomials of degree n.
//% Print all corresponding multiplier matrices.


ulong
max_row_count(const ulong *M, ulong n)
{
    ulong m = 0;
    for (ulong j=0; j<n; ++j)
    {
        ulong b = bit_count(M[j]);
        if ( b > m )  m = b;
    }
    return m;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 9;
    NXARG(n, "Degree of the polynomials");

    ulong wh = 1;
    NXARG(wh, "What to print: 2==>poly+matrix 1==>poly 0==>just count");

    ALLOCA(ulong, M, n);  // multiplier matrix
    for (ulong j=0; j<n; ++j)  M[j] = 0;
    all_irredpol ip(n);
    ulong *Mp = M;
    if ( 0==wh )  Mp = 0; // suppress computation of multiplier matrix

//    ulong tm = 99999;  // min type
    ulong nct = 0;  // count normal polynomials
    ulong pct = 0;  // count primitive normal polynomials
    ulong xct = 0;  // count polynomials with coeff('x')==1
//    ulong h = 1UL<<(n-1);
    ulong p = ip.data();
    do
    {
        ulong nq = bitpol_normal_q(p, n, 1, Mp);
        if ( nq )
        {
            ++nct;
            ulong pq = ip.is_primitive();
            if ( pq )  ++pct;

            if ( p & 2 )  ++xct;

//            ulong t = max_row_count(M, n);
//            if ( tm > t )  tm = t;

            if ( 0==wh )  goto next;  // just count

            cout << setw(3) << nct << ":";
            print_bin_nn("  c=", p, n+1);
            if ( pq )  cout << "  P";  // primitive polynomial
            cout << endl;

            if ( wh<=1 )  goto next;  // do not show matrix

            bitmat_print("M=", M, n);
//            cout << " t = " << t << endl;

            cout << endl;
        }

    next:
        p = ip.next();
    }
    while ( p );

    cout << "  n=" << n;
//    if ( wh>=2 )  cout << "  min(t) = " << tm;
    cout << "   #= " << nct << "   #primitive = " << pct;
    cout << "   #non-primitive = " << nct-pct;
//    cout << "   xct = " << xct;
    cout << endl;

    return 0;
}
// -------------------------

//  n=2  min(t) = 2   #= 1   #primitive = 1
//  n=3  min(t) = 2   #= 1   #primitive = 1
//  n=4  min(t) = 2   #= 2   #primitive = 1
//  n=5  min(t) = 2   #= 3   #primitive = 3
//  n=6  min(t) = 2   #= 4   #primitive = 3
//  n=7  min(t) = 4   #= 7   #primitive = 7
//  n=8  min(t) = 4   #= 16   #primitive = 7
//  n=9  min(t) = 2   #= 21   #primitive = 19
//  n=10  min(t) = 2   #= 48   #primitive = 29
//  n=11  min(t) = 2   #= 93   #primitive = 87
//  n=12  min(t) = 2   #= 128   #primitive = 52
//  n=13  min(t) = 4   #= 315   #primitive = 315
//  n=14  min(t) = 2   #= 448   #primitive = 291
//  n=15  min(t) = 4   #= 675   #primitive = 562
//  n=16  min(t) = 8   #= 2048   #primitive = 1017
//  n=17  min(t) = 6   #= 3825   #primitive = 3825
//  n=18  min(t) = 2   #= 5376   #primitive = 2870
//  n=19  min(t) = 10   #= 13797   #primitive = 13797
//  n=20  min(t) = 4   #= 24576   #primitive = 11255
//  n=21  min(t) = 8   #= 27783   #primitive = 23579  // Gauss-mintype==10
//  n=22  min(t) = 4   #= 95232   #primitive = 59986
//  n=23  min(t) = 2   #= 182183   #primitive = 178259
//  n=24  min(t) = 8   #= 262144   #primitive = 103680
