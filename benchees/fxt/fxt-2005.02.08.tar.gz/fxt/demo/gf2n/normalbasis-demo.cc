
#include "bpol/normalbasis.h"
// demo-include "bpol/bitpolnormal.cc"
// demo-include "bpol/normalmult.cc"
// demo-include "bpol/normalsolvequadratic.cc"
// demo-include "bpol/highbitnormalprimpoly.cc"
// demo-include "bpol/highbitnormalpoly.cc"
#include "bmat/bitmat.h"


#include "bits/parity.h"
#include "bits/bitrotate.h"
#include "bits/printbin.h"

#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"  // ulong
#include "fxtiomanip.h"
#include "fxtalloca.h"
#include "jjassert.h"

#include <cstdlib>  // atol()

//% Multiplication with a normal basis for GF(2**n).

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "The n in GF(2**n)");

//    ulong c = highbit_normal_poly[n];
    ulong c = highbit_normal_primpoly[n];  // 'x' is always a generator
    RESTARGS("Optionally supply nonzero coefficients of normal poly c");
    if ( argc>2 )  c = (1UL<<n);
    for (ulong k=2; k<(ulong)argc; ++k)  c |= (1UL << atol(argv[k]));

    cout << endl;
    print_binv("Normal poly:  c=", c, n+1);

    ALLOCA(ulong, M, n);  // multiplication matrix
    ulong q = bitpol_normal_q(c, n, 0, M);
    jjassert( q );
    bitmat_print("Multiplication matrix:  M=", M, n);
    cout << endl;


    ulong pn = n;
    ulong nn = (1UL << n) - 1;

    ulong g = 1UL; // 'x'
//    ulong g = 7UL; // '1+x+x^2'  // for type-1 bases and n=4, n=10
    print_bin("g=", g, pn);

    cout << "  k" << " = " << setw(pn) << "bin(k)" << " : ";
    cout << "   " << setw(pn) << "f=g**k";
    cout << " " << "trace(f)";
    cout << " " << "x^2+x==f";
    cout << endl;
    ulong f = g;
    ulong k = 1;
    do
    {
        cout << setw(3) << k;
        print_bin_nn(" = ", k, pn); cout << " : ";
        print_bin_nn("   ", f, pn);
        ulong t = parity(f);  // trace
        cout << "    " << ".1"[t];

        if ( 0==t )  // solve x^2+x==f
        {
            ulong x = normal_solve_reduced_quadratic(f, n);
            print_bin_nn("      x=", x, n);
        }

        f = normal_mult(f, g, M, n);  // f *= g

        ++k;
        cout << endl;
    }
    while ( f!=g );

    --k;
    cout << " k = " << k << endl;
    cout << " (2**n-1)/k = " << nn/k << endl;

    return 0;
}
// -------------------------
