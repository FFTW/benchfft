
#include "comb/setpartition.h"
// demo-include "comb/setpartition.cc"

//#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% Set partitions.



int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Partition set of n elements");
    bool xdr = true;
    NXARG(xdr, "Change direction in recursion ==> minimal change order");
    int dr0 = +1;
    NXARG(dr0, "Starting direction in recursion (+-1)");
    dr0 = ( (dr0>0) ? +1 : -1 );
    ulong maxct = 0;
    NXARG(maxct, "Stop after maxct partitions (0: never stop)");
    bool priq = true;
    NXARG(priq, "Option: print internal state with each partition");

    set_partition sp(n, xdr, dr0);

    ulong ct = 0;
    do
    {
        ++ct;
        cout << setw(3) << ct << ":  ";
        if ( priq )  sp.print_internal();
        sp.print();
        cout << endl;
        if ( maxct && (ct>maxct) )  break;
    }
    while ( sp.next() );

    cout << endl;

    return 0;
}
// -------------------------

// Printing disabled:
//  % time ./bin 13
//./bin 13  2.97s user 0.01s system 99% cpu 2.986 total
