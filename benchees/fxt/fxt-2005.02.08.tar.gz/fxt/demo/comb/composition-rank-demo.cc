
#include "comb/composition-rank.h"
// demo-include "comb/composition-rank.h"
// demo-include "comb/numof-compositions.h"

#include "demo/nextarg.h"

#include "jjassert.h"
#include "fxttypes.h"
#include "fxtiomanip.h"


//% Ranking and unranking compositions in near-perfect order


int
main(int argc, char **argv)
{
    ulong n = 3;
    NXARG(n, "k-compositions of n (n>=1)");
    ulong k = 5;
    NXARG(k, " (k>=1) ");

    composition_rank cr(n, k);

    ulong *x = new ulong[k];
    ulong nc = cr.num_comp(n,k);
    for (ulong j=0; j<nc; ++j)
    {
        cout << "  " << setw(3) << j << ":   ";

//        cr.unrank_lex(x, n, k, j);
//        cr.unrank_gray(x, n, k, j);
        cr.unrank_nearperfect(x, n, k, j);

        cr.print_x(x, k);
//        cr.print_set(x, k);
        cr.print_nset(x, k);

//        ulong r = cr.rank_lex(x, n, k);
//        ulong r = cr.rank_gray(x, n, k);
//        ulong r = cr.rank_nearperfect(x, n, k);
//        jjassert( r == j );

        cout << endl;
    }

    cout << "  #= " << nc << endl;

    return 0;
}
// -------------------------

