
// demo-is-self-contained

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "jjassert.h"
#include "demo/nextarg.h"


//% Gray code for Fibonacci words, recursive CAT algorithm

ulong n; //
ulong *rv;  // record of visits in graph

ulong ct;   // count objects
ulong rct;  // count recursions (==work)

bool zq;  // 0==>Lex  1==>Gray


void visit()
{
    cout << setw(4) << ct << ":";
    cout << "   ";
    for (ulong j=0; j<n; ++j)  cout << " " << (rv[j] ? '1' : '.');
    cout << endl;
}
// -------------------------


void fib_rec(ulong d, bool z)
{
    if ( d>=n )
    {
        ++ct;  // count objects
        visit();
    }
    else
    {
        ++rct;  // measure computational work
        z ^= zq;
        if ( z )
        {
            rv[d]=0;  fib_rec(d+1, z);
            rv[d]=1;  rv[d+1]=0;  fib_rec(d+2, z);
        }
        else
        {
            rv[d]=1;  rv[d+1]=0;  fib_rec(d+2, z);
            rv[d]=0;  fib_rec(d+1, z);
        }
    }
}
// -------------------------


int
main(int argc, char **argv)
{
    n = 7;
    NXARG(n, "Length of Fibonacci words");
    rv = new ulong[n+1];
    zq = 1;
    NXARG(zq, " 0==>Lex order  1==>Gray code");
    bool rq = 0;
    NXARG(rq, "Whether to reverse order");

    ct = 0;
    rct = 0;
    fib_rec(0, rq);

//    cout << "rct=" << rct << endl;  // rct == ct-1
    cout << "work/object=" << 1.0*(rct)/(ct) << endl;  // ratio <= 1

    return 0;
}
// -------------------------
