
#include "comb/subset-debruijn.h"

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "aux1/auxprint.h"
#include "demo/nextarg.h"


//% Generate all subsets in De Bruijn order.

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Size of the set");

    subset_debruijn sdb(n);

    for (ulong j=0; j<=n; ++j)  sdb.next();  // cosmetics: end with empty set

    ulong ct = 0;
    do
    {
        cout << "    " << setw(2) << ct << ":";
        ulong num = print_delta_set_as_set("    ", sdb.data(), n, 1);
        cout << "   #=" << num;
        print_delta_set_as_set("    ", sdb.data(), n);
        cout << endl;

        sdb.next();
    }
    while ( ++ct < (1UL<<n) );

    return 0;
}
// -------------------------
