
#include "comb/combination-lex.h"

#include "bits/printbin.h"
#include "aux1/auxprint.h"
#include "demo/nextarg.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"


//% Generating all combinations in lexicographic order.


int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    NXARG(n, "Combinations (n choose k):  n>0");
    NXARG(k, " 0 < k <= n");
    ulong ct = 0;
    combination_lex comb(n, k);

    do
    {
        cout << endl;
        cout << "    [" << comb << " ]";
        print_set_as_bitset("    ", comb.data(), k, n );
        cout << "    #" << setw(3) << ct;

        ++ct;
    }
    while ( comb.next() );
    cout << endl;

//    cout << " reversed order: " << endl;
//    comb.last();
//    do
//    {
//        --ct;
//        cout << "   [ " << comb << " ]  ";
//        print_set_as_bitset("", comb.data(), k, n );
//        cout << "  #" << setw(3) << ct;
//        cout << endl;
//    }
//    while ( comb.prev() );
//    cout << endl;


    return 0;
}
// -------------------------


