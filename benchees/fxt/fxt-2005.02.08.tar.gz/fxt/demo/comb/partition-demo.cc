
#include "comb/partition.h"

#include "fxttypes.h"
#include "aux1/copy.h" // set_seq()

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtio.h"

//% Generate all integer partitions.


int
main(int argc, char **argv)
{
    ulong nmax = 6;
    NXARG(nmax, "Shown all partitions for n<=nmax");
    ulong cmax = 30;
    NXARG(cmax, "Count number of partitions for n<=cmax");


    for (ulong j=1; j<nmax; ++j)
    {
        ulong len = j + 1;
        partition pp(len);
        ulong ct = 0;
        while ( pp.next() < len )
        {
            pp.dump();
            ++ct; // total count
        }
        cout << " " << len << ":  ct=" << ct << endl;

        cout << endl;
    }
    cout << endl;


    if ( cmax )
    {
        cout << "----------- Number of partitions of n into 1,2,3,...,n:" << endl;
        for (ulong j=1; j<cmax; ++j)
        {
            ulong x = j;
            ulong len = x;  // ==ceil(x/min(v_i))
            partition pp(len);
            ulong ct = pp.count(x);
            cout << " ct=" << x << ":  " << ct << endl;
        }
    }

    return 0;
}
// -------------------------
