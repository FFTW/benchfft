

#include "comb/binaryprimestring.h"
#include "bits/tinyfactors.h"

#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong

//% Binary pre-necklaces, necklaces and Lyndon words: CAT generation.


int
main(int argc, char **argv)
{
    ulong n = 8;
    if ( argc>1 )  n = atol(argv[1]);

    binary_prime_string bps(n);

    const ulong *x = bps.data();

    ulong tfb = tiny_factors_tab[n];  // for fast factor lookup

    ulong nct = 0;  // count necklaces (prime strings)
    ulong lct = 0;  // count lyndon words
    ulong ct = 0;   // count pre-necklaces (pre-prime strings)
    ulong j = bps.current();  // first string is zero word (period==1)
    do
    {
        cout.width(4);  cout << ct << ": ";

        for (ulong i=0; i<n; ++i)  cout << (x[i] ? '1' : '.' );
        cout << "  ";
        cout.width(2);  cout << j;
        cout << "  ";
        // fast lookup if j is a factor of n:
        if ( (tfb>>j) & 1 )
        {
            ++nct;
            cout << 'N';  // necklace
        }

        if ( j==n )
        {
            ++lct;
            cout << 'L';  // Lyndon word
        }

        j = bps.next();
        ++ct;
        cout << endl;
    }
    while ( j );

    cout << " n = " << n << ":  ";
//    cout << endl;
    cout << "  # pre-necklaces=" << ct-1;
    cout << "  # necklaces=" << nct;
    cout << "  # Lyndon words=" << lct;
    cout << endl;


    return 0;
}
// -------------------------
