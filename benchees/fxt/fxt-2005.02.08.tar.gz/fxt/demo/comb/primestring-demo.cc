
#include "comb/primestring.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

#include "fxtiomanip.h"

//% Generate all (pre-)primestrings alias (pre-)necklaces.

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "length of strings >=1");
    ulong m = 3;
    NXARG(m, "number of words >=2");
    ulong pq = 1;
    NXARG(pq, "whether to also print preprime strings");

    prime_string ps(m, n);
    const ulong *x = ps.data();

    ulong j = ps.j_;  // ==1
    ulong pct = 0;  // count preprime strings (prenecklaces)
    ulong ct = 0;   // count primestrings (necklaces)
    ulong lct = 0;  // count Lyndon words
    do
    {
        ++pct;
        if ( (0==pq) && (0!=(n%j)) )  continue;

        cout << "    ";
        for (ulong k=0; k<n; ++k)  cout << x[k];
        cout << "  " << setw(2) << j;
        cout << "    ";
        ulong k;
        for (k=0; k<n-j; ++k)  cout << " ";
        for (  ; k<n; ++k)  cout << x[k];

        if ( 0==(n%j) )
        {
            ++ct;
            cout << "  %";
            if ( n==j )
            {
                ++lct;
                cout << " L";
            }
        }
        cout << endl;
    }
    while ( (j=ps.next()) );

    cout << "  #pre = " << pct;
    cout << "  #necklaces = " << ct;
    cout << "  #lyn = " << lct;
    cout << endl;

    return 0;
}
// -------------------------
