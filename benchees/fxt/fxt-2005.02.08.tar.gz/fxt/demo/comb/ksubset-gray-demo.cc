
#include "comb/ksubset-gray.h"

#include "fxtiomanip.h"
#include "fxttypes.h"
#include "aux1/auxprint.h"

#include "demo/nextarg.h" // NXARG()

//% k-subsets (kmin<=k<=kmax) in minimal-change order


void
print_set1_as_bitset(const char *bla, const ulong *x, ulong n, ulong N)
// Print x[0,..,n-1] ( a n-subset of {1,2,...,N}) as bit-set.
// Example:  x[]=[1,2,4,5,9]  ==> "11.11...1"
{
    if ( bla )  cout << bla;

    ulong j = 0;
    for (ulong k=0; k<n; ++k)
    {
        for (  ; j<x[k]-1; ++j)  cout << '.';
        cout << '1';
        ++j;
    }

    while ( j++ < N )  cout << '.';
}
// -------------------------


int
main(int argc, char **argv)
{
    cout << "k-subsets of n,  kmin<=k<=kmax  in minimal-change order." << endl;
    ulong n = 5;
    NXARG(n, "size of set");
    ulong kmin = 2;
    NXARG(kmin, "Minimum of k");
    ulong kmax = 4;
    NXARG(kmax, "Maximum of k  (zero ==> kmax:=n)");
    if ( 0==kmax )  kmax = n;
    bool rq = 0;
    NXARG(rq, "Whether to generate subsets in reversed order");

    ksubset_gray kg(n, kmin, kmax);
    const ulong *x = kg.data();

    ulong num, idx = 0, q;
    if ( rq )  kg.last();  else  kg.first();
    do
    {
        num = kg.num();
        cout << "    " << setw(2) << idx << ":";
        cout << "   #=" << num;
        print_set1_as_bitset("   ", x, num, n);
//        cout << "   j=" << kg.j_;
        print_set("   set=", x, num);
        cout << endl;
        ++idx;
        q = ( rq ? kg.prev() : kg.next() );
    }
    while ( q );
    cout << endl;

    return 0;
}
// -------------------------



/* *********************
// Original taken from T.A.Jenkyns: "Loopless Gray Code Algorithms":

//  Algorithm A4 //  to generate all k-subsets of {1..n}
//               //  where min    <    k    <    max  in a Gray code
BEGIN S[1]:=1;  k:=min;
    IF min=1 THEN j:=1
    ELSE FOR i:=2 TO min DO S[i]:=n-min+i END; j:=2
    END;

    Process( S[1],...,S[k] );

    WHILE S[1] < n-min+1 DO
        IF ((j MOD 2) > 0 THEN           // j is odd
            IF S[j] = n THEN j:=j-1
            ELSE IF j < max THEN  S[j+1]:=n;  j:=j+1
                ELSE S[j]:=S[j]+1;
                    IF S[min]=n THEN j:=j-1 END
                END
            END
        ELSE // j is even
            IF S[j-1] = S[j]-1 THEN S[j-1]:= S[j];
                IF j > min THEN
                    IF S[min] = n THEN j:=j-2 ELSE j:=j-1 END
                ELSE S[j]:=n-min+j;
                    IF S[j-1]=S[j]-1 THEN j:=j-2 END
                END
            ELSE S[j]:=S[j]-1;
                IF j < max THEN S[j+1]:=S[j]+1;
                    IF j >= min-1 THEN j:=j+1 ELSE j:=j+2 END
                END
            END
        END;
        IF j<min THEN k:=min ELSE k:=j END;
        Process( S[1],...,S[k] )
    END
END // Algorithm A4.

//This algorithm can be somewhat simplified when 1<min and/or min<max.

********************* */

