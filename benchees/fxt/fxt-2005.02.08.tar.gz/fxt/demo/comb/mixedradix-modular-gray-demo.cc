
#include "comb/mixedradix-modular-gray.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"

//% Modular mixed radix Gray code.

void
print(const char *bla, const ulong *f, ulong n)
{
    if ( bla )  cout << bla;
    cout << "{";
    for (ulong k=0; k<n; ++k)  cout << (long)f[k] << (k<n-1?", ":"");
    cout << "}";
}
// -------------------------

void
do_demo(ulong *m, ulong n)
{
    cout << " n = " << n << endl;
    print(" m = ", m, n);
    cout << endl;

    ulong ct = 0;
    mixedradix_modular_gray mg(m, n); cout << endl;

    do
    {
        cout << setw(3) << ct << ":  ";
        print(" ", mg.data(), n);
        cout << "   j = " << mg.pos();
        cout << endl;

//        print(" d = ", mg.s_, n);  cout << endl;
//        print(" f = ", mg.f_, n+1);  cout << endl;
//        print(" m1 = ", mg.m1_, n);  cout << endl;
//        cout << endl;

        ++ct;
    }
    while ( mg.next() );

    cout << endl;
    cout << endl;
}
// -------------------------

#define  ARSZ(x)  (sizeof(x)/sizeof(typeof(x[0])))
#define  DEMO(x)  do_demo(x, ARSZ(x))
int
main()
{
//    ulong m1[] = {2, 2, 2, 2};  // same as binary gray code

    ulong m2[] = {2, 3, 4, 5};
    ulong m3[] = {3, 3};

    DEMO( m3 );
    DEMO( m2 );


    return 0;
}
// -------------------------
