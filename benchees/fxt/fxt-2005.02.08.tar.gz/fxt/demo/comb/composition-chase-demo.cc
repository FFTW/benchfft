
#include "comb/composition-chase.h"
#include "aux0/binomial.h"

#include "fxttypes.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtiomanip.h"

//%  Generating all k-compositions of n in a near-perfect order (Chase's sequence).

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, " k-composition of n: n>=1");
    ulong k = 4;
    NXARG(k, " 1<=k");

    composition_chase cnp(n,k);
    ulong N = cnp.N_,  K=cnp.K_;
    ulong bnk =  binomial(N, K);
    cout << "Using (" << N << " choose " << K << ") combinations." << endl;
    cout << "binomial(" << N << ", " << K << ")=" << bnk << endl;

    ulong ct = 0;
    do
    {
        cout << setw(3) << ct << ":   ";
        const ulong *x = cnp.get_combination();
        for (ulong j=0; j<N; ++j)  if ( x[j] ) cout << " " << j;
        cout << "    ";
        for (ulong j=0; j<N; ++j)  cout << " " << (x[j] ? '1' : '.');

        const ulong *p = cnp.get();
        cout << "    ";
        for (ulong j=0; j<k; ++j)  cout << " " << p[j];

        cout << endl;
        ++ct;
    }
    while ( cnp.next() );

    jjassert( bnk==ct );
    cout << endl;

    return 0;
}
// -------------------------

// for n in $(seq 1 10); do for k in $(seq 1 $n); do ./bin $n $k || break 2; done; done
