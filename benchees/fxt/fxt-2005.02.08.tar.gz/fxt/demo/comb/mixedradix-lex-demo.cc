
#include "comb/mixedradix-lex.h"
#include "comb/mixedradix.h"

#include "aux1/misc.h" // compare()
#include "aux1/copy.h" // fill()

#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"
#include "fxtalloca.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()

//% Mixed radix numbers in lexicographic order.

void
print_mr(const ulong *x, ulong n)
{
    for (ulong j=0; j<n; ++j)
    {
        ulong v = x[j];
        cout << " ";
        if ( 0==v )  cout << '.';
        else         cout << v;
    }
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n,"Number of digits")

    ALLOCA(ulong, r, n);
    ulong rr = 3;
    NXARG(rr, "Base (radix) of digits");
    fill(r, n, rr);
    RESTARGS("Optionally supply radix for second...last digit")
    for (ulong k=3;  k<(ulong)argc; ++k)  r[k-2] = atol(argv[k]);

    mixedradix mr(r, n);
    mixedradix_lex mrl(r, n);
    ulong ct = 0;
    do
    {
        cout << " " << setw(4) << ct << "  ";
        print_mr( mr.data(), n );

        cout << "    ";
        print_mr( mrl.data(), n );

        // check whether fixed point:
        ulong fp = compare(mr.data(), mrl.data(), n );
        if ( 0==fp )  cout << "  *";

        mr.prev();
        ++ct;
        cout << endl;
    }
    while ( mrl.next() );

    return 0;
}
// -------------------------
