
#include "comb/combination-chase.h"
#include "aux0/binomial.h"

#include "fxttypes.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtiomanip.h"

//%  Generating all combinations in near-perfect minimal-change order.

int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "(n choose k): n>=1");
    ulong k = 3;
    NXARG(k, "(n choose k):  1<=k<=n");
    bool rq = 0;
    NXARG(rq, "Option: print in reverse order");

    if ( (k>n) || ( k==0 ) || ( n==0 ) )  { return 1; }

    combination_chase cnp(n,k);

    ulong ct = 0;
    do
    {
        cout << setw(3) << ct << ":  ";

        const ulong *x = cnp.get();
        if ( rq )
        {
            for (ulong j=0; j<n; ++j)  if ( x[n-1-j] ) cout << " " << (n-1-j);
            cout << "    ";
            for (ulong j=0; j<n; ++j)  cout << " " << (x[n-1-j] ? '1' : '.');
        }
        else
        {
            for (ulong j=0; j<n; ++j)  if ( x[j] ) cout << " " << j;
            cout << "    ";
            for (ulong j=0; j<n; ++j)  cout << " " << (x[j] ? '1' : '.');
        }

        cout << endl;
        ++ct;
    }
    while ( cnp.next() );

    ulong bnk =  binomial(n, k);
    cout << "binomial(" << n << ", " << k << ")=" << bnk << endl;
    jjassert( bnk==ct );
    cout << endl;

    return 0;
}
// -------------------------

// for n in $(seq 1 10); do for k in $(seq 1 $n); do ./bin $n $k || break 2; done; done
