
#include "comb/paren.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "aux1/auxprint.h"

#include "demo/nextarg.h"
#include "jjassert.h"


//% Generate all well-formed pairs of parenthesis.

int
main(int argc, char **argv)
{
    ulong k = 5;
    NXARG(k, "Number of paren pairs >=2");

    bool bwq = 0;
    NXARG(bwq, "Whether to also generate in backward direction");

    ulong n = 2*k;
    ulong ct = 0;

    paren par(k);


    do
    {
        cout << "  " << par.string() << "  ";
        print_set_as_bitset("", par.data(), k, n );
        cout << "  #" << setw(3) << ct;
        ++ct;
        cout << endl;
        jjassert( par.OK() );
    }
    while ( par.next() );
    cout << endl;

    if ( bwq )
    {
        par.last();
        do
        {
            --ct;
            cout << "  " << par.string() << "  ";
            print_set_as_bitset("", par.data(), k, n );
            cout << "  #" << setw(3) << ct;
//            for (ulong j=0; j<k; ++j)  cout << "  " << par.data()[j];
            cout << endl;
            jjassert( par.OK() );
        }
        while ( par.prev() );
        cout << endl;
        jjassert( 0==ct );
    }

    return 0;
}
// -------------------------
