
#include "comb/combination-colex.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "aux1/auxprint.h"

#include "demo/nextarg.h"

//% Generating all combinations in co-lexicographic order.


int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    NXARG(n, "Combinations (n choose k):  n>0");
    NXARG(k, " 0 < k <= n");
    ulong ct = 0;
    combination_colex comb(n, k);

    do
    {
        cout << endl;
        cout << "    [" << comb << " ]";
        print_set_as_bitset("    ", comb.data(), k, n );
        cout << "    #" << setw(3) << ct;
        ++ct;
    }
    while ( comb.next() );
    cout << endl;

//    cout << " reversed order: " << endl;
//    comb.last();
//    do
//    {
//        --ct;
//        cout << "   [ " << comb << " ]  ";
//        print_set_as_bitset("", comb.data(), k, n );
//        cout << "  #" << setw(3) << ct;
//        cout << endl;
//    }
//    while ( comb.prev() );
//    cout << endl;

    return 0;
}
// -------------------------
