
#include "comb/subset-gray-delta.h"

#include "aux1/auxprint.h"  // print_delta_set_as_set()
#include "demo/nextarg.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "fxtiomanip.h"


//% Generate all subsets (as delta sets) in minimal-change order.

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Size of the set");
    bool rq = 0;
    NXARG(rq, "Whether to generate subsets in reversed order");

    subset_gray_delta sg(n);
    const ulong *x = sg.data();

    ulong num;
    do
    {
        num = sg.num();
        cout << setw(2) << sg.current() << ":  ";

        // print as bit set:
        for (ulong k=0; k<n; ++k)  cout << (x[k]?'1':'.');
        cout << "   chg @ " << sg.ch_;
        cout << "   #=" << num;

        print_delta_set_as_set("   set=", x, n);
        cout << endl;

        num = ( rq ? sg.prev() : sg.next() );
    }
    while ( num );

    return 0;
}
// -------------------------
