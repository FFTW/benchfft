
#include "comb/composition-lex.h"
#include "bits/bit2composition.h"

#include "bits/printbin.h"
#include "demo/nextarg.h"

#include "fxttypes.h"
#include "fxtio.h"


//% Generating all k-compositions of n in lexicographic order.


int
main(int argc, char **argv)
{
    ulong n = 3;
    NXARG(n, "k-compositions of n (n>=1)");

    ulong k = 5;
    NXARG(k, " (k>=1) ");

    composition_lex p(n, k);
    ulong wn = n+k-1;
    const ulong *x = p.data();
    ulong ct = 0;
    do
    {
        cout << " #" << setw(3) << ct << ":   ";
        for (ulong i=0; i<k; ++i)  cout << x[i] << " ";
        ulong w = composition2bit(x, wn);
        print_binv_nn("   ", w, wn);
        cout << endl;

        ++ct;
    }
    while ( p.next() );

    cout << "  #= " << ct << endl;

    return 0;
}
// -------------------------

