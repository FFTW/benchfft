
#include "graph/digraph.h"
#include "graph/digraphpaths.h"
// demo-include "graph/digraphpaths-condsearch.cc"
#include "graph/digraphspecial.h"
// demo-include "graph/digraphgray.cc"

#include "graph/printpath.h"
#include "comb/gray.h"

#include "bits/bitcount.h"
#include "bits/bitlow.h"
#include "bits/bitrotate.h"
#include "bits/printbin.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

#include "fxtiomanip.h"


//% Paths through a directed graph: adjacent changes (AC) Gray paths.


ulong
pfunc(digraph_paths &dp)
// Function to be called with each path.
{
    const ulong *rv = dp.rv_;
    ulong ng = dp.ng_;

//    if ( ! dp.cq_ )   return 0;  // cycles only

    cout << dp.pfct_ << ":" << endl;
    print_gray(rv, ng);

//    dp.print_turns( 0 );  cout << endl;
//    cout << ".";  cout.flush();

    return 1;
}
// -------------------------


ulong cf_mt; // mid track < cf_mt,  set in main()
bool cfunc_ac(digraph_paths &dp, ulong ns)
// Condition: difference of successive delta values == +-1
// paths exist for n<=6 but no path for n==7.
{
//    if ( ns<2 )  return  true;
    if ( ns<2 )  return  (dp.rv_[1] < cf_mt); // avoid track-reflected solutions
    ulong p  = dp.rv_[ns],  p1 = dp.rv_[ns-1], p2 = dp.rv_[ns-2];
    ulong c = p ^ p1, c1 = p1 ^ p2;
    if ( c & (c1<<1) )  return  true;
    if ( c1 & (c<<1) )  return  true;
    return false;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "size in bits");
    if ( n<2 )  n = 2;
    cf_mt = (1UL << ((n+1)/2));

    ulong maxnp = 0;
    NXARG(maxnp, " stop after maxnp paths (0: never stop)");

    digraph dg = make_gray_digraph(n, 0);
//    dg.print("Graph =");

    digraph_paths dp(dg);


    // Option: set max number of paths:
    if ( maxnp )
    {
        cout << "We will stop after " << maxnp << " paths";
        cout << " that pfunc() counts.";
        cout << endl;
    }

    // All the work is done here:
    ulong ns = 0, p = 0;
    dp.all_cond_paths(pfunc, cfunc_ac, ns, p, maxnp);

    cout << "n = " << n;
    cout << "   #pfct = " << dp.pfct_;
    cout << endl;
    cout << "   #paths = " << dp.pct_;
    cout << "   #cycles = " << dp.cct_;
    cout << endl;

    return 0;
}
// -------------------------

