
#include "comb/lyndongray.h"
#include "bits/crc64.h"  // class crc64

#include "bits/bitlow.h"
#include "bits/printbin.h"

#include "demo/nextarg.h"

#include "fxttypes.h"
#include "bits/bitsperlong.h"
#include "fxtiomanip.h"
#include "jjassert.h"


//% Gray cycle through n-bit Lyndon words. Must have n prime < BITS_PER_LONG
//% By default print (length-7710, base-36) delta sequence for n=17.

crc64 crcw;  // CRC for words
crc64 crcd;  // CRC for delta sequence

static inline void print_crc(const crc64 &crc)
{
    cout << setfill('0');
    cout << "   crc=" << hex << setw(16) << (crc.get_a()) << dec;
    cout << setfill(' ');
}
// -------------------------

ulong
check(lyndon_gray &lg)
{
    ulong k = 0;
    while ( 1 )
    {
        const ulong m1 = (1UL<<16);
        const ulong m2 = (1UL<<20)-1;
        for (ulong j=m1;  j;  --j)
        {
            ++k;
            if ( 0==lg.next() )
            {
                return k;
            }
        }

        // indicate progress:
        cout << ".";  cout.flush();
        if ( 0==(k&m2) )
        {
            cout << "  "  << setw(9) << k;
            cout << " ( " << 100.0*k/lg.nlyn_ << " % )";
            crcw.word_in( lg.p_ );
            print_crc(crcw);
            cout << endl;
        }
    }
    return k;  // never reached
}
// -------------------------


ulong
print(lyndon_gray &lg, ulong wh)
{
    const char dd[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ@";
    // enough w/base: "_23456789.123456789.123456789.123456789";

    ulong n = lg.n_;
    ulong k = 0;
    while ( 1 )
    {
        ++k;
        if ( wh>=2 )
        {
            cout << setw(4) << k << ": ";
            print_bin_nn("   ", lg.p_, n);  // Lyndon word
            cout << "  " << setw(2) << lg.r_;  // amount of rotation
            print_bin_nn("  ", lg.pr_, n );    // rotated word
            print_bin_nn("   ", lg.d_, n);     // delta word
            cout << "  ";
        }

        //if ( k<1001 )
        {
            ulong d = lowest_bit_idx(lg.d_);
            crcd.byte_in((uchar)d);
            cout << dd[d];
            if ( 1==wh )  if ( 0==(k%100) )  cout << endl;
        }

        if ( wh>=2 )  cout << endl;

        if ( 0==lg.next() )  return k;
        lg.make_rot();
    }
    return k;  // never reached
}
// -------------------------

void
doit(ulong n, ulong wh, ulong ncmp)
{
    lyndon_gray  lg(n, ncmp);

    ulong nlyn = lg.nlyn_;
    cout << "n = " << n;
    cout << "   #lyn = " << nlyn;
    cout << endl;


    ulong k;
    if ( 0==wh )  k = check(lg);
    else          k = print(lg, wh);

    cout << endl;
    cout << "last = "; print_bin_nn("", lg.p_, lg.n_);
    cout << "  ";
    crcw.word_in( lg.p_ );
    if ( 1==wh )  print_crc( crcd );
    else          print_crc( crcw );
    cout << endl;

    cout << endl;
    cout << "n = " << n;
    cout << "   #lyn = " << nlyn;
    cout << "   #= " << k;
    cout << endl;

    jjassert( k>=nlyn );
    jjassert( (n<3) || (2==bit_count(lg.p_)) );  // cycles only
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 17;
    NXARG(n, " a prime < BITS_PER_LONG (37 needs 4GByte of RAM and a 64-bit machine)");
    if ( n<2 )  n = 2;

    ulong wh = 1;
    NXARG(wh, "printing: 0==>none, 1==>delta seq., 2==>full output");

    ulong ncmp = 2;
    NXARG(ncmp, "use comparison function (0,1,2,3)");

    ulong testall = 0;
    NXARG(testall, "special: test all primes <= value");

    if ( 0==testall )  doit(n, wh, ncmp);
    else
    {
        ulong p[] = {2,3,5,7,11,13,17,19,23,29,31, 37,41,43,47,53,59,61, ~0UL};

        ulong k = 0, n;
        while ( (n=p[k++])<=testall )  doit(n, 0, ncmp);
    }

    return 0;
}
// -------------------------
