
#include "graph/digraph.h"
#include "graph/digraphpaths.h"
// demo-include "graph/digraphpaths-search.cc"
#include "graph/digraphspecial.h"
// demo-include "graph/digraphfull.cc"

#include "sort/convex.h"
#include "perm/permutation.h"

#include "demo/nextarg.h"

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "jjassert.h"


//% Paths through the full graph: Permutations.



ulong
pfunc_perm(digraph_paths &dp)
// Function to be called with each path:
//  print all but the first node.
{
    const ulong *rv = dp.rv_;
    ulong ng = dp.ng_;

//    if ( 0 < is_convex(rv, ng) )  // select rising-falling permutations:
        // # = 2**(n-1) - 2 = 1,1,3,7,5,15,31,...
//    if ( is_inverse(rv, rv, ng) )  // select self-inverse permutations:
        // # = 1,2,4,10,26,76,232,764,2620,9496,...
    {
        cout << setw(4) << dp.pfct_ << ":  ";
        for (ulong k=1; k<ng; ++k)  cout << " " << rv[k];
        cout << endl;

        return 1;
    }

    return 0;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "number of nodes of graph");
    if ( n<1 )  n = 1;

    digraph dg = make_full_digraph(n);


    digraph_paths dp(dg);

    ulong maxnp = 0;
    NXARG(maxnp, "stop after maxnp paths (0: never stop)");

    dg.print("Graph =");
    cout << endl;


    // All the work is done here:
    // (pfunc_perm() is called with each path)
    dp.all_paths(pfunc_perm, 0, 0, maxnp);

    cout << "n = " << n;
    cout << "   #pfct = " << dp.pfct_;
    cout << endl;
    cout << "   #paths = " << dp.pct_;
    cout << "   #cycles = " << dp.cct_;
    cout << endl;


    return 0;
}
// -------------------------

