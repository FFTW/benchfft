
#include "perm/permtrotter.h"
//demo-include "perm/permtrotter.cc"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in minimal-change order using Trotter's algorithm.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");

    perm_trotter perm(n);
    const ulong *x = perm.data();
    ulong sw1, sw2;
    do
    {
#ifndef TIMING
        cout << "   " << setw(3) << perm.current() << ":   ";

        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm.get_swap(sw1, sw2);
        cout << "  swap: (" << sw1 << ", " << sw2 << ") ";

        cout << "  p= ";
        for (ulong i=0; i<n; ++i)  cout << perm.p_[i] << " ";

        cout << endl;
#endif
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


