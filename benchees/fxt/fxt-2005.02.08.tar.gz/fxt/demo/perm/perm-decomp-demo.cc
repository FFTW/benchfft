
#include "perm-all.h"
// demo-include "perm/permrecognize.cc"

#include "aux1/copy.h" // swap()
#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong

#include <cstdlib>  // atol()


//% Permutations as Kronecker products of simpler permutations.
//% Check the (nasty but useful) code.


static int q = 1;
#define  TT(x)  { if ( q ) { cout << " " << #x << endl;}  x; }
#define  P1(x)  { if ( q ) { cout << " [1]: " << #x << endl;}  x; }
#define  P2(x)  { if ( q ) { cout << " [2]: " << #x << endl;}  x; }


void p1_func(ulong *f, ulong n)
{
    ulong nh = n/2;
    ulong n4 = n/4;


//    P1( zip(f, n) );  // revbin_permute
//    P1( unzip(f, n) );  // ???
//    P1( revbin_permute(f, n) );  // ???
//    P1( gray_permute(f, n) );  // ???
//    P1( haar_permute(f, n) );  // ???
//    P1( inverse_haar_permute(f, n) );  // ???

//    P1( swap(f, f+nh, nh) );  // reverse

    P1( swap(f+nh, f+nh+n4, n4) );  // gray_permute
//    P1( swap(f, f+n4, n4) );  // rev @ gray_rev_permute == rev @ gray_permute @ rev
//    P1( swap(f+n4, f+nh, n4) );  // unzip
//    P2( swap(f, f+nh+n4, n4) );  // unzip @ rev

//    P1( swap(f+n4, f+nh, n4) );  P1( swap(f+nh, f+nh+n4, n4) ); // unzip_rev
//    P1( swap(f, f+n4, n4) );  P1( swap(f, f+nh, n4) );  // rev @ unzip_rev @ rev

//    P2( swap(f, f+n4, n4) );  P2( swap(f, f+nh, nh) ); // gray_rev_permute

//    P1( swap(f, f+nh, n4) );  // inverse_green_rev_permute @ rev
    // == rev @ inverse_green_permute @ rev

//    P1( swap(f+n4, f+nh+n4, n4) );  // inverse_green_permute
    // == rev @ inverse_green_rev_permute
    // == hswap @ inverse_green_permute(g, n) @ hswap

//    P1( reverse(f+nh, nh) );  // inverse_gray_permute
    // == rev @ inverse_gray_rev_permute
//    P1( reverse(f, nh) );  // rev @ inverse_gray_permute @ rev
    // == inverse_gray_rev_permute @ rev

//    P1( negate(f+nh+n4, n4) );  //  grs_negate
//    P1( negate(f+nh, n4) );  //  ???

    nh = n4 = 0; // avoid warning
    q = 0;
}
// -------------------------
//
void perm1(ulong *f, ulong n)
// From shorter to longer subarrays.
{
    for (ulong k=2; k<=n; k*=2)
    {
        for (ulong j=0; j<n; j+=k)  p1_func(f+j, k);
    }
}
// -------------------------


void p2_func(ulong *f, ulong n)
{
    ulong nh = n/2;
    ulong n4 = n/4;

//    P2( zip(f, n) );  // ???
//    P2( unzip(f, n) );  // revbin_permute

//    P2( revbin_permute(f, n) );  // ???

//    P2( inverse_gray_rev_permute(f, n) );  // ???
//    P2( gray_permute(f, n) );  // ???
//    P2( reverse(f, n) );  // xor_permute(g, n, x) @ rev
//    P2( xor_permute(f, n, 1) );  // identity
//    P2( xor_permute(f, n, nh) );  // identity @ rev

//    P2( swap(f, f+nh, nh) );  // reverse

    P2( swap(f+nh, f+nh+n4, n4) );  // inverse_gray_permute
//    P2( swap(f+n4, f+nh, n4) );  // zip
//    P2( swap(f, f+nh+n4, n4) );  // zip @ rev

//    P2( swap(f, f+n4, n4) );  // inverse_gray_rev_permute @ rev
    // == rev @ inverse_gray_permute @ rev

//    P2( swap(f, f+nh, nh) );  P2( swap(f, f+n4, n4) );  // inverse_gray_rev_permute

//    P1( swap(f+nh, f+nh+n4, n4) );  P1( swap(f+n4, f+nh, n4) ); // zip_rev
//    P1( swap(f, f+nh, n4) );  P1( swap(f, f+n4, n4) );  // rev @ zip_rev @ rev

//    P2( swap(f, f+nh, n4) );  // rev @ green_rev_permute == rev @ green_permute @ rev
//    P2( swap(f+n4, f+nh+n4, n4) );  // green_permute == green_rev_permute @ rev

//    P2( reverse(f+nh, nh) );  // gray
//    P2( reverse(f, nh) );  // rev @ gray_rev_permute

//    P2( negate(f+nh+n4, n4) );  //  grs_negate
//    P2( negate(f+nh, n4) );  //  ???

    nh = n4 = 0; // avoid warning
    q = 0;
}
// -------------------------
//
void perm2(ulong *f, ulong n)
// From longer to shorter subarrays.
{
    for (ulong k=n; k>=2; k/=2) // k == n, n/2, n/4, ... , 4, 2
    {
        for (ulong j=0; j<n; j+=k)  p2_func(f+j, k);
    }
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong ldn = 6;
    if ( argc>1 )  ldn = atol(argv[1]);
    ulong  n = (1<<ldn);

    ulong *f = new ulong[n];
    set_seq( f, n );
    cout << "Operations:" << endl;


    // ---------- start PLAYGROUND ----------

    // --- 1: Try "known" permutations:
    TT( gray_permute(f, n) );
//    TT( green_permute(f, n) );
//    TT( unzip(f, n) );

    // --- 2: Discover primitives:
    // 2a: define permutation and its inverse
#define F gray_permute
#define I inverse_gray_permute
//#define F zip_rev
//#define I unzip_rev
    // 2b: select one of:
//    TT( F(f, n) ); TT( I(f, n/2) ); TT( I(f+n/2, n/2) ); // 2b:  F I I
//    TT( I(f, n) ); TT( F(f, n/2) ); TT( F(f+n/2, n/2) ); // 2b:  I F F
//    TT( F(f, n/2) ); TT( F(f+n/2, n/2) ); TT( I(f, n) ); // 2b:  F F I
//    TT( F(f, n/2) ); TT( F(f+n/2, n/2) ); TT( F(f, n) ); // 2b:  I I F

    // --- 3: Permutations from primitives:
//    TT( perm1(f, n); );
//    TT( perm2(f, n); );


    // ---------- end PLAYGROUND ----------


    q = 0;

    cout << "Result:" << endl;
    cout << "[";
    for (ulong k=0; k<n; ++k)
    {
        if ( 0==(k % (n/4)) )  cout << endl;
        ulong v = f[k];
        cout << setw(2) << (v);
        if ( k<n-1 ) cout << ",";
    }
    cout << " ]";
    cout << endl;

    cout << "Analysis:" << endl;
    perm_recognize(f, n);
    cout << endl;

    return 0;
}
// -------------------------
