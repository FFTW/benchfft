
#include "perm/permgray.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in minimal-change order using a loopless algorithm.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");

    perm_gray perm(n);
    const ulong *x = perm.data();
    const ulong *ix = perm.invdata();
    ulong sw1, sw2;
    do
    {
#ifndef TIMING
        cout << "   " << setw(3) << perm.current() << ":   ";

        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm.get_swap(sw1, sw2);
        cout << "  sw(" << sw1 << ", " << sw2 << ")";

        cout << "    ";
        for (ulong i=0; i<n; ++i)  cout << ix[i] << " ";

        const ulong *a = perm.mrg_->data();
        cout << "    a= ";
        for (ulong i=0; i<n-1; ++i)  cout << a[i] << " ";

//        if ( is_cyclic(x, n) )  cout << "  Cyc";
        cout << endl;
#endif // TIMING
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


// Timing:
// perm_gray:
//  3.279*0.5*10^9/(11!) == 41.1  cycles / permutation (500 MHz Pentium3)
//  1.265*2.0*10^9/(11!) == 63.4  cycles / permutation (2Ghz AMD Athlon XP)
//
// perm_trotter:
//  2.332*0.5*10^9/(11!) == 29.2  cycles / permutation (500 MHz Pentium3)
//  0.866*2.0*10^9/(11!) == 43.4  cycles / permutation (2Ghz AMD Athlon XP)
//
//  time*(cycles/sec)/num == cycles/perm
