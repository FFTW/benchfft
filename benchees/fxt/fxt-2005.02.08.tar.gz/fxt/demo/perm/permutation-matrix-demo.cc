
#include "perm-all.h"
#include "aux1-all.h"

#include "fxtalloca.h"
#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong

#include <cstdlib>  // atol()


//% Matrices corresponding to permutations.


#define  TT(X)  { {cout << " " << #X << endl;}  X; }

template <typename Type>
void prsgn(Type *f, ulong n, ulong x)
{
    cout << "  ";
    cout.width(3);  cout << x << ":";
    cout << " [ ";
    for (ulong k=0; k<n; ++k)
    {
        double v = f[k];
//        cout << setw(2) << (v); // debug
        cout << (v>0 ? '+' : (v<0 ? '-' : ' ') );
        if ( k<n-1 ) cout << ' ';
    }
    cout << " ]";
}
// -------------------------


void
showmat(const ulong *f, ulong n)
{
    ALLOCA(ulong, g, n);
    for (ulong x=0; x<n; ++x)
    {
        null(g, n);
        g[f[x]] = 1;
        prsgn(g, n, x);
        ulong d;  ulong i = test_delta(g, n, &d);
        if ( i<n )  cout << "  [" << setw(2) << i << "] ";
//        cout << (d > 0 ? '+' : '-');
        cout << endl;
    }
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong ldn = 5;
    if ( argc>1 )  ldn = atol(argv[1]);
    ulong  n = (1<<ldn);

    ALLOCA(ulong, f, n);

    cout << "Operations:" << endl;
    set_seq( f, n );

    // Playground: apply one or more permutations
    TT( gray_permute(f, n) );
//    TT( inverse_green_permute(f, n) );

    showmat(f, n);

    cout << "Inverse:" << endl;
    make_inverse(f, n);
    showmat(f, n);

    return 0;
}
// -------------------------
