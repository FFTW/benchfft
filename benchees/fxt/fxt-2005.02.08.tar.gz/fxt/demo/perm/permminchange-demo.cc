
#include "perm/permminchange.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in minimal-change order.

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");
    bool piq = 0;
    NXARG(piq, "Option: print internal data.");

    perm_minchange perm(n);
    const ulong *x = perm.data();
    const ulong *ix = perm.invdata();
    ulong sw1, sw2;
    do
    {
        cout << " #"; cout.width(3); cout << perm.current() << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm.get_swap(sw1, sw2);
        cout << "  swap: (" << sw1 << ", " << sw2 << ") ";

        cout << "  inv= ";
        for (ulong i=0; i<n; ++i)  cout << ix[i] << " ";

        if ( piq )
        {
            cout << "    d= ";
            for (ulong i=0; i<n; ++i)  cout << (perm.d_[i]==1 ? '+' : '-' ) << " ";

            cout << "  ii= ";
            for (ulong i=0; i<n; ++i)  cout << perm.ii_[i] << " ";
        }

        cout << endl;
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


