
#include "perm/permstar.h"

#include "perm/permutation.h"
#include "jjassert.h"

#include "fxttypes.h"
#include "demo/nextarg.h"  // NXARG()
#include "fxtio.h"

#include <cstdlib> // atol()

//% Generate all permutations in star-transpostion order.


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");

    perm_star perm(n);
    const ulong *x = perm.data();
    const ulong *xi = perm.invdata();

    do
    {
        cout << " #"; cout.width(3); cout << perm.current() << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
        cout << "  swap: (" << 0 << ", " << perm.get_swap() << ") ";

        cout << "  inv= ";
        for (ulong i=0; i<n; ++i)  cout << xi[i] << " ";
        cout << endl;
        jjassert ( is_inverse(x, xi, n) );
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


