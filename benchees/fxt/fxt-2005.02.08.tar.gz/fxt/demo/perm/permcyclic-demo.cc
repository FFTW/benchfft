
#include "perm/permcyclic.h"

#include "fxttypes.h"
#include "fxtio.h"

#include <cstdlib> // atol()

//% Demo of cyclic permutations.

int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    perm_cyclic perm(n);
    const ulong *x = perm.data();

    ulong ct = 0;
    do
    {
        cout << " #"; cout.width(3); cout << ct << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
        cout << endl;

        ++ct;
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


