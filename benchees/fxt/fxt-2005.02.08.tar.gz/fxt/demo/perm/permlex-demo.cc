
#include "perm/permlex.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in lexicographic order.

void
print_fact(ulong idx, ulong n)
// print factorial representation of the index:
{
    cout << "    ";
    ulong f = 1;
    for (ulong i=2; i<n; ++i)  f *= i;
    ulong z = idx; //perm.current();
    for (ulong i=n-1;  i>=1;   f/=i, --i)
    {
        ulong d = 0;
        if ( z>=f )  { d = z/f; z-=d*f; }
        // d: number of following elements smaller than the current
        cout << d << " ";
    }
//    cout << "0"; // no element follows the last
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");

    perm_lex perm(n);
    const ulong *x = perm.data();
    do
    {
        cout << " #" << setw(3) << perm.current() << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        cout << "  ";  cout << (perm.sign() ? '-' : '+');

        print_fact(perm.current(), n);

        cout << endl;
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


