
#include "mod/mod.h"

#include "fxttypes.h"  // ulong

//% Demo of cosine/sine modulo p.

umod_t mm[] = {
//    5,
//    17,
    257,
//    65537,
//    0x3f40f80000000001ULL,
//    0x3fffc00000000001ULL,
    0
};

int
main(int argc, char **argv)
{
    if ( argc==1 )
    {
        for (ulong k=0; mm[k]; ++k)
        {
            mod::init(mm[k]);
            mod::print_info();
            cout << endl;
            mod_info_roots();
            cout << endl;
        }
    }
    else
    {
        umod_t m = atol(argv[1]);
        {
            for (ulong k=1; (ulong)argc>k; ++k)
            {
                m = atol(argv[k]);
                mod::init(m);
                mod::print_info();
                cout << endl;
                mod_info_roots();
                cout << endl;
            }
        }
    }

    cout << endl;

    return 0;
}
// -------------------------
