
#include "mod/primes.h"
#include "mod/modarith.h"

#include "mod/factor.h"
#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong


//% Find moduli where all quadratic residues are non-prime.


int
main(int argc, char **argv)
{
    ulong n = 2000;
    NXARG(n,"Search limit for moduli");
    bitarray *ba = make_oddprime_bitarray(n);
    ulong e = 2;
    NXARG(e,"Exponent");

    ulong ct = 0;
    for ( umod_t m=2; m<n; ++m)
    {
        bool q = 0;
        for ( umod_t x=0; x<m; ++x )
        {
            umod_t z = pow_mod(x, e, m);
            q |= is_small_prime( z, ba );
        }
        if ( 0==q )
        {
            ++ct;
            cout << m;
            cout << " == " << factorization(m);
            cout << endl;
        }
    }

    cout << endl;
    cout << " #=" << ct << endl;

    return 0;
}
// -------------------------
