
#include "bits/bitxtransforms.h"

#include "bits/printbin.h"
#include "bits/revbin.h"
#include "fxtio.h"
#include "fxttypes.h"
#include "bits/bitsperlong.h"

#include <cstdlib>  // atol()

#include "jjassert.h"

//% Matrices corresponding to symbolic powers of the 'color' transforms.


int
main()
{
    ulong pn = BITS_PER_LONG;
    for (ulong x=0; x<pn; ++x)
    {
        print_bin_nn("x = ", x, 6);
        cout << " = " << x;
        cout << endl;
        for (ulong z=1,k=0;  k<pn;  ++k,z<<=1)
        {
            ulong a = z;
            a = yellow_xcode(a, x);
//            a = cyan_xcode(a, x);
            a = revbin(a);  // so identity == diagonal
            print_bin(" ", a , pn);
        }
        cout << endl;
    }
    return 0;
}
// -------------------------
