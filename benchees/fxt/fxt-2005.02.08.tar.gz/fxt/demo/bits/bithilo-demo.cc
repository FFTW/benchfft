
#include "bits/bit2pow.h"
#include "bits/bitlow.h"
#include "bits/bithigh.h"
#include "demo/bits/bitdemos.h"  // ugly, very ugly  (just for the demo)

#include "fxttypes.h"

//% Operations on the low and high bits of binary words.

void
do_the_show(ulong v)
{
    ulong t;

    print_sep();

    WORD;


    SHWBIN( highest_bit );
    SHWBIN( highest_bit_01edge );
    SHWBIN( highest_bit_10edge );
    SHWDEC( highest_bit_idx );

    SHWDEC( ld );

    SHWBIN( low_zeros );
    SHWBIN( low_bits );

    SHWBIN( lowest_bit );
    SHWBIN( lowest_bit_01edge );
    SHWBIN( lowest_bit_10edge );
    SHWDEC( lowest_bit_idx );

    SHWBIN( lowest_block );

    SHWBIN( delete_lowest_bit );

    SHWBIN( lowest_zero );
    SHWBIN( set_lowest_zero );

    SHWBIN( high_bits );
    SHWBIN( high_zeros );
    SHWBIN( highest_zero );
    SHWBIN( set_highest_zero );


    cout << endl;
}
// -------------------------
