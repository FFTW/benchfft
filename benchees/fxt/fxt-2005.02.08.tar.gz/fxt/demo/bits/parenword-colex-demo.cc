
#include "bits/parenwords.h"  // parenword2str()
#include "bits/printbin.h"  // print_bin()

#include "jjassert.h"
#include "fxtio.h"
#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

//% Binary 'parenthesis words' in colex order


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Number of paren pairs");
    ulong pn = 2*n+1;
    char *str = new char[n+1];  str[n] = 0;

    ulong x = first_parenword(n);
    ulong pct = 0;
    while ( x )
    {
        ++pct;
        print_bin_nn("  ", x, pn);
        parenword2str(x, str);
        cout << "   " << str;
        cout << endl;

        jjassert( is_parenword(x) );
        x = next_parenword(x);
    }
    cout << "  pct=" << pct << endl;
    cout << endl;

    return 0;
}
// -------------------------
