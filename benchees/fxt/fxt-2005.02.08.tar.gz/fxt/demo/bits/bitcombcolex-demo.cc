
#include "bits/bitcombcolex.h"

#include "fxttypes.h"
#include "bits/printbin.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtio.h"


//% Generating combinations of bits (as binary words) in co-lexicographic order.

int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    NXARG(n, "Colex combinations (n over k):  n  (n>0)");
    NXARG(k, "  (0<k<=n)");

    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    const ulong pd = n;
    ulong last = last_comb(k, n);
    ulong g = first_comb(k);
    ulong gg = 0;
    do
    {
        print_bin_nn("    ", g, pd);
        if ( gg )  print_bin_diff_nn("    ", gg, g, pd, ".1+-");
        gg = g;
        g =  next_colex_comb(g);

        cout << endl;
    }
    while ( gg!=last );

    cout << endl;

    return 0;
}
// -------------------------
