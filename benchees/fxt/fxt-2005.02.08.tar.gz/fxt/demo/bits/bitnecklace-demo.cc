
#include "bits/bitnecklace.h"

#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong

//% Binary necklaces and Lyndon words: CAT generation.


#include "bits/printbin.h"
#include "bits/bit2pow.h"


int
main(int argc, char **argv)
{
    ulong n = 8;
    if ( argc>1 )  n = atol(argv[1]);

    bit_necklace bn(n);

    ulong nct = 0;  // count necklaces (prime strings)
    ulong lct = 0;  // count lyndon words
    ulong j = bn.current();
    do
    {
        cout.width(4);  cout << nct << ": ";

        ulong z=bn.data();
        cout << "  ";
        print_bin_nn("", z, n);
        cout << "  ";
        cout.width(2);  cout << 1+ld(j);
        cout << "  ";
        if ( bn.is_lyndon_word() )
        {
            ++lct;
            cout << 'L';  // Lyndon word
        }

        j = bn.next();
        ++nct;
        cout << endl;
    }
    while ( j );

    cout << " n = " << n << ":  ";
    cout << "  # necklaces=" << nct;
    cout << "  # Lyndon words=" << lct;
    cout << endl;


    return 0;
}
// -------------------------

//$ time for f in  $(seq 31); do ./bin $f; done
// n = 1:    # necklaces=2  # Lyndon words=2
// n = 2:    # necklaces=3  # Lyndon words=1
// n = 3:    # necklaces=4  # Lyndon words=2
// n = 4:    # necklaces=6  # Lyndon words=3
// n = 5:    # necklaces=8  # Lyndon words=6
// n = 6:    # necklaces=14  # Lyndon words=9
// n = 7:    # necklaces=20  # Lyndon words=18
// n = 8:    # necklaces=36  # Lyndon words=30
// n = 9:    # necklaces=60  # Lyndon words=56
// n = 10:    # necklaces=108  # Lyndon words=99
// n = 11:    # necklaces=188  # Lyndon words=186
// n = 12:    # necklaces=352  # Lyndon words=335
// n = 13:    # necklaces=632  # Lyndon words=630
// n = 14:    # necklaces=1182  # Lyndon words=1161
// n = 15:    # necklaces=2192  # Lyndon words=2182
// n = 16:    # necklaces=4116  # Lyndon words=4080
// n = 17:    # necklaces=7712  # Lyndon words=7710
// n = 18:    # necklaces=14602  # Lyndon words=14532
// n = 19:    # necklaces=27596  # Lyndon words=27594
// n = 20:    # necklaces=52488  # Lyndon words=52377
// n = 21:    # necklaces=99880  # Lyndon words=99858
// n = 22:    # necklaces=190746  # Lyndon words=190557
// n = 23:    # necklaces=364724  # Lyndon words=364722
// n = 24:    # necklaces=699252  # Lyndon words=698870
// n = 25:    # necklaces=1342184  # Lyndon words=1342176
// n = 26:    # necklaces=2581428  # Lyndon words=2580795
// n = 27:    # necklaces=4971068  # Lyndon words=4971008
// n = 28:    # necklaces=9587580  # Lyndon words=9586395
// n = 29:    # necklaces=18512792  # Lyndon words=18512790
// n = 30:    # necklaces=35792568  # Lyndon words=35790267
// n = 31:    # necklaces=69273668  # Lyndon words=69273666
// real    0m7.648s
// user    0m7.560s
// sys     0m0.050s

// n = 31:    # necklaces=69273668  # Lyndon words=69273666
// real    0m3.581s
// user    0m3.580s
// sys     0m0.010s
