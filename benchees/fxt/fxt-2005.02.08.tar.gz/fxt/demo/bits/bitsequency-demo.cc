
#include "bits/bitsequency.h"

#include "bits/printbin.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "jjassert.h"


//% Generating bit sets of given sequency.

int
main()
{
    const ulong pd = 6;

    ulong Ct = 1;
    for (ulong i=0; i<pd ; ++i)
    {
        ulong v = first_sequency(i+1);

        cout << endl;
        cout << "   sequency = " << bit_sequency(v) << endl;
        print_bin(" ", v, pd);

        ulong ct = 0;
        ulong c = v;
        do
        {
            ++ct;
            c = next_sequency(c);

            // special condition for pd-bit demo:
            if ( c>=(1UL<<pd) )  break;
            print_bin(" ", c, pd);
            jjassert( bit_sequency(c)==(i+1) );
        }
        while ( c );

        Ct += ct;
        cout << " ct == " << ct;
        cout << "    Ct == " << Ct;
        cout << endl;
    }

    cout << endl;

    return 0;
}
// -------------------------
