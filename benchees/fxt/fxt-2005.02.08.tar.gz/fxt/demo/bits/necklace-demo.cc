
#include "bits/bitcyclic.h"
#include "bits/bitcyclic2.h"

#include "bits/revbin.h"
#include "bits/bitcount.h"

#include "fxttypes.h"
#include "bits/printbin.h"

#include "demo/nextarg.h"
#include "fxtiomanip.h"


//% Binary necklaces and Lyndon words: brute force search.

int
main(int argc, char **argv)
{
    ulong n = 8;
    NXARG(n, "Number of bits");
    ulong nn = 1UL << n;

    ulong ct = 0;  // count necklaces
    ulong cto = 0;  // count necklaces of odd weight
    ulong cte = 0;  // count necklaces of even weight
    ulong ctmo = 0; // count Lyndon words of odd weight
    ulong ctme = 0; // count Lyndon words of even weight
    for (ulong k=0; k<nn; ++k)
    {
        if ( k==bit_cyclic_min(k, n) )
        {
            cout << "  " << setw(4) << ct;
            ++ct;
            print_bin_nn("  ", k, n);

            ulong p = bit_cyclic_period(k, n);
            cout << "  " << setw(2) << p;

            ulong b = bit_count(k);
            cout << " " << setw(2) << b;
            if ( b&1 )  { ++cto;  cout << "   o"; }
            else        { ++cte;  cout << "   e"; }
            if ( n==p )
            {
                cout << "  L";
                if ( b&1 )  ++ctmo;
                else        ++ctme;
            }

            cout << endl;
        }
        if ( 0!=k )  ++k;
    }
    cout << " n = " << n << ":  ";
    cout << endl;
    cout << "  #necklaces=" << (cte+cto);
    cout << "  #even=" << cte << "  #odd=" << cto;
    cout << endl;
    cout << "  #Lyndon="<< (ctme+ctmo) ;  // Lyndon words
    cout << "  #even=" << ctme << "  #odd=" << ctmo;
    cout << endl;


    return 0;
}
// -------------------------

// cf. concrete math, pp.139-141.
// for(n=1, 30, s=0;fordiv(n,d,s=s+eulerphi(d)*2^(n/d)); print(n, " ", s/n))
//   1: 2
//   2: 3
//   3: 4
//   4: 6
//   5: 8
//   6: 14
//   7: 20
//   8: 36
//   9: 60
//  10: 108
//  11: 188
//  12: 352
//  13: 632
//  14: 1182
//  15: 2192
//  16: 4116
//  17: 7712
//  18: 14602
//  19: 27596
//  20: 52488
//  21: 99880
//  22: 190746
//  23: 364724
//  24: 699252
//  25: 1342184
//  26: 2581428
//  27: 4971068
//  28: 9587580
//  29: 18512792
//  30: 35792568
