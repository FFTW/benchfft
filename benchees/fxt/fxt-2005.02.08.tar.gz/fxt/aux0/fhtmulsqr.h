#if !defined HAVE_FHTMULSQR_H__
#define      HAVE_FHTMULSQR_H__

#include "complextype.h"


static inline  void
fht_sqr(double &xi, double &xj, double v)
// Auxiliary routine for fht_auto_convolution_core().
// xi <-- v*( 2*xi*xj + xi*xi - xj*xj )
// xj <-- v*( 2*xi*xj - xi*xi + xj*xj )
{
    double a = xi,  b = xj;
    double s1 = (a + b) * (a - b);
    a *= b;
    a += a;
    xi = (a+s1) * v;
    xj = (a-s1) * v;
}
// -------------------------

static inline  void
fht_mul(double xi, double xj, double &yi, double &yj, double v)
// Auxiliary routine for fht_convolution_core()
{
    double h1p = xi,  h1m = xj;
    double s1 = h1p + h1m,  d1 = h1p - h1m;
    double h2p = yi,  h2m = yj;
    yi = (h2p * s1 + h2m * d1) * v;
    yj = (h2m * s1 - h2p * d1) * v;
}
// -------------------------


// --- complex versions:

static inline  void
fht_sqr(Complex &xi, Complex &xj, double v)
// Auxiliary routine for fht_auto_convolution_core().
// xi <-- v*( 2*xi*xj + xi*xi - xj*xj )
// xj <-- v*( 2*xi*xj - xi*xi + xj*xj )
{
    Complex a = xi,  b = xj;
    Complex s1 = (a + b) * (a - b);
    a *= b;
    a += a;
    xi = (a+s1) * v;
    xj = (a-s1) * v;
}
// -------------------------

static inline  void
fht_mul(Complex xi, Complex xj, Complex &yi, Complex &yj, double v)
// Auxiliary routine for fht_convolution_core().
{
    Complex h1p = xi,  h1m = xj;
    Complex s1 = h1p + h1m,  d1 = h1p - h1m;
    Complex h2p = yi,  h2m = yj;
    yi = (h2p * s1 + h2m * d1) * v;
    yj = (h2m * s1 - h2p * d1) * v;
}
// -------------------------


#endif // !defined HAVE_FHTMULSQR_H__
