#if !defined  HAVE_VERSION_H__
#define       HAVE_VERSION_H__


// aux0/version.cc:
void print_fxt_version();


#endif  // !defined HAVE_VERSION_H__
