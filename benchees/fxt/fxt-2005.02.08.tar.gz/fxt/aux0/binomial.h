#if !defined  HAVE_BINOMIAL_H__
#define       HAVE_BINOMIAL_H__

#include "fxttypes.h"

// aux0/binomial.cc:
ulong binomial(ulong n, ulong k);


#endif  // !defined HAVE_BINOMIAL_H__
