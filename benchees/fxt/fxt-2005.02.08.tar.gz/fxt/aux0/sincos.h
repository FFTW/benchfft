#if !defined  HAVE_SINCOS_H__
#define       HAVE_SINCOS_H__

//#include "aux0/sincos.h" // this file

#define  SINCOS_AUTOMATIC  // undefine to select sincos by hand
//
// uncomment the above to manually choose one of:
//
#if !defined  SINCOS_AUTOMATIC
//#  define  SINCOS_USE_ASM_TEMPLATE // x86 asm template sincos
//#  define  SINCOS_USE_ASM          // x86 asm sincos
//#  define  SINCOS_USE_MATHINLINE   // inline-math sincos
//#  define  SINCOS_USE_C            // plain call of sin() and cos()
#endif //  !defined  SINCOS_AUTOMATIC


#if defined SINCOS_AUTOMATIC

#  if defined  __i386__  // ------- if x86 cpu

#    if defined  __GNUC__  // GNU compiler
// choose (uncomment) one of the next two lines:
#      define  SINCOS_USE_ASM_TEMPLATE  // use x86 asm template
//#      define  SINCOS_USE_ASM    // use x86 ASM asm code in sincos.cc
#    endif //  defined  __GNUC__

#  else //  defined  __i386__

// if __sincos_code is defined in /usr/include/bits/mathinline.h
#    if defined  __sincos_code
#      define  SINCOS_USE_MATHINLINE
#    else
#      define  SINCOS_USE_C  // use C-version
#    endif //  defined  __sincos_code

#  endif //  defined  __i386__

#else //  defined SINCOS_AUTOMATIC

// ... algorithm selected by hand

#endif //  defined SINCOS_AUTOMATIC



#if defined  SINCOS_USE_ASM_TEMPLATE
static inline void SinCos(double a, double *s, double *c)
{
    __asm__ ("fsincos" : "=t" (*c), "=u" (*s) : "0" (a));
}
// used (special i386) constraints:
//    `t'  First (top of stack) floating point register
//    `u'  Second floating point register
#endif //  defined  SINCOS_USE_ASM_TEMPLATE


#if defined  SINCOS_USE_ASM
// aux0/sincos.cc:
void SinCos(double a, double *c, double *s);
#endif //  defined  SINCOS_USE_ASM


#if defined  SINCOS_USE_MATHINLINE
#  define  SinCos(a,s,c)  __sincos(a,s,c)
#endif


#if defined  SINCOS_USE_C

#  include <cmath>

static inline void SinCos(double a, double *s, double *c)
{
    *s = sin(a);
    *c = cos(a);
}
#endif //  defined  SINCOS_USE_C



#endif //  !defined  HAVE_SINCOS_H__
