
//#include <sys/types.h>
#include <signal.h>
//#include <unistd.h> // getpid(), pause()

#include <cstdlib>  // abort()

#include "jjassert.h"
#include "fxtio.h"

static int fail_action = JJ_ASSERT_DEFAULT;

void
set_fail_action(int a/*=JJ_ASSERT_DEFAULT*/)
{
    fail_action = a;
}
// -------------------------


void
jjassert_fail(
              const char *func,
              const char *pretty_func,
              const char *file,
              const int   line,
              const char *expr,
              const char *bla
              )
{
    cout.flush();

    cerr << "\n";

    cerr << "FAILED ASSERTION: ( " << expr << " )";
    cerr << "\n";

    cerr << " FUNCTION: \"" << func <<"()\"";
    cerr << "\n";

    cerr << " FILE: " << file
         << " (line " << line << ")";
    cerr << "\n";

    cerr << " PRETTY_FUNCTION: \"" << pretty_func <<"\"";
    cerr << "\n";

    if ( bla )  cerr << " REASON: " << bla << "\n";

    cerr << "\n";


 do_fail:
    switch ( fail_action )
    {
    case JJ_ASSERT_IGNORE: ; break;  // happily continue into disaster

    case JJ_ASSERT_ABORT:  abort(); break;  // no return
        // If the SIGABRT signal is blocked or ignored,
        // the abort() function will still override it.

//    case JJ_ASSERT_PAUSE:  pause(); break;
    case JJ_ASSERT_SEGV:  raise(SIGSEGV); break;  // no return
    case JJ_ASSERT_STOP:  raise(SIGSTOP); break;

    default: fail_action = JJ_ASSERT_DEFAULT;  goto do_fail;
    }
}
// -------------------------



