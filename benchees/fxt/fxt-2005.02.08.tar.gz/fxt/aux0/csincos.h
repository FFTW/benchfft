#if !defined  HAVE_CSINCOS_H__
#define       HAVE_CSINCOS_H__

#include "aux0/sincos.h"
#include "complextype.h"

static inline Complex SinCos(double phi)
{
    double c, s;
    SinCos(phi, &s, &c);
    return  Complex(c, s);
}
// -------------------------

static inline void SinCos(double phi, Complex *z)
{
    double *c = (double *)z;
    double *s = c + 1;
    SinCos(phi, s, c);
}
// -------------------------


#endif //  !defined  HAVE_CSINCOS_H__
