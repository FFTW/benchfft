
everything in the directory bucket/
is hereby officially declared nonexistent.

... with the exception of this file  ;)

