#if !defined  HAVE_RANDF_H__
#define       HAVE_RANDF_H__

#include "fxttypes.h"     // ulong

// aux0/rand.cc:
uint rseed(uint s=0);
double rnd01();
void rnd01(double *f, ulong n);
double white_noise();
double white_noise(double *f, ulong n);


#endif  // !defined HAVE_RANDF_H__
