
#include "bits/bitsperlong.h"
#include "fxttypes.h"
#include "bits/zerobyte.h"


ulong
long_strlen(const char *str)
//
// might be a win on 64-bit machines
//
{
    ulong x;
    const char *p = str;

    // alignment: scan bytes up to word boundary:
    while ( (ulong)p % BYTES_PER_LONG )
    {
        if ( 0 == *p )  return  (ulong)(p-str);
        ++p;
    }

    x = *(ulong *)p;
    while ( ! contains_zero_byte(x) )
    {
        p += BYTES_PER_LONG;
        x = *(ulong *)p;
    }

    // now a zero byte is somewhere in x:
//    while ( x & 0xff )  { ++p;  x >>= 8; }
    while ( 0 != *p )  { ++p; }

    return  (ulong)(p-str);
}
// -------------------------


const char *
long_memchr(const char *str, char c)
//
// might be a win on 64-bit machines
//
{
    // alignment: scan bytes up to word boundary:
    while ( (ulong)str % BYTES_PER_LONG )
    {
        if ( c == *str )  return  str;
        ++str;
    }

    ulong w;
    w = c;         /* 0000000c */
    w ^= (w<<8);   /* 000000cc */
    w ^= (w<<16);  /* 0000cccc */
#if  BITS_PER_LONG > 32
    w ^= (w<<32);  /* cccccccc */
#endif

    ulong x = *(ulong *)str;
    x ^= w;  // if x contained c it now contains a zero:
    while ( ! contains_zero_byte(x) )
    {
        str += BYTES_PER_LONG;
        x = *(ulong *)str;
        x ^= w;
    }

    // now a zero byte is somewhere (where the c was) in x:
    while ( x & 0xff )  { ++str;  x >>= 8; }

    return  str;
}
// -------------------------
