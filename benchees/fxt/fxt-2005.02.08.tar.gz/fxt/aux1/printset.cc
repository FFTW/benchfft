
#include "aux1/auxprint.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include "fxtalloca.h"
#include "fxttypes.h"


void
print_set(const char *bla, const ulong *x, ulong n)
// Print x[0,..,n-1] as set.
{
    if ( bla )  cout << bla;

    cout << "{";
    for (ulong k=0; k<n; ++k)
    {
        cout << x[k];
        if ( k<n-1 )  cout << ", ";
    }
    cout << "}";
}
// -------------------------


void
print_set_as_bitset(const char *bla, const ulong *x, ulong n, ulong N)
// Print x[0,..,n-1] as bit-set.
// Example:  x[]=[0,1,3,4,8]  ==> "11.11...1"
{
    if ( bla )  cout << bla;

    ulong j = 0;
    for (ulong k=0; k<n; ++k)
    {
        for (  ; j<x[k]; ++j)  cout << '.';
        cout << '1';
        ++j;
    }

    while ( j++ < N )  cout << '.';
}
// -------------------------

ulong
print_delta_set_as_set(const char *bla, const ulong *x, ulong n, int eq/*=0*/)
// Print delta set x[0,..,n-1] as set.
// Example:  x[]=[0,0,1,0,1,1] ==> "{2,4,5}"
// if eq!=0 then print spaces for empty positions:
// With example above:  "{ , , 2, , 4, 5}"
// Return number of elements (3 in example).
{
    if ( bla )  cout << bla;

    cout << "{";
    ulong k = 0;
    ulong num = 0;

    if ( 0==eq )  // skip leading empty buckets
    {
        while ( k<n-1 && 0==x[k])  { ++k; }
    }

    if ( x[k] )  { cout << k;  ++num; }
    else if ( 0!=eq )   cout << " ";

    for (++k; k<n; ++k)
    {
        if ( x[k] )
        {
            cout << ", " << k;
            ++num;
        }
        else if ( 0!=eq )   cout << ",  ";
    }
    cout << "}";

    return  num;
}
// -------------------------

ulong
print_bitset_as_set(const char *bla, ulong x, ulong n, int eq/*=0*/)
{
    ALLOCA(ulong, f, n);
    for (ulong j=0; j<n; ++j)
    {
        f[j] = x & 1;
        x >>= 1;
    }

    return  print_delta_set_as_set(bla, f, n, eq);
}
// -------------------------

