#if !defined HAVE_AUXPRINT_H__
#define      HAVE_AUXPRINT_H__

#include "fxttypes.h"
#include "complextype.h"



// aux1/printset.cc:
void print_set(const char *bla, const ulong *x, ulong n);
void print_set_as_bitset(const char *bla, const ulong *f, ulong n, ulong N);
ulong print_delta_set_as_set(const char *bla, const ulong *x, ulong n, int eq=0);
ulong print_bitset_as_set(const char *bla, const ulong x, ulong n, int eq=0);


// aux1/auxprint.cc:
extern double print_epsilon;
void print(const char *bla, const double *f, ulong n, double eps=0.0);
void graph_print(const char *bla, const double *f, ulong n, double eps=0.0);
void print_twodim(const char *bla, const double *f, ulong r, ulong c, double eps=0.0);


// jj_endauto_doc


// useful but yucky:

void c_print(const char *what, const Complex *c, long n, double eps=0.0);
void ri_print(const char *bla, const double *fr, const double *fi, long n, double eps=0.0);


void approx_eq(const double *f, const double *g, uint n,
               const char *bla, double eps=1e-12);

void approx_eq(const Complex *f, const Complex *g, uint n,
               const char *bla, double eps=1e-12);

void approx_eq(const ulong *f, const ulong *g, uint n, const char *bla);


#endif  // !defined HAVE_AUXPRINT_H__
