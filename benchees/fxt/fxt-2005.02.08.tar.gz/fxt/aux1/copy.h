#if !defined HAVE_COPY_H__
#define      HAVE_COPY_H__


#include "fxttypes.h"

namespace fxtaux
{


template <typename Type>
inline void null(Type *f, ulong n)
// Set array to zero
{
    const Type z(0);
    while ( n-- )  f[n] = z;
}
// -------------------------


template <typename Type>
inline void fill(Type *dst, ulong n, Type v)
// Fill array with value v
{
    while ( n-- )  dst[n] = v;
}
// -------------------------


template <typename Type1, typename Type2>
inline void copy(const Type1 *src, Type2 *dst, ulong n)
// Copy array src[] to dst[]
{
    while ( n-- )  dst[n] = (Type2)src[n];
}
// -------------------------

template <typename Type1, typename Type2>
inline void copy0(const Type1 *src, ulong ns, Type2 *dst, ulong nd)
// Copy as much as makes sense, fill rest with zeros
// from src[] (length ns) to dst[] (length nd):
{
    ulong k = 0;
    ulong n = ( nd<ns ? nd : ns ); // == min(nd, ns);
    for (k=0; k<n; ++k)  dst[k] = (Type2)src[k];
    for (  ; k<nd; ++k)  dst[k] = (Type2)0;
}
// -------------------------


template <typename Type1, typename Type2>
inline void copy_cyclic(const Type1 *src, Type2 *dst, ulong n, ulong s)
// Copy array src[] to dst[]
// starting from position s in src[]
// wrap around end of src[]  (src[n-1])
//
// src[] is assumed to be of length n
// dst[] must be length n at least
//
// same as:  { copy(src, dst, n); rotate_right(dst, n, s)}
{
    ulong k = 0;
    while ( s<n )  dst[k++] = (Type2)src[s++];

    s = 0;
    while ( k<n )  dst[k++] = (Type2)src[s++];
}
// -------------------------


template <typename Type1, typename Type2>
inline void copy_reverse(const Type1 *src, Type2 *dst, ulong n)
// copy array reversed:
// dst[] <-- reverse(f[])
{
    ulong j = 0;
    while ( n-- )
    {
        dst[j] = (Type2)src[n];
        ++j;
    }
}
// -------------------------

template <typename Type1, typename Type2>
inline void copy_reverse_0(const Type1 *src, Type2 *dst, ulong n)
// copy array reversed around index 0:
// dst[] <-- reverse_0(f[])
{
    dst[0] = (Type2)src[0];
    copy_reverse(src+1, dst+1, n-1);
}
// -------------------------



//template <typename Type1, typename Type2>
//inline void offset_copy(const Type1 *src, ulong ns,
//            Type2 *dst, ulong nd,
//            ulong off)
//// copy with offset
//// from src[] (length ns) to dst[] (length nd):
//{
//    if ( off>=ns )  return;  // no elements to copy from
//    if ( off>=nd )  return;  // no elements to copy to
//
//    ulong len = min(ns-off, nd-off);
//    copy(src+off, dst+off, len);
//}
//// -------------------------


template <typename Type1, typename Type2>
inline void skip_copy(const Type1 *src, Type2 *dst, ulong n, ulong d)
// copy n elements from src[] at positions
// [0],[d],[2d],[3d],...,[(n-1)*d]
// to dst[0, 1, ... ,n-1]
{
    for (ulong k=0,j=0; j<n; k+=d,j++)  dst[j] = src[k];
}
// -------------------------


template <typename Type1, typename Type2>
inline void skip_copy_back(const Type1 *src, Type2 *dst, ulong n, ulong d)
// copy n elements from src[0, 1, ... ,n-1]
// to dst[] at positions
// [0],[d],[2d],[3d],...,[(n-1)*d]
{
    for (ulong k=0,j=0; j<n; k+=d,j++)  dst[k] = src[j];
}
// -------------------------


template <typename Type>
inline void swap(Type *f, Type *g, ulong n)
// swap arrays
{
    while ( n-- )
    {
        Type t(f[n]);  f[n]=g[n];  g[n]=t;
    }
}
// -------------------------


template <typename Type>
inline void swap_reverse(Type *f, Type *g, ulong n)
// swap arrays reversed:
// f[] <-- reverse(g[])
// g[] <-- reverse(f[])
{
    ulong j = 0;
    while ( n-- )
    {
        Type t(f[j]);  f[j]=g[n];  g[n]=t;
        ++j;
    }
}
// -------------------------


template <typename Type>
inline void set_seq(Type *dst, ulong n, Type start=0, Type step=1)
// fill array with sequence
// start, start+step, start+2*step, ...
{
    for (ulong k=0; k<n; ++k)
    {
        dst[k] = start;
        start += step;
    }
}
// -------------------------


template <typename Type>
inline bool is_seq(const Type *dst, ulong n, Type start=0, Type step=1)
// check whether array with the sequence
// start, start+step, start+2*step, ...
// (as filled in by set_seq(dst, n, start, step)
{
    for (ulong k=0; k<n; ++k)
    {
        if ( dst[k] != start )  return false;
        start += step;
    }

    return true;
}
// -------------------------


template <typename Type1, typename Type2>
inline long compare(const Type1 *f, const Type2 *g, ulong n)
// Compare sequences, return 0 if both are identical.
// If a difference is detected, the return +-(k+1)
//  where k is the index so that  f[k]!=g[k]
//  and the sign is positive if f[k]>g[k], else negative.
{
    ulong k;
    for (k=0; k<n; ++k)
    {
        if ( f[k] != g[k] )  break;
    }

    if ( k==n )  return 0;
    else
    {
        ulong j = k+1;
        return ( f[k]>g[k] ? j : -j );
    }
}
// -------------------------



} // end namespace fxtaux


using namespace fxtaux;


#endif // !defined HAVE_COPY_H__
