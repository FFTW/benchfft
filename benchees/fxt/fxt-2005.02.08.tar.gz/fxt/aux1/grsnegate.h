#if !defined  HAVE_GRSNEGATE_H__
#define       HAVE_GRSNEGATE_H__

#include "fxttypes.h"
#include "bits/parity.h"


template <typename Type>
void grs_negate(Type *f, ulong n)
// negate elements at indices where the
// Golay-Rudin-Shapiro is negative.
{
    for (ulong k=0; k<n; ++k)
    {
        ulong gnq  =  parity( k & (k>>1) );  // == grs_negative_q(k)
        if ( gnq )  f[k] = -f[k];
    }
}
// -------------------------


#endif  // !defined HAVE_GRSNEGATE_H__
