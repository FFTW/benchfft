#if !defined  HAVE_WORDGRAY_H__
#define       HAVE_WORDGRAY_H__

#include "fxttypes.h"

//<<
// Gray code (and green code over GF(2**n)
// cf. bits/graycode.h and bits/graypower.h
//>>

template <typename Type>
void word_gray(Type *f, ulong ldn)
{
    ulong n = 1UL<<ldn;
    for (ulong k=0;  k<n-1;  ++k)  f[k] ^= f[k+1];
}
// -------------------------

template <typename Type>
void inverse_word_gray(Type *f, ulong ldn)
// todo: cut work by half by "integrating"
{
    ulong n = 1UL<<ldn;
    for (ulong s=1; s<n; s*=2)
    {
        // word_gray ** s:
        for (ulong k=0, j=k+s;  j<n;  ++k,++j)  f[k] ^= f[j];
    }
}
// -------------------------

template <typename Type>
void word_gray_pow(Type *f, ulong ldn, ulong x)
// result is identical to
//   for (ulong k=0; k<x; ++k)  word_gray(f, ldn);
// work <= n/2
{
    ulong n = 1UL<<ldn;
    x &= (n-1);  // modulo n
    for (ulong s=1; s<n; s*=2)
    {
        if ( x & 1)
        {
            // word_gray ** s:
            for (ulong k=0, j=k+s;  j<n;  ++k,++j)  f[k] ^= f[j];
        }
        x >>= 1;
    }
}
// -------------------------


template <typename Type>
void word_green(Type *f, ulong ldn)
{
    ulong n = 1UL<<ldn;
    for (ulong k=n-1;  0!=k;  --k)  f[k] ^= f[k-1];
}
// -------------------------

template <typename Type>
void inverse_word_green(Type *f, ulong ldn)
// todo: cut work by half by "integrating"
{
    ulong n = 1UL<<ldn;
    for (ulong s=1; s<n; s*=2)
    {
        // word_green ** s:
        for (ulong k=n-1, j=k-s;  k>=s;  --k,--j)  f[k] ^= f[j];
    }
}
// -------------------------

template <typename Type>
void word_green_pow(Type *f, ulong ldn, ulong x)
// result is identical to
//   for (ulong k=0; k<x; ++k)  word_green(f, ldn);
// work <= n/2
{
    ulong n = 1UL<<ldn;
    x &= (n-1);  // modulo n
    for (ulong s=1; s<n; s*=2)
    {
        if ( x & 1)
        {
            // word_green ** s:
            for (ulong k=n-1, j=k-s;  k>=s;  --k,--j)  f[k] ^= f[j];
        }
        x >>= 1;
    }
}
// -------------------------



#endif  // !defined HAVE_WORDGRAY_H__
