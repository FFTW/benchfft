
fxt.lsm       short description

00legal.txt   legal notice

doc/*         automatically generated docs


======== DESCRIPTION: ========
  fxt is a library package (coming as C++ source code)
  containing code for:

  --- Fast Fourier transform (FFT): ---
  Hartley transform based fft.
  Decimation in time/frequency, radix 2 & 4.
  Split radix FFT (DIT and DIF).
  Matrix (aka four-step) FFT.
  Special versions for zero padded data.
  Various versions of real valued FFTs.
  Arbitrary length FFT based on chirp filter.
  2...5 dimensional FFT
  Fractional FFT (based on chirp filter).
  Weighted FFT
  GrayCode-ordered FFT (a novel algorithm)

  --- Fast Hartley transform (FHT): ---
  Highly optimised FHT (DIF and DIT).
  2-dimensional Hartley transform.
  Short length (generated) FHTs.

  --- Number theoretic transforms (NTTs): ---
  Radix 2/4, decimation in freq./time.
  Exact integer (modular-)convolution.

  --- Fast Walsh transform ---
  Radix 2 decimation in freq./time:
  Walsh-Kronecker (wak), Walsh-Paley (pal) and
  Walsh-Kaczmarz (wal, sequency ordered).
  Dyadic convolution via Walsh transform.

  --- Convolution, correlation, power spectrum: ---
  Cyclic and linear convolution and auto convolution
  for real and complex data.
  Correlation (and auto-corr.) for real and complex data.
  Power spectrum.
  Weighted convolution; negacyclic and right angle convolution.

  --- Fast Haar transform: ---
  Haar transform and its inverse.
  Inplace version of Haar transform.
  Integer-to-integer version of Haar transform

  --- Fast wavelet transform: ---
  Fast transforms and inverses: Haar, Daubechies

  --- Fast multiplication routines: ---
  fft-multiplication and mass storage multiplication
  for high precision ('bignum') libraries
  Mass-storage convolution with size limited only by disk space.

   --- Sine and cosine transforms ---

   --- Fast z-transform ---
  based on chirp-filter

  --- Low level bit manipulation: ---
  a fast bitarray utility class
  bitcounting, bitreversal, graycode etc.
  combinatorics on binary words

  --- Combinatorics: ---
  combinations (lexicographic/numeric/minchange- order)
  permutations (lexicographic/derange/minchange- order)
  partitions / paren-pairs
  subset (numeric/minchange- order)
  general routines for permutation analysis (cycle analysis etc.)

  --- Sorting & searching: ---
  normal/index/pointer-  (both selection- and quick-) sort
  sort via compare-function (similar to C's qsort())
  sort for complex values (real-major/imag-minor)
  normal/index/pointer- search
  uniq

  --- Binary polynomials and arithmetics over GF(2**n) ---

