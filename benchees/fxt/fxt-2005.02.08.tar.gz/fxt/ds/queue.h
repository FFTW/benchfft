#if !defined  HAVE_QUEUE_H__
#define       HAVE_QUEUE_H__

#include "fxttypes.h"
#include "realloc.h"
#include "perm/rotate.h"  // rotate_left()

#include "aux1/copy.h"
#define copy fxtaux::copy // avoid unwanted std::copy

template <typename Type>
class queue
{
public:
    Type *x_;   // pointer to data
    ulong s_;   // allocated size (# of elements)
    ulong n_;   // current number of entries in buffer
    ulong wpos_;  // next position to write in buffer
    ulong rpos_;  // next position to read in buffer
    ulong gq_;  // grow gq elements if necessary, 0 for "never grow"

public:
    explicit queue(ulong n, ulong growq=0)
    {
        s_ = n;
        x_ = new Type[s_];
        n_ = 0;
        wpos_ = 0;
        rpos_ = 0;
        gq_ = growq;
    }

    ~queue()  { delete [] x_; }

    ulong n()  const  { return n_; }

    ulong push(const Type &z)
    // Return number of entries.
    // Zero is returned on failure
    //   (i.e. space exhausted and 0==gq_)
    {
        if ( n_ >= s_ )
        {
            if ( 0==gq_ )  return 0;  // growing disabled
            grow();
        }

        x_[wpos_] = z;
        ++wpos_;
        if ( wpos_>=s_ )  wpos_ = 0;

        ++n_;
        return n_;
    }

    ulong peek(Type &z)
    // Return number of entries.
    // if zero is returned the value of z is undefined.
    {
        z = x_[rpos_];
        return n_;
    }

    ulong pop(Type &z)
    // Return number of entries before pop
    // i.e. zero is returned if queue was empty.
    // If zero is returned the value of z is undefined.
    {
        ulong ret = n_;
        if ( 0!=n_ )
        {
            z = x_[rpos_];
            ++rpos_;
            if ( rpos_ >= s_ )  rpos_ = 0;
            --n_;
        }

        return ret;
    }

private:
    void grow()
    {
        ulong ns = s_ + gq_;  // new size
#ifdef USE_C_REALLOC
        rotate_left(x_, s_, rpos_);
        x_ = ReAlloc<Type>(x_, ns);
        wpos_ = s_;
        rpos_ = 0;
#else
        Type *nx = new Type[ns];
        // move read-position to zero:
        // rotate_left(x_, s_, rpos_);  copy(x_, nx, s_);
        copy_cyclic(x_, nx, s_, rpos_);
        wpos_ = s_;
        rpos_ = 0;
        delete [] x_;  x_ = nx;
#endif
        s_ = ns;
    }

};
// -------------------------


#undef copy // end (avoid unwanted std::copy)

#endif  // !defined HAVE_QUEUE_H__
