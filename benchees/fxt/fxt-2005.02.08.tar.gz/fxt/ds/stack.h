#if !defined HAVE_STACK_H__
#define      HAVE_STACK_H__

#include "fxttypes.h"

#include "aux1/copy.h"
#define copy fxtaux::copy // avoid unwanted std::copy


template <typename Type>
class stack
{
public:
    Type  *x_;  // data
    ulong  s_;  // size
    ulong  p_;  // stack pointer (position of next write), top entry @ p-1
    ulong  gq_; // grow gq elements if necessary, 0 for "never grow"

public:
    stack(ulong n, ulong growq=0)
    {
        s_ = n;
        x_ = new Type[s_];
        p_ = 0;  // stack is empty
        gq_ = growq;
    }

    ~stack()  { delete [] x_; }


private:
    stack& operator = (const stack&);  // forbidden


public:
    ulong n()  const
    // return number of entries
    {
        return p_;
    }

    ulong push(Type z)
    // return size of stack, zero on stack overflow
    // if gq_ is non-zero the stack grows
    {
        if ( p_ >= s_ )
        {
            if ( 0==gq_ )  return 0;  // overflow
            grow();
        }

        x_[p_] = z;
        ++p_;

        return  s_;
    }

    ulong pop(Type &z)
    // read top entry and remove it
    // return number of entries at function start
    // if empty return zero and z is undefined
    {
        ulong ret = p_;
        if ( 0!=p_ )  { --p_;  z = x_[p_]; }
        return  ret;
    }

    ulong poke(Type z)
    // modify top entry
    // return number of entries
    // if empty return zero and nothing is done
    {
        if ( 0!=p_ )  x_[p_-1] = z;
        return p_;
    }

    ulong peek(Type &z)
    // read top entry (without removing it)
    // return number of entries
    // if empty return zero and z is undefined
    {
        if ( 0!=p_ )  z = x_[p_-1];
        return p_;
    }

private:
    void grow()
    {
        ulong ns = s_ + gq_;  // new size
#ifdef USE_C_REALLOC
        x_ = ReAlloc<Type>(x_, ns)
#else
        Type *nx = new Type[ns];
        copy(x_, nx, s_);
        delete [] x_;  x_ = nx;
#endif
        s_ = ns;
    }
};
// -------------------------


#undef copy // end (avoid unwanted std::copy)

#endif // !defined HAVE_STACK_H__
