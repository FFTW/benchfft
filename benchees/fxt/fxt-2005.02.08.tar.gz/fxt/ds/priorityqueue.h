#if !defined  HAVE_PRIORITYQUEUE_H__
#define       HAVE_PRIORITYQUEUE_H__


#include "fxttypes.h"
#include "realloc.h"

#include "aux1/copy.h"
#define copy fxtaux::copy // avoid unwanted std::copy

#include "aux0/swap.h"


//<<
#if  1
// next() is the one with the smallest key
// i.e.  extract_next()  is  extract_min()
#define _CMP_ <
#define _CMPEQ_ <=
#else
// next() is the one with the biggest key
// i.e.  extract_next()  is  extract_max()
#define _CMP_ >
#define _CMPEQ_ >=
#endif
//>>

template <typename Type1, typename Type2>
class priority_queue
{
public:
    Type1 *t_;  // time:   t[0..s-1]
    Type2 *e_;  // events: e[0..s-1]
    ulong s_;   // allocated size (# of elements)
    ulong n_;   // current number of events
    ulong gq_;  // grow gq elements if necessary, 0 for "never grow"

public:
    priority_queue(ulong n, ulong growq=0)
    {
        s_ = n;
        t_ = new Type1[s_];
        e_ = new Type2[s_];
        n_ = 0;
        gq_ = growq;
    }

    ~priority_queue()  { delete [] t_;  delete [] e_; }

    ulong n()  const  { return n_; }

    Type1 get_next(Type2 &e)  const
    // No check if empty
    {
        e = e_[0];
        return t_[0];
    }

    void heapify1(Type1 *t1, ulong n, ulong k, Type2 *e1)
    // events in         e1[1..n]
    // time of events in t1[1..n]
    {
        ulong m = k;
        ulong l = (k<<1); // left(k);
        if ( (l <= n) && (t1[l] _CMP_ t1[k]) )  m = l;
        ulong r = (k<<1) + 1; // right(k);
        if ( (r <= n) && (t1[r] _CMP_ t1[m]) )  m = r;
        if ( m != k )
        {
            swap2(t1[k], t1[m]);  swap2(e1[k], e1[m]);
            heapify1(t1, n, m, e1);
        }
    }

    Type1 extract_next(Type2 &e)
    {
        Type1 m = get_next(e);
        if ( 0 != n_ )
        {
            Type1 *t1 = t_ - 1;
            Type2 *e1 = e_ - 1;
            t1[1] = t1[n_];  e1[1] = e1[n_];
            --n_;
            heapify1(t1, n_, 1, e1);
        }
        // else error
        return m;
    }

    bool insert(const Type1 &t, const Type2 &e)
    // Insert event e at time t
    // Return true if successful
    // else (i.e. space exhausted and 0==gq_) false
    {
        if ( n_ >= s_ )
        {
            if ( 0==gq_ )  return false;  // growing disabled
            grow();
        }

        ++n_;
        Type1 *t1 = t_ - 1;
        Type2 *e1 = e_ - 1;
        ulong j = n_;
        while ( j > 1 )
        {
            ulong k = (j>>1);  // k==parent(j)
            if ( t1[k] _CMPEQ_ t )  break;
            t1[j] = t1[k];  e1[j] = e1[k];
            j = k;
        }
        t1[j] = t;
        e1[j] = e;

        return true;
    }

private:
    void grow()
    {
        ulong ns = s_ + gq_;  // new size
#ifdef USE_C_REALLOC
        t_ = ReAlloc<Type1>(t_, ns);
        e_ = ReAlloc<Type2>(e_, ns);
#else
        Type1 *nt = new Type1[ns];
        copy(t_, nt, s_);
        Type2 *ne = new Type2[ns];
        copy(e_, ne, s_);
        delete [] t_;  t_ = nt;
        delete [] e_;  e_ = ne;
#endif
        s_ = ns;
    }
};
// -------------------------

#undef _CMP_
#undef _CMPEQ_

#undef copy // end (avoid unwanted std::copy)

#endif  // !defined HAVE_PRIORITYQUEUE_H__
