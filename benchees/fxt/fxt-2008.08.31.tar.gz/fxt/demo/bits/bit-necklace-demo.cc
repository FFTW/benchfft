
#include "bits/bit-necklace.h"

#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong

#include "bits/bitsperlong.h"
#include "jjassert.h"

#include "demo/nextarg.h" // NXARG()

#include "bits/printbin.h"
#include "bits/bit2pow.h"

//% Binary necklaces and Lyndon words: CAT generation.


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 8;
    NXARG(n, "Number of bits 0<n<=BITS_PER_LONG");
    jjassert( n>0 );
    jjassert( n<=BITS_PER_LONG );

    bit_necklace N(n);

    ulong nct = 0;  // count necklaces (prime strings)
    ulong lct = 0;  // count Lyndon words
    do
    {
        ++nct;
#ifndef TIMING
        cout << setw(4) << nct << ": ";
        print_bin("  ", N.data(), n);
        cout << "  " << setw(2) << N.period();
        if ( N.is_lyndon_word() )
        {
            ++lct;
            cout << "  L";
        }
        cout << endl;
#endif  // TIMING
    }
    while ( N.next() );

//    cout << " n = " << n << ":  ";
    cout << "  # necklaces=" << nct;
#ifndef TIMING
    cout << "  # Lyndon words=" << lct;
#endif  // TIMING
    cout << endl;


    return 0;
}
// -------------------------

/*
Timing:

// with highest_zero_idx() in next():
 % time ./bin 32
  # necklaces=134219796
./bin 32  2.91s user 0.00s system 99% cpu 2.909 total
 ==> 134219796/2.91 == 46,123,641 per second
 (using  # pre-necklaces == 277737797 )
 ==> 277737797/2.91 == 95,442,541 pre-necklaces per second

// with explicit bit scan in next():
 % time ./bin 32
  # necklaces=134219796
./bin 32  2.47s user 0.01s system 100% cpu 2.483 total
 ==> 134219796/2.47 == 54,339,998 per second
 ==> 277737797/2.47 == 112,444,452 pre-necklaces per second

BENCHARGS=34
*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/bit-necklace-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/bit-necklace-demo.cc DEMOFLAGS=-DTIMING"
/// End:

