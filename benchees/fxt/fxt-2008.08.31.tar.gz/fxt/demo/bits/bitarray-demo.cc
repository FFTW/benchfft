
#include "ds/bitarray.h"

#include "fxttypes.h"
#include "jjassert.h"
#include "fxtio.h"

//% Demo of the bitarray data structure.


#define  PRINT_DO(x) \
 { x;  cout << (#x) << " ==>" << endl;  ba.dump_bits(1); }

#define  PRINT_VAL(x) \
 { ulong t = x;  cout << #x << " ==> " << (t?1:0) << " (" << t << ")" << endl; }

#define  PRINT_DO_VAL(x) \
 { ulong t = x;   cout << #x << " ==> " << t << endl;  ba.dump_bits(1); }


int
main()
{
    bitarray ba(60);
    ba.clear_all();
    ba.dump(); cout << endl;

    PRINT_DO( ba.set_all() );
    PRINT_VAL( ba.all_set_q() );
    jjassert( ba.all_set_q() );

    PRINT_DO( ba.clear_all() );
    PRINT_VAL( ba.all_clear_q() );
    jjassert( ba.all_clear_q() );

    PRINT_DO( ba.set(12) );
    PRINT_DO( ba.set(13) );
    PRINT_DO( ba.set(33) );

    PRINT_VAL( ba.test(42) );
    PRINT_VAL( ba.test(43) );
    PRINT_VAL( ba.test(44) );

    PRINT_VAL( ba.next_set(13) );
    PRINT_VAL( ba.next_set(14) );
//    PRINT_VAL( ba.next_set(999) );

    PRINT_VAL( ba.test(13) );
    PRINT_VAL( ba.test(14) );
//    PRINT_VAL( ba.test(999) );

    PRINT_DO_VAL( ba.test_set(24) );
    PRINT_DO_VAL( ba.test_clear(24) );
    PRINT_DO_VAL( ba.test_change(24) );

    return 0;
}
// -------------------------

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/bitarray-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/bitarray-demo.cc DEMOFLAGS=-DTIMING"
/// End:

