
#include "bits/hilbert.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

//% TeX picture of the Hilbert curve.


int
main(int argc, char **argv)
{
    ulong ldn = 6;
    NXARG(ldn,"number of moves == 2**ldn");
    ulong n = 1UL<<ldn;

    ulong tx, ty; 
    ulong x = 0, y = 0; 
    for (ulong t=1; t<n; ++t)
    {
        tx = x;
        ty = y;
        lin2hilbert(t, x, y);
        long dx = x - tx;
        long dy = y - ty;
        cout << "\\put(" << tx << "," << ty << ")"
             << "{\\vector(" << dx <<","<< dy << ")"
             << "{" << 1.0 << "}}" << endl;
        
    }

    return 0;
}
// -------------------------

/*
Embedding LaTeX code is:

\begin{figure}
\begin{center}
\setlength{\unitlength}{6.0mm}
\begin{picture}(7.5,7.5)(0,-0.3)
  \thicklines
 [OUTPUT of the program HERE] <--= there!
\end{picture}
\end{center}
\caption{\jjlabel{fig:hilbert2d}
The Hilbert curve.}
\end{figure}
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/hilbert-texpic-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/hilbert-texpic-demo.cc DEMOFLAGS=-DTIMING"
/// End:

