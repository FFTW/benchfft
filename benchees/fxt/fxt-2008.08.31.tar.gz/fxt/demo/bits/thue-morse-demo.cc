
#include "bits/thue-morse.h"

#include "demo/nextarg.h"

//% Generate the Thue-Morse sequence

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 64;
    NXARG(n, "Print this many values of the sequence.");
    ulong k = 0;
    NXARG(k, "Start point of the sequence.");

    thue_morse S(k);
    for (ulong j=0; j<n; ++j)
    {
#ifndef TIMING
        cout << (S.data() ? '1' : '.');
#endif
        S.next();
    }
    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:

 time ./bin $(( 2**30 ))
arg 1: 1073741824 == n  [Print this many values of the sequence.]  default=64
arg 2: 0 == k  [Start point of the sequence.]  default=0
./bin $(( 2**30 ))  2.46s user 0.00s system 99% cpu 2.466 total
 ==> 1073741824/2.46 == 436,480,416 per second

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/thue-morse-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/thue-morse-demo.cc DEMOFLAGS=-DTIMING"
/// End:
