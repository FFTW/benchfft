
#include "bits/negbin.h"

#include "bits/printbin.h"  // print_bin()
#include "fxtiomanip.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

#include "jjassert.h"


//% radix(-2) representations: successive generation.


//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Number of bits");
    bool fq = 1;
    NXARG(fq, "Whether to use increasing order");

    ulong ct = 0;

    const ulong pn = n+3;
    const ulong N = 1UL << n;
    ulong t = 0;
    if ( fq )
    {
        do
        {
#ifndef TIMING
            cout << setw(4) << ct;
            print_bin(": ", t, pn);
//            print_bin(": ", prev_negbin(t), pn);
            cout << endl;
#endif
            t = next_negbin(t);
            ++ct;
        }
        while ( ct<N );
    }
    else
    {
        do
        {
#ifndef TIMING
            cout << setw(4) << -(long)ct;
            print_bin(": ", t, pn);
            cout << endl;
#endif
            t = prev_negbin(t);
            ++ct;
        }
        while ( ct<N );
    }

    cout << "ct=" << ct << endl;

#ifdef TIMING
    cout << "dummy=" << t << endl;
#endif

    return 0;
}
// -------------------------

/*
Timing:

forward:
% time ./bin 32 1
arg 1: 32 == n  [Number of bits]  default=5
arg 2: 1 == fq  [Whether to use increasing order]  default=1
ct=4294967296
./bin 32 1  9.77s user 0.05s system 99% cpu 9.820 total
 ==> 4294967296/9.77 == 439,607,706  words per second

backward: (same rate)

forward (version without masks): (same rate)
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/negbin2-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/negbin2-demo.cc DEMOFLAGS=-DTIMING"
/// End:

