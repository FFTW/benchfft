
#include "bits/bitsequency.h"

#include "bits/printbin.h"

#include "demo/nextarg.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "jjassert.h"


//% Generating bit sets of given sequency.


//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong pd = 6;
    NXARG(pd, "Word size in bits");

    ulong Ct = 1;
    for (ulong i=0; i<pd ; ++i)
    {
        ulong c = first_sequency(i+1);

#ifndef TIMING
        cout << endl;
        cout << "   sequency = " << bit_sequency(c) << endl;
        print_bin(" ", c, pd);
//        print_bin("    ", c ^ 0xaaaaaaaaUL, pd);  // negated sequency
        cout << endl;
#endif

        ulong ct = 0;
        do
        {
            ++ct;
            c = next_sequency(c);

            // special condition for pd-bit demo:
            if ( c>=(1UL<<pd) )  break;

#ifndef TIMING
            print_bin(" ", c, pd);
//            print_bin("    ", c ^ 0xaaaaaaaaUL, pd);  // negated sequency
            cout << endl;
            jjassert( bit_sequency(c)==(i+1) );
#endif
        }
        while ( c );

        Ct += ct;
#ifndef TIMING
        cout << " ct == " << ct;
        cout << "    Ct == " << Ct;
        cout << endl;
#endif
    }

#ifdef TIMING
    cout << " Ct = " << Ct;
#endif
    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:
time ./bin 29
arg 1: 29 == pd  [Word size in bits]  default=6
 Ct = 536870912
./bin 29  9.65s user 0.00s system 100% cpu 9.652 total
 ==> 536870912/9.65 == 55,634,291 per second

BENCHARGS=29

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/bitsequency-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/bitsequency-demo.cc DEMOFLAGS=-DTIMING"
/// End:

