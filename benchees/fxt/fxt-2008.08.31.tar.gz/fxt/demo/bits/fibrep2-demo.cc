

#include "bits/fibrep.h"

#include "bits/printbin.h"  // print_bin()
#include "fxtiomanip.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong
#include "bits/bitsperlong.h"

#include "jjassert.h"


//% Fibonacci representations: successive generation.


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "Number of bits");
    jjassert( n<BITS_PER_LONG );
    bool fq = 1;
    NXARG(fq, "Whether to use increasing order");

    ulong ct = 0;


    if ( fq )
    {
        const ulong f = 1UL << n;
        ulong t = 0;
        do
        {
#ifndef TIMING
            cout << setw(4) << ct;
            print_bin(": ", t, n);
            cout << endl;
#endif
            ++ct;
            t = next_fibrep(t);
        }
        while ( t!=f );
    }
    else
    {
        ulong f = 1UL << n;
        while ( f )
        {
            ulong t = prev_fibrep(f);
            f = t;
#ifndef TIMING
            cout << setw(4) << ct;
            print_bin(": ", t, n);
            cout << endl;
#endif
            ++ct;
        }
    }

    cout << "ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:

forward:
% time ./bin 40 1
arg 1: 40 == n  [Number of bits]  default=7
arg 2: 1 == fq  [Whether to use increasing order]  default=1
ct=267914296
./bin 40 1  1.33s user 0.02s system 99% cpu 1.355 total
 ==> 267914296/1.33 == 201,439,320 per second

time ./bin 44 1
arg 1: 44 == n  [Number of bits]  default=7
arg 2: 1 == fq  [Whether to use increasing order]  default=1
ct=1836311903
./bin 44 1  10.02s user 0.00s system 100% cpu 10.022 total
 ==> 1836311903/10.02 == 183,264,660 per second

BENCHARGS=44 1


backward:
% time ./bin 40 0
arg 1: 40 == n  [Number of bits]  default=7
arg 2: 0 == fq  [Whether to use increasing order]  default=1
ct=267914296
./bin 40 0  1.96s user 0.01s system 99% cpu 1.963 total
 ==> 267914296/1.96 == 136,690,967 per second

backward, with second version in fibrep.h:
% time ./bin 40 0  //
arg 1: 40 == n  [Number of bits]  default=7
arg 2: 0 == fq  [Whether to use increasing order]  default=1
ct=267914296
./bin 40 0  2.56s user 0.01s system 99% cpu 2.576 total
 ==> 267914296/2.56 == 104,654,021 per second
*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/fibrep2-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/fibrep2-demo.cc DEMOFLAGS=-DTIMING"
/// End:

