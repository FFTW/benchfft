
#include "bits/zorder.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

//% TeX picture of the z-order curve.


int
main(int argc, char **argv)
{
    ulong ldn = 6;
    NXARG(ldn,"number of moves == 2**ldn");
    ulong n = 1UL<<ldn;

    ulong tx, ty; 
    ulong x = 0, y = 0; 
    for (ulong t=1; t<n; ++t)
    {
        tx = x;
        ty = y;
        lin2zorder(t, x, y);
        cout << "\\curve(" << tx << "," << ty << ", " << x <<","<< y << ")" << endl;
    }

    return 0;
}
// -------------------------

/*
Embedding LaTeX code is:

\usepackage{curves}% <--=  before \begin{document}

\begin{figure}%[hbt]
\begin{center}
\setlength{\unitlength}{6.0mm}
\begin{picture}(7.5,7.5)(0,-0.3)
  \thicklines
 [OUTPUT of the program HERE] <--= there!
\end{picture}
\end{center}
\caption{\jjlabel{fig:hilbert2d}
The Z-order curve.}
\end{figure}

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/bits"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/bits/zorder-texpic-demo.cc"
/// make-target2: "1demo DSRC=demo/bits/zorder-texpic-demo.cc DEMOFLAGS=-DTIMING"
/// End:

