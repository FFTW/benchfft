
#include "ds/heap.h"
#include "ds/priorityqueue.h"

#include "fxttypes.h"
#include "sort/monotone.h"


#include "aux1/arith1.h"
#include "perm/reverse.h"

#include "aux0/randf.h"  // rnd01()

#include "jjassert.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include "demo/nextarg.h" // NXARG()

#include "aux1/copy.h"


//% Priority queue.


void
print(const char *bla, const double *f, ulong n)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        double r = f[k];

        cout.flags(ios::right);
        cout << setw(4) << k << ":  ";

        cout.precision(5);
        cout.flags(ios::left);
        cout << setw(8) << r;
        cout << endl;
    }
    cout << endl;
}
// -------------------------


//#define RSEED

int
main(int argc, char **argv)
{
#ifdef  RSEED
    cout << " rseed=" << rseed() << endl;
#endif

    ulong n = 10;
    NXARG(n, "Number of elements (0<n<=26)");

//    priority_queue<double, double> pq(n);
    priority_queue<double, char> pq(3, 2); // check grow

    double *t = new double[n];
    char *e = new char[n];
    rnd01(t, n);
//    print("random values:", t, n);
    for (ulong k=0; k<n; ++k)  e[k] = 'A' + k;  // events names are A, B, C, ...

    cout << endl;
    cout << "Inserting into piority_queue:" << endl;
    cout << setw(2) << "# " << ": ";
    cout << setw(6) << " event"
         << "  @  " << setw(12) << "time" << endl;
    for (ulong k=0; k<n; ++k)
    {
        char ev = e[k];
        double tev = t[k];
        cout << setw(2) << k << ": "
             << setw(6) << ev
             << "  @  " << setw(12) << tev << endl;
        jjassert( pq.insert(t[k], e[k]) );
    }

    cout << endl;
    cout << "Extracting from piority_queue:" << endl;
    cout << setw(2) << "# " << ": "
         << setw(6) << " event"
         << "  @  " << setw(12) << "time" << endl;
    ulong k = n;
    while ( k )
    {
        --k;

        jjassert( pq.num() );
        char ev;
        double tev = pq.extract_next(ev);
        cout << setw(2) << k << ": "
             << setw(6) << ev
             << "  @  " << setw(12) << tev << endl;

        t[k] = tev;
        e[k] = ev;
    }
    jjassert( 0==pq.num() );

//    print("t-values:", t, n);
    jjassert( is_monotone(t, n) );

//    print("e-values:", e, n);
//    jjassert( is_monotone(e, n) );

    delete [] t;
    delete [] e;

    return 0;
}
// -------------------------


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/ds"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/ds/priorityqueue-demo.cc"
/// make-target2: "1demo DSRC=demo/ds/priorityqueue-demo.cc DEMOFLAGS=-DTIMING"
/// End:

