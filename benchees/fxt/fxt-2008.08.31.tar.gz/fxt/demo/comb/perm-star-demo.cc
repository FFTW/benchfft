
#include "comb/perm-star.h"

//#include "perm/permq.h"
//#include "comb/fact2perm.h"
//#include "comb/mixedradix.h"
//#include "comb/comb-print.h"

#include "comb/check-permgen.h"
#include "jjassert.h"

#include "fxttypes.h"
#include "demo/nextarg.h"  // NXARG()
#include "fxtio.h"


//% Generate all permutations in star-transposition order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");
    bool dfz = true;  // whether to print dots for zeros

    perm_star P(n);
//    ulong *fc = new ulong[n-1];

    check_permgen C(n);
    C.first( P.invdata() );  // inverse permutations(!)
    const ulong nfh = factorial(n)/2;

#ifdef TIMING
    while ( P.next() )  {;}
#else
    ulong ct = 0;
    do
    {
        cout << setw(4) << ct << ":";
        ++ct;

        P.print("    ", dfz);
        cout << "    (" << 0 << ", " << P.get_swap() << ") ";
        P.print_inv("    ", dfz);

//        perm2rfact(P.data(), n, fc);
//        print_mixedradix("    ", fc, n-1);

        cout << endl;

        if ( ct<nfh ) 
        {
            jjassert( ! C.is_repeat() );
            jjassert( ! C.is_repeat_rev() );
        }
    }
    while ( P.next() );
#endif

//    delete [] fc;

    return 0;
}
// -------------------------

/*
Timing:
time ./bin 12

./bin 12  6.14s user 0.02s system 99% cpu 6.163 total
 ==> 12!/6.163 == 77,722,148 permutations per second (with inverse)

./bin 12  4.15s user 0.02s system 100% cpu 4.173 total
 ==>  12!/4.173 == 114,785,909 (without inverse)
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-star-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-star-demo.cc DEMOFLAGS=-DTIMING"
/// End:

