
#include "comb/rgs-fincr.h"


//#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% All restricted growth strings (RGS) s[0,...,n-1]
//%   so that  s[k] <= F[j]+i  where
//%  F[0]=i, F[j+1]=( a[j+1]-a[j]==i ?  F[j]+i : F[j] )
//% Lexicographic order


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Length of restricted growths strings");
    ulong i = 2;
    NXARG(i, "Increment allowed (1==> set partitions)");
    // i=1 ==> Bell numbers A000110
    // i=2 ==> A004211,  i=3 ==> A004212,  i=4 ==> A004213
    // i=5 ==> A005011,  i=6 ==> A005012
    // i=x ==> "shifts one place left under x-th order binomial transform"
    //          a(n)=sum((x^(n-k))*stirling2(n, k)

    rgs_fincr R(n, i);

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(3) << ct << ":  ";
        R.print(true);
        cout << endl;
#endif // TIMING
    }
    while ( R.next() );

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------


/*
Timing:
time ./bin 12
 ct = 487026929
./bin 12  3.58s user 0.02s system 99% cpu 3.602 total
 ==>  136,041,041 RGS/sec
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/rgs-fincr-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/rgs-fincr-demo.cc DEMOFLAGS=-DTIMING"
/// End:

