
#include "comb/partition.h"

#include "fxttypes.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtio.h"

//% Generate all integer partitions, iterative algorithm.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 6;
    NXARG(n, "Partitions of n");
    bool sq = 0;
    NXARG(sq, "Whether to print cumulative sums");
    partition P(n);

//    P.last();
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << "    #" << setw(2) << ct << ": ";
        cout << setw(4) << P.n_ << " == ";
        P.print2();
        cout << "  ==  ";  P.print();
        cout << endl;

        if ( sq )
        {
            cout << "       sums: ";
            for (ulong k=2; k<=n; ++k)  cout << setw(7) << P.s_[k];
            cout << endl;
            cout << endl;
        }
        jjassert( P.OK() );
#endif // TIMING
        ++ct;
    }
    while ( P.next() );
//    while ( P.prev() );


    cout << " " << n << ":  ct=" << ct << endl;
    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:
 % time ./bin 100
arg 1: 100 == n  [Partitions of n]  default=6

forward:
 100:  ct=190569292
./bin 100  1.35s user 0.00s system 99% cpu 1.351 total
 ==>  141,162,438 part/sec

backwards:
 100:  ct=190569292
./bin 100  3.30s user 0.01s system 99% cpu 3.308 total  // line  q = z/i;
 ==> 57,748,270 part/sec
./bin 100  2.86s user 0.00s system 99% cpu 2.865 total  // line  q = (z>=i ? z/i : 0);
 ==> 66,632,619 part/sec
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/partition-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/partition-demo.cc DEMOFLAGS=-DTIMING"
/// End:

