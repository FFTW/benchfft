
#include "comb/perm-heap2-swaps.h"

#include "comb/mixedradix.h"
#include "comb/comb-print.h"
#include "aux0/swap.h"

#include "fxtio.h"
#include "demo/nextarg.h"
#include "jjassert.h"
#include "fxttypes.h"


//% Swaps for Gray code for permutations, CAT algorithm, optimized version.
//% Algorithm following B.R.Heap (1963)

//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute n>=3");
    jjassert( n>=3 );
    bool dfz= true; // whether to print dots for zeros


    perm_heap2_swaps P(n);
    P.first();

    ulong *x = new ulong[n];  // permutations
    ulong *xi = new ulong[n];  // inverse permutations
    for (ulong k=0; k<n; ++k)  x[k] = xi[k] = k;

#ifdef TIMING
//    do { ; }  while ( P.next() );

    ulong zz = 0;
    do { zz^=(P.sw1_^P.sw2_); }  while ( P.next() );
    return (zz==999);  // zz<=n

#else
    ulong ct = 0;
    do
    {
        cout << setw(4) << ct << ":";
        ulong sw1, sw2;
        P.get_swap(sw1, sw2);
        swap2( x[sw1], x[sw2]);  // update permutation
        print_perm("    ", x, n, dfz);

//        cout << " (" << P.ct_ << ") ";
//        cout << " (" << P.fc_ << ") ";

        cout << "     (" << sw1 << ", " << sw2 << ") ";

//        print_mixedradix("    ", P.d_+2, n-3, dfz);

        swap2( xi[x[sw1]], xi[x[sw2]] );  // update inverse permutation
        print_perm("    ", xi, n, dfz);

        cout << endl;
        ++ct;
    }
    while ( P.next() );
    cout << endl;
    cout << " ct=" << ct << endl;
#endif

    cout << endl;

    delete [] x;
    delete [] xi;

    return 0;
}
// -------------------------

/*
Timing:

arrays, and XOR-ing sw1 and sw2:
 time ./bin 13
arg 1: 13 == n  [Number of elements to permute n>=3]  default=4
./bin 13  16.06s user 0.01s system 99% cpu 16.071 total
 ==> 13!/16.06 == 387,734,794 per second
 ==> 5.67 cycles per udate

pointers, and XOR-ing sw1 and sw2:
 % time ./bin 13
arg 1: 13 == n  [Number of elements to permute n>=3]  default=4
./bin 13  16.31s user 0.04s system 99% cpu 16.352 total
 ==> 13!/16.31 == 381,791,587 per second
 ==> 5.76 cycles per udate

arrays:
time ./bin 13
./bin 13  9.82s user 0.04s system 99% cpu 9.854 total
 ==> 13!/9.82 == 634,116,171 per second
 ==> 3.47 cycles per udate

pointers:
time ./bin 13
 ct=6227020800
./bin 13  10.64s user 0.04s system 100% cpu 10.676 total
 ==> 13!/10.64 == 585,246,315 per second
 ==> 3.76 cycles per udate



BENCHARGS=13

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-heap2-swaps-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-heap2-swaps-demo.cc DEMOFLAGS=-DTIMING"
/// End:

