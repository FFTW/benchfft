
#include "comb/combination-chase.h"
#include "aux0/binomial.h"

#include "comb/comb-print.h"

#include "fxttypes.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtiomanip.h"

//% Combinations in near-perfect minimal-change order (Chase's sequence).

//#define TIMING // uncomment to disable printing

void
visit(const combination_chase &C, ulong ct)
{
    cout << setw(4) << ct << ":";
    const ulong *x = C.data();
    const ulong n = C.n_;
    print_deltaset_as_set("  ", x, n);  // zero based
//    print_deltaset_as_set1("  ", x, n);  // one based
    print_deltaset("  ", x, n);
    cout << endl;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "Combinations (n choose k): n>=1");
    ulong k = 3;
    NXARG(k, " 1<=k<=n");

    if ( (k>n) || ( k==0 ) || ( n==0 ) )  { return 1; }

    combination_chase C(n,k);

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        visit(C, ct);
#endif
    }
    while ( C.next() );

    ulong bnk =  binomial(n, k);
    cout << "binomial(" << n << ", " << k << ")=" << bnk << endl;
    jjassert( bnk==ct );
    cout << endl;

    return 0;
}
// -------------------------

// for n in $(seq 1 10); do for k in $(seq 1 $n); do ./bin $n $k || break 2; done; done

/*
Timing:
% time ./bin 32 20
binomial(32, 20)=225792840
./bin 32 20  3.51s user 0.02s system 99% cpu 3.540 total
 ==> 225792840/3.51 == 64,328,444 objects per second

% time ./bin 32 12  is identical
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/combination-chase-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/combination-chase-demo.cc DEMOFLAGS=-DTIMING"
/// End:

