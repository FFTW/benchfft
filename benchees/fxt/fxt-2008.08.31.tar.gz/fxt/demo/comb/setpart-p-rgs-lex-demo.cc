
#include "comb/setpart-p-rgs-lex.h"

// demo-include "comb/setpart-p-rgs-lex.cc"

#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% Set partitions into p parts as restricted growth strings (RGS).

//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Partition set of n elements");
    ulong p = 3;
    NXARG(p, "Partitions into p parts (2<=p<=n)");
    jjassert( p>=2 );
    jjassert( p<=n );

    setpart_p_rgs_lex P(n, p);
    P.first(p);

    ulong ct = 0;

#ifdef TIMING
    do { ++ct; }  while ( P.next() );

#else

    do
    {
        ++ct;
        cout << setw(3) << ct << ":  ";
        P.print();
        cout << "    ";  P.print_set();
        cout << endl;
        jjassert ( P.m_[n]==p );
    }
    while ( P.next() );
#endif

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:

 time ./bin 15 8
arg 1: 15 == n  [Partition set of n elements]  default=5
arg 2: 8 == p  [Partitions into p parts]  default=3
 ct = 216627840
./bin 15 8  2.00s user 0.00s system 99% cpu 2.005 total
 ==> 216627840/2.00 == 108,313,920 per second

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/setpart-p-rgs-lex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/setpart-p-rgs-lex-demo.cc DEMOFLAGS=-DTIMING"
/// End:

