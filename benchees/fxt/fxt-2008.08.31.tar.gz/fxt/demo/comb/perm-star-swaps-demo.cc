
#include "comb/perm-star-swaps.h"

#include "perm/permq.h"
#include "comb/comb-print.h"

#include "fxttypes.h"
#include "demo/nextarg.h"  // NXARG()
#include "fxtio.h"

//% Generate swaps for permutations in star-transpostion order.

//#define TIMING // uncomment to disable printing



int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");
    bool dfz= true; // whether to print dots for zeros
//    jjassert( n>=3 );

    perm_star_swaps P(n);
    P.first();

    ulong *x = new ulong[n];  // permutations
    ulong *xi = new ulong[n];  // inverse permutations
    for (ulong k=0; k<n; ++k)  x[k] = xi[k] = k;

    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << setw(4) << ct << ":";
        ulong sw1, sw2;
        P.get_swap(sw1, sw2);
        swap2( x[sw1], x[sw2]);  // update permutation
        print_perm("    ", x, n, dfz);

        cout << "     (" << sw1 << ", " << sw2 << ") ";

        swap2( xi[x[sw1]], xi[x[sw2]]);  // update inverse permutation
        print_perm("    ", xi, n, dfz);

        cout << endl;
#endif
        ++ct;
    }
    while ( P.next() );

    cout << endl;
    cout << " ct=" << ct << endl;
    cout << endl;

    delete [] x;
    delete [] xi;

    return 0;
}
// -------------------------


/*
Timing:
time ./bin 12
./bin 12  3.02s user 0.02s system 99% cpu 3.043 total
 ==> 158,609,801 permutations per second
 ==> 13.87 cycles per update

time ./bin 13
./bin 13  39.32s user 0.20s system 99% cpu 39.554 total
 ==> 158,367,772 permutations per second
 ==> 13.89 cycles per update
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-star-swaps-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-star-swaps-demo.cc DEMOFLAGS=-DTIMING"
/// End:

