
#include "comb/cyclic-perm.h"
// demo-include "comb/fact2cyclic.cc"
// demo-include "comb/mixedradix-gray.h"

#include "comb/fact2perm.h"
#include "perm/printcycles.h"

#include "comb/comb-print.h"
#include "comb/mixedradix.h"
#include "perm/perminvert.h"

#include "fxtio.h"
#include "fxttypes.h"
#include "demo/nextarg.h"

#include "jjassert.h"
#include "perm/permq.h"  // is_cyclic()


//% Generate all cyclic permutations in minimal-change order, CAT algorithm.


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Cyclic permutations of n elements.");

    cyclic_perm P(n);
    ulong *t = new ulong[n];
    const ulong *x = P.data();
    const ulong *ix = P.invdata();
    const ulong *a = P.M_->data();
    const ulong z = P.M_->n_;
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << setw(4) << ct << ":";

        print_perm("    ", x, n);
//        print_perm("    ", ix, n);

        print_mixedradix("    ", a, z, true);

        cout << "    ";
        print_cycle(x, n-1);
        cout << endl;

        ffact2cyclic(a, n, t);
        for (ulong i=0; i<n; ++i)  { jjassert(t[i]==ix[i]); }

        jjassert( is_cyclic(x, n) );
        jjassert( is_inverse(x, ix, n) );

        ++ct;
#endif
    }
    while ( P.next() );

    delete [] t;

    return 0;
}
// -------------------------


/*
Timing:
% time ./bin 13
./bin 13  12.15s user 0.06s system 99% cpu 12.219 total
 ==> 12!/12.15 == 39,424,000 per second

BENCHARGS=13

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/cyclic-perm-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/cyclic-perm-demo.cc DEMOFLAGS=-DTIMING"
/// End:

