
#include "comb/paren.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "comb/comb-print.h"

#include "demo/nextarg.h"
#include "jjassert.h"


//% Generate all well-formed pairs of parenthesis in co-lexicographic order.

//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong k = 5;
    NXARG(k, "Number of paren pairs >=2");

    bool bwq = 0;
    NXARG(bwq, "Whether to also generate in backward direction");

    ulong n = 2*k;
    ulong ct = 0;

    paren par(k);

    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(3) << ct << ":  ";
        cout << par.string() << "  ";
        print_set_as_deltaset("", par.data(), k, n );
        cout << endl;
        jjassert( par.OK() );
#endif // TIMING
    }
    while ( par.next() );

#ifndef TIMING
    cout << endl;
    if ( bwq )
    {
        par.last();
        do
        {
            --ct;
            cout << "  " << par.string() << "  ";
            print_set_as_deltaset("", par.data(), k, n );
            cout << "  #" << setw(3) << ct;
//            for (ulong j=0; j<k; ++j)  cout << "  " << par.data()[j];
            cout << endl;
            jjassert( par.OK() );
        }
        while ( par.prev() );
        cout << endl;
        jjassert( 0==ct );
    }
#else // TIMING
    cout << " ct = " << ct << endl;
#endif // TIMING

    return 0;
}
// -------------------------


/*
Timing:

 time ./bin 18
arg 1: 18 == k  [Number of paren pairs >=2]  default=5
arg 2: 0 == bwq  [Whether to also generate in backward direction]  default=0
 ct = 477638700
./bin 18  7.08s user 0.02s system 100% cpu 7.095 total
 ==> 477638700/7.08 == 67,463,093 per second

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/paren-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/paren-demo.cc DEMOFLAGS=-DTIMING"
/// End:

