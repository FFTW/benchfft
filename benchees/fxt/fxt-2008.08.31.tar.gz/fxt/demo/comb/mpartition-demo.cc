
#include "comb/mpartition.h"

#include "fxtiomanip.h"
#include "demo/nextarg.h"

//% Integer partitions of n into m parts

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 19;
    NXARG(n, "integers partitions of n");
    ulong m = 11;
    NXARG(m, "partitions into m parts");

    mpartition P(n, m);
    const ulong *x = P.data();
    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(3) << ct << ": ";
        for (ulong k=0; k<m; ++k)  cout << " " << x[k];
        cout << endl;
#endif
    }
    while ( P.next() );

    cout << "#part = " << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:
arg 1: 140 == n  [integers partitions of n]  default=10
arg 2: 20 == m  [partitions into m parts]  default=4
#part = 693703134
./bin 140 20  6.44s user 0.04s system 99% cpu 6.478 total
 ==> 6.44/693,703,134 == 10,7717,877 partitions/ second
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/mpartition-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/mpartition-demo.cc DEMOFLAGS=-DTIMING"
/// End:

