
#include "comb/debruijn.h" // class debruijn
// demo-include "comb/necklace.h"

#include "mod/ipow.h"
#include "fxttypes.h"
#include "fxtio.h"

#include "demo/nextarg.h"

//% Generating De Bruijn sequences.

void
show_seq(ulong m, ulong n)
{
    debruijn db(m, n);
    ulong ndb = ipow(m, n);
    cout << "\n n = " << n
         << "  length = " << ndb
         << ":" << endl;
    db.first();
    ulong wct = 0;
    for (ulong j=0; j<ndb; ++j,++wct)
    {
        cout << db.next();
        if ( 0==(j%n) )
        {
            if ( wct>60 )  { wct=0;  cout << "\n "; }
            cout << " ";
            ++wct;
        }
    }
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong m = 2;
    NXARG(m, "m-ary De Bruijn sequences")
    ulong n = 4;
    NXARG(n, "length = m**n")
    
    show_seq(m, n);

//    const ulong maxlen[] = {0, 0, 8, 5, 4, 3, 0};
//    //         for:               2  3  4  5
//
//    for (ulong m=2; 0!=maxlen[m]; ++m)
//    {
//        cout << " ----- m = " << m << endl;
//        for (ulong n=1; n<=maxlen[m]; ++n)
//        {
//            show_seq(m, n);
//        }
//        cout << endl;
//    }
//
    return 0;
}
// -------------------------

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/debruijn-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/debruijn-demo.cc DEMOFLAGS=-DTIMING"
/// End:

