
#include "comb/subset-lex.h"

#include "comb/comb-print.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "fxtiomanip.h"
#include "demo/nextarg.h"
//#include "jjassert.h"


//% Generate all subsets in lexicographic order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Size of the set");
    subset_lex S(n);

#ifdef TIMING
    bool dir = 0;
    NXARG(dir, "Benchmark: whether to go backwards");
    if ( !dir )
    {
        cout << "forward:" << endl;
        while ( S.next() )  {;}
    }
    else
    {
        cout << "backward:" << endl;
        S.last();
        while ( S.prev() )  {;}
    }

#else // TIMING
    ulong ct = 0;
    ulong num = S.first();
    const ulong *x = S.data();
    do
    {
        ++ct;
        cout << setw(4) << ct << ":";
//        cout << "  #=" << setw(2) << num;
        print_set_as_deltaset("    ", x, num, n);
        print_set("    ", x, num);
        cout << endl;
    }
    while ( (num = S.next()) );

//    cout << endl;
//    num = S.last();
//    do
//    {
//        ++ct;
//        cout << setw(4) << ct << ":";
//
//        cout << "  #=" << setw(2) << num;
//        print_set_as_deltaset("  ", x, num, n);
//        print_set("  ", x, num);
//        cout << endl;
//    }
//    while ( (num = S.prev()) );
#endif // TIMING

    return 0;
}
// -------------------------

/*

Timing:

 time ./bin 30 0
arg 1: 30 == n  [Size of the set]  default=5
arg 2: 0 == dir  [Benchmark: whether to go backwards]  default=0
forward:
./bin 30 0  3.94s user 0.00s system 100% cpu 3.943 total
 ==> 2^30/3.94 == 272,523,305 per second

 time ./bin 30 1
arg 1: 30 == n  [Size of the set]  default=5
arg 2: 1 == dir  [Benchmark: whether to go backwards]  default=0
backward:
./bin 30 1  6.81s user 0.03s system 99% cpu 6.842 total
 ==> 2^30/6.81 == 157,671,339 per second

BENCHARGS=30 0
BENCHARGS=30 1

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/subset-lex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/subset-lex-demo.cc DEMOFLAGS=-DTIMING"
/// End:

