
#include "comb/mixedradix-lex.h"

#include "aux1/copy.h" // fill()

#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"
#include "fxtalloca.h"
#include "fxtio.h"
#include "jjassert.h"

//% Mixed radix counting.


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 3;
    NXARG(n,"Number of digits");

    ulong rr = 4;
    NXARG(rr, "Base (radix) of digits (0==>falling factorial, 1==>rising factorial)");

    ALLOCA(ulong, r, n);
    fill(r, n, rr);
    RESTARGS("Optionally supply radix for all digits (rr ignored)");
    if ( argc>3)  jjassert( argc == (int)n+3 );
    for (ulong k=3;  k<(ulong)argc; ++k)  r[k-3] = atol(argv[k]);

    mixedradix_lex M(n, rr, (argc>3? r:0) );
    M.print_nines("Nines: ");
    cout << endl;

//    M.last();
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << " " << setw(4) << ct << ":  ";
        M.print("    ", 1 );
        cout << setw(6) << M.to_num();  // == ct
        cout << endl;
#endif // TIMING
        ++ct;
    }
    while ( M.next() );
//    while ( M.prev() );

    cout << " ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:

 time ./bin 30 2  ## binary is worst case
arg 1: 30 == n  [Number of digits]  default=3
arg 2: 2 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ]
 ct=1073741824
./bin 30 2  6.44s user 0.02s system 99% cpu 6.474 total
==> 1073741824/6.44 == 166,730,096 per second

 time ./bin 19 3
arg 1: 19 == n  [Number of digits]  default=3
arg 2: 3 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 ]
 ct=1162261467
./bin 19 3  4.52s user 0.02s system 99% cpu 4.545 total
==>  1162261467/4.52 == 257,137,492 per second

 time ./bin 16 4
arg 1: 16 == n  [Number of digits]  default=3
arg 2: 4 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 ]
 ct=4294967296
./bin 16 4  13.64s user 0.00s system 100% cpu 13.643 total
==>  4294967296/13.64 == 314,880,300 per second

 time ./bin 10 8
arg 1: 10 == n  [Number of digits]  default=3
arg 2: 8 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 7 7 7 7 7 7 7 7 7 7 ]
 ct=1073741824
./bin 10 8  2.90s user 0.01s system 99% cpu 2.908 total
==> 1073741824/2.90 == 370,255,801 per second

 time ./bin 8 16
arg 1: 8 == n  [Number of digits]  default=3
arg 2: 16 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 15 15 15 15 15 15 15 15 ]
 ct=4294967296
./bin 8 16  12.54s user 0.04s system 99% cpu 12.607 total
==>  4294967296/12.54 == 342,501,379 per second

 time ./bin 12 1  ## rising factorial
arg 1: 12 == n  [Number of digits]  default=3
arg 2: 1 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 1 2 3 4 5 6 7 8 9 10 11 12 ]
 ct=6227020800
./bin 12 1  20.03s user 0.02s system 100% cpu 20.049 total
 ==>  6227020800/20.03 == 310,884,712 per second

 time ./bin 12 0  ## falling factorial
arg 1: 12 == n  [Number of digits]  default=3
arg 2: 0 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 12 11 10 9 8 7 6 5 4 3 2 1 ]
 ct=6227020800
./bin 12 0  19.45s user 0.04s system 100% cpu 19.494 total
 ==> 6227020800/19.45 == 320,155,311 per second


BENCHARGS=30 2
BENCHARGS=19 3
BENCHARGS=16 4
BENCHARGS=10 8
BENCHARGS=8 16
BENCHARGS=12 1
BENCHARGS=12 0

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/mixedradix-lex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/mixedradix-lex-demo.cc DEMOFLAGS=-DTIMING"
/// End:

