
#include "comb/composition-ex-colex.h"

#include "comb/comb-print.h"
#include "bits/printbin.h"
#include "demo/nextarg.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "fxtio.h"


//% Compositions of n into exactly k parts in co-lexicographic (colex) order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 8;
    NXARG(n, "Compositions of n (n>=1)");
    ulong k = 4;
    NXARG(k, "Into exactly k parts (must have: k>=n) ");
    bool rq = 0;
    NXARG(rq, "Whether to reverse order");

    jjassert( n>=k );

    composition_ex_colex P(n, k);

    if ( rq )  P.last();
    else       P.first();

    ulong ct = 0;

#ifdef TIMING
    if ( rq )  do { ++ct; }  while  ( P.prev() != k );
    else       do { ++ct; }  while  ( P.next() != k );

#else
    const ulong *x = P.data();
    ulong q = k-1;
    do
    {
        ++ct;
        cout << setw(4) << ct << ":";
        print_vec("    ", x, k, true);
        cout << "  " << q << "  ";

        // show corresponding compositions of n-k into at most k parts:
        cout << "    [";
        for (ulong j=0; j<k; ++j)
        {
            cout << " ";
            ulong v = x[j] - 1;
            if ( 0==v )  cout << '.';
            else         cout << v;
        }
        cout << " ]";
        cout << endl;

        if ( rq )  q = P.prev();
        else       q = P.next();
    }
    while ( q != k );
#endif

    cout << "  ct=" << ct << endl;

    return 0;
}
// -------------------------


/*
Timing:

----------- next():

time ./bin 40 10 0
arg 1: 40 == n  [Compositions of n (n>=1)]  default=8
arg 2: 10 == k  [Into exactly k parts (must have: k>=n) ]  default=4
arg 3: 0 == rq  [Whether to reverse order]  default=0
  ct=211915132
./bin 40 10 0  1.05s user 0.01s system 99% cpu 1.064 total
  ==> 211915132/1.05 == 201,823,935 compositions per second
time ./bin 30 10 0

----------- prev():  identical

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/composition-ex-colex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/composition-ex-colex-demo.cc DEMOFLAGS=-DTIMING"
/// End:
