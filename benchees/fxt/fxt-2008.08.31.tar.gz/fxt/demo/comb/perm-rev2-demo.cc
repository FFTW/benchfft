
#include "comb/perm-rev2.h"

#include "comb/comb-print.h"
#include "comb/mixedradix.h"

#include "fxtio.h"
#include "demo/nextarg.h"
#include "fxttypes.h"
#include "jjassert.h"


//% Permutations by prefix reversions, CAT algorithm.

//#define TIMING // uncomment to disable printing



int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute n>=3");
    jjassert( n>= 3);
    bool dfz= true; // whether to print dots for zeros

    perm_rev2 P(n);
    P.first();

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(4) << ct << ":";
        P.print("    ", dfz);
//        print_mixedradix("    ", P.d_+2, n-3, dfz);
        cout << endl;
#endif
    }
    while ( P.next() );


    cout << endl;
    cout << " ct=" << ct << endl;
    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:
 time ./bin 13
./bin 13  33.38s user 0.17s system 99% cpu 33.549 total
 ==> 13!/33.38 == 186,549,454 per second
 ==> 11.79 cycles per update

fix-arrays:
 time ./bin 13
./bin 13  30.48s user 0.16s system 99% cpu 30.659 total
 ==> 13!/30.48 == 204,298,582 per second
 ==> 10.79 cycles per update

BENCHARGS=13

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-rev2-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-rev2-demo.cc DEMOFLAGS=-DTIMING"
/// End:

