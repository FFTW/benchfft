
#include "comb/rgs-kincr.h"


//#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% All Restricted growth strings (RGS) s[0,...,n-1] so that s[k] <= s[k-1]+k
//% Lexicographic order.

// The number of length-n RGS is
// 1, 2, 7, 37, 268, 2496, 28612, 391189, 6230646 (seq A107877)

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Length of restricted growths strings");

    rgs_kincr R(n);

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(3) << ct << ":  ";
        R.print(true);
        cout << endl;
#endif // TIMING
    }
    while ( R.next() );

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------


/*
Timing:
 time ./bin 15
arg 1: 15 == n  [Partition set of n elements]  default=5
 ct = 1382958545
./bin 15  11.05s user 0.05s system 99% cpu 11.109 total
 ==>  125,154,619 RGS/sec
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/rgs-kincr-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/rgs-kincr-demo.cc DEMOFLAGS=-DTIMING"
/// End:

