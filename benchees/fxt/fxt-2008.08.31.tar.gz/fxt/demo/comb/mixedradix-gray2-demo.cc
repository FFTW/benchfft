
#include "comb/mixedradix-gray2.h"

#include "comb/comb-print.h"

#include "aux1/copy.h" // fill()

#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"
#include "fxtalloca.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "jjassert.h"


//% Mixed radix Gray code, loopless algorithm.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 3;
    NXARG(n,"Number of digits");

    ulong rr = 4;
    NXARG(rr, "Base (radix) of digits (0==>falling factorial, 1==>rising factorial)");

    ALLOCA(ulong, r, n);
    fill(r, n, rr);
    RESTARGS("Optionally supply radix for all digits (rr ignored)");
    if ( argc>3)  jjassert( argc == (int)n+3 );
    for (ulong k=3;  k<(ulong)argc; ++k)  r[k-3] = atol(argv[k]);

    mixedradix_gray2 M(n, rr, (argc>3? r:0) );
    M.print_nines("Nines: ");
    cout << endl;

//    M.last();
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << " " << setw(4) << ct << ":  ";
        M.print("    ", 1 );
        cout << setw(6) << M.to_num();
        cout << setw(6) << M.pos() << "  " << (M.dir()<0?'-':'+') << 1;
        print_vec("    f=", M.f_, n+1);  // focus pointer incl. sentinel
        cout << endl;
#endif // TIMING
        ++ct;
    }
    while ( M.next() );
//    while ( M.prev() );

    cout << " ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:

 time ./bin 30 2  ## binary is worst case
arg 1: 30 == n  [Number of digits]  default=3
arg 2: 2 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ]
 ct=1073741824
./bin 30 2  8.94s user 0.01s system 100% cpu 8.951 total
 ==> 1073741824/8.94 == 120,105,349 per second

 time ./bin 16 4
arg 1: 16 == n  [Number of digits]  default=3
arg 2: 4 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 ]
 ct=4294967296
./bin 16 4  22.05s user 0.03s system 100% cpu 22.080 total
 ==> 4294967296/22.05 == 194,783,097 per second

 time ./bin 10 8
arg 1: 10 == n  [Number of digits]  default=3
arg 2: 8 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 7 7 7 7 7 7 7 7 7 7 ]
 ct=1073741824
./bin 10 8  4.06s user 0.02s system 100% cpu 4.078 total
 ==> 1073741824/4.06 == 264,468,429 per second

 time ./bin 8 16
arg 1: 8 == n  [Number of digits]  default=3
arg 2: 16 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 15 15 15 15 15 15 15 15 ]
 ct=4294967296
./bin 8 16  15.66s user 0.04s system 100% cpu 15.703 total
 ==> 4294967296/15.66 == 274,263,556 per second

 time ./bin 12 1  ## rising factorial
arg 1: 12 == n  [Number of digits]  default=3
arg 2: 1 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 1 2 3 4 5 6 7 8 9 10 11 12 ]
 ct=6227020800
./bin 12 1  42.56s user 0.06s system 99% cpu 42.642 total
 ==> 6227020800/42.56 == 146,311,578 per second

 time ./bin 12 0  ## falling factorial
arg 1: 12 == n  [Number of digits]  default=3
arg 2: 0 == rr  [Base (radix) of digits (0==>falling factorial, 1==>rising factorial)]  default=4
args 3,4,... : [Optionally supply radix for all digits (rr ignored)]
Nines: [ 12 11 10 9 8 7 6 5 4 3 2 1 ]
 ct=6227020800
./bin 12 0  24.21s user 0.05s system 100% cpu 24.257 total
 ==> 6227020800/24.21 == 257,208,624 per second

BENCHARGS=30 2
BENCHARGS=19 3
BENCHARGS=16 4
BENCHARGS=10 8
BENCHARGS=8 16
BENCHARGS=12 1
BENCHARGS=12 0

*/



/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/mixedradix-gray2-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/mixedradix-gray2-demo.cc DEMOFLAGS=-DTIMING"
/// End:

