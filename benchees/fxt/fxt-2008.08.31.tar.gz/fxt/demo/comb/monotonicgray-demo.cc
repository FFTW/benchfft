
#include "comb/gray.h"
//demo-include "comb/monotonicgray.cc"

#include "bits/printbin.h"
#include "bits/bitcount.h"

#include "fxttypes.h"
#include "fxtalloca.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include "demo/nextarg.h"

//% Monotonic Gray path (Savage/Winkler).


int
main(int argc, char **argv)
{
    ulong ldn = 5;
    NXARG(ldn, "Use ldn-bit words");

    ulong n = 1UL << ldn;
    ulong pd = ldn;
    ALLOCA(ulong, g, n);
    monotonic_gray(g, ldn);

    for (ulong k=0; k<n; ++k)
    {
        cout << setw(4) << k << ":  ";
        print_bin(" ", g[k], pd);
        cout << setw(3) << bit_count(g[k]);
        if ( 0!=k )  print_bin("    ", g[k]^g[k-1] , pd);
        cout << endl;
    }

    return 0;
}
// -------------------------


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/monotonicgray-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/monotonicgray-demo.cc DEMOFLAGS=-DTIMING"
/// End:

