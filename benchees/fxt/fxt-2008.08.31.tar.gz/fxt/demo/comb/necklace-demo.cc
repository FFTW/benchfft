
#include "comb/necklace.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

#include "fxtiomanip.h"

//% Generate all (pre-)necklaces.

#define PRX()  { if (x[k])  cout << x[k]; else cout << '.'; }

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "length of strings >=1");
    ulong m = 3;
    NXARG(m, "number of words >=2");
    ulong pq = 1;
    NXARG(pq, "whether to also print preprime strings");

    necklace P(m, n);
    const ulong *x = P.data();

    ulong j = P.j_;  // ==1
    ulong pct = 0;  // count pre-necklaces (pre-prime strings)
    ulong ct = 0;   // count necklaces (prime strings)
    ulong lct = 0;  // count Lyndon words
    do
    {
        ++pct;
#ifndef TIMING
        bool nq = P.is_necklace();
        if ( (0==pq) && ( ! nq ) )  continue;

        cout << "    ";
        for (ulong k=0; k<n; ++k)  PRX();
        cout << "  " << setw(2) << j;
        cout << "    ";
        ulong k;
        for (k=0; k<n-j; ++k)  cout << " ";
        for (  ; k<n; ++k)  PRX();

        if ( nq )
        {
            ++ct;
            cout << "  N";  // necklace
            if ( P.is_lyn() )
            {
                ++lct;
                cout << " L";  // Lyndon word
            }
        }
        cout << endl;
#endif // TIMING
    }
    while ( (j=P.next_pre()) );

    cout << "  # pre-necklaces = " << pct;
#ifndef TIMING
    cout << "  # necklaces = " << ct;
    cout << "  # Lyndon words = " << lct;
#endif // TIMING
    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:

 time ./bin 32 2
  #pre = 277737797
./bin 32 2  2.82s user 0.02s system 99% cpu 2.840 total
 ==> 277737797/2.81 == 98,839,073 per second
with NECKLACE_MAX_ARRAY_LEN defined:
./bin 32 2  2.59s user 0.02s system 99% cpu 2.618 total


 time ./bin 21 3
  #pre = 766918996
./bin 21 3  5.43s user 0.03s system 99% cpu 5.462 total
 ==> 766918996/5.43 == 141,237,384 per second

 time ./bin 16 4
  #pre = 366273464
./bin 16 4  2.03s user 0.00s system 99% cpu 2.032 total
 ==> 366273464/2.03 == 180,430,277 per second
with NECKLACE_MAX_ARRAY_LEN defined:
./bin 16 4  1.81s user 0.02s system 99% cpu 1.837 total

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/necklace-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/necklace-demo.cc DEMOFLAGS=-DTIMING"
/// End:

