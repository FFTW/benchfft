
#include "comb/mset-perm-lex.h"

#include "comb/comb-print.h"
#include "fxtiomanip.h"
//#include "jjassert.h"

#include <cstdlib>  // atol()
//#include "demo/nextarg.h"



//% All multiset permutations in lexicographic order, iterative generation.
//% Same as: all strings with fixed content.


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong k;   // number of sorts of elements
    ulong *r;  // element i is repeated r[i] times
    const bool dfz = true;  // whether to print dots for zeros

    cout << "args: multiplicities of elements" << endl;
    if ( argc<=1 )
    {
        ulong t[]={2, 2, 1, 0};  // proper multisets  ct=30
//        ulong t[]={1, 1, 1, 1, 0};  // permutations  ct = 24
//        ulong t[]={6, 2, 0};  // combinations  ct=28
        k=0;  while ( t[k] )  { ++k; }
        r = new ulong[k];
        for (ulong j=0; j<k; ++j)  r[j] = t[j];
    }
    else
    {
        k = argc - 1;
        r = new ulong[k];
        for (ulong j=0; j<k; ++j)
        {
            ulong t = atol(argv[j+1]);
            r[j] = t;
        }
    }

    mset_perm_lex P(r, k);

    cout << "multiplicities: ( ";
    for (ulong i=0; i<k; ++i)  cout << P.r_[i] << (i<k-1?", ":" ");
    cout << ")";
    cout << "  k=" << P.k_ << "  n=" << P.n_;
    cout << endl;

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(4) << ct << ":";
        print_perm("  ", P.ms_, P.n_, dfz);

        cout << endl;
#endif
    }
    while ( P.next() );


    cout << "ct=" << ct << endl;

    delete [] r;

    return 0;
}
// -------------------------

/*
Timing:

time ./bin 2 2 2 3 3 3 
multiplicities: ( 2, 2, 2, 3, 3, 3 )  k=6  n=15
ct=756756000
./bin 2 2 2 3 3 3  9.03s user 0.05s system 99% cpu 9.079 total
  ==> 756756000/9.03 == 83,804,651 per second

 time ./bin 3 3 3 2 2 2 ## reordered
args: multiplicities of elements
multiplicities: ( 3, 3, 3, 2, 2, 2 )  k=6  n=15
ct=756756000
./bin 3 3 3 2 2 2  9.23s user 0.04s system 99% cpu 9.274 total
  ==> 756756000/9.23 == 81,988,732 per second

time  ./bin 1 1 1 1 1 1 1 1 1 1 1 1  ## permutations of 12
args: multiplicities of elements
multiplicities: ( 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 )  k=12  n=12
ct=479001600
./bin 1 1 1 1 1 1 1 1 1 1 1 1  4.26s user 0.02s system 99% cpu 4.276 total
  ==> 479001600/4.26 == 112,441,690 per second

time  ./bin 15 15  ## combination (30 choose 15)
args: multiplicities of elements
multiplicities: ( 15, 15 )  k=2  n=30
ct=155117520
./bin 15 15  2.55s user 0.01s system 99% cpu 2.562 total
  ==> 155117520/2.55 == 60,830,400 per second

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/mset-perm-lex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/mset-perm-lex-demo.cc DEMOFLAGS=-DTIMING"
/// End:
