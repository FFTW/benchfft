
#include "comb/perm-gray-lipski.h"

#include "comb/comb-print.h"

#include "demo/nextarg.h"
#include "fxtio.h"
#include "fxttypes.h"
#include "jjassert.h"


//#include "comb/fact2perm.h"
//#include "perm/perminvert.h"


//% Four Gray codes for permutations, CAT algorithm.

//#define TIMING // uncomment to disable printing

#define INVERSE  // define to show inverse permutations

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Number of elements to permute");
    ulong r = 1;
    NXARG(r, "Ordering:"
          "\n    0 ==> Lipski(9) == Heap,"
          "\n    1 ==> Lipski(16),"
          "\n    2 ==> Lipski(10),"
          "\n    3 ==> order not in Lipski's paper");
    cout << endl;

    bool dfz= true; // whether to print dots for zeros

    perm_gray_lipski P(n, r);
    P.first();

#ifdef INVERSE
    const ulong *x = P.data();
    ulong *xi = new ulong[n];  // inverse permutations
    for (ulong k=0; k<n; ++k)  xi[k] = k;
#endif // INVERSE

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(4) << ct << ":";
        P.print("    ", dfz);

        ulong sw1, sw2;
        P.get_swap(sw1, sw2);
        cout << "     (" << sw1 << ", " << sw2 << ") ";


        print_mixedradix("    ", P.d_, n-1, dfz);

#ifdef INVERSE
        cout << "    ";
        swap2( xi[x[sw1]], xi[x[sw2]]);  // update inverse permutation
        print_perm("    ", xi, n, dfz);
//        perm2rfact(xi, n, rfc);
//        print_mixedradix("    ", rfc, n-1, dfz);
#endif // INVERSE

        cout << endl;
#endif
    }
    while ( P.next() );

    cout << endl;
    cout << " ct=" << ct << endl;
    cout << endl;

#ifdef INVERSE
    delete [] xi;
#endif

    return 0;
}
// -------------------------

/*
Timing:
 time ./bin 12
 ct=479001600
./bin 12  4.37s user 0.02s system 99% cpu 4.400 total
 ==>  479001600/4.37 == 109,611,350  per second
*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-gray-lipski-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-gray-lipski-demo.cc DEMOFLAGS=-DTIMING"
/// End:
