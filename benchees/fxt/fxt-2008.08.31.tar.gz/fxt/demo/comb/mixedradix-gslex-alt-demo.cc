
#include "comb/mixedradix-gslex-alt.h"

#include "aux1/copy.h" // fill()

#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"
#include "fxtalloca.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "jjassert.h"

//% Mixed radix numbers in alternative (generalized, subset-) lexicographic order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 3;
    NXARG(n,"Number of digits");

    ulong rr = 4;
    NXARG(rr, "Base (radix) of digits (0==>falling factorial, 1==>rising factorial)");

    ALLOCA(ulong, r, n);
    fill(r, n, rr);
    RESTARGS("Optionally supply radix for all digits (rr ignored)");
    if ( argc>3)  jjassert( argc == (int)n+3 );
    for (ulong k=3;  k<(ulong)argc; ++k)  r[k-3] = atol(argv[k]);

    mixedradix_gslex_alt M(n, rr, (argc>3? r:0) );
    M.print_nines("Nines: ");
    cout << endl;

//    M.last();
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << " " << setw(4) << ct << ":  ";
        M.print("    ", 1 );
        cout << setw(6) << M.to_num();
        cout << endl;
#endif // TIMING
        ++ct;
    }
    while ( M.next() );
//    while ( M.prev() );

    cout << " ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:
% time ./bin 30 2  ## binary is worst case
 ct=1073741824
./bin 30 2  8.98s user 0.05s system 99% cpu 9.041 total
 ==> 1073741824/8.98 == 119,570,359 per second

% time ./bin 16 4
 ct=4294967296
./bin 16 4  23.33s user 0.12s system 97% cpu 23.990 total
 ==> 4294967296/23.33 == 184,096,326 per second

% time ./bin 10 8
 ct=1073741824
./bin 10 8  4.74s user 0.04s system 99% cpu 4.783 total
 ==> 1073741824/4.74 == 226,527,810 per second

% time ./bin 8 16
 ct=4294967296
./bin 8 16  13.76s user 0.06s system 99% cpu 13.902 total
 ==> 4294967296/13.76 == 312,134,251 per second

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/mixedradix-gslex-alt-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/mixedradix-gslex-alt-demo.cc DEMOFLAGS=-DTIMING"
/// End:

