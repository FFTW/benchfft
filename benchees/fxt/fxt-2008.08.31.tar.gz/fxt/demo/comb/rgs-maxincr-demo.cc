
#include "comb/rgs-maxincr.h"

//#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% All restricted growth strings (RGS) s[0,...,n-1]
//%   so that s[k] <= max_{j<k}(s[j]+i)
//% Lexicographic order


//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Length of restricted growths strings");
    ulong i = 2;
    NXARG(i, "Increment allowed (1==> set partitions)");
    // i=1 ==> Bell numbers A000110
    // i=2 ==> Number of symmetric positions of non-attacking rooks
    //          on upper-diagonal part of n X n chessboard.  A080337
    //         see also A080107

    rgs_maxincr R(n, i);

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(3) << ct << ":  ";
        R.print(true);
        cout << endl;
#endif // TIMING
    }
    while ( R.next() );

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------


/*
Timing:
 time ./bin 15 1
 ct = 1382958545
./bin 15 1  12.09s user 0.06s system 99% cpu 12.150 total
 ==>  114,388,630 RGS/sec
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/rgs-maxincr-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/rgs-maxincr-demo.cc DEMOFLAGS=-DTIMING"
/// End:

