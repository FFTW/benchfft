
#include "comb/perm-heap.h"
#include "comb/fact2perm.h"

#include "comb/mixedradix.h"
#include "comb/comb-print.h"
#include "aux0/swap.h"

#include "fxtio.h"
#include "demo/nextarg.h"
#include "fxttypes.h"


//% Gray code for permutations, CAT algorithm.
//% Algorithm following B.R.Heap (1963)

//#define TIMING // uncomment to disable printing

#define INVERSE  // define to show inverse permutations

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");
    bool dfz= true; // whether to print dots for zeros


    perm_heap P(n);
    P.first();

    ulong *rfc = new ulong[n];  // rising factorial

    const ulong *x = P.data();
#ifdef INVERSE
    ulong *xi = new ulong[n];  // inverse permutations
    for (ulong k=0; k<n; ++k)  xi[k] = k;
#endif // INVERSE

    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << setw(4) << ct << ":";
        P.print("    ", dfz);

        ulong sw1, sw2;
        P.get_swap(sw1, sw2);
        cout << "     (" << sw1 << ", " << sw2 << ") ";

        print_mixedradix("    ", P.d_, n-1, dfz);


        perm2rfact(x, n, rfc);
        print_mixedradix("    ", rfc, n-1, dfz);


#ifdef INVERSE
        cout << "    ";
        swap2( xi[x[sw1]], xi[x[sw2]]);  // update inverse permutation
        print_perm("    ", xi, n, dfz);
        perm2rfact(xi, n, rfc);
        print_mixedradix("    ", rfc, n-1, dfz);
#endif // INVERSE

        cout << endl;
#endif // TIMING
        ++ct;
    }
    while ( P.next() );

    cout << endl;
    cout << " ct=" << ct << endl;
    cout << endl;

    delete [] rfc;
#ifdef INVERSE
    delete [] xi;
#endif

    return 0;
}
// -------------------------

/*
Timing:
time ./bin 12
 ct=479001600
./bin 12  4.19s user 0.02s system 99% cpu 4.211 total
 ==>  479001600/4.19 ==  114,320,190 permutations per second

no swaps:
time ./bin 12
 ct=479001600
./bin 12  2.95s user 0.02s system 99% cpu 2.975 total
 ==> 479001600/2.9 == 165,172,965

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-heap-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-heap-demo.cc DEMOFLAGS=-DTIMING"
/// End:

