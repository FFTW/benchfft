
#include "comb/perm-trotter-lg.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in strong minimal-change order using Trotter's algorithm.
//% Largest element moves most often.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");
    bool bq = 0;
    NXARG(bq, "Whether to go backwards.");

    bool dfz = true;  // whether to print dots for zeros

    perm_trotter_lg P(n);
    if ( bq )  P.last();

    ulong ct = 0;
#ifdef TIMING
    if ( !bq)  do { ++ct; } while ( P.next() );
    else       do { ++ct; } while ( P.prev() );
#else
    do
    {
        cout << setw(4) << ct << ":";
        ++ct;

        P.print("    ", dfz);

        ulong sw1, sw2;
        P.get_swap(sw1, sw2);
        cout << "    (" << sw1 << ", " << sw2 << ") ";

        P.print_inv("    ", dfz);

        // print directions:
        cout << "    ";
        for (ulong j=0; j<n; ++j)  cout << " " << (P.d_[j]==1?'+':'-');

        cout << endl;
    }
    while ( (!bq ? P.next() : P.prev()) );
#endif

    cout << "  ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
 Timing:
 time ./bin 12
./bin 12  3.78s user 0.01s system 99% cpu 3.797 total
  ==> 126,720,000 permutations per second
  ==> 17.36 cycles per update
*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-trotter-lg-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-trotter-lg-demo.cc DEMOFLAGS=-DTIMING"
/// End:

