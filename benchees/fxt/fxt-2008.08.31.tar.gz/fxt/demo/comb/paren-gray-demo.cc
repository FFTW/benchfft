
#include "comb/paren-gray.h"

#include "demo/nextarg.h"
#include "fxtio.h"

//% Parenthesis strings in minimal-change order (Xiang, Ushijima)

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Number of parenthesis pairs");

    paren_gray P(n);

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(4) << ct << ":    ";
        cout << P.string();
        cout << "    ";
        for (ulong k=0; k<2*n; ++k)  cout << (P.string()[k]=='(' ? '1' : '.' );
        cout << endl;
#endif  // TIMING
    }
    while ( P.next() );
    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------

/*

 time ./bin 18
arg 1: 18 == n  [Number of parenthesis pairs]  default=5
 ct = 477638700
./bin 18  8.83s user 0.04s system 100% cpu 8.872 total
 ==> 477638700/8.83 == 54,092,718 per second

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/paren-gray-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/paren-gray-demo.cc DEMOFLAGS=-DTIMING"
/// End:
