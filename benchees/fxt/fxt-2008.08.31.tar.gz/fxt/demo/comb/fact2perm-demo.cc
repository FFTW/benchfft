
#include "comb/fact2perm.h"
// demo-include "comb/fact2perm.cc"
#include "comb/mixedradix-lex.h"
#include "perm/reverse.h"
#include "perm/permcomplement.h"
#include "perm/perminvert.h"

#include "comb/mixedradix-modular-gray.h"
#include "comb/mixedradix-gslex.h"
#include "comb/mixedradix-gray.h"
#include "comb/mixedradix-endo.h"
#include "comb/mixedradix-endo-gray.h"

#include "comb/comb-print.h"
#include "comb/mixedradix.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "demo/nextarg.h"  // NXARG()
#include "fxtio.h"


//% Generate all permutations from mixed radix (factorial) numbers.

//#define MOD  // generate inverse permutation (not reversed complement)

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");
    bool rq = 1;
    NXARG(rq, "Whether to use rising factorial base.");
    const bool dfz = true;  // whether to print dots for zeros
    const ulong n1 = n - 1;

//    mixedradix_lex M(n1, rq);
    mixedradix_gray M(n1, rq);  // default
//    mixedradix_modular_gray M(n1, rq);
//    mixedradix_gslex M(n1, rq);
//    mixedradix_endo M(n1, rq);
//    mixedradix_endo_gray M(n1, rq);
    M.print_nines(" Nines: ");  cout << endl;

    const ulong *a = M.data();  // factorial number
    ulong *ia = new ulong[n1];  // factorial number for inverse permutation

    ulong *p = new ulong[n];  // permutation
    ulong *ip = new ulong[n];  // inverse permutation

    ulong *t = new ulong[n1];  // aux for testing

    ulong ct = 0;
    do
    {
        cout << " " << setw(3) << ct << ":";

        print_mixedradix("    ", a, n1, dfz);

        if ( rq )  rfact2perm(a, n, p);
        else       ffact2perm(a, n, p);
        print_perm("    ", p, n, dfz);

        cout << "      ";


#ifdef MOD
        make_inverse(p, ip, n);
        print_perm("    ", ip, n, dfz);
        if ( rq )  perm2rfact(ip, n, ia);
        else       perm2ffact(ip, n, ia);
        print_mixedradix("    ", ia, n1, dfz);
#else
        make_complement(p, ip, n);
        reverse(ip, n);
        print_perm("    ", ip, n, dfz);
        if ( ! rq )  perm2rfact(ip, n, ia);
        else         perm2ffact(ip, n, ia);
        print_mixedradix("    ", ia, n1, dfz);
#endif


#if 1 // Testing that Xfact2perm() is inverse of perm2Xfact():
        if ( rq )  perm2rfact(p, n, t);
        else       perm2ffact(p, n, t);
//        print_mixedradix(" :: ", t, n1, dfz);
        for (ulong j=0; j<n1; ++j)  { jjassert(t[j]==a[j]); }
#endif

        ++ct;
        cout << endl;
    }
    while ( M.next() );

    delete [] ia;
    delete [] p;
    delete [] ip;
    delete [] t;

    return 0;
}
// -------------------------


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/fact2perm-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/fact2perm-demo.cc DEMOFLAGS=-DTIMING"
/// End:

