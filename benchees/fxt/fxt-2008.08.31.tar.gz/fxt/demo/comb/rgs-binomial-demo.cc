
#include "comb/rgs-binomial.h"

//#include "comb/comb-print.h"


//#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% All restricted growth strings (RGS) s[0,...,n-1] so that  s[k] <= s[k-1]+i
//% Lexicographic order


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Length of restricted growths strings");
    ulong i = 2;
    NXARG(i, "Increment allowed (1==> RGS for parenthesis strings)");
    // i=1 ==> A000108 = binomial(2n,n)/(n+1) (Catalan numbers)
    // i=2 ==> A001764 = binomial(3n,n)/(2n+1)
    // i=3 ==> A002293 = binomial(4n,n)/(3n+1)
    // i=4 ==> A002294 = binomial(5n,n)/(4n+1)
    // i=x ==> binomial(x*n,n)/((x-1)*n+1)

    rgs_binomial R(n, i);

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(4) << ct << ":  ";
        R.print();

//        print_set_as_deltaset("    ds=", R.data(), n, i*n);

        cout << endl;
#endif // TIMING
    }
    while ( R.next() );

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------


/*
Timing:
time ./bin 18 1
 ct = 477638700
./bin 18 1  3.69s user 0.02s system 100% cpu 3.714 total
 ==> 129,441,382  RGS/sec

 time ./bin 13 2
 ct = 300830572
./bin 13 2  2.10s user 0.02s system 99% cpu 2.127 total
 ==>   143,252,653 RGS/sec

  time ./bin 12 3
 ct = 1882933364
./bin 12 3  12.06s user 0.06s system 99% cpu 12.149 total
==>  156,130,461 RGS/sec
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/rgs-binomial-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/rgs-binomial-demo.cc DEMOFLAGS=-DTIMING"
/// End:

