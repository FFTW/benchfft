
#define PERM_MV0_UPDATE_D0  // define to update d[0] with each step
// ^^^--- comment out for timing!
#include "comb/perm-mv0.h"

#include "comb/comb-print.h"

#include "comb/fact2perm.h"
#include "perm/perminvert.h"
#include "comb/mixedradix-lex.h"


#include "jjassert.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all inverse permutations with falling factorial numbers, CAT algorithm.


//#define TIMING // uncomment to disable printing

#ifdef TIMING
#ifdef PERM_MV0_UPDATE_D0
#error "At top of file comment out the #define PERM_MV0_UPDATE_D0"
#endif
#else
#ifndef PERM_MV0_UPDATE_D0
#error "At top of file uncomment the #define PERM_MV0_UPDATE_D0"
#endif
#endif

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements (n>=2).");

    perm_mv0 P(n);

    mixedradix_lex M(n-1, 0);  // falling factorial basis
    M.first();

    ulong ct = 0;
#ifdef TIMING
    do { ++ct; }  while ( P.next() );
#else
    bool dfz = true;  // whether to print dots for zeros
    ulong *t = new ulong[n];  // permutations for checking
    const ulong *x = P.data();
    const ulong *d = P.d_;
    do
    {
        cout << setw(4) << ct << ":";
        ++ct;
        print_perm("    ", x, n, dfz);
        print_mixedradix("    ", d, n-1, dfz);

        make_inverse(x, t, n);
        print_perm("    ", t, n, dfz);

        cout << endl;

        ffact2invperm(d, n, t);
        for (ulong k=0; k<n; ++k)  jjassert( t[k]==x[k] );
        M.next();

    }
    while ( P.next() );

    delete [] t;
#endif // TIMING

    cout << "  ct=" << ct << endl;

    return 0;
}
// -------------------------


/*
 Timing:

 time ./bin 12
arg 1: 12 == n  [Permutations of n elements.]  default=4
  ct=479001600
./bin 12  2.99s user 0.02s system 99% cpu 3.010 total
 ==> 12!/2.99 == 160,201,204  permutations per second

arg 1: 13 == n  [Permutations of n elements.]  default=4
  ct=6227020800
./bin 13  38.19s user 0.19s system 99% cpu 38.383 total

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-mv0-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-mv0-demo.cc DEMOFLAGS=-DTIMING"
/// End:

