
#include "comb/subset-deltalex.h"
#include "comb/comb-print.h"

#include "fxtio.h"
#include "demo/nextarg.h"

//% All subsets in lexicographic order with respect to delta sets.

//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Subsets of the n-elemnt set {0,1,...,n-1}.");
    bool dfz = true;  // whether to print dots for zeros
    char c01[] = "01";
    if ( dfz )  c01[0] = '.';

    subset_deltalex S(n);
    const ulong *x = S.data();
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << setw(4) << ct << ":";
        cout << "    ";
        for (ulong j=0; j<n; ++j)  cout << c01[x[j]];
        print_deltaset_as_set( "    ", S.data(), n);
        cout << endl;
#endif
        ++ct;
    }
    while ( S.next() );


    return 0;
}
// -------------------------

/*
Timing:
 time ./bin 30
./bin 30  5.92s user 0.03s system 99% cpu 5.962 total
 ==> 2^30/5.92 == 181,375,308 subsets per second
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/subset-deltalex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/subset-deltalex-demo.cc DEMOFLAGS=-DTIMING"
/// End:
