
#include "comb/binary-necklace.h"

#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong

#include "demo/nextarg.h" // NXARG()

//% Binary pre-necklaces, necklaces and Lyndon words: CAT generation.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 8;
    NXARG(n, "Number of bits");

    binary_necklace P(n);

    const ulong *x = P.data();

    ulong nct = 0;  // count necklaces (prime strings)
    ulong lct = 0;  // count lyndon words
    ulong pct = 0;  // count pre-necklaces (pre-prime strings)
    ulong j = 1;  // first string is zero word (period==1)
    do
    {
        ++pct;
#ifndef TIMING
        cout << setw(4) << pct << ": ";
        for (ulong i=0; i<n; ++i)  cout << (x[i] ? '1' : '.' );
        cout << "  ";
        cout << setw(2) << j;
        cout << "  ";
        if ( P.is_necklace() )
        {
            ++nct;
            cout << "  N";  // necklace
            if ( P.is_lyn() )
            {
                ++lct;
                cout << "  L";  // Lyndon word
            }
        }
        cout << endl;
#endif  // TIMING
    }
    while ( ( j=P.next_pre() ) );

    cout << " n = " << n << ":  ";
//    cout << endl;
    cout << "  # pre-necklaces = " << pct;
#ifndef TIMING
    cout << "  # necklaces = " << nct;
    cout << "  # Lyndon words = " << lct;
#endif  // TIMING
    cout << endl;


    return 0;
}
// -------------------------

/*
Timing:

with BINARY_NECKLACE_MAX_ARRAY_LEN defined:
 time ./bin 34
arg 1: 34 == n  [Number of bits]  default=8
 n = 34:    # pre-necklaces = 1043325198
./bin 34  8.07s user 0.00s system 99% cpu 8.069 total
 ==> 1043325198/8.07 == 129,284,411 per second

with pointers:
 time ./bin 34
arg 1: 34 == n  [Number of bits]  default=8
 n = 34:    # pre-necklaces = 1043325198
./bin 34  8.14s user 0.00s system 100% cpu 8.139 total
 ==> 1043325198/8.14 == 128,172,628 per second

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/binary-necklace-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/binary-necklace-demo.cc DEMOFLAGS=-DTIMING"
/// End:

