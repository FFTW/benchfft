
#include "comb/perm-colex.h"

#include "comb/comb-print.h"

#include "perm/perminvert.h"
//#include "comb/fact2perm.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in co-lexicographic (colex) order


//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements (n>=2).");
    bool dfz = true;  // whether to print dots for zeros

    perm_colex P(n);

    ulong ct = 0;
#ifdef TIMING
    do { ++ct; }  while ( P.next() );
#else
    const ulong *x = P.data();
    const ulong *d = P.d_;
    ulong *t = new ulong[n];  // inverse permutations
    do
    {
        cout << setw(4) << ct << ":";
        print_perm("    ", x, n, dfz);
        print_mixedradix("    ", d, n-1, dfz);

        make_inverse(x, t, n);
        print_perm("        ", t, n, dfz);

        cout << endl;
        ++ct;
    }
    while ( P.next() );

    delete [] t;
#endif // TIMING

    cout << "  ct=" << ct << endl;

    return 0;
}
// -------------------------


/*
 Timing:

 time ./bin 12
arg 1: 12 == n  [Permutations of n elements.]  default=4
  ct=479001600
./bin 12  2.47s user 0.00s system 99% cpu 2.481 total
 ==> 12!/2.47 == 193,927,773  per second

with PERM_COLEX_FIXARRAYS:
./bin 12  2.27s user 0.00s system 99% cpu 2.272 total
 ==> 12!/2.27 == 211,013,920  per second

BENCHARGS=13

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-colex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-colex-demo.cc DEMOFLAGS=-DTIMING"
/// End:

