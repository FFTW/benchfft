
#include "comb/setpart-rgs-gray.h"

// demo-include "comb/setpart-rgs-gray.cc"

//#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% Set partitions as restricted growth strings (RGS).


//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Partition set of n elements");
    int dr0 = +1;
    NXARG(dr0, "Starting direction in recursion (+-1)");
    dr0 = ( (dr0>0) ? +1 : -1 );
//    ulong px = 0;
//    NXARG(px, "If !=0, only list partitions into exactly px sets");

    setpart_rgs_gray P(n, dr0);

    ulong ct = 0;
#ifdef TIMING
    do  { ++ct; }  while ( P.next() );
#else // TIMING
    do
    {
//        if ( px && (P.m_[n]!=px) )  continue;
        ++ct;
        cout << setw(3) << ct << ":  ";
        P.print();
        cout << "    ";  P.print_set();
        cout << endl;
    }
    while ( P.next() );
#endif // TIMING

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:

 time ./bin 15 0
arg 1: 15 == n  [Partition set of n elements]  default=5
arg 2: 0 == dr0  [Starting direction in recursion (+-1)]  default=1
 ct = 1382958545
./bin 15 0  8.98s user 0.03s system 100% cpu 9.014 total
 ==> 1382958545/8.98 == 154,004,292 per second

same with dr0 == 1

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/setpart-rgs-gray-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/setpart-rgs-gray-demo.cc DEMOFLAGS=-DTIMING"
/// End:

