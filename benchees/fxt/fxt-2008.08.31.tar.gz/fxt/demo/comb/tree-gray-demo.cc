
#include "comb/tree-gray.h"

#include "fxtio.h"
#include "fxttypes.h"
#include "demo/nextarg.h"
#include "comb/comb-print.h"


//% Gray code for k-ary trees with n (internal) nodes.
//% Loopless algorithm, all changes are homogeneous.

//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of (internal) nodes of the tree.");
    ulong k = 3;
    NXARG(k, "Tree is k-ary.");


    tree_gray T(n, k);
    T.first();
    const ulong *x = T.data();

    ulong ct = 0;
    ulong ch = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(4) << ct << ":";
        print_sym_vec("  ", x, n);
        print_sign_vec("    ", T.dr_+1, n);
//        print_vec("  np=", T.np_+1, n);
//        print_vec("  mx=", T.mx_+1, n);  // does not change

        print_set1_as_deltaset("    ", x, n, k*n);

        cout << endl;
#endif

//        if ( ct > 56 )  break;
    }
    while ( (ch=T.next()) );

    cout << "  ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
 Timing:

 time ./bin 18 2
arg 1: 18 == n  [Number of (internal) nodes of the tree.]  default=4
arg 2: 2 == k  [Tree is k-ary.]  default=3
  ct=477638700
./bin 18 2  4.92s user 0.02s system 99% cpu 4.942 total
 ==> 477638700/4.92 == 97,081,036 per second

 time ./bin 13 3
arg 1: 13 == n  [Number of (internal) nodes of the tree.]  default=4
arg 2: 3 == k  [Tree is k-ary.]  default=3
  ct=300830572
./bin 13 3  2.51s user 0.00s system 99% cpu 2.510 total
 ==> 300830572/2.51 == 119,852,817 per second

 time ./bin 12 4
arg 1: 12 == n  [Number of (internal) nodes of the tree.]  default=4
arg 2: 4 == k  [Tree is k-ary.]  default=3
  ct=1882933364
./bin 12 4  13.56s user 0.08s system 99% cpu 13.640 total
 ==> 1882933364/13.56 == 138,859,392 per second

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/tree-gray-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/tree-gray-demo.cc DEMOFLAGS=-DTIMING"
/// End:
