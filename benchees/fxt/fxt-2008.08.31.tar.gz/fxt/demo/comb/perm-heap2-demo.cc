
#include "comb/perm-heap2.h"

#include "comb/mixedradix.h"
#include "comb/comb-print.h"
#include "aux0/swap.h"

#include "fxtio.h"
#include "demo/nextarg.h"
#include "jjassert.h"
#include "fxttypes.h"


//% Gray code for permutations, CAT algorithm, optimized version.
//% Algorithm following B.R.Heap (1963)

//#define TIMING // uncomment to disable printing

#ifdef TIMING
#include "aux0/factorial.h"
#endif


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute n>=3");
    jjassert( n>=3 );
    bool dfz= true; // whether to print dots for zeros


    perm_heap2 P(n);
    P.first();

    ulong *x = new ulong[n];  // permutations
    ulong *xi = new ulong[n];  // inverse permutations
    for (ulong k=0; k<n; ++k)  x[k] = xi[k] = k;

#ifdef TIMING
    ulong ct = 0;
    do { ++ct; }  while ( P.next() );

//    do
//    {
//        ulong s1, s2;
//        P.get_swap(s1, s2);
//        ct += s1 + s2;
//    }
//    while ( P.next() );
//    { ulong f = factorial(n);  if (ct!=f) ct=f; }

#else
    ulong ct = 0;
    do
    {
        cout << setw(4) << ct << ":";
        ulong sw1, sw2;
        P.get_swap(sw1, sw2);
        swap2( x[sw1], x[sw2]);  // update permutation
        print_perm("    ", x, n, dfz);

//        cout << " (" << P.ct_ << ") ";
//        cout << " (" << P.fc_ << ") ";

        cout << "     (" << sw1 << ", " << sw2 << ") ";

//        print_mixedradix("    ", P.d_+2, n-3, dfz);

        swap2( xi[x[sw1]], xi[x[sw2]]);  // update inverse permutation
        print_perm("    ", xi, n, dfz);

        cout << endl;
        ++ct;
    }
    while ( P.next() );
#endif

    cout << endl;
    cout << " ct=" << ct << endl;
    cout << endl;

    delete [] x;
    delete [] xi;

    return 0;
}
// -------------------------

/*
Timing:
time ./bin 13
./bin 13  32.37s user 0.18s system 99% cpu 32.578 total
 ==> 13!/32.37 == 192,370,120 per second
 ==> 11.43 cycles per udate

fix-arrays:
./bin 13  33.55s user 0.17s system 99% cpu 33.716 total
 ==> slower

BENCHARGS=13

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-heap2-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-heap2-demo.cc DEMOFLAGS=-DTIMING"
/// End:

