
#include "comb/ruler-func.h"

#include "comb/comb-print.h"

#include "demo/nextarg.h"
#include "fxttypes.h"

#include "fxtio.h"

//% Ruler function sequence.

//#define TIMING // uncomment to disable printing



int
main(int argc, char **argv)
{
    ulong n = 6;
    NXARG(n, "Stop when n is encountered in the sequence (==>2**n elements).");

    ruler_func R(n);

#ifdef TIMING
    do  { ; }  while ( n!=R.next() );

#else

    ulong ct = 0;
    ulong j;
    do
    {
        ++ct;
        j = R.next();
        cout << " " << j;
//        print_vec("    ", R.f_, n);  cout << endl;
        if ( j>3 )  cout << endl;
    }
    while ( j!=n );
    cout << endl;
    cout << " ct=" << ct << endl;


#endif

    return 0;
};
// -------------------------


/*
Timing:

 time ./bin 30
arg 1: 30 == n  [Stop when n is encountered in the sequence (==>2**n elements).]  default=6
 ct=1073741824
./bin 30  4.39s user 0.00s system 100% cpu 4.396 total
 ==> 2^30/4.39 == 244,588,114 per second

// with RULER_FUNC_MAX_ARRAY_LEN defined:
 time ./bin 30
arg 1: 30 == n  [Stop when n is encountered in the sequence (==>2**n elements).]  default=6
 ct=1073741824
./bin 30  4.69s user 0.00s system 100% cpu 4.696 total
 ==> 2^30/4.69 == 228,942,819 per second

BENCHARGS=30

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/ruler-func-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/ruler-func-demo.cc DEMOFLAGS=-DTIMING"
/// End:
