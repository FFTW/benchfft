
#include "comb/perm-lex.h"

#include "comb/fact2perm.h"
#include "perm/perminvert.h"
#include "perm/permcomplement.h"

#include "comb/comb-print.h"
#include "comb/mixedradix.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in lexicographic order.

//#define TIMING // uncomment to disable printing

//#define SHORT_OUT  // suppress some output

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");
    bool dfz= true; // whether to print dots for zeros

    perm_lex P(n);
#ifdef TIMING
    while ( P.next() )  {;}
#else
    const ulong *x = P.data();
    ulong *t1 = new ulong[n]; // aux
    ulong *t2 = new ulong[n]; // aux

    cout << "         permutation         inv. perm.";
    cout << "     compl. inv. perm.    reversed perm.      fact." << endl;

    ulong ct = 0;
    do
    {
        cout << setw(4) << ct << ":";
        ++ct;

        P.print("    ", dfz);

        make_inverse(x, t1, n);
        print_perm("        ", t1, n, dfz);

#ifndef SHORT_OUT
        make_complement(t1, t2, n);
        print_perm("        ", t2, n, dfz);

        make_inverse(t2, t1, n);
        print_perm("        ", t1, n, dfz);
#endif // SHORT_OUT

//        perm2ffact(x, n, t1);
//        print_mixedradix("        ", t1, n-1, dfz);

        cout << endl;
    }
    while ( P.next() );

    delete [] t1;
    delete [] t2;
#endif

    return 0;
}
// -------------------------

/*
Timing:
time ./bin 12
arg 1: 12 == n  [Permutations of n elements.]  default=4
./bin 12  4.22s user 0.02s system 99% cpu 4.251 total
 ==> 12!/4.22 == 113.507.488  permutations per second
*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-lex-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-lex-demo.cc DEMOFLAGS=-DTIMING"
/// End:

