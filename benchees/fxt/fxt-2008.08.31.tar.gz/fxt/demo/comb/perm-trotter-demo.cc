
#include "comb/perm-trotter.h"

//#include "comb/fact2perm.h"
//#include "comb/mixedradix.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in strong minimal-change order using Trotter's algorithm.
//% Smallest element moves most often.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");
    bool bq = 0;
    NXARG(bq, "Whether to go backwards.");

    bool dfz = true;  // whether to print dots for zeros

    perm_trotter P(n);
    if ( bq )  P.last();

    ulong ct = 0;

#ifdef TIMING
    if ( !bq)  do { ++ct; } while ( P.next() );
    else       do { ++ct; } while ( P.prev() );
#else
//    ulong fc[32];
    do
    {
        cout << setw(4) << ct << ":";
        ++ct;

        P.print("    ", dfz);

        ulong sw1, sw2;
        P.get_swap(sw1, sw2);
        cout << "    (" << sw1 << ", " << sw2 << ") ";

        P.print_inv("    ", dfz);

        // print directions:
        cout << "    ";
        for (ulong j=0; j<n; ++j)  cout << " " << (P.d_[j]==1?'+':'-');

//        perm2ffact(P.invdata(), n, fc);
//        print_mixedradix("  fc=", fc, n-1);

        cout << endl;
    }
    while ( (!bq ? P.next() : P.prev()) );
#endif

    cout << "  ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
 Timing:
 time ./bin 12
./bin 12  3.49s user 0.02s system 99% cpu 3.517 total
  ==> 137,249,742 permutations per second
  ==> 16.03 cycles per update

optimized:
 time ./bin 13
./bin 13  35.77s user 0.17s system 99% cpu 35.948 total
  ==> 174,085,009  permutations per second
  ==> 12.63 cycles per update

x-optimized:
 time ./bin 13
./bin 13  34.74s user 0.18s system 99% cpu 34.982 total
  ==> 179,246,424  permutations per second
  ==> 12.27 cycles per update

BENCHARGS=13

*/


/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/perm-trotter-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/perm-trotter-demo.cc DEMOFLAGS=-DTIMING"
/// End:

