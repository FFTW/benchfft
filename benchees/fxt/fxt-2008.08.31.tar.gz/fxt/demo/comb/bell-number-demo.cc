
// demo-is-self-contained

#include "fxtio.h"
#include "demo/nextarg.h"
#include "fxttypes.h"

//% Bell numbers.

int
main(int argc, char **argv)
{
    ulong N = 11;
    NXARG(N,"Show N rows");

    ulong *v = new ulong[N+1];  v[0] = 1;
    ulong *w = new ulong[N+1];
    ulong *b = new ulong[N+1];  b[0] = 1; // Bell numbers

    for (ulong n=1; n<=N; ++n)
    {
        b[n] = v[0];

        cout << setw(2) << n-1 << ": ";
        for (ulong k=0; k<n; ++k)  cout << " " << setw(3) << v[k];
        cout << endl;

        w[0] = v[n-1];
        for (ulong k=1; k<=n; ++k)  w[k] = w[k-1] + v[k-1];
        for (ulong k=0; k<=n; ++k)  v[k] = w[k];
    }

    delete [] v;
    delete [] w;
    delete [] b;
    return 0;
}
// -------------------------

/*
pari/gp:

N=7;  v=w=b=vector(N);  v[1]=1;
{ for(n=1,N-1,
    b[n] = v[1];
    print(n-1, ":  ", v); \\ print row
    w[1] = v[n];
    for(k=2,n+1, w[k]=w[k-1]+v[k-1]);
    v=w;
 ); }
b  \\ vector of Bell-numbers

*/

/// Emacs:
/// Local Variables:
/// MyRelDir: "demo/comb"
/// makefile-dir: "../../"
/// make-target: "1demo DSRC=demo/comb/bell-number-demo.cc"
/// make-target2: "1demo DSRC=demo/comb/bell-number-demo.cc DEMOFLAGS=-DTIMING"
/// End:

