
fxt.lsm       short description

00legal.txt   legal notice

doc/*         automatically generated docs

fxt.h         function declarations


======== DESCRIPTION: ========
  fxt is a library package (coming as C++ source code)
  containing code for:

  --- FAST FOURIER TRANSFORMS (FFTs): ---
  Hartley transform based fft.
  Decimation in time/frequency, radix 2 & 4.
  Split radix FFT (DIT and DIF).
  Matrix (aka four-step) FFT.
  Special versions for zero padded data.
  Various versions of realfft (and inverse).
  Arbitrary length FFT based on chirp filter.
  2...5 dimensional FFT
  Fractional FT (based on chirp filter).
  Weighted FFT
  GrayCode-ordered FFT (a novel algorithm)
  short length (generated) FFTs

  --- FAST HARTLEY TRANSFORM (FHTs): ---
  highly optimised FHT (DIF and DIT)
  2-dimensional hartley transform
  short length (generated) FHTs

  --- NUMBER THEORETIC TRANSFORMS (NTTs): ---
  Radix 2/4, decimation in freq./time.
  Exact integer (modular-)convolution.

  --- FAST WALSH TRANSFORM ---
  Radix 2 decimation in freq./time:
  Walsh-Kronecker (wak), Walsh-Paley (pal) and
  Walsh-Kaczmarz (wal, sequency ordered).
  Dyadic convolution via walsh transform.

  --- CONVOLUTION, CORRELATION, POWER SPECTRUM: ---
  Cyclic and linear convolution and auto convolution
  for real and complex data.
  Correlation (and auto-corr.) for real and complex data.
  Power spectrum.
  Weighted convolution; negacyclic and right angle convolution.

  --- FAST HAAR TRANSFORM: ---
  Haar transform and its inverse inverse haar transform.
  Inplace version of Haar transform.
  Integer-to-integer version of Haar transform

  --- FAST WAVELET TRANSFORM: ---
  Fast transforms and inverses: Haar, Daubechies

  --- MASS STORAGE CONVOLUTION: ---
  Convolutions with size limited only by disk space.

  --- FAST MULTIPLICATION ROUTINES: ---
  fft-multiplication and mass storage multiplication
  for high precision ('bignum') libraries

   --- SINE AND COSINE TRANSFORM ---

   --- FAST Z-TRANSFORM ---
  based on chirp-filter

  --- LOW LEVEL BIT MANIPULATION: ---
  a fast bitarray utility class
  bitcounting, bitreversal, graycode etc.
  in auxbit/
    
  --- COMBINATORICS: ---
  combinations (lexicographic/numeric/minchange- order)
  permutations (lexicographic/derange/minchange- order)
  partitions / paren-pairs
  subset (numeric/minchange- order)
  general routines for permutation analysis (cycle analysis etc.)

  --- SORTING & SEARCHING: ---
  normal/index/pointer-  (both selection- and quick-) sort
  sort via compare-function (similar to C's qsort())
  sort for complex values (real-major/imag-minor)
  normal/index/pointer- search
  uniq

  --- 2D-ARRAY UTILITY CLASS ---


Keywords:
  fourier transform, fft, real fft, weighted fft,
  hartley transform, fht, 2dim transform, ndim transform,
  numbertheoretic transform, ntt, integer convolution,
  walsh transform, haar transform, wavelets, wavelet transform,
  convolution, negacyclic convolution, right angle convolution,
  correlation, spectrum, mass storage fft, multiplication,
  combinations, permutations, partitions, subsets,
  sorting, searching
