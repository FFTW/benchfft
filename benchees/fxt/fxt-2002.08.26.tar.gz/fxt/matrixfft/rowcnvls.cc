
#include "fxt.h"
#include "bit2pow.h" // ld()


void
row_weighted_auto_convolutions(double *fr, double *fi, ulong nr, ulong nc, double v)
//
// (complex, weighted) convolution of the rows of the
// nr x nc matrix (nr rows, nc columns)
//
// v!=0.0 chooses alternative normalization
{
    const ulong ldc = ld(nc);

    double *pr = fr, *pi = fi;
    for (ulong k=0; k<nr; ++k)
    {
        double w = (double)k/nr;
        weighted_complex_auto_convolution(pr, pi, ldc, w, v);
        pr += nc;
        pi += nc;
    }
}
// -------------------------


void
row_weighted_auto_convolutions(Complex *f, ulong nr, ulong nc, double v)
//
// (complex, weighted) convolution of the rows of the
// nr x nc matrix (nr rows, nc columns)
//
// v!=0.0 chooses alternative normalization
{
    const ulong ldc = ld(nc);

    Complex *p = f;
    for (ulong k=0; k<nr; ++k)
    {
        double w = (double)k/nr;
        weighted_complex_auto_convolution(p, ldc, w, v);
        p += nc;
    }
}
// -------------------------

