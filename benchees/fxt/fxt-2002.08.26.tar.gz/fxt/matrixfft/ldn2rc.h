#if !defined HAVE_LDN2RC_H__
#define      HAVE_LDN2RC_H__


inline void
ldn2rc(ulong ldn, ulong &nr, ulong &nc)
//
// input ldn == log_2(n)
// nr, nc are set that nr*nc = n and ldr>=ldc
//
// used in matrix fft/convolution
{
    ulong ldc = (ldn>>1);
    ulong ldr = ldn-ldc;

    nc = (1<<ldc);
    nr = (1<<ldr);  // nrow >= ncol
}
// -------------------------


#endif  // !defined HAVE_LDN2RC_H__
