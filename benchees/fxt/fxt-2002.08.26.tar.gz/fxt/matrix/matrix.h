#if !defined HAVE_MATRIX_H__
#define      HAVE_MATRIX_H__

#include "fxttypes.h"
#include "arith2d.h" // add(), add_val()
#include "arith.h" // add(), add_val()
#include "copy.h" // copy()

#include "array2d.h"



// ++++++++++++ CONSTRUCTION SITE ++++++++++++
//#include "jjassert.h"

// note: todo: insert compatibility checks with binary matrix-operations


template <typename Type>
class matrix : public array2d<Type>
{
public:
    Type *tmp_;  // scratch space with max(nr_, nc_) elements

public:
    matrix(ulong nr, ulong nc, Type *f=0)
        : array2d<Type>(nr, nc, f)
    { tmp_ = new Type[maxrc_]; }

    matrix(ulong nr, ulong nc, Type **_rowp)
        : array2d<Type>(nr, nc, rowp)
    { tmp_ = new Type[maxrc_]; }

    matrix(const matrix<Type> &m)
        : array2d<Type>(m.nr_, m.nc_)
    {
        tmp_ = new Type[maxrc_];
        ::copy(m.rowp_, rowp_, nr_, nc_);
    }

    ~matrix()  { delete [] tmp_; }

    matrix<Type> & operator =(const matrix<Type> &m)
    {
        copy(m, *this);
        return *this;
    }

//    operator const Type *const*()  { return rowp_; }
//    operator Type **()  { return rowp_; }


    Type norm()  const
    { return  sqrt( ::sum_of_squares(rowp_, nr_, nc_) ); }

    Type normalize(Type v=1)
    {
        Type a = norm();
        ::multiply_val(rowp_, nr_, nc_,  v / a);
        return  a;
    }


    void get_row(ulong r, Type *v)  const
    { ::copy(rowp_[r], v, nc_); }

    void set_row(ulong r, const Type *v)
    { ::copy(v, rowp_[r], nc_); }

    void set_row(ulong r, Type v)
    {
        ::fill(rowp_[r], nc_, v);
    }


    void get_col(ulong c, Type *v)  const
    { for (ulong r=0; r<nr_; ++r)  v[r] = rowp_[r][c]; }

    Type *get_col(ulong c)  const
    { get_col(c, tmp_); return tmp_; }

    void set_col(ulong c, Type *v)
    { for (ulong r=0; r<nr_; ++r)  rowp_[r][c] = v[r]; }

    void set_col(ulong c, Type v)
    { for (ulong r=0; r<nr_; ++r)  rowp_[r][c] = v; }


    void get_diag(Type *v)  const
    { for (ulong k=0; k<minrc_; ++k)  v[k] = rowp_[k][k]; }

    Type *get_diag()  const
    { get_diag(tmp_); return tmp_; }

    void set_diag(Type v)
    { for (ulong k=0; k<minrc_; ++k)  rowp_[k][k] = v; }

    void set_diag(const Type *v)
    { for (ulong k=0; k<minrc_; ++k)  rowp_[k][k] = v[k]; }

    void set_diag_seq(Type start=0, Type step=1)
    {
        for (ulong k=0; k<minrc_; ++k)
        { rowp_[k][k] = start; start += step; }
    }

    void unit(Type v=1)  { null();  set_diag( v ); }
    Type unit_sqr_diff(Type v=1)
    {
        Type s = 0;
        for (ulong r=0; r<nr_; ++r)
        {
            s += delta_sqr_diff(rowp_[r], nc_, r, v);
        }
        return  s;
    }

    void diag_add_val(Type v)
    { for (ulong k=0; k<minrc_; ++k)  rowp_[k][k] += v; }

    void diag_subtract_val(Type v)
    { for (ulong k=0; k<minrc_; ++k)  rowp_[k][k] -= v; }

    void negate()  { ::negate(rowp_, nr_, nc_); }
    void add_val(Type x)  { ::add_val(rowp_, nr_, nc_, x); }
    void subtract_val(Type x)  { ::subtract_val(rowp_, nr_, nc_, x); }
    void multiply_val(Type x)  { ::multiply_val(rowp_, nr_, nc_, x); }

    // element wise (!) operations:
    void add(const array2d<Type> &x)  { ::add(rowp_, nr_, nc_, x.rowp_); }
    void subtract(const array2d<Type> &x)  { ::subtract(rowp_, nr_, nc_, x.rowp_); }
    void multiply(const array2d<Type> &x)  { ::multiply(rowp_, nr_, nc_, x.rowp_); }
    void divide(const array2d<Type> &x)  { ::divide(rowp_, nr_, nc_, x.rowp_); }
};
// -------------------------
#undef  DIAG_LOOP



#include "mmult.h"  // matrix multiplication


template <typename Type>
inline matrix<Type> & operator += (matrix<Type> &t, const matrix<Type> &h)
{ t.add(h);  return t; }

template <typename Type>
inline matrix<Type> & operator -= (matrix<Type> &t, const matrix<Type> &h)
{ t.subtract(h);  return t; }

template <typename Type>
inline matrix<Type> & operator *= (matrix<Type> &t, const matrix<Type> &h)
{ mmultby(t, h);  return t; }

template <typename Type>
inline matrix<Type> & operator ^= (matrix<Type> &t, const matrix<Type> &h)
{ mmultbytr2(t, h);  return t; }



template <typename Type>
inline matrix<Type> & operator += (matrix<Type> &t, Type i)
{ t.add_val(i);  return t; }

template <typename Type>
inline matrix<Type> & operator -= (matrix<Type> &t, Type i)
{ t.subtract_val(i);  return t; }

template <typename Type>
inline matrix<Type> & operator *= (matrix<Type> &t, Type i)
{ t.multiply_val(i);  return t; }



#endif  // !defined HAVE_MATRIX_H__
