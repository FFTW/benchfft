#if !defined HAVE_VECTOR_H__
#define      HAVE_VECTOR_H__

#include "fxttypes.h"
#include "arith.h" // add(), add_val()
#include "copy.h" // copy()

#include "array.h"


// ++++++++++++ CONSTRUCTION SITE ++++++++++++
//#include "jjassert.h"

// note: todo: insert compatibility checks with binary vector-operations


template <typename Type>
class vector : public array<Type>
{
public:
    vector(ulong n, Type *f=0)
        : array<Type>(n, f)
    { ; }

    vector(const vector<Type> &m)
        : array<Type>(m.n_)
    { ::copy(m.f_, f_, n_); }

    ~vector()  { ; }

    vector<Type> & operator =(const vector<Type> &m)
    {
        copy(m, *this);
        return *this;
    }

//    operator const Type *()  { return f_; }
//    operator Type *()  { return f_; }


    Type norm()  const
    { return  sqrt( ::sum_of_squares(f_, n_) ); }

    Type normalize(Type v=1)
    {
        Type a = norm();
        ::multiply_val(f_, n_,  v / a);
        return  a;
    }

    void delta(ulong d)  { ::delta(f_, n_, d); }
    void set_seq(Type start=0, Type step=1)  { ::set_seq(f_, n_, start, step); }

    void negate()  { ::negate(f_, n_); }
    void add_val(Type x)  { ::add_val(f_, n_, x); }
    void subtract_val(Type x)  { ::subtract_val(f_, n_, x); }
    void multiply_val(Type x)  { ::multiply_val(f_, n_, x); }

    // element wise (!) operations:
    void add(const array<Type> &x)  { ::add(f_, n_, x.f_); }
    void subtract(const array<Type> &x)  { ::subtract(f_, n_, x.f_); }
    void multiply(const array<Type> &x)  { ::multiply(f_, n_, x.f_); }
    void divide(const array<Type> &x)  { ::divide(f_, n_, x.f_); }
};
// -------------------------
#undef  DIAG_LOOP



template <typename Type>
inline vector<Type> & operator += (vector<Type> &t, const vector<Type> &h)
{ t.add(h);  return t; }

template <typename Type>
inline vector<Type> & operator -= (vector<Type> &t, const vector<Type> &h)
{ t.subtract(h);  return t; }

template <typename Type>
inline vector<Type> & operator *= (vector<Type> &t, const vector<Type> &h)
{ mmultby(t, h);  return t; }

template <typename Type>
inline vector<Type> & operator ^= (vector<Type> &t, const vector<Type> &h)
{ mmultbytr2(t, h);  return t; }


template <typename Type>
inline vector<Type> & operator += (vector<Type> &t, Type i)
{ t.add_val(i);  return t; }

template <typename Type>
inline vector<Type> & operator -= (vector<Type> &t, Type i)
{ t.subtract_val(i);  return t; }

template <typename Type>
inline vector<Type> & operator *= (vector<Type> &t, Type i)
{ t.multiply_val(i);  return t; }



#endif  // !defined HAVE_VECTOR_H__
