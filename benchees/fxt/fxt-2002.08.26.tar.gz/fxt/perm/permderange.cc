
#include "permderange.h"
#include "permtrotter.h"
#include "inline.h"
#include "newop.h"


perm_derange::perm_derange(ulong nn)
{
    n_ = ( nn<4 ? 4 : nn );  // 2: trivial, 3: no solution exists,  4..: ok
    x_ = NEWOP(ulong, n_);
    pt = new perm_trotter(n_-1);
    first();
}
// -------------------------

perm_derange::~perm_derange()
{
    delete [] x_;
    delete pt;
}
// -------------------------

void
perm_derange::first()
{
    idx_ = 0;
    idxm_ = 0;
    for (ulong k=0; k<n_; ++k)  x_[k] = k;
}
// -------------------------

static inline void rotl1(ulong *x_, ulong n_)
// rotate array left by one position
{
    ulong x0 = x_[0];
    for (ulong k=0; k<n_-1; ++k)  x_[k] = x_[k+1];
    x_[n_-1] = x0;
}
// -------------------------

static inline void rotr1(ulong *x_, ulong n_)
// rotate array right by one position
{
    ulong xl = x_[n_-1];
    for (ulong k=n_-1; k>0; --k)  x_[k] = x_[k-1];
    x_[0] = xl;
}
// -------------------------

void
perm_derange::make_next()
{
    ++idx_;
    ++idxm_;

    if ( idxm_>=n_ ) // every n steps: need next perm_trotter
    {
        idxm_ = 0;
        if ( 0==pt->next() )
        {
            idx_ = 0;
            return;
        }

        // copy in:
        const ulong *xx = pt->data();
        for (ulong k=0; k<n_-1; ++k)  x_[k] = xx[k];
        x_[n_-1] = n_-1;  // last element
    }
    else  // rotate
    {
        if ( idxm_==n_-1 )
        {
            rotl1(x_, n_);
        }
        else // last two swapped
        {
            rotr1(x_, n_);
            if ( idxm_==n_-2 )  rotr1(x_, n_);
        }
    }
}
// -------------------------

