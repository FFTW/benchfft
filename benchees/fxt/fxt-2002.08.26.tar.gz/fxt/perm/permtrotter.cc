
#include "permtrotter.h"
#include "inline.h"
#include "newop.h"


perm_trotter::perm_trotter(ulong nn)
{
    n_ = ( nn<2 ? 2 : nn );  // 1: trivial & segfault in make_next()
    p_ = NEWOP(ulong, 3*n_);
    d_ = p_ + n_;
    x_ = d_ + n_;
    first();
}
// -------------------------

perm_trotter::~perm_trotter()
{
    delete [] p_;
}
// -------------------------

void
perm_trotter::first()
{
    yy_ = 0;
    idx_ = 0;
    for (ulong i=0; i<n_; i++)
    {
        p_[i] = 0;
        d_[i] = 1;
        x_[i] = i;
    }

    sw1_ = n_ - 1;
    sw2_ = n_ - 2;
}
// -------------------------

void
perm_trotter::make_next()
// Trotter's algorithm
// based on code by Helmut Herold
{
    ++idx_;

    ulong k = 0;
    ulong m = 0;
    yy_ = p_[m] + d_[m];
    p_[m] = yy_;

    while ( (yy_==n_-m) || (yy_==0) )
    {
        if ( yy_==0 )
        {
            d_[m] = 1;
            k++;
        }
        else  d_[m] = -1UL;

        if ( m==n_-2 )
        {
            sw1_ = n_ - 1;
            sw2_ = n_ - 2;
            swap(x_[sw1_], x_[sw2_]);

            yy_ = 1;
            idx_ = 0;
            return;
        }
        else
        {
            m++;
            yy_ = p_[m] + d_[m];
            p_[m] = yy_;
        }
    }

    sw1_ = yy_ + k;  // note that sw1 == sw2 + 1 (adjacent positions)
    sw2_ = sw1_ - 1;
    swap(x_[sw1_], x_[sw2_]);
}
// -------------------------

