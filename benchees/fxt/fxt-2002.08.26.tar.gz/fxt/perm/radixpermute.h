#if !defined HAVE_RADIXPERMUTE_H__
#define      HAVE_RADIXPERMUTE_H__


#include "fxttypes.h"
#include "inline.h"  // swap()

// defined in radixpermute.cc:
extern ulong radix_permute_nt[];  // nt[] = 9, 90, 900  for r=10, x=3
extern ulong radix_permute_kt[];  // kt[] = 1, 10, 100  for r=10, x=3
#define  nt  radix_permute_nt
#define  kt  radix_permute_kt

template <typename Type>
void radix_permute(Type *f, ulong n, ulong r)
//
// swap elements with index pairs i, j were the
// radix-r representation of i and j are mutually
// digit-reversed (e.g. 436 <--> 634)
//
// This is a radix-r generalization of revbin_permute()
// revbin_permute(f, n)) =^= radix_permute(f, n, 2)
//
// must have:
//  n == p**x for some x>=1
//  r >= 2
//
// original by Andre Piotrowski
// this optimized version avoids the (n*log(n)) divisions
// by using two size-BITS_PER_LONG tables nt[], kt[]
//
{
    ulong x = 0;
    nt[0] = r-1;
    kt[0] = 1;
    while ( 1 )
    {
        ulong z = kt[x] * r;
        if ( z>n )  break;
        ++x;
        kt[x] = z;

        nt[x] = nt[x-1] * r;
    }
    // here: n == p**x

    for (ulong i=0, j=0;  i < n-1;  i++)
    {
        if ( i<j )  swap(f[i], f[j]);

        ulong t = x - 1;
        ulong k = nt[t];  // =^=  k = (r-1) * n / r;

        while ( k<=j )
        {
            j -= k;
            k = nt[--t];  // =^=  k /= r;
        }

        j += kt[t]; // =^=  j += (k/(r-1));
    }
}
// -------------------------

#undef  nt
#undef  kt


#endif // !defined HAVE_RADIXPERMUTE_H__
