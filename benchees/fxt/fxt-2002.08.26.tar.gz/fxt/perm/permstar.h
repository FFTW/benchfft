#if !defined HAVE_PERMSTAR_H__
#define      HAVE_PERMSTAR_H__


#include "fxttypes.h"
#include "inline.h"
#include "newop.h"


class perm_star
//
// algorithm of Gideon Ehrlich, as given in Knuth
//
{
public:
    ulong n_;    // number of elements
    ulong swp_;  // index of element that was swapped (with index 0)
    ulong *a_;   // current permutation
    ulong *b_;   // aux
    ulong *c_;   // aux

public:
    perm_star(ulong n)
        : n_(n)
    {
        a_ = NEWOP(ulong, 3*n_+1);
        b_ = a_ + n_;
        c_ = b_ + n_;
        first();
    }

    ~perm_star()  { delete [] a_; }

    void first()
    {
        swp_ = n_ - 1;
        for (ulong k=0; k<n_; ++k)  a_[k] = b_[k] = k;
        for (ulong k=0; k<=n_; ++k)  c_[k] = 0;
    }

    ulong next()
    {
        ulong k = 1;

        if ( c_[k] == k )
        {
            do
            {
                c_[k] = 0;
                ++k;
            }
            while ( c_[k] >= k );
        }

        if ( k == n_ )  return 0;
        else            ++c_[k];

        swp_ = b_[k];
        swap(a_[0], a_[swp_]);

        ulong j = 1;
        --k;

        while ( j < k )  // < 0.18 iterations per call
        {
            swap(b_[j], b_[k]);
            ++j;
            --k;
        }

        return  1;  // ==0
    }

    ulong get_swap()  const  { return swp_; }

//    ulong current()  const  { return k_; }

    const ulong *data()  const  { return a_; }
};
// -------------------------


#endif  // !defined HAVE_PERMSTAR_H__
