#if !defined HAVE_REVERSE_H__
#define      HAVE_REVERSE_H__


#include "fxttypes.h"

#define  USE_PTRS   0 // default is 0
#define  USE_UNROLL 0 // default is 0

template <typename Type>
inline void reverse(Type *f, ulong n)
// reverse order of array
//
// used as reference in timing, therefore
//  the 'unnecessary' optimizations
{
    if ( n<=1 )  return;
#if  USE_PTRS == 1
    Type *g = f+n-1;
    do
    {
        Type t = *f;  *f = *g;  *g = t; // swap()
    }
    while ( ++f < --g );
#else
#if  USE_UNROLL == 1
    if ( n<16 )
    {
#endif // USE_UNROLL
        for (ulong k=0, i=n-1;  k<i;  ++k, --i)
        {
            Type t(f[k]);  f[k]=f[i];  f[i]=t;  // swap(f[k],f[i]);
        }
#if  USE_UNROLL == 1
    }
    else
    {
        ulong k = 0, i= n-1;
        if ( n&1 )
        {
            Type t(f[k]);  f[k]=f[i];  f[i]=t;
            ++k;  --i;
        }

        if ( n&2 )
        {
            Type t0(f[k]);  f[k]=f[i];  f[i]=t0;
            ++k;  --i;
            Type t1(f[k]);  f[k]=f[i];  f[i]=t1;
            ++k;  --i;
        }

        while ( k<i )
        {
            Type t0(f[k]);  f[k]=f[i];  f[i]=t0;
            ++k;  --i;
            Type t1(f[k]);  f[k]=f[i];  f[i]=t1;
            ++k;  --i;
            Type t2(f[k]);  f[k]=f[i];  f[i]=t2;
            ++k;  --i;
            Type t3(f[k]);  f[k]=f[i];  f[i]=t3;
            ++k;  --i;
        }

    }
#endif // USE_UNROLL
#endif // USE_PTRS
}
// -------------------------


template <typename Type>
inline void reverse_nh(Type *f, ulong n)
// reverse array around index n/2:
// used by recursive fht
{
    if ( n<=2 )  return;
#if  USE_PTRS == 1
    Type *g = f+n-1;
    ++f;
    do
    {
        Type t = *f;  *f = *g;  *g = t; // swap()
    }
    while ( ++f < --g );
#else
    for (ulong k=1, i=n-1;  k<i;  ++k, --i)
    {
        Type t(f[k]);  f[k]=f[i];  f[i]=t;  // swap(f[k],f[i]);
    }
#endif // USE_PTRS
}
// -------------------------

#undef  USE_PTRS


#endif // !defined HAVE_REVERSE_H__
