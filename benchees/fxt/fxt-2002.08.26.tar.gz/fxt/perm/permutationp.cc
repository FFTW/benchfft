
#include "permutation.h"
#include "bitarray.h"

#include "fxtio.h"
#include "fxtiomanip.h"

ulong
print_cycles(const ulong *f, ulong n, bitarray *bp=0)
//
// print the cycles of the permutation
// return number of fixed points
//
{
    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags
    tp->clear_all();

    ulong ct = 0;  // # of fixed points
    for (ulong k=0; k<n; ++k)
    {
        if ( tp->test_clear(k) )  continue;  // already processed
        tp->set(k);

        // follow a cycle:
        ulong i = k;
        ulong g = f[i];  // next index
        if ( g==i )  // fixed point ?
        {
            ++ct;
            continue;
        }

        cout << "(" << setw(3) << i;
        while ( 0==(tp->test_set(g)) )
        {
            cout << " <-- " << setw(3) << g;
            g = f[g];
        }
//        cout << " <-- " << setw(3) << g;  // repeat cycle leader
        cout << " )" << endl;
    }

    if ( 0==bp )  delete tp;

    return  ct;
}
// -------------------------

