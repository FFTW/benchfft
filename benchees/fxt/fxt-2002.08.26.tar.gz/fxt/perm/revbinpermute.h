#if !defined HAVE_REVBINPERMUTE_H__
#define      HAVE_REVBINPERMUTE_H__


#include "inline.h"  // swap()
#include "fxttypes.h"
#include "bitsperlong.h" //  BITS_PER_LONG
#include "revbin.h" // revbin(), revbin_update()

#include "bitasm.h"
#if  defined  BITS_USE_ASM
#include "bitlow.h" // lowest_bit_idx()
#define  RBP_USE_ASM  // use bitscan if available, comment out to disable
#endif // defined  BITS_USE_ASM


#define  RBP_SYMM  4  // 1, 2, 4 (default is 4)
#define  idx_swap(f, k, r)  { ulong kx=(k), rx=(r);  swap(f[kx], f[rx]); }
template <typename Type>
void revbin_permute(Type *f, ulong n)
{
    if ( n<=8 )
    {
        if ( n==8 )
        {
            swap(f[1], f[4]);
            swap(f[3], f[6]);
        }
        else if ( n==4 )  swap(f[1], f[2]);

        return;
    }

    const ulong nh = (n>>1);
    ulong x[BITS_PER_LONG];
    x[0] = nh;
    {  // initialize xor-table:
        ulong i, m = nh;
        for (i=1; m!=0; ++i)
        {
            m >>= 1;
            x[i] = x[i-1] ^ m;
        }
    }

#if  ( RBP_SYMM >= 2 )
    const ulong n1  = n - 1;    // = 11111111
#if  ( RBP_SYMM >= 4 )
    const ulong nx1 = nh - 2;   // = 01111110
    const ulong nx2 = n1 - nx1; // = 10111101
#endif //  ( RBP_SYMM >= 4 )
#endif //  ( RBP_SYMM >= 2 )
    ulong k=0, r=0;
    while ( k<n/RBP_SYMM  )  // n>=16, n/2>=8, n/4>=4
    {
        // ----- k%4 == 0:
        if ( r>k )
        {
            swap(f[k], f[r]);  // <nh, <nh 11
#if  ( RBP_SYMM >= 2 )
            idx_swap(f, n1^k, n1^r);  // >nh, >nh 00
#if  ( RBP_SYMM >= 4 )
            idx_swap(f, nx1^k, nx1^r);  // <nh, <nh 11
            idx_swap(f, nx2^k, nx2^r);  // >nh, >nh 00
#endif //  ( RBP_SYMM >= 4 )
#endif //  ( RBP_SYMM >= 2 )
        }

        r ^= nh;
        ++k;

        // ----- k%4 == 1:
        if ( r>k )
        {
            swap(f[k], f[r]);  // <nh, >nh 10
#if  ( RBP_SYMM >= 4 )
            idx_swap(f, n1^k, n1^r);  // >nh, <nh 01
#endif //  ( RBP_SYMM >= 4 )
        }

        { // scan for lowest unset bit of k:
#ifdef  RBP_USE_ASM
            ulong i = lowest_bit_idx(~k);
#else
            ulong m = 2,  i = 1;
            while ( m & k )  { m <<= 1;  ++i; }
#endif // RBP_USE_ASM
            r ^= x[i];
        }
        ++k;

        // ----- k%4 == 2:
        if ( r>k )
        {
            swap(f[k], f[r]);  // <nh, <nh 11
#if  ( RBP_SYMM >= 2 )
            idx_swap(f, n1^k, n1^r); // >nh, >nh 00
#endif //  ( RBP_SYMM >= 2 )
        }

        r ^= nh;
        ++k;

        // ----- k%4 == 3:
        if ( r>k )
        {
            swap(f[k], f[r]);    // <nh, >nh 10
#if  ( RBP_SYMM >= 4 )
            idx_swap(f, nx1^k, nx1^r);   // <nh, >nh 10
#endif //  ( RBP_SYMM >= 4 )
        }

        { // scan for lowest unset bit of k:
#ifdef  RBP_USE_ASM
            ulong i = lowest_bit_idx(~k);
#else
            ulong m = 4,  i = 2;
            while ( m & k )  { m <<= 1;  ++i; }
#endif // RBP_USE_ASM
            r ^= x[i];
        }
        ++k;
    }
}
// -------------------------
#undef  idx_swap
//#undef  RBP_SYMM  // keep for checks in revbinpermute.cc

#endif // !defined HAVE_REVBINPERMUTE_H__
