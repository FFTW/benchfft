#if !defined HAVE_PERMDERANGE_H__
#define      HAVE_PERMDERANGE_H__

#include "fxttypes.h"


class perm_trotter;

class perm_derange
{
public:
    ulong n_;    // number of elements
    ulong *x_;   // current permutation
    ulong idx_;  // index
    ulong idxm_; // index modulo n
    perm_trotter* pt;

public:
    perm_derange(ulong nn);
    ~perm_derange();

    ulong next()  { make_next();  return idx_; }
    ulong current()  const  { return idx_; }
    const ulong *data()  const  { return x_; }

protected:
    void first();
    void make_next();
};
// -------------------------


#endif  // !defined HAVE_PERMDERANGE_H__
