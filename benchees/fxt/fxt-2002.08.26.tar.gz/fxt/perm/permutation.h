#if !defined HAVE_PERMUTATION_H__
#define      HAVE_PERMUTATION_H__


//#include "bitarray.h"
class bitarray;

#include "fxttypes.h"


// perm/permutationq.cc:
int is_identity(const ulong *f, ulong n);
int has_fixed_points(const ulong *f, ulong n);
ulong count_fixed_points(const ulong *f, ulong n);
int is_derangement(const ulong *f, const ulong *g, ulong n);
int is_valid_permutation(const ulong *f, ulong n, bitarray *bp=0);
int is_involution(const ulong *f, ulong n);

int is_inverse(const ulong *f, const ulong *g, ulong n);

int is_square(const ulong *f, const ulong *g, ulong n);

ulong permutation_index(const ulong *f, ulong n);

// perm/permutationp.cc:
ulong print_cycles(const ulong *f, ulong n, bitarray *bp=0);


// perm/permutation.cc:
void make_inverse(const ulong *f, ulong *g, ulong n);
void make_inverse(ulong *f, ulong n, bitarray *bp=0);
void boothroyd(ulong *f, ulong n, bitarray *bp=0);

void make_square(ulong *f, ulong n, bitarray *bp=0);
void make_square(const ulong *f, ulong *g, ulong n);

void compose(const ulong *f, const ulong *g, ulong *h, ulong n);
void compose(const ulong *f, ulong *g, ulong n);

void power(const ulong *f, ulong *g, ulong n, long e, ulong *t=0);

void random_permute(ulong *f, ulong n);
void random_permutation(ulong *f, ulong n);

//: functions for the application of permutations to data
//: are found in perm/permapply.h

#endif  // !defined HAVE_PERMUTATION_H__
