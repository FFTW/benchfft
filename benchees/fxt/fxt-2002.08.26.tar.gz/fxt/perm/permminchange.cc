
#include "permminchange.h"
#include "inline.h"
#include "newop.h"


perm_minchange::perm_minchange(ulong nn)
{
    n = ( nn<1 ? 1 : nn );
    p  = NEWOP(ulong, 4*n);
    ip = p + n;
    d  = ip + n;
    ii = d + n;
    first();
}
// -------------------------

perm_minchange::~perm_minchange()
{
    delete [] p;
}
// -------------------------


void
perm_minchange::first()
{
    for (ulong i=0; i<n; i++)
    {
        p[i] = ip[i] = i;
        d[i] = -1UL;
        ii[i] = 0;
    }
    sw1 = sw2 = 0;
    idx = 0;
}
// -------------------------


ulong
perm_minchange::make_next(ulong m)
{
    ulong i = ii[m];
    ulong ret = 1;

    if ( i==m )
    {
        d[m] = -d[m];
        if ( 0!=m )  ret = make_next(m-1);
        else         ret = 0;
        i = -1UL;
    }

    if ( (long)i>=0 )
    {
        // this block based on code by
        // Frank Ruskey / Glenn Rhoads:
        ulong j = ip[m];
        ulong k = j + d[m];
        ulong z = p[k];
        p[j] = z;
        p[k] = m;
        ip[z] = j;
        ip[m] = k;

        sw1 = j;  // note that sw1 == sw2 +-1 (adjacent positions)
        sw2 = k;
        ++idx;
    }

    ++i;
    ii[m] = i;

    return  ret;
}
// -------------------------
