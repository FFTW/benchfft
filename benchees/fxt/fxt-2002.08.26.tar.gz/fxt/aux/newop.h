#if !defined HAVE_NEWOP_H__
#define      HAVE_NEWOP_H__

#define  NEWOP(type, num)  ((type *)operator new ((num)*sizeof(type)))

#endif // !defined HAVE_NEWOP_H__
