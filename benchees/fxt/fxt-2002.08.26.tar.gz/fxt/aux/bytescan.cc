
#include  "bitsperlong.h"
#include  "fxttypes.h"
#include  "zerobyte.h"


//ulong www = 0;

ulong
long_strlen(const char *str)
//
// (almost) UNTESTED
//
// might be a win on 64bit-machines
//
{
    unsigned long x;
    const char *p = str;

    /* alignment: scan bytes up to word boundary */
    while ( (ulong)p % BYTES_PER_LONG )
    {
        if ( 0 == *p )  return  (ulong)(p-str);
        ++p;
    }

    x = *(unsigned long *)p;
    while ( ! contains_zero_byte(x) )
    {
        p += BYTES_PER_LONG;
        x = *(unsigned long *)p;
    }

//    www = x;

    /* now a zero byte is somewhere in x */
//    while ( x & 0xff )  { ++p;  x >>= 8; }
    while ( 0 != *p )  { ++p; }  // ok

    // for utterly mysterious reasons this function seems
    // to work also with the 'broken' version of contains_zero_byte()

    return  (ulong)(p-str);
}
//------------------------


const char *
long_memchr(const char *str, char c)
//
// UNTESTED
//
{
    /* alignment: scan bytes up to word boundary */
    while ( (ulong)str % BYTES_PER_LONG )
    {
        if ( c == *str )  return  str;
        ++str;
    }

    unsigned long w;
    w = c;         /* 0000000c */
    w ^= (w<<8);   /* 000000cc */
    w ^= (w<<16);  /* 0000cccc */
#if  BITS_PER_LONG > 32
    w ^= (w<<32);  /* cccccccc */
#endif

    unsigned long x = *(unsigned long *)str;
    x ^= w;  /* if x contained c it now contains a zero */
    while ( ! contains_zero_byte(x) )
    {
        str += BYTES_PER_LONG;
        x = *(unsigned long *)str;
        x ^= w;
    }

    /* now a zero byte is somewhere (where the c was) in x */

    while ( x & 0xff )  { ++str;  x >>= 8; }

    return  str;
}
//------------------------
