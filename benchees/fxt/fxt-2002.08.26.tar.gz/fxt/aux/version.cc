
#include "fxtio.h"


static const char *version_string = "26-August-2002";


void
print_fxt_version()
//
// print fxt version, compile date and flags
//
{
    cout << "  ----=============== FXT version " << version_string << " ================---- " << endl;
    cout << "       author: Joerg Arndt,  email: arndt (AT) jjj.de " << endl;
#if defined  __GNUC__
//#define  XSTR(s)  STR(s)
//#define  STR(s)  #s
    cout << "     compiler used: GNU C " << __VERSION__ << endl;
    cout << "     compilation date: " << __DATE__  << ", " << __TIME__ << endl;
#if defined OFLAGS
    cout << "     compilation flags were:\n   " << OFLAGS << endl;
#endif // OFLAGS
#endif // __GNUC__
    cout << "        FXT is online at http://www.jjj.de/fxt/   " << endl;
    cout << "  ----===========================================================----  " << endl;
    cout << endl;
}
// -------------------------
