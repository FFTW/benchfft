#if !defined HAVE_SCANFUNC_H__
#define      HAVE_SCANFUNC_H__


#include "fxttypes.h"


template <typename Type>
inline ulong first_idx(const Type *f, ulong n, bool (* func)(Type))
// return index of first element for which func returns true
// return n  if there is no such element
{
    ulong k = 0;
    while ( (k<n) && (!func(f[k])) )  k++;
    return k;
}
// -------------------------

template <typename Type>
inline ulong next_idx(const Type *f, ulong n, bool (* func)(Type), ulong k0)
// like first_idx() but start from k0
{
    ulong k = k0;
    while ( (k<n) && (!func(f[k])) )  k++;
    return k;
}
// -------------------------


template <typename Type>
inline ulong last_idx(const Type *f, ulong n, bool (* func)(Type))
// return index of last element for which func returns true
// return n  if there is no such element
{
    ulong k = n-1;
    while ( ! func(f[k]) )
    {
        k--;
        if ( 0==k )  return n;
    }
    return k;
}
// -------------------------

template <typename Type>
inline ulong previous_idx(const Type *f, ulong n, bool (* func)(Type), ulong k0)
// like last_idx() but start from k0
// initial call with n-1, _not_ n !
{
    ulong k = k0;
    while ( ! func(f[k]) )
    {
        k--;
        if ( 0==k )  return n;
    }
    return k;
}
// -------------------------


template <typename Type>
inline ulong count(const Type *f, ulong n, bool (* func)(Type))
// return number of elements for which func returns true
{
    ulong ct = 0;
    for (ulong k=0; k<n; ++k)  if ( func(f[k]) )  ct++;
    return  ct;
}
// -------------------------

template <typename Type>
inline ulong grep(const Type *f, ulong n, bool (* func)(Type), Type *g)
// make g[] the sequence of values for which func returns true
// return number of 'matching' elements found
{
    ulong ct = 0;
    for (ulong k=0; k<n; ++k)  if ( func(f[k]) )  g[ct++] = f[k];
    return  ct;
}
// -------------------------


template <typename Type>
inline ulong grep_idx(const Type *f, ulong n, bool (* func)(Type), ulong *x)
// make x[] the sequence of indices for which func returns true
// return number of 'matching' elements found
{
    ulong ct = 0;
    for (ulong k=0; k<n; ++k)  if ( func(f[k]) )  x[ct++] = k;
    return  ct;
}
// -------------------------



#endif // !defined HAVE_SCANFUNC_H__
