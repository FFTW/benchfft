
#include "fxttypes.h"

#include "printbin.h"

#include "fxtio.h"
#include "fxtiomanip.h"

void
print_set(const char *bla, const ulong *x, ulong n)
{
    if ( bla )  cout << bla;

    cout << "{";
    for (ulong k=0; k<n; ++k)
    {
        cout << x[k];
        if ( k<n-1 )  cout << ", ";
    }
    cout << "}";
}
// -------------------------


void
print_set_as_bitset(const char *bla, const ulong *x, ulong n, ulong N)
{
    if ( bla )  cout << bla;
    ulong w = 0;
    for (ulong j=0; j<n; ++j)  w |= (1UL<<x[j]);
    print_bin_nn(w, N, ".1");

//    ulong j = 0;
//    for (ulong k=0; k<n; ++k)
//    {
//        for (  ; j<x[k]; ++j)  cout << '.';
//        cout << '1';
//        ++j;
//    }
//
//    while ( j++ < N )  cout << '.';
}
// -------------------------


ulong
print_delta_set_as_set(const char *bla, const ulong *x, ulong n,
                       int eq/*=0*/)
// print delta set like:  {0, 1, 3}
// if eq!=0 then print spaces for empty positions: {0, 1,  , 3}
{
    if ( bla )  cout << bla;

    cout << "{";
    ulong k = 0;
    ulong num = 0;

    if ( 0==eq )  // skip leading empty buckets
    {
        while ( k<n-1 && 0==x[k])  { ++k; }
    }

    if ( x[k] )  { cout << k;  ++num; }
    else if ( 0!=eq )   cout << " ";

    for (++k; k<n; ++k)
    {
        if ( x[k] )
        {
            cout << ", " << k;
            ++num;
        }
        else if ( 0!=eq )   cout << ",  ";
    }
    cout << "}";

    return  num;
}
// -------------------------
