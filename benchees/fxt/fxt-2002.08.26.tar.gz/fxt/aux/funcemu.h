#if !defined HAVE_FUNCEMU_H__
#define      HAVE_FUNCEMU_H__


#include "fxttypes.h"

template <typename Type>
class funcemu
{
public:
    ulong tp_;  // sTate stack Pointer
    ulong dp_;  // Data stack Pointer
    ulong *t_;  // sTate stack
    Type  *d_;  // Data stack


public:
    funcemu(ulong maxdepth, ulong ndata)
    {
        t_ = new ulong[maxdepth];
        d_ = new Type[ndata];
        init();
    }

    ~funcemu()
    {
        delete [] d_;
        delete [] t_;
    }

    funcemu & operator = (const funcemu &);  // forbidden

    void init()  { dp_=0; tp_=0; }


    void stpush(ulong x)  { t_[tp_++] = x; }
    ulong stpeek()  const  { return  t_[tp_-1]; }
    void stpeek(ulong &x)  { x = t_[tp_-1]; }
    void stpoke(ulong x)  { t_[tp_-1] = x; }
    void stpop()  { --tp_; }
    void stpop(ulong ct)  { tp_-=ct; }

    void stnext()  { ++t_[tp_-1]; }
    void stnext(ulong x)  { t_[tp_-1] = x; }
    bool more()  const  { return (0!=dp_); }

    void push(Type x)  { d_[dp_++] = x; }
    void push(Type x, Type y)  { push(x); push(y); }
    void push(Type x, Type y, Type z)  { push(x); push(y); push(z); }
    void push(Type x, Type y, Type z, Type u)
    { push(x); push(y); push(z); push(u); }

    void peek(Type &x)  { x = d_[dp_-1]; }
    void peek(Type &x, Type &y)
    { y = d_[dp_-1]; x = d_[dp_-2]; }
    void peek(Type &x, Type &y, Type &z)
    { z = d_[dp_-1]; y = d_[dp_-2]; x = d_[dp_-3]; }
    void peek(Type &x, Type &y, Type &z, Type &u)
    { u = d_[dp_-1]; z = d_[dp_-2]; y = d_[dp_-3]; x = d_[dp_-4]; }

    void poke(Type x)  { d_[dp_-1] = x; }
    void poke(Type x, Type y)
    { d_[dp_-1] = y; d_[dp_-2] = x; }
    void poke(Type x, Type y, Type z)
    { d_[dp_-1] = z; d_[dp_-2] = y; d_[dp_-3] = x; }
    void poke(Type x, Type y, Type z, Type u)
    { d_[dp_-1] = u; d_[dp_-2] = z; d_[dp_-3] = y; d_[dp_-4] = x; }

    void pop(ulong ct=1) { dp_-=ct; }
};
// -------------------------


#endif // !defined HAVE_FUNCEMU_H__
