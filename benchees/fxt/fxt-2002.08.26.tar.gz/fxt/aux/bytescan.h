#if !defined HAVE_BYTESCAN_H__
#define      HAVE_BYTESCAN_H__

#include "fxttypes.h"

// auxbit/bytescan.cc:
ulong long_strlen(const char *str);
char *long_memchr(const void *str, char c);



#endif //  !defined HAVE_BYTESCAN_H__
