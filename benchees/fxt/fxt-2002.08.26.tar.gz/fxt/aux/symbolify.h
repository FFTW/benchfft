#if !defined HAVE_SYMBOLIFY_H__
#define      HAVE_SYMBOLIFY_H__


#include "fxttypes.h"
#include "permutation.h"
#include "permapply.h"
#include "restrict.h"



template <typename Type>
ulong symbolify_by_size(const Type *f, Type * restrict g, ulong n,
                        Type eps=1e-6,
                        ulong *ix=0)
//
// out of f[] compute an array of 'symbols' (i.e. numbers)
// that represent the different values
//
// negative values get negative 'symbols'
// symbols are given wrt. to sort-order
//
// return number of different values found (after quantise)
//
// e.g.:
//
//   1.3133     -1.0101     0.79412     -0.71544
//   0.29064     0.99173   -1.4382       0.79412
//  -1.1086      1.2521     0.99173     -1.0101
//  -0.18003    -1.1086     0.29064      1.3133
//
// is (using eps==1e-4) transformed to:
//
//   9           2           6           3
//   5           7           0           6
//   1           8           7           2
//   4           1           5           9
//
// this routine is useful to find structure
// in purely numerical data
//
{
    ulong *x = ix;
    if ( 0==ix )  x = NEWOP(ulong, n);

    set_seq(x, n);
    idx_quick_sort(f, n, x);

    apply(x, f, g, n);
    quantise(g, n, eps);

    eps *= 0.5;  // some val <1.0
    ulong nsym = 1;

    ulong z = 0;
    Type s = 0.0;
    Type el = g[z], lel;
    g[z] = s;
    for(ulong k=z+1; k<n; ++k)
    {
        lel = el;
        el = g[k];
        if ( fabs(el-lel) > eps )
        {
            ++nsym;;
            s += 1.0;
        }
        g[k] = s;
    }

    apply_inverse(x, g, n);

    if ( 0==ix )  delete [] x;

    return  nsym;
}
// -------------------------



template <typename Type>
ulong symbolify_by_order(const Type *f, Type * restrict g, ulong n,
                         Type eps=1e-6,
                         ulong *ix=0)
//
// out of f[] compute an array of 'symbols' (i.e. numbers)
// that represent the different values
//
// symbols are given wrt. to order of appearence.  The first
// appearence of each value gets its index as value.  The later
// appearences of the same value 'point' to the first appearence.
//
// returns number of different values found (after quantise)
//
// e.g.:
//
//   1.3133     -1.0101     0.79412     -0.71544
//   0.29064     0.99173   -1.4382       0.79412
//  -1.1086      1.2521     0.99173     -1.0101
//  -0.18003    -1.1086     0.29064      1.3133
//
// is (using eps==1e-4) transformed to:
//
//     0           1           2           3
//     4           5           6           2
//     8           9           5           1
//     12          8           4           0
//
// this routine is useful to find structure
// in purely numerical data
//
// primitive algorithm proportional n*n, to be improved
//
{
    ulong *x = ix;
    if ( 0==ix )  x = NEWOP(ulong, n);

    ulong nsym = symbolify_by_size(f, g, n, eps, x);

    Type t[n];
    for (ulong k=0; k<n; ++k)
    {
        Type s = k;
        Type so = g[k];
        if ( so<0 )  continue;

        for (ulong j=0; j<n; ++j)
        {
            if ( g[j]==so )
            {
                t[j] = s;
                g[j] = -1;
            }
        }
    }

    copy(t, g, n);

    if ( 0==ix )  delete [] x;

    return  nsym;
}
// -------------------------


#endif // !defined HAVE_SYMBOLIFY_H__
