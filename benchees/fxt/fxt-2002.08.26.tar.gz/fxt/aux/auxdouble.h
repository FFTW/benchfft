#if !defined HAVE_AUXDOUBLE_H__
#define      HAVE_AUXDOUBLE_H__


#include "fxttypes.h"     // for ulong


// aux/auxdouble.cc:

double rnd01();
void rnd01(double *f, ulong n);
double white_noise();
double white_noise(double *f, ulong n);
double pythag(double a, double b);
double extr3_estimate(const double *f);
double extr3_estimate(const double *f, double &xval);
double sinc(double x);

void chop(double &x, double eps=1e-6);
void chop(double *f, ulong n, double eps=1e-6);
double norm(const double *f, ulong n);
double normalize(double *f, ulong n, double v=1.0);
double sigma(const double *f, ulong n, double *mp=0);
void   mean_sigma(const double *f, ulong n, double *mp, double *sp);
void   smooth(double *f, ulong n, ulong m=1);
double rms_diff(const double *f, const double *g, ulong n);
ulong *histogram(const double *f, ulong n, ulong nbox, ulong *hh=0);

void welch_win(double *f, ulong n);

void ri_multiply(const double *fr, const double *fi,
                 double *gr, double *gi, ulong n);

// jj_end_autodoc


// aux/trigtable.cc:
void make_sincos_table(ulong n, ulong m, double **s, double **c);


// aux/resample.cc:
ulong resample_sinc(const double *a, ulong an, double af, double *b, double bf, ulong bn);
ulong resample_linear(const double *f, ulong nf, double v, double *g, ulong ng);
ulong sample_up_linear(const double *f, ulong nf, double v, double *g, ulong ng);
ulong sample_down_linear(const double *f, ulong nf, double v, double *g, ulong ng);


#endif  // !defined HAVE_AUXDOUBLE_H__
