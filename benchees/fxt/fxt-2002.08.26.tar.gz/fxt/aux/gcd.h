#if !defined HAVE_GCD_H__
#define      HAVE_GCD_H__


#include "fxttypes.h"


// aux/gcd.cc:
ulong gcd(ulong a, ulong b);
long sgcd(long a, long b);
ulong lcm(ulong a, ulong b);

long  binary_gcd(long a, long b);
long  egcd(long u, long v, long &u1, long &u2);


#endif  // !defined HAVE_GCD_H__
