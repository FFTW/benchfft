#if !defined HAVE_RANGE_H__
#define      HAVE_RANGE_H__

#include "bitsperlong.h"

template <typename Type>
static inline int in_range_q(Type x, Type xmin, Type xmax)
// Return whether xmin<= x <=xmax
{
    return ( (x>=xmin) && (x<=xmax) );
//    return ( (x-xmin) | (xmax-x) ) >> (BITS_PER_LONG-1);
}
// -------------------------

template <typename Type>
static inline int off_range_q(Type x, Type xmin, Type xmax)
// Return whether x<xmin or x>xmax
{
    return ( (x<xmin) || (x>xmax) );
//    return  ( (xmin-x) | (x-xmax) ) >> (BITS_PER_LONG-1);
}
// -------------------------


template <typename Type>
static inline void wrap_range(Type &x, Type xmin, Type xmax)
// toroidal rules apply
{
    if ( x<xmin )  x = xmax;
    else if ( x>xmax )  x = xmin;
}
// -------------------------

template <typename Type>
static inline void clip_range(Type &x, Type xmin, Type xmax)
// force x into [xmin, xmax]
{
    if ( x<xmin )        x = xmin;
    else  if ( x>xmax )  x = xmax;
}
// -------------------------

template <typename Type>
static inline int clip_range_q(Type &x, Type xmin, Type xmax)
// force x into [xmin, xmax]
// return whether clipping occurred
{
    int clipq = 0;
    if ( x<xmin )
    {
        x = xmin;
        clipq = 1;
    }
    else
    {
        if ( x>xmax )
        {
            x = xmax;
            clipq = 1;
        }
    }

    return clipq;
}
// -------------------------


//template <typename Type>
//static inline void intersect_range(Type &t1, Type &t2, Type tmin, Type tmax)
//// precondition:  t1<=t2
//{
//    // completely outside ?:
//    if ( (t1>tmax) || (t2<tmin) )  return;
////    if ( ((tmax-t1) | (t2-tmin)) >> (BITS_PER_LONG-1) )  return;
//
//    if ( t1<tmin )  t1 = tmin;
//    if ( t2>tmax )  t2 = tmax;
//}
//// -------------------------

template <typename Type>
static inline int intersect_range_q(Type &t1, Type &t2, Type tmin, Type tmax)
//
// return:
// -1  if  completely outside
//  0  if  completely inside
// +1  if  clipped
//
// precondition:  t1<=t2
{
    // completely outside ?:
    if ( (t1>tmax) || (t2<tmin) )  return -1;
//    if ( ((tmax-t1) | (t2-tmin)) >> (BITS_PER_LONG-1) )  return -1;

    int clipq = 0;
    if ( t1<tmin )
    {
        t1 = tmin;
        clipq = 1;
    }

    if ( t2>tmax )
    {
        t2 = tmax;
        clipq = 1;
    }

    return  clipq;
}
// -------------------------



#endif // !defined HAVE_RANGE_H__
