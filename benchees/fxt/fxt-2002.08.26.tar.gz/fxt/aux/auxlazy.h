#if !defined HAVE_AUXLAZY_H__
#define      HAVE_AUXLAZY_H__

// include file for the lazy

#include "array.h"
#include "gcd.h"
#include "auxdouble.h"
#include "quantise.h"
#include "auxprint.h"
#include "copy.h"
#include "inline.h"
#include "minmax.h"
#include "range.h"
#include "arith.h"
#include "intarith.h"
#include "misc.h"
#include "scale.h"
#include "scan.h"
#include "scanbox.h"
#include "shift.h"
#include "sincos.h"
#include "csincos.h"
#include "workspace.h"
#include "newop.h"
#include "funcemu.h"
#include "symbolify.h"
#include "scanfunc.h"
#include "applyfunc.h"
#include "diff.h"
#include "symmetry.h"
#include "bytescan.h"


#endif // !defined HAVE_AUXLAZY_H__
