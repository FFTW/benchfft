#if !defined HAVE_INLINE_H__
#define      HAVE_INLINE_H__


#include "fxttypes.h"

template <typename Type>
static inline Type  sqr(Type x)
{ return  x * x; }

template <typename Type>
static inline void  swap(Type &x, Type &y)
// swap values
{ Type t(x);  x = y;  y = t; }

template <typename Type>
static inline void  swap0(Type &x, Type &y)
// swap() for y known to be zero
{ y = x;  x = 0; }


template <typename Type>
static inline Type  min(const Type &x, const Type &y)
// Return minimum of the input values
{ return  x<y ? x : y; }

template <typename Type>
static inline ulong  idx_min(const Type &x, const Type &y)
// Return index (0 or 1) of minimum of the input values
{ return  x<y ? 0 : 1; }

template <typename Type>
static inline Type  max(const Type &x, const Type &y)
// Return maximum of the input values
{ return  x>y ? x : y; }

template <typename Type>
static inline ulong  idx_max(const Type &x, const Type &y)
// Return index (0 or 1) of maximum of the input values
{ return  x>y ? 0 : 1; }


template <typename Type>
static inline Type  min3(const Type &x, const Type &y, const Type &z)
// Return minimum of the input values
{ return  min( min(x,y), z ); }

template <typename Type>
static inline ulong  idx_min3(const Type &x, const Type &y, const Type &z)
// Return index (0,1, or 2) of minimum of the input values
{ return  x<z ? (x<y ? 0 : 1 ) : (y<z ? 1 : 2); }


template <typename Type>
static inline Type  max3(const Type &x, const Type &y, const Type &z)
// Return maximum of the input values
{ return  max( max(x,y), z ); }

template <typename Type>
static inline ulong  idx_max3(const Type &x, const Type &y, const Type &z)
// Return index (0,1, or 2) of maximum of the input values
{ return  x>z ? (x>y ? 0 : 1 ) : (y>z ? 1 : 2); }


template <typename Type>
static inline void  idx_minmax3(Type x0, Type x1, Type x2, ulong &i, ulong &a)
// set i, a to index (0,1, or 2) of min and max, resp.
// jjtodo: optimize
{ i = idx_min3(x0, x1, x2);  a = idx_max3(x0, x1, x2); }


template <typename Type>
static inline Type  median3(const Type &x, const Type &y, const Type &z)
// Return median of the input values
{ return  x<y ? (y<z ? y : (x<z ? z : x)) : (z<y ? y : (z<x ? z : x)); }

template <typename Type>
static inline ulong  idx_median3(const Type &x, const Type &y, const Type &z)
// Return index (0,1, or 2) of median of the input values
{ return  x<y ? (y<z ? 1 : (x<z ? 2 : 0)) : (z<y ? 1 : (z<x ? 2 : 0)); }


template <typename Type>
static inline Type  sign(const Type &x)
// Return sign(x)
{ return  x<0 ? -1 : (x==0?0:1); }

template <typename Type>
static inline Type  sign1(const Type &x)
// Return 1 iff x==0, else sign(x)
{ return  x<0 ? -1 : 1; }

template <typename Type>
static inline int sign_bit(const Type &x)
// Return 1 iff x<0, else 0
{ return  x<0 ? 1 : 0; }

template <typename Type>
static inline Type  abs(const Type &x)
// Return abs(x)
{ return  x>=0 ? x : -x; }

// ---- sorting:

template <typename Type>
static inline void sort2(Type &x1, Type &x2)
// sort x1, x2
{ if ( x1>x2 )  swap(x1, x2); }

template <typename Type>
static inline void sort3(Type &x0, Type &x1, Type &x2)
// sort x0, x1, x2
//{ sort2(x0,x1); sort2(x1,x2); sort2(x0,x1); }
{ sort2(x0,x1); if (x1>x2) {swap(x1,x2); sort2(x0,x1);} }


template <typename Type>
static inline void idx_sort2(const Type *f, ulong *x)
// sort index x[] so that f[x[0]]<=f[x[1]]
{ if ( f[x[0]]>f[x[1]] )  swap(x[0], x[1]); }

template <typename Type>
static inline void idx_sort2(Type f0, Type f1, ulong &x0, ulong &x1)
// sort x0, x1 according to order of f0, f1
{ if ( f0>f1 )  swap(x0, x1); }

template <typename Type>
static inline void idx_sort3(const Type *f, ulong *x)
// sort index x[] so that f[x[0]]<=f[x[1]]<=f[x[2]]
{ sort2_idx(f, x); sort2_idx(f+1, x+1); sort2_idx(f, x); }

template <typename Type>
static inline void idx_sort3(Type f0, Type f1, Type f2,
                             ulong &x0, ulong &x1, ulong &x2)
// sort x0, x1, x2 according to order of f0, f1, f2
{
    if ( f0>f1 )  { swap(x0, x1); swap(f0, f1); }
    if ( f1>f2 )  { swap(x1, x2); swap(f1, f2); }
    if ( f0>f1 )  { swap(x0, x1); }
}


template <typename Type>
static inline void ptr_sort2(const Type *dummy, Type *x)
// sort x[] so that f[x[0]]<=f[x[1]]
{ if ( *x[0]>*x[1] )  swap(x[0], x[1]); }

template <typename Type>
static inline void ptr_sort2(const Type *dummy, Type *&x0, ulong *&x1)
// sort x0, x1 according to order of f0, f1
{ if ( *x0>*x1 )  swap(x0, x1); }


#endif // !defined HAVE_INLINE_H__
