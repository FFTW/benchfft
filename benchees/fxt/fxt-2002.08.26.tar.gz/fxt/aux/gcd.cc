
//#include "fxtio.h"
//#include "jjassert.h"

#include "fxttypes.h"


ulong
gcd(ulong a, ulong b)
{
    if ( a==0 )  return b;
    if ( b==0 )  return a;
    ulong r;
    do
    {
        r = a % b;
        a = b;
        b = r;
    }
    while ( r!=0 );
    return a;
}
// -------------------------

long
sgcd(long a, long b)
{
    if ( a==0 )  return b;
    if ( b==0 )  return a;
    long r;
    do
    {
        r = a % b;
        a = b;
        b = r;
    }
    while ( r!=0 );
    return a;
}
// -------------------------

ulong
lcm(ulong a, ulong b)
{
    return  a / gcd(a,b) * b;
}
// -------------------------


long
binary_gcd(long a, long b)
{
    if ( a < b )  { long t = a; a = b; b = t; }

    if ( b==0 )  return a;

//    long r;
//    r = a % b;
//    a = b;
//    b = r;
//    if ( b==0 )  return a;

    long k = 0;
//    while ( !(a&1) && !(b&1) )  // both even
    while ( !((a|b)&1) )  // both even
    {
        k++;
        a >>= 1;
        b >>= 1;
    }

    while ( !(a&1) )  a >>= 1;

    while ( !(b&1) )  b >>= 1;

    while ( 1 )
    {
        long t = (a-b) >> 1;

        if ( t==0 )  return  (1<<k) * a;

        while ( !(t&1) )  t >>= 1;

        if ( t>0 )  a =  t;
        else        b = -t;
    }
}
// -------------------------



#define  EGCD_CHECK  0  // 0 (no check, default) or 1 (debug)
#if  ( EGCD_CHECK==1 )
#else
//#warning  "FYI: egcd is not checked "
#endif // EGCD_CHECK

#define  EGCD_PRINT  0  // 0 or 1 (for debug)


long
egcd(long u, long v, long &u1, long &u2)
//
// return u3 and set u1,v1 so that
//   u3 == u*u1 + v*u2
//
// cf. knuth2, p.325
{
    long v1 = 0;
    long v3 = v;

    u1 = 1;
    u2 = 0;
    long u3 = u;

#if  ( EGCD_PRINT==1 )
    cout << "\n egcd():  u= " << u;
    cout << "\n egcd():  v= " << v << endl;
#endif

    long v2 = 1;
    while ( v3!=0 )
    {
        long q = u3/v3;

        long t1 = u1-v1*q;
        u1 = v1;
        v1 = t1;

        long t3 = u3-v3*q; // u3%v3
        u3 = v3;
        v3 = t3;

#if  ( EGCD_PRINT==1 )
        cout << "\n  q= " << q;
        cout << "\n  u1= " << u1;
        cout << "\n  u*u1= " << u*u1;
        cout << "\n  u3= " << u3 << endl;
        cout << "\n  u3-u*u1= " << u3-u*u1;
        cout << "\n  u2:=(u3-u*u1)/v= " << (u3-u*u1)/v << endl;
//        jjassert( u*u1+v*((u3-u*u1)/v)==u3 );
#endif

        long t2 = u2-v2*q;
        u2 = v2;
        v2 = t2;

#if  ( EGCD_PRINT==1 )
        cout << "\n  u2= " << u2;
        cout << "\n  v*u2= " << v*u2;
#endif

#if  ( EGCD_CHECK==1 )
        jjassert( u*t1+v*t2==t3 );
        jjassert( u*u1+v*u2==u3 );
        jjassert( u*v1+v*v2==v3 );
#endif // ( EGCD_CHECK )
    }


#if  ( EGCD_CHECK==1 )
    jjassert( (ulong)u3==gcd(u,v) );
    jjassert( u*u1+v*u2==u3 );
#endif // ( EGCD_CHECK )


    return u3;
}
// -------------------------

