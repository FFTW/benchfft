#if !defined HAVE_SCAN_H__
#define      HAVE_SCAN_H__

#include "fxttypes.h"


template <typename Type>
inline ulong first_eq_idx(const Type *f, ulong n, Type v)
// return index of first element == v
// return n if all !=v
{
    ulong k = 0;
    while ( (k<n) && (f[k]!=v) )  k++;
    return k;
}
// -------------------------

template <typename Type>
inline ulong first_ne_idx(const Type *f, ulong n, Type v)
// return index of first element != v
// return n if all ==v
{
    ulong k = 0;
    while ( (k<n) && (f[k]==v) )  k++;
    return k;
}
// -------------------------


template <typename Type>
inline ulong first_ge_idx(const Type *f, ulong n, Type v)
// return index of first element >=v
// return n if no such element is found
{
    for (ulong i=0; i<n; ++i)  if ( f[i]>=v )  return i;
    return n;
}
// -------------------------


template <typename Type>
inline ulong first_le_idx(const Type *f, ulong n, Type v)
// return index of first element <=v
// return n if no such element is found
{
    for (ulong i=0; i<n; ++i)  if ( f[i]<=v )  return i;
    return n;
}
// -------------------------



template <typename Type>
inline ulong last_eq_idx(const Type *f, ulong n, Type v)
// return index of last element == v
// return n if all !=v
{
    ulong k = n-1;
    while ( f[k]!=v )
    {
        k--;
        if ( 0==k )  return n;
    }
    return k;
}
// -------------------------


template <typename Type>
inline ulong last_ne_idx(const Type *f, ulong n, Type v)
// return index of last element != v
// return n if all ==v
{
    ulong k = n-1;
    while ( f[k]==v )
    {
        k--;
        if ( 0==k )  return n;
    }
    return k;
}
// -------------------------


template <typename Type>
inline ulong last_ge_idx(const Type *f, ulong n, Type v)
// return index of last element >= v
// return n if all <v
{
    ulong k = n-1;
    while ( f[k]<v )
    {
        k--;
        if ( 0==k )  return n;
    }
    return k;
}
// -------------------------


template <typename Type>
inline ulong last_le_idx(const Type *f, ulong n, Type v)
// return index of last element <= v
// return n if all >v
{
    ulong k = n-1;
    while ( f[k]>v )  { k--;  if ( 0==k )  return n; }
    return k;
}
// -------------------------



template <typename Type>
inline ulong eq_count(const Type *f, ulong n, Type v)
// return number of elements that are ==v
{
    ulong ct = 0;
    while ( n-- )  if ( f[n]==v )  ++ct;
    return ct;
}
// -------------------------


template <typename Type>
inline ulong ne_count(const Type *f, ulong n, Type v)
// return number of elements that are !=v
{
    ulong ct = 0;
    while ( n-- )  if ( f[n]!=v )  ++ct;
    return ct;
}
// -------------------------


template <typename Type>
inline ulong ge_count(const Type *f, ulong n, Type v)
// return number of elements that are >=v
{
    ulong ct = 0;
    while ( n-- )  if ( f[n]>=v )  ++ct;
    return ct;
}
// -------------------------


template <typename Type>
inline ulong le_count(const Type *f, ulong n, Type v)
// return number of elements that are <=v
{
    ulong ct = 0;
    while ( n-- )  if ( f[n]<=v )  ++ct;
    return ct;
}
// -------------------------


#endif // !defined HAVE_SCAN_H__
