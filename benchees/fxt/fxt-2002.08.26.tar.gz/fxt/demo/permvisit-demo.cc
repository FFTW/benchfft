
#include "permvisit.h"

#include "fxtio.h"

//#include "permlazy.h"
//#include "jjassert.h"

#include <cstdlib> // atol()

int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    perm_visit perm(n);
    const ulong *x = perm.data();

    do
    {
        cout << " #"; cout.width(3); cout << perm.current() << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

//        cout << "    ";
//        for (ulong i=0; i<n; ++i)  cout << perm.xi[i] << " ";
//        jjassert( is_inverse( x, perm.xi, n) );

        cout << endl;
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


