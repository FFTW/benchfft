
#include "permderange.h"
#include "permtrotter.h"

#include "fxtio.h"

#include <cstdlib> // atol()

int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    perm_derange perm(n);
    const ulong *x = perm.data();
    do
    {
//        // show underlying minchange-permutation:
//        if ( 0==perm.current()%n )
//        {
//            cout << "   ";
//            for (ulong i=0; i<n-1; ++i)  cout << perm.pt->x_[i] << " ";
//            cout << endl;
//        }

        cout << " #"; cout.width(3); cout << perm.current() << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        cout << endl;
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


