
#include "sortcomplex.h"
#include "search.h"

#include "fxttypes.h"
#include "auxdouble.h"  // rnd01()
#include "quantise.h"  // quantise()
#include "jjassert.h"
#include "newop.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


void
print(const char *bla, const Complex *f, ulong n)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        Complex r = f[k];

        cout.width(4);
        cout.flags(ios::right);
        cout << k << ":  ";
//        cout.flags(ios::left);

        cout.precision(5);
        cout << "(";
        cout.width(5);
        cout << r.real();
        cout << ", ";
        cout.width(5);
        cout << r.imag();
        cout << ")";
        cout << endl;
    }
    cout << endl;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 25;
    if ( argc>1 )  n = atol(argv[1]);
    ulong nr = 2 * n;

    double *fr = NEWOP(double, nr);

    for (ulong i=0; i<nr; ++i)  fr[i] = rnd01();
    quantise(fr, nr, 1.0/10); // we want repeated real parts

    Complex *f = (Complex *)fr;
    print("random values:", f, n);

    Complex v = f[n/2];

    complex_sort(f, n);
    print("sorted values:", f, n);

    jjassert( is_complex_sorted(f, n) );

    cout << "searching for v=" << v << endl;
    ulong i = bsearch_complex(f, n, v);
    jjassert( i<n );
    cout << "found at index " << i << endl;

    return 0;
}
// -------------------------
