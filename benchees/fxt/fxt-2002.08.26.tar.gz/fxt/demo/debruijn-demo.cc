
#include "debruijn.h"

#include "intarith.h" // ipow()
#include "fxtio.h"

#include <cstdlib> // atol()

void
show_seq(ulong m, ulong n)
{
    debruijn db(m, n);
    ulong ndb = ipow(m, n);
    cout << " n = " << n << "  len = " << ndb << endl;
    db.init(m, n);
    for (ulong j=0; j<ndb; ++j)  cout << db.next();
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong m = 2;
    if ( argc>1 )  m = atol(argv[1]);
    ulong n = 4;
    if ( argc>2 )
    {
        n = atol(argv[2]);
        cout << " ----- m = " << m << endl;
        show_seq(m, n);
        return 0;
    }


    const ulong maxlen[] = {0, 0, 8, 6, 4};
    //         for:               2  3  4

    for (ulong m=2; m<=4; ++m)
    {
        cout << " ----- m = " << m << endl;
        for (ulong n=1; n<=maxlen[m]; ++n)
        {
            show_seq(m, n);
        }
        cout << endl;
    }

    return 0;
}
// -------------------------
