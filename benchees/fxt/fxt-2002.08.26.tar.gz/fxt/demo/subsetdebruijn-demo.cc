
#include "subsetdebruijn.h"

#include "fxtio.h"
#include "auxprint.h"

#include <cstdlib> // atol()


int
main(int argc, char **argv)
{
    ulong n = 5;
    if ( argc>1 )  n = atol(argv[1]);

    subset_debruijn sdb(n);

    for (ulong j=0; j<=n; ++j)  sdb.next();  // cosmetics: end with empty set

    ulong ct = 0;
    do
    {
        ulong num = print_delta_set_as_set("", sdb.data(), n, 1);;
        cout << "   #=" << num;
        cout << "   " << ct;
        cout << endl;

        sdb.next();
    }
    while ( ++ct < (1UL<<n) );

    return 0;
}
// -------------------------
