
#include "unique.h"

#include "fxttypes.h"
#include "sort.h"
#include "quantise.h"  // quantise()
#include "auxdouble.h"  // rnd01()

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()



void
print(const char *bla, const double *f, ulong n)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        double r = f[k];

        cout.width(4);
        cout.flags(ios::right);
        cout.fill(' ');
        cout << k << ":  ";

        cout.precision(10);
        cout.flags(ios::left);
        cout.fill('0');
        cout.width(12);
        cout << r;
        cout << endl;
    }
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 25;
    if ( argc>1 )  n = atol(argv[1]);

    double q = 1.0/100;
    if ( argc>2 )  q = atof(argv[2]);

    double f[n];

    for (  ; n>2; n/=2)
    {
        cout << "---------------------------" << endl;

        for (ulong i=0; i<n; ++i)  f[i] = rnd01();
        print("Random values:", f, n);

        cout << "Quantisation with q=" << q << endl;
        quantise(f, n, q);
//        print("quantised values:", f, n);

        quick_sort(f, n);
        print("Quantised & sorted :", f, n);


        ulong u = test_unique(f, n);
        if ( 0==u )  cout << "all UNIQUE values" << endl;
        else
        {
            cout << "First REPEATED value at index " << u
                 << "  (and " << u-1 << ")" << endl;

            u = unique_count(f, n);
            cout << "There are " << u << " unique values (of " << n << ")." << endl;
            cout << "  i.e. " << (n-u) << " repeated value(s). " << endl;

            u = unique(f, n);
            print("Unique'd array:", f, u);
        }


        cout << endl;
    }

    return 0;
}
// -------------------------
