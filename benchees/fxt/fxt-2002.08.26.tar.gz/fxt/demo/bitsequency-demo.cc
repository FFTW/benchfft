
#include "bitsequency.h"

#include "printbin.h"

#include "fxtio.h"
#include <cstdlib>  // strtoul()


static const char c01[] = ".1";

int
main()
{
    const ulong pd = 8;

    ulong Ct = 1;
    for (ulong i=0; i<pd ; ++i)
    {
        ulong v = first_sequency(i+1);

        cout << endl;
        cout << "   sequency = " << bit_sequency(v) << endl;
        print_bin(" ", v, pd, c01);

        ulong ct = 0;
        ulong c = v;
        do
        {
            ++ct;
            c = next_sequency(c);

            // special condition for 8-bit demo:
            if ( c>=(1UL<<pd) )  break;
            print_bin(" ", c, pd, c01);
        }
        while ( c );

        Ct += ct;
        cout << " ct == " << ct;
        cout << "    Ct == " << Ct;
        cout << endl;
    }

    cout << endl;

    return 0;
}
// -------------------------
