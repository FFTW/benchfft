
#include "revbin.h"
#include "bitswap.h"
#include "graycode.h"
#include "greencode.h"
#include "bitsequency.h"
#include "bitrotate.h"
#include "bitcyclic.h"
#include "bitdemos.h"  // ugly, very ugly (just for the demo)


void
do_the_show(ulong v)
{
    ulong t;

    print_sep();

    WORD;

    SHWBIN( revbin );

    SHWBIN( gray_code );
    SHWBIN( inverse_gray_code );
    SHWBIN( green_code );
    SHWBIN( inverse_green_code );

    SHWBIN( bit_swap_4 );
    SHWBIN( bit_swap_8 );

    SHWBIN2( bit_rotate_right, 3 );

    SHWBIN( next_sequency );

    SHWBIN( cyclic_min );
    SHWBIN( cyclic_max );

    cout << endl;
}
// -------------------------

