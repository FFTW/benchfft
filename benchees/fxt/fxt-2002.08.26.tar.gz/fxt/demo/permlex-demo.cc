
#include "permlex.h"

#include "fxtio.h"

#include <cstdlib> // atol()


void
print_fact(ulong idx, ulong n)
// print factorial representation of the index:
{
    cout << "    ";
    ulong f = 1;
    for (ulong i=2; i<n; ++i)  f *= i;
    ulong z = idx; //perm.current();
    for (ulong i=n-1;  i>=1;   f/=i, --i)
    {
        ulong d = 0;
        if ( z>=f )  { d = z/f; z-=d*f; }
        // d: number of following elements smaller than the current
        cout << d << " ";
    }
    cout << "0"; // no element follows the last
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    perm_lex perm(n);
    const ulong *x = perm.data();
    do
    {
        cout << " #"; cout.width(3); cout << perm.current() << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        cout << "  ";  cout << (perm.sign() ? '-' : '+');

        print_fact(perm.current(), n);

        cout << endl;
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


