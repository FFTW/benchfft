
#include "comblex.h"

#include "jjassert.h"

#include "fxtio.h"
#include "fxtiomanip.h"
#include "printbin.h"
#include "auxprint.h"

#include <cstdlib> // atol()


int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    if ( argc>1 )  n = atol(argv[1]);
    if ( argc>2 )  k = atol(argv[2]);
    cout << " n = " << n << "  k = " << k << endl;
    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    ulong ct = 0;
    comb_lex comb(n, k);

    do
    {
        cout << endl;
        cout << "   [ " << comb << " ]  ";
        print_set_as_bitset("", comb.data(), k, n );
        cout << "  #" << setw(3) << ct;

        ++ct;
    }
    while ( comb.next() );
    cout << endl;

    cout << " reversed order: " << endl;
    comb.last();
    do
    {
        --ct;
        cout << "   [ " << comb << " ]  ";
        print_set_as_bitset("", comb.data(), k, n );
        cout << "  #" << setw(3) << ct;
        cout << endl;
    }
    while ( comb.prev() );
    cout << endl;


    return 0;
}
// -------------------------


