
#include "sortptr.h"
#include "searchptr.h"

#include "fxttypes.h"
#include "copy.h" // set_seq()
#include "auxdouble.h"  // rnd01()
#include "jjassert.h"
#include "newop.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


void
ptr_print(const char *bla, const double *f, ulong n, double **x)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        double r = *x[k];

        cout.width(4);
        cout.flags(ios::right);
        cout << k << ":  ";

        cout.precision(5);
        cout.flags(ios::left);
        cout.width(8);
        cout << r;

        cout << "  x[" << k << "]=^=" << (x[k]-f);
        cout << endl;
    }
    cout << endl;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 25;
    if ( argc>1 )  n = atol(argv[1]);

    double *f = NEWOP(double, n);

    ulong *xx = NEWOP(ulong, n);  // ! assume sizeof(ptr) == sizeof(ulong)
    double **x = (double **)xx;
    set_seq(xx, n, (ulong)f, (ulong)sizeof(double));

    for (ulong i=0; i<n; ++i)  f[i] = rnd01();
    ptr_print("random values:", f, n, x);

    double v = f[n/2];


//    cout << "ptr_min=" << ptr_min(f, n, x) << endl;
//    cout << "ptr_max=" << ptr_max(f, n, x) << endl;

//    ulong p = ptr_partition(f, n, x);
//    ptr_print("partitioned values:", f, n, x);
//    cout << "p-ptr=" << p << endl;
//    cout << "p-max=" << ptr_max(f, p, x) << endl;
//    cout << "p-min=" << ptr_min(f, n-p, x+p) << endl;
//    jjassert( is_ptr_partitioned(f, n, x, p) );


//    ptr_selection_sort(f, n, x);
    ptr_quick_sort(f, n, x);
    ptr_print("sorted values:", f, n, x);

    jjassert( is_ptr_sorted(f, n, x) );

    cout << "searching for v=" << v << endl;
    ulong i = ptr_bsearch(f, n, x, v);
    cout << "found at (ptr-)index " << (x[i]-f) << " == x[" << i << "]" << endl;

    return 0;
}
// -------------------------
