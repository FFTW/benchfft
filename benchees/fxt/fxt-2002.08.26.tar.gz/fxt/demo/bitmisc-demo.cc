
#include "bitswap.h"
#include "zerobyte.h"
#include "bitmisc.h"
#include "bitcount.h"
#include "bitdemos.h"  // ugly, very ugly (just for the demo)


void
do_the_show(ulong v)
{
    ulong t;

    print_sep();
    WORD;


    SHWBIN( revbin );

    SHWBIN( single_bits );
    SHWBIN( single_zeros );
    SHWBIN( single_values );

    SHWBIN( border_bits );
    SHWBIN( border_values );
    SHWBIN( high_border_bits );
    SHWBIN( low_border_bits );
    SHWBIN( block_border_bits );
    SHWBIN( low_block_border_bits );
    SHWBIN( high_block_border_bits );

    SHWBIN( block_bits );
    SHWBIN( block_values );
    SHWBIN( interior_bits );
    SHWBIN( interior_values );

    SHWBIN( contains_zero_byte );

    SHWDEC( bit_count );
//    SHWDEC( bit_count_sparse );  // same result as bit-count()
    SHWDEC( bit_block_count );
    SHWDEC( bit_block_ge2_count );

//    SHWDEC( 0!=contains_zero_byte );


    cout << endl;
}
// -------------------------

