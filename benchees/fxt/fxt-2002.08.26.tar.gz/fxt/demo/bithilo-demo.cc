
#include "bit2pow.h"
#include "bitlow.h"
#include "bithigh.h"
#include "bitdemos.h"  // ugly, very ugly  (just for the demo)


void
do_the_show(ulong v)
{
    ulong t;

    print_sep();

    WORD;


    SHWBIN( highest_bit );
    SHWBIN( highest_bit_01edge );
    SHWBIN( highest_bit_10edge );
    SHWDEC( highest_bit_idx );

    SHWDEC( ld );

    SHWBIN( low_zeros );
    SHWBIN( low_bits );

    SHWBIN( lowest_bit );
    SHWBIN( lowest_bit_01edge );
    SHWBIN( lowest_bit_10edge );
    SHWDEC( lowest_bit_idx );

    SHWBIN( lowest_block );

    SHWBIN( delete_lowest_bit );

    SHWBIN( lowest_zero );
    SHWBIN( set_lowest_zero );

    SHWBIN( high_bits );
    SHWBIN( high_zeros );
    SHWBIN( highest_zero );
    SHWBIN( set_highest_zero );


    cout << endl;
}
// -------------------------
