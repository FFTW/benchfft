#if !defined  HAVE_WALSHLAZY_H__
#define       HAVE_WALSHLAZY_H__


#include "dyadiccnvl.h"
#include "walshgray.h"
#include "walshhartley.h"
#include "walshpal.h"
#include "walshseq.h"
#include "walshwak.h"
#include "walshwal.h"


#endif  // !defined HAVE_WALSHLAZY_H__
