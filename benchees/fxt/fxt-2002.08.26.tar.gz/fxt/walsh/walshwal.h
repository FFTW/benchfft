#if !defined  HAVE_WALSHWAL_H__
#define       HAVE_WALSHWAL_H__

#include "revbinpermute.h"
#include "graypermute.h"
#include "walshwak.h"


template <typename Type>
void dif2_walsh_wal(Type *f, ulong ldn)
//
// transform wrt. to walsh-kaczmarz basis (wal-functions)
// the basis: (sequency at end of lines, '*':=1, ' ':=-1)
//  0: [* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *] ( 0)
//  1: [* * * * * * * * * * * * * * * *                                ] ( 1)
//  2: [* * * * * * * *                                 * * * * * * * *] ( 2)
//  3: [* * * * * * * *                 * * * * * * * *                ] ( 3)
//  4: [* * * *                 * * * * * * * *                 * * * *] ( 4)
//  5: [* * * *                 * * * *         * * * * * * * *        ] ( 5)
//  6: [* * * *         * * * *                 * * * *         * * * *] ( 6)
//  7: [* * * *         * * * *         * * * *         * * * *        ] ( 7)
//  8: [* *         * * * *         * * * *         * * * *         * *] ( 8)
//  9: [* *         * * * *         * *     * * * *         * * * *    ] ( 9)
// 10: [* *         * *     * * * *         * * * *     * *         * *] (10)
// 11: [* *         * *     * * * *     * *         * *     * * * *    ] (11)
// 12: [* *     * *         * *     * * * *     * *         * *     * *] (12)
// 13: [* *     * *         * *     * *     * *     * * * *     * *    ] (13)
// 14: [* *     * *     * *     * *         * *     * *     * *     * *] (14)
// 15: [* *     * *     * *     * *     * *     * *     * *     * *    ] (15)
// 16: [*     * *     * *     * *     * *     * *     * *     * *     *] (16)
// 17: [*     * *     * *     * *     *   * *     * *     * *     * *  ] (17)
// 18: [*     * *     *   * *     * *     * *     * *   *     * *     *] (18)
// 19: [*     * *     *   * *     * *   *     * *     *   * *     * *  ] (19)
// 20: [*     *   * *     * *   *     * *     *   * *     * *   *     *] (20)
// 21: [*     *   * *     * *   *     *   * *   *     * *     *   * *  ] (21)
// 22: [*     *   * *   *     *   * *     * *   *     *   * *   *     *] (22)
// 23: [*     *   * *   *     *   * *   *     *   * *   *     *   * *  ] (23)
// 24: [*   *     *   * *   *     *   * *   *     *   * *   *     *   *] (24)
// 25: [*   *     *   * *   *     *   *   *   * *   *     *   * *   *  ] (25)
// 26: [*   *     *   *   *   * *   *     *   * *   *   *   *     *   *] (26)
// 27: [*   *     *   *   *   * *   *   *   *     *   *   *   * *   *  ] (27)
// 28: [*   *   *   *     *   *   *   * *   *   *   *     *   *   *   *] (28)
// 29: [*   *   *   *     *   *   *   *   *   *   *   * *   *   *   *  ] (29)
// 30: [*   *   *   *   *   *   *   *     *   *   *   *   *   *   *   *] (30)
// 31: [*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *  ] (31)
//
// the wal functions are sequency- ordered
//
// decimation in frequency (DIF) algorithm
// self-inverse
{
    const ulong n = (1<<ldn);

#if  1
//    gray_permute(f, n);
//    revbin_permute(f, n);
//    dif2_walsh_wak(f, ldn);
// =^=
    dif2_walsh_wak(f, ldn);
    revbin_permute(f, n);
    inverse_gray_permute(f, n);
#else
    for (ulong ldm=ldn; ldm>=1; --ldm) // dif
    {
        const ulong m = (1<<ldm);
        const ulong mh = (m>>1);
        for (ulong r=0; r<n; r+=m)
        {
            ulong t1 = r;
            ulong t2 = r+mh;

            // reverse(f+t2, mh); =^=
            for (ulong i=r+mh,j=i+mh-1; i<j; ++i,--j)  swap(f[i], f[j]);

            for (ulong j=0; j<mh; ++j,++t1,++t2)
            {
                Type u = f[t1];
                Type v = f[t2];
                f[t1] = u + v;
                f[t2] = u - v;
            }
        }
    }
    revbin_permute(f,n);
#endif
}
// -------------------------



template <typename Type>
void dit2_walsh_wal(Type *f, ulong ldn)
//
// transform wrt. to walsh-kaczmarz basis (wal-functions)
// the wal functions are sequency- ordered
// decimation in time (DIT) algorithm
// self-inverse
//
{
    const ulong n=(1<<ldn);

#if  1
//    gray_permute(f,n);
//    revbin_permute(f,n);
//    dit2_walsh_wak(f,ldn);
// =^=
    dit2_walsh_wak(f,ldn);
    revbin_permute(f,n);
    inverse_gray_permute(f,n);
#else
    revbin_permute(f,n);
    for (ulong ldm=1; ldm<=ldn; ++ldm) // dit
    {
        const ulong m = (1<<ldm);
        const ulong mh = (m>>1);
        for (ulong r=0; r<n; r+=m)
        {
            ulong t1 = r;
            ulong t2 = r+mh;
            for (ulong j=0; j<mh; ++j,++t1,++t2)
            {
                Type u = f[t1];
                Type v = f[t2];
                f[t1] = u + v;
                f[t2] = u - v;
            }

            // reverse(f+r+mh, mh); ==
            for (ulong i=r+mh,j=i+mh-1; i<j; ++i,--j)  swap(f[i], f[j]);
        }
    }
#endif
}
// -------------------------


template <typename Type>
inline void walsh_wal(Type *f, ulong ldn)
{ dif2_walsh_wal(f, ldn); }


#endif  // !defined HAVE_WALSHWAL_H__
