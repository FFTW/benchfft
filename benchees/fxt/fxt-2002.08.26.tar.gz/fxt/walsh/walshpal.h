#if !defined  HAVE_WALSHPAL_H__
#define       HAVE_WALSHPAL_H__

#include "revbinpermute.h"
#include "walshwak.h"  // walsh_wak()



//<<
// walsh_pal(f, ldn) is equivalent to either of:
//
// 1)
//        for (ulong ldk=1; ldk<ldn; ++ldk)
//        {
//            ulong k = 1UL << ldk;
//            for (ulong j=k; j<n; j+=2*k)  inverse_haar(f+j, ldk);
//        }
//        inverse_haar(f,ldn);
//
// 1.5)
//        haar_nn(f,ldn);
//        for (ulong ldk=ldn-1; ldk>0; --ldk)
//        {
//            ulong k = 1UL << ldk;
//            for (ulong j=k; j<n; j+=2*k)  haar_nn(f+j, ldk);
//        }
//
// 2)
//        haar(f,ldn);
//        for (ulong ldk=ldn-1; ldk>0; --ldk)
//        {
//            ulong k = 1UL << ldk;
//            for (ulong j=k; j<n; j+=2*k)  haar(f+j, ldk);
//        }
//
// 3)
//        for (ulong ldk=1; ldk<ldn; ++ldk)
//        {
//            ulong k = 1UL << ldk;
//            for (ulong j=k; j<n; j+=2*k)
//            {
//                inverse_haar_permute(f+j, ldk);
//                inverse_inplace_haar(f+j, ldk);
//            }
//        }
//        inverse_haar_permute(f, ldn);
//        inverse_inplace_haar(f,ldn);
//>>


template <typename Type>
void dif2_walsh_pal(Type *f, ulong ldn)
//
// transform wrt. to walsh-paley basis (pal-functions)
// the basis: (sequency at end of lines, '*':=1, ' ':=-1)
//  0: [* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *] ( 0)
//  1: [* * * * * * * * * * * * * * * *                                ] ( 1)
//  2: [* * * * * * * *                 * * * * * * * *                ] ( 3)
//  3: [* * * * * * * *                                 * * * * * * * *] ( 2)
//  4: [* * * *         * * * *         * * * *         * * * *        ] ( 7)
//  5: [* * * *         * * * *                 * * * *         * * * *] ( 6)
//  6: [* * * *                 * * * * * * * *                 * * * *] ( 4)
//  7: [* * * *                 * * * *         * * * * * * * *        ] ( 5)
//  8: [* *     * *     * *     * *     * *     * *     * *     * *    ] (15)
//  9: [* *     * *     * *     * *         * *     * *     * *     * *] (14)
// 10: [* *     * *         * *     * * * *     * *         * *     * *] (12)
// 11: [* *     * *         * *     * *     * *     * * * *     * *    ] (13)
// 12: [* *         * * * *         * * * *         * * * *         * *] ( 8)
// 13: [* *         * * * *         * *     * * * *         * * * *    ] ( 9)
// 14: [* *         * *     * * * *     * *         * *     * * * *    ] (11)
// 15: [* *         * *     * * * *         * * * *     * *         * *] (10)
// 16: [*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *  ] (31)
// 17: [*   *   *   *   *   *   *   *     *   *   *   *   *   *   *   *] (30)
// 18: [*   *   *   *     *   *   *   * *   *   *   *     *   *   *   *] (28)
// 19: [*   *   *   *     *   *   *   *   *   *   *   * *   *   *   *  ] (29)
// 20: [*   *     *   * *   *     *   * *   *     *   * *   *     *   *] (24)
// 21: [*   *     *   * *   *     *   *   *   * *   *     *   * *   *  ] (25)
// 22: [*   *     *   *   *   * *   *   *   *     *   *   *   * *   *  ] (27)
// 23: [*   *     *   *   *   * *   *     *   * *   *   *   *     *   *] (26)
// 24: [*     * *     * *     * *     * *     * *     * *     * *     *] (16)
// 25: [*     * *     * *     * *     *   * *     * *     * *     * *  ] (17)
// 26: [*     * *     *   * *     * *   *     * *     *   * *     * *  ] (19)
// 27: [*     * *     *   * *     * *     * *     * *   *     * *     *] (18)
// 28: [*     *   * *   *     *   * *   *     *   * *   *     *   * *  ] (23)
// 29: [*     *   * *   *     *   * *     * *   *     *   * *   *     *] (22)
// 30: [*     *   * *     * *   *     * *     *   * *     * *   *     *] (20)
// 31: [*     *   * *     * *   *     *   * *   *     * *     *   * *  ] (21)
//
// decimation in frequency (DIF) algorithm
// self-inverse
{
    const ulong n = 1<<ldn;
    revbin_permute(f, n);
    dif2_walsh_wak(f, ldn);
// =^=
//    dif2_walsh_wak(f, ldn);
//    revbin_permute(f, n);
}
// -------------------------


template <typename Type>
void dit2_walsh_pal(Type *f, ulong ldn)
//
// transform wrt. to walsh-paley basis (pal-functions)
// decimation in time (DIT) algorithm
// self-inverse
//
{
    const ulong n = 1UL<<ldn;
    revbin_permute(f, n);
    dit2_walsh_wak(f, ldn);
}
// -------------------------


template <typename Type>
inline void walsh_pal(Type *f, ulong ldn)
{ dif2_walsh_pal(f, ldn); }


#endif  // !defined HAVE_WALSHPAL_H__
