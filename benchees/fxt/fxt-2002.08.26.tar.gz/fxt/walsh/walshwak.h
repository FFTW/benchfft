#if !defined  HAVE_WALSHWAK_H__
#define       HAVE_WALSHWAK_H__


#include "fxttypes.h"


template <typename Type>
void dif2_walsh_wak(Type *f, ulong ldn)
//
// transform wrt. to walsh-kronecker basis (wak-functions)
// the basis: (sequency at end of lines, '*':=1, ' ':=-1)
//  0: [* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *] ( 0)
//  1: [*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *  ] (31)
//  2: [* *     * *     * *     * *     * *     * *     * *     * *    ] (15)
//  3: [*     * *     * *     * *     * *     * *     * *     * *     *] (16)
//  4: [* * * *         * * * *         * * * *         * * * *        ] ( 7)
//  5: [*   *     *   * *   *     *   * *   *     *   * *   *     *   *] (24)
//  6: [* *         * * * *         * * * *         * * * *         * *] ( 8)
//  7: [*     *   * *   *     *   * *   *     *   * *   *     *   * *  ] (23)
//  8: [* * * * * * * *                 * * * * * * * *                ] ( 3)
//  9: [*   *   *   *     *   *   *   * *   *   *   *     *   *   *   *] (28)
// 10: [* *     * *         * *     * * * *     * *         * *     * *] (12)
// 11: [*     * *     *   * *     * *   *     * *     *   * *     * *  ] (19)
// 12: [* * * *                 * * * * * * * *                 * * * *] ( 4)
// 13: [*   *     *   *   *   * *   *   *   *     *   *   *   * *   *  ] (27)
// 14: [* *         * *     * * * *     * *         * *     * * * *    ] (11)
// 15: [*     *   * *     * *   *     * *     *   * *     * *   *     *] (20)
// 16: [* * * * * * * * * * * * * * * *                                ] ( 1)
// 17: [*   *   *   *   *   *   *   *     *   *   *   *   *   *   *   *] (30)
// 18: [* *     * *     * *     * *         * *     * *     * *     * *] (14)
// 19: [*     * *     * *     * *     *   * *     * *     * *     * *  ] (17)
// 20: [* * * *         * * * *                 * * * *         * * * *] ( 6)
// 21: [*   *     *   * *   *     *   *   *   * *   *     *   * *   *  ] (25)
// 22: [* *         * * * *         * *     * * * *         * * * *    ] ( 9)
// 23: [*     *   * *   *     *   * *     * *   *     *   * *   *     *] (22)
// 24: [* * * * * * * *                                 * * * * * * * *] ( 2)
// 25: [*   *   *   *     *   *   *   *   *   *   *   * *   *   *   *  ] (29)
// 26: [* *     * *         * *     * *     * *     * * * *     * *    ] (13)
// 27: [*     * *     *   * *     * *     * *     * *   *     * *     *] (18)
// 28: [* * * *                 * * * *         * * * * * * * *        ] ( 5)
// 29: [*   *     *   *   *   * *   *     *   * *   *   *   *     *   *] (26)
// 30: [* *         * *     * * * *         * * * *     * *         * *] (10)
// 31: [*     *   * *     * *   *     *   * *   *     * *     *   * *  ] (21)
//
// decimation in frequency (DIF) algorithm
// self-inverse
{
    const ulong n = (1<<ldn);
    for (ulong ldm=ldn; ldm>=1; --ldm)
    {
        const ulong m = (1<<ldm);
        const ulong mh = (m>>1);
        for (ulong r=0; r<n; r+=m)
        {
            ulong t1 = r;
            ulong t2 = r+mh;
            for (ulong j=0;  j<mh;  ++j, ++t1, ++t2)
            {
                Type u = f[t1];
                Type v = f[t2];
                f[t1] = u + v;
                f[t2] = u - v;
            }
        }
    }
}
// -------------------------


template <typename Type>
void dit2_walsh_wak(Type *f, ulong ldn)
//
// transform wrt. to walsh-kronecker basis (wak-functions)
// decimation in time (DIT) algorithm
// self-inverse
//
{
    ulong n = (1<<(ulong)ldn);
    for (ulong ldm=1; ldm<=ldn; ++ldm)
    {
        const ulong m = (1<<ldm);
        const ulong mh = (m>>1);
        for (ulong r=0; r<n; r+=m)
        {
            ulong t1 = r;
            ulong t2 = r+mh;
            for (ulong j=0;  j<mh;  ++j, ++t1, ++t2)
            {
                Type u = f[t1];
                Type v = f[t2];
                f[t1] = u + v;
                f[t2] = u - v;
            }
        }
    }
}
// -------------------------


template <typename Type>
inline void walsh_wak(Type *f, ulong ldn)
{ dif2_walsh_wak(f, ldn); }


#endif  // !defined HAVE_WALSHWAK_H__
