
#include "fxt.h"
#include "fxtauxlazy.h"
#include "permlazy.h"
#include "jjassert.h"
#include "newop.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


static char *tt = 0;
#define  TT(x)  { tt = "// " #x " for n="; cerr << tt << n << endl;  x; }
#define  PP()   { cerr << tt << n << endl; }


template <typename Type>
void
rb_permute(Type *f, ulong n)
// put data in revbin order
// self-inverse
{
    if ( n<=2 )  return;

    const ulong nh = (n>>1);
    Type * const f1 = f + n - 1;
    swap(f[1], f[nh]);

    ulong k=2, r=nh;
    while ( k<nh  )
    {
        // k even:
        r ^= nh;
        for (ulong m=(nh>>1); !((r^=m)&m); m>>=1)  {;}
        if ( r>k )
        {
//            swap(f[k], f[r]);     // k<nh, r<nh
//            swap(f1[-k], f1[-r]); // n-k>nh, n-r>nh
        }
        ++k;

        // k odd:
        r += nh;
        swap(f[k], f[r]);  // k<nh, r>nh
        ++k;
    }
}
// -------------------------


template <typename Type>
void
gray_permute_hi(Type *f, ulong n)
{
    ulong z = 1; // mask for cycle maxima
    ulong v = 0; // ~z
    ulong cl = 1;  // cycle length

    f -= n;

    ulong ldm, m;
    for (ldm=1, m=2;  m<n;  ++ldm, m<<=1)
    {
        z <<= 1;
        v <<= 1;
        if ( is_pow_of_2(ldm) )
        {
            ++z;
            cl <<= 1;
        }
        else  ++v;
    }

    for ( ;  m<2*n;  ++ldm, m<<=1)
    {
        z <<= 1;
        v <<= 1;
        if ( is_pow_of_2(ldm) )
        {
            ++z;
            cl <<= 1;
        }
        else  ++v;

        ulong tv = v, tu = 0;  // cf. bitsubset.h
        do
        {
            tu = (tu-tv) & tv;
            ulong s = z | tu;  // start of cycle

            // --- do cycle: ---
            ulong g = gray_code(s);
            Type t = f[s];
            for (ulong k=cl-1; k!=0; --k)
            {
                Type tt = f[g];
                f[g] = t;
                t = tt;
                g = gray_code(g);
            }
            f[g] = t;
            // --- end (do cycle) ---
        }
        while ( tu );
    }
}
// -------------------------

void
tower(long *f, ulong ldx)
{
    const ulong n = 1<<ldx;

    for (ulong ldm=ldx; ldm>=1; ldm--) // dif (gray, inverse_evenodd)
//    for (ulong ldm=1; ldm<=ldx; ldm++) // dit (inverse_gray, evenodd)
    {
        ulong m = 1<<ldm;
        for (ulong r=0; r<n; r+=m)
        {
            unzip(f+r, m);
        }
    }
}
// -------------------------

void
haar_cyc(ulong *f, ulong n)
{
    ulong ldn = ld(n);
    revbin_permute(f, n);
//    gray_permute(f, n);
    for (ulong ldm=1; ldm<=ldn-1; ++ldm)
    {
        ulong m = (1<<ldm);  // m=2, 4, 8, ..., n/2
        revbin_permute(f+m, m);
    }
}
// -------------------------

void
mod_per(ulong *f, ulong n)
{
    ulong z[n];
    copy(f, z, n);
    ulong m = 3; //n/2 - 1;
    cout << "m=" << m << endl;
    for (ulong k=0; k<n-1; ++k)
    {
        ulong j = (m*k) % (n-1);
        jjassert( j<n );
        z[k] = f[j];
    }
//    z[n-1] = f[n-1];

    copy(z, f, n);
    jjassert( is_valid_permutation(f, n) );
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 16;
    if ( argc>1 )  n = atol(argv[1]);
    ulong ldn = ld(n);
    if ( (long)n<0 )
    {
        ldn = -(long)n;
        n = 1<<ldn;
    }
    cout << "ldn=" << ldn << "  n=" << n << endl;

    ulong nr = 2;
    if ( argc>2 )  nr = atol(argv[2]);
    ulong nc = n / nr;
    jjassert( nr*nc == n );


    ulong *y = NEWOP(ulong, n);  // permuted indices
    set_seq(y, n);


    // ++++++++++ apply some permutation: ++++++++++
//    TT( revbin_permute(y, n) );
//    TT( reverse(y, n) );

//    TT( gray_permute(y, n) );
//    TT( transpose_ba(y, nr, nc, 0) );

//    ulong nh = n/2;
//    TT( gray_permute_hi(y, n); gray_permute(y, n); );
//    TT( gray_permute_hi(y, n); gray_permute_hi(y, nh); gray_permute_hi(y+nh, nh); );
//    TT( gray_permute_hi(y, n); reverse(y,n); gray_permute_hi(y, n); );

//    TT( rb_permute(y, n); rb_permute(y, n/2); rb_permute(y+n/2, n/2); );
//    TT( rb_permute(y, n); );
//    TT( rb_permute(y, n/2); rb_permute(y+n/2, n/2);
//    TT( revbin_permute(y, n/2); revbin_permute(y+n/2, n/2); );
//    TT( reverse_nh(y, n); reverse(y, n); );

    TT( unzip_rev(y, n); );
//    TT( mod_per(y, n); );

//    TT( haar_cyc(y, n); );

//    TT( radix_permute(y, n, 4); revbin_permute(y, n); );
//    TT( revbin_permute(y, n); gray_permute(y, n) );
//    TT( radix_permute(y, n, 3) );
//    TT( radix_permute(y, n, 2); revbin_permute(y, n) );

//    TT( tower(y, ldn); );

//    TT( tower(y, ldn-1);  tower(y+n/2, ldn-1); );

//    prseq(y,0,n);  exit(99);

//    cout << "." << endl;

    // ++++++++++ study permutation: ++++++++++
    cycles cc(n);
    cc.make_cycles(y, n);
    cc.print();
//    cc.print( 1 );  // only info
//    cc.print_leaders();
    jjassert( cc.is_equivalent(y, n) );

//    //        01234567
//    char strf[] = "ABadCafe";
//    char strg[10];
//    ulong x[] = {7, 6, 3, 2, 5, 1, 0, 4};
//    jjassert( is_valid_permutation(x, 8) );
//    apply(x, strf, strg, 8);
//    strg[8] = 0;
//    cout << strf << endl;
//    cout << strg << endl;
//    ulong nf = print_cycles(x, 8);
//    cout << " nf = " << nf << endl;

//    cout << endl;
//    for (ulong k=0; k<n; ++k )  cout << y[k] << ", ";  cout << endl;
//    ulong nf = print_cycles(y, n);
//    cout << " nf = " << nf << endl;
//
//    make_inverse(y, n);
//    cout << endl;
//    for (ulong k=0; k<n; ++k )  cout << y[k] << ", ";  cout << endl;
//    print_cycles(y, n);


//    ulong v[n];
//    cc.make_permutation(v, n);
//    jjassert( cc.is_equivalent(v, n) );
//    jjassert( 0==compare((ulong *)y, v, n) );

//    cc.print_leaders();

    // ++++++++++ print code: ++++++++++
//    cc.print_code("zulp", n, 1);
//    cc.invert();
//    cc.print_code("inverse_zulp", n, 1);


    return 0;
}
// -------------------------
