
#include <cmath>  // sqrt()

#include "copy.h"
#include "newop.h"


void
haar(double *f, ulong ldn, double *ws/*=0*/)
//
// transform wrt. to haar base
//
// the basis:
//  0: [+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +]
//  1: [+ + + + + + + + + + + + + + + + - - - - - - - - - - - - - - - -]
//  2: [+ + + + + + + + - - - - - - - -                                ]
//  3: [                                + + + + + + + + - - - - - - - -]
//  4: [+ + + + - - - -                                                ]
//  5: [                + + + + - - - -                                ]
//  6: [                                + + + + - - - -                ]
//  7: [                                                + + + + - - - -]
//  8: [+ + - -                                                        ]
//  9: [        + + - -                                                ]
// 10: [                + + - -                                        ]
// 11: [                        + + - -                                ]
// 12: [                                + + - -                        ]
// 13: [                                        + + - -                ]
// 14: [                                                + + - -        ]
// 15: [                                                        + + - -]
// 16: [+ -                                                            ]
// 17: [    + -                                                        ]
// 18: [        + -                                                    ]
// 19: [            + -                                                ]
// 20: [                + -                                            ]
// 21: [                    + -                                        ]
// 22: [                        + -                                    ]
// 23: [                            + -                                ]
// 24: [                                + -                            ]
// 25: [                                    + -                        ]
// 26: [                                        + -                    ]
// 27: [                                            + -                ]
// 28: [                                                + -            ]
// 29: [                                                    + -        ]
// 30: [                                                        + -    ]
// 31: [                                                            + -]
//
{
    ulong n = (1UL<<ldn);
    double s2 = sqrt(0.5);
    double v = 1.0;

    double *g = ws;
    if ( !ws )  g = NEWOP(double, n);

    for (ulong m=n; m>1; m>>=1)
    {
        v *= s2;

        ulong mh = (m>>1);
        for (ulong j=0, k=0;  j<m;  j+=2, k++)
        {
            double x = f[j];
            double y = f[j+1];
            g[k]    =  x + y;
            g[mh+k] = (x - y) * v;
        }

        copy(g, f, m);
    }

    f[0] *= v; // v == 1.0/sqrt(n);

    if ( !ws )  delete [] g;
}
// -------------------------


void
inverse_haar(double *f, ulong ldn, double *ws/*=0*/)
//
// inverse transform wrt. to haar base
//
{
    ulong n = (1UL<<ldn);
    double s2 = sqrt(2.0);
    double v = 1.0/sqrt(n);

    double *g = ws;
    if ( !ws )  g = NEWOP(double, n);

    f[0] *= v;

    for (ulong m=2; m<=n; m<<=1)
    {
        ulong mh = (m>>1);

        for (ulong j=0, k=0;  j<m;  j+=2, k++)
        {
            double x = f[k];
            double y = f[mh+k] * v;
            g[j]    =  x + y;
            g[j+1]  =  x - y;
        }

        copy(g, f, m);
        v *= s2;
    }

    if ( !ws )  delete [] g;
}
// -------------------------
