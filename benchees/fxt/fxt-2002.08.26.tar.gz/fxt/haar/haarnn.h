#if !defined  HAVE_HAARNN_H__
#define       HAVE_HAARNN_H__

#include "copy.h"
#include "newop.h"


template <typename Type>
void haar_nn(Type *f, ulong ldn, Type *ws/*=0*/)
//
// transform wrt. to haar base
// version without normalization
//
{
    ulong n = (1<<(ulong)ldn);

    Type *g = ws;
    if ( !ws )  g = NEWOP(Type, n);

    for (ulong m=n; m>1; m>>=1)
    {
        ulong mh = (m>>1);
        for (ulong j=0, k=0;  j<m;  j+=2, k++)
        {
            Type x = f[j];
            Type y = f[j+1];
            g[k]    =  x+y;
            g[mh+k] =  x-y;
        }

        copy(g, f, m);
    }

    if ( !ws )  delete [] g;
}
// -------------------------

template <typename Type>
void inverse_haar_nn(Type *f, ulong ldn, Type *ws/*=0*/)
//
// inverse transform wrt. to haar base
// version without normalization
//
{
    ulong n = (1<<(ulong)ldn);

    Type *g = ws;
    if ( !ws )  g = NEWOP(Type, n);

    for (ulong m=2; m<=n; m<<=1)
    {
        ulong mh = (m>>1);

        for (ulong j=0, k=0;  j<m;  j+=2, k++)
        {
            Type x = f[k];
            Type y = f[mh+k];
            g[j]    =  x+y;
            g[j+1]  =  x-y;
        }

        copy(g, f, m);
    }

    if ( !ws )  delete [] g;
}
// -------------------------

#endif  // !defined HAVE_HAARNN_H__
