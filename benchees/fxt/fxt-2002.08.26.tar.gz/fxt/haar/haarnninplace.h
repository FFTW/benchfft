#if !defined  HAVE_HAARNNINPLACE_H__
#define       HAVE_HAARNNINPLACE_H__

#include "fxttypes.h"


template <typename Type>
void inplace_haar_nn(Type *f, ulong ldn)
//
// transform wrt. to haar base
// inplace operation
//
// version without normalization
//
// the sequence
//   inplace_haar_nn();  haar_permute();
// is equivalent to
//   haar_nn()
//
{
    ulong n = 1<<ldn;
    for (ulong js=2; js<=n; js<<=1)
    {
        for (ulong j=0, t=js>>1;  j<n;  j+=js, t+=js)
        {
            Type x = f[j];
            Type y = f[t];
            f[j]  =  x+y;
            f[t]  =  x-y;
        }
    }
}
// -------------------------


template <typename Type>
void inverse_inplace_haar_nn(Type *f, ulong ldn)
//
// inverse transform wrt. to haar base
// inplace operation
//
// version without normalization
//
// the sequence
//   inverse_haar_permute(); inverse_inplace_haar_nn();
// is equivalent to
//   inverse_haar_nn()
//
{
    ulong n = 1<<ldn;
    for (ulong js=n; js>=2; js>>=1)
    {
        for (ulong j=0, t=js>>1;  j<n;  j+=js, t+=js)
        {
            Type x = f[j];
            Type y = f[t];
            f[j]  =  x+y;
            f[t]  =  x-y;
        }
    }
}
// -------------------------


#endif  // !defined HAVE_HAARNNINPLACE_H__
