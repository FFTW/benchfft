#!/bin/bash


JJTMP=/tmp/demo2web/
rm -rf ${JJTMP:?}/*  ### !!!  RM  !!!
mkdir -p ${JJTMP}


function pv () { true; }
#function pv () { for x in $*; do eval "echo $x==\$$x"; done }

DSRC=demo/*-demo.cc
WEBLOC=$WEBDIR/fxt/demo/

XDSRC=""
for f in $DSRC; do  XDSRC="$XDSRC $f"; done

pv WEBLOC
pv DSRC
pv XDSRC

############## generate html page:

#exec 1<>${JJTMP}/00main.html

cat <<EOF
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
<!-- GENERATED_FILE DEMO2WEB_MAGIC -->
</HEAD>
<BODY bgcolor="#fffff0" text="#000000">
<H1>The fxt demos (generated webpage)</H1>

Find a list of all files in this directory <a href="index.html">here</a>.
<P>

You may want to look at the outputs first.
And yes, there is significant room for more/better documentation.
<P>

EOF


ALLHDRS="";
for f in $XDSRC; do
    g=${f/-demo.cc/-out.txt}

    sf=${f#demo/}
    sg=${g#demo/}

    echo "<!-- ---------- $f ---------- -->";
    echo "<a href=\"$sg\">$sg</a> is the output of <a href=\"$sf\">$sf</a>";
    echo ", a demo for the funcs in ";

    HDRS=$(perl scripts/firsthdrs.pl < $f);
    for h in $HDRS; do
        hf=$(echo */$h);
        echo "<a href=\"$h\">$h</a> (fxt/$hf)";
        ALLHDRS="$ALLHDRS $hf";
    done
    echo '<P>'
done

#pv ALLHDRS
SUHDRS=$(for h in $ALLHDRS; do echo $h; done | sort | uniq )
pv SUHDRS

XDOUT=${XDSRC//-demo.cc/-out.txt}
pv XDOUT


cat <<EOF
</BODY>
</HTML>
EOF


############## copying the files:

cp -a $SUHDRS $JJTMP
cp -a $XDSRC  $JJTMP
cp -a $XDOUT  $JJTMP


exit 0;

