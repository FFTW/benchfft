#!/bin/bash

# unused

DEP=depend.mk
INVDEP=depend.inv
NNDEP=/tmp/depend.nn

################################

## create dependency file without linebreaks:
cp depend.mk $NNDEP
replace -f -q '\.o:' '.cc:' $NNDEP > /dev/null
replace -f -q ': +[^ ]+.cc' ': ' $NNDEP > /dev/null
replace -f -q '\\\\\\n' '' $NNDEP > /dev/null

################################

TMPH=/tmp/tmph
TMPC=/tmp/tmpc
TMPT=/tmp/tmpt
echo -n > $TMPH
echo -n > $TMPC
for f in $(cat $DEP); do
    case $f in
        *.h)
        echo $f >> $TMPH;
            ;;
        *.cc)
        echo $f >> $TMPC
            ;;
        *)
#        echo "XXX $f";
            ;;
    esac;
done

sort $TMPH | uniq > $TMPT;
mv $TMPT $TMPH
## TMPH == uniq list of headers appearing in dependencies


echo -n > $TMPT;
for f in $(cat $TMPH); do
    echo -n "$f: " >> $TMPT;
    X=$(grep -E "\b$f\b" $NNDEP | cut -d':' -f1);
    echo $X >> $TMPT;
done
## TMPT consists of lines of the form
## hdrname.h: cfile_1.cc cfile_2.cc ... cfile_n.cc

mv $TMPT $INVDEP

rm -f $TMPI $TMPC $TMPT

exit 0;
################################
################################
