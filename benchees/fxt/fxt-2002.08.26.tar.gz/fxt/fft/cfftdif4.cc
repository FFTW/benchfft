
#include <cmath>

#include "fxt.h"
#include "cmult.h"
#include "sumdiff.h"
#include "revbinpermute.h"
#include "csincos.h"
#include "reverse.h"


static const ulong RX = 4;
static const ulong LX = 2;


void
dif4_fft(Complex *f, ulong ldn, int is)
// Fast Fourier Transform
// ldn := base-2 logarithm of the array length
// is := sign of the transform (+1 or -1)
// radix 4 decimation in frequency algorithm
{
    dif4_fft_core(f, ldn);

    const ulong n = 1<<ldn;
    revbin_permute(f, n);

    if ( is<0 )  // note: ugly: explicit reordering
    {
        reverse_nh(f, n);
    }
}
// -------------------------


void
dif4_fft_core(Complex *f, ulong ldn)
// auxiliary routine for dif4_fft()
// radix 4 decimation in frequency FFT
// ldn := base-2 logarithm of the array length
// isign = +1
// output data is in revbin_permuted order
{
    const ulong n = (1<<ldn);

    if ( n<=2 )
    {
        if ( n==2 )  sumdiff(f[0], f[1]);
        return;
    }

    for (ulong ldm=ldn; ldm>=(LX<<1); ldm-=LX)
    {
        ulong m = (1<<ldm);
        ulong m4 = (m>>LX);

        const double ph0 = 2.0*M_PI/m;

        for (ulong j=0; j<m4; j++)
        {
            double phi = j * ph0;
            Complex e  = SinCos(phi);
            Complex e2 = e * e;
            Complex e3 = e2 * e;

            for (ulong r=0, i0=j+r;  r<n;  r+=m, i0+=m)
            {
                Complex x,y,u,v;
                ulong i1 = i0 + m4;
                ulong i2 = i1 + m4;
                ulong i3 = i2 + m4;

                sumdiff(f[i0], f[i2], x, u);
                sumdiff(f[i1], f[i3], y, v);
                v *= Complex(0,1);

                diffsum3(x, y, f[i0]);
                f[i1] = y * e2;

                sumdiff(u, v, x, y);
                f[i3] = y * e3;
                f[i2] = x * e;
            }
        }
    }


    if ( ldn & 1 )  // n is not a power of 4, need a radix 8 step
    {
        for (ulong i0=0; i0<n; i0+=8)  fft8_dif_core(f+i0);
    }
    else
    {
        for (ulong i0=0; i0<n; i0+=4)
        {
            ulong i1 = i0 + 1;
            ulong i2 = i1 + 1;
            ulong i3 = i2 + 1;

            Complex x, y, u, v;
            sumdiff(f[i0], f[i2], x, u);
            sumdiff(f[i1], f[i3], y, v);
            v *= Complex(0,1);
            sumdiff(x, y, f[i0], f[i1]);
            sumdiff(u, v, f[i2], f[i3]);
        }
    }
}
// -------------------------
