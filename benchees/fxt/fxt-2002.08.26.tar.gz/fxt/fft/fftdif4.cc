
#include <cmath>
//#include "jjassert.h"

#include "fxt.h"
#include "cmult.h"
#include "sumdiff.h"
#include "revbinpermute.h"
#include "sincos.h"


static const ulong RX = 4;
static const ulong LX = 2;


void
dif4_fft(double *fr, double *fi, ulong ldn, int is)
// Fast Fourier Transform
// ldn := base-2 logarithm of the array length
// is := sign of the transform (+1 or -1)
// radix 4 decimation in frequency algorithm
{
    if ( is>0 )  dif4_fft_core(fr, fi, ldn);
    else         dif4_fft_core(fi, fr, ldn);

    revbin_permute(fr, 1<<ldn);
    revbin_permute(fi, 1<<ldn);
}
// -------------------------


void
dif4_fft_core(double *fr, double *fi, ulong ldn)
// auxiliary routine for dif4_fft()
// Fast Fourier Transform
// ldn := base-2 logarithm of the array length
// isign = +1
// radix 4 decimation in frequency fft
// output data is in revbin_permuted order
{
    const ulong n = (1<<ldn);

    if ( n<=2 )
    {
        if ( n==2 )
        {
            sumdiff(fr[0], fr[1]);
            sumdiff(fi[0], fi[1]);
        }
        return;
    }

    for (ulong ldm=ldn; ldm>=(LX<<1); ldm-=LX)
    {
        ulong m = (1<<ldm);
        ulong m4 = (m>>LX);

        const double ph0 = 2.0*M_PI/m;

        for (ulong j=0; j<m4; j++)
        {
            double c,s, c2,s2, c3,s3;
            SinCos(j*ph0, &s, &c);
            csqr(c, s, c2, s2);
            cmult(c, s, c2, s2, c3, s3);

            for (ulong r=0, i0=j+r;  r<n;  r+=m, i0+=m)
            {
                double xr,yr,ur,vr, xi,yi,ui,vi;
                ulong i1 = i0 + m4;
                ulong i2 = i1 + m4;
                ulong i3 = i2 + m4;

                // {x,u} = {f[i0]+f[i2], f[i0]-f[i2]}:
                sumdiff(fr[i0], fr[i2], xr, ur);
                sumdiff(fi[i0], fi[i2], xi, ui);

                // {y,v} = {f[i1]+f[i3], (f[i1]-f[i3])*(0,is)}:
                sumdiff(fi[i3], fi[i1], yi, vr);
                sumdiff(fr[i1], fr[i3], yr, vi);

                diffsum3(xr, yr, fr[i0]);
                diffsum3(xi, yi, fi[i0]);

                cmult(c2, s2, yr, yi, fr[i1], fi[i1]);

                sumdiff(ur, vr, xr, yr);
                sumdiff(ui, vi, xi, yi);

                cmult(c3, s3, yr, yi, fr[i3], fi[i3]);
                cmult(c,  s,  xr, xi, fr[i2], fi[i2]);
            }
        }
    }


    if ( (ldn&1)!=0 )  // n is not a power of 4, need a radix 8 step
    {
        for (ulong i0=0; i0<n; i0+=8)
            fft8_dif_core(fr+i0, fi+i0);
    }
    else
    {
        for (ulong i0=0; i0<n; i0+=4)
        {
            double xr,yr,ur,vr, xi,yi,ui,vi;
            ulong i1 = i0 + 1;
            ulong i2 = i1 + 1;
            ulong i3 = i2 + 1;

            sumdiff(fr[i0], fr[i2], xr, ur);
            sumdiff(fr[i1], fr[i3], yr, vi);
            sumdiff(fi[i0], fi[i2], xi, ui);
            sumdiff(fi[i3], fi[i1], yi, vr);

            sumdiff(xi, yi, fi[i0], fi[i1]);
            sumdiff(ui, vi, fi[i2], fi[i3]);
            sumdiff(xr, yr, fr[i0], fr[i1]);
            sumdiff(ur, vr, fr[i2], fr[i3]);
        }
    }
}
// -------------------------
