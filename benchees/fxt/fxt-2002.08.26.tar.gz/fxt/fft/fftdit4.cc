
#include <cmath>
//#include "jjassert.h"

#include "fxt.h"
#include "cmult.h"
#include "sumdiff.h"
#include "revbinpermute.h"
#include "sincos.h"


static const ulong RX = 4;
static const ulong LX = 2;


void
dit4_fft(double *fr, double *fi, ulong ldn, int is)
// Fast Fourier Transform
// ldn := base-2 logarithm of the array length
// is := sign of the transform (+1 or -1)
// radix 4 decimation in time algorithm
{
    revbin_permute(fr, 1<<ldn);
    revbin_permute(fi, 1<<ldn);

    if ( is>0 )  dit4_fft_core(fr, fi, ldn);
    else         dit4_fft_core(fi, fr, ldn);
}
// -------------------------


void
dit4_fft_core(double *fr, double *fi, ulong ldn)
// auxiliary routine for dit4_fft()
// radix 4 decimation in frequency fft
// ldn := base-2 logarithm of the array length
// isign = +1
// input data must be in revbin_permuted order
{
    const ulong n = (1<<ldn);

    if ( n<=2 )
    {
        if ( n==2 )
        {
            sumdiff(fr[0], fr[1]);
            sumdiff(fi[0], fi[1]);
        }
        return;
    }


    ulong ldm = (ldn&1);
    if ( ldm!=0 )  // n is not a power of 4, need a radix 8 step
    {
        for (ulong i0=0; i0<n; i0+=8)  fft8_dit_core(fr+i0, fi+i0);
    }
    else
    {
        for (ulong i0=0; i0<n; i0+=4)
        {
            double xr,yr,ur,vr, xi,yi,ui,vi;
            ulong i1 = i0 + 1;
            ulong i2 = i1 + 1;
            ulong i3 = i2 + 1;

            sumdiff(fr[i0], fr[i1], xr, ur);
            sumdiff(fr[i2], fr[i3], yr, vi);
            sumdiff(fi[i0], fi[i1], xi, ui);
            sumdiff(fi[i3], fi[i2], yi, vr);

            sumdiff(ui, vi, fi[i1], fi[i3]);
            sumdiff(xi, yi, fi[i0], fi[i2]);
            sumdiff(ur, vr, fr[i1], fr[i3]);
            sumdiff(xr, yr, fr[i0], fr[i2]);
        }
    }
    ldm += 2*LX;


    for ( ; ldm<=ldn; ldm+=LX)
    {
        ulong m = (1<<ldm);
        ulong m4 = (m>>LX);
        const double ph0 = 2.0*M_PI/m;

        for (ulong j=0; j<m4; j++)
        {
            double c,s,c2,s2,c3,s3;
            SinCos(j*ph0, &s, &c);
            csqr(c, s, c2, s2);
            cmult(c, s, c2, s2, c3, s3);

            for (ulong r=0, i0=j+r;  r<n;  r+=m, i0+=m)
            {
                double xr,yr,ur,vr, xi,yi,ui,vi;
                ulong i1 = i0 + m4;
                ulong i2 = i1 + m4;
                ulong i3 = i2 + m4;

                cmult(c2, s2, fr[i1], fi[i1], xr, xi);

                sumdiff3_r(xr, fr[i0], ur);
                sumdiff3_r(xi, fi[i0], ui);

                cmult(c,  s,  fr[i2], fi[i2], yr, vr);
                cmult(c3, s3, fr[i3], fi[i3], vi, yi);

                sumdiff(yr, vi);
                sumdiff(yi, vr);

                sumdiff(ur, vr, fr[i1], fr[i3]);
                sumdiff(ui, vi, fi[i1], fi[i3]);
                sumdiff(xr, yr, fr[i0], fr[i2]);
                sumdiff(xi, yi, fi[i0], fi[i2]);
            }
        }
    }
}
// -------------------------
