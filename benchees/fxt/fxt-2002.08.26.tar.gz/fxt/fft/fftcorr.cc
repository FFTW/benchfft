
#include "fxt.h"
#include "cmult.h"
#include "sumdiff.h"


void
fft_correlation(double *f, double *g, ulong ldn)
// compute (real, cyclic) correlation of f[], g[]
// result is in g[]
// ldn := base-2 logarithm of the array length
// n = 2**ldn  must be >=2
{
    const ulong n=(1<<ldn);
    const ulong nh=(n>>1);

    fht_real_complex_fft(f, ldn);
    fht_real_complex_fft(g, ldn);

    const double v = 1.0/n;
    g[0]  *= f[0] * v;
//    if ( nh>0 )
    {
        g[nh] *= f[nh] * v;
        for (ulong i=1,j=n-1; i<nh;  ++i,--j)
        {
            cmult_n(f[i], -f[j], g[i], g[j], v);
        }
    }

    fht_complex_real_fft(g, ldn);
}
// -------------------------


void
fft_auto_correlation(double *f, ulong ldn)
// compute (real, cyclic) self correlation of f[]
// ldn := base-2 logarithm of the array length
// n = 2**ldn  must be >=2
{
    const ulong n=(1<<ldn);
    const ulong nh=(n>>1);

    fht_real_complex_fft(f, ldn);

    const double v = 1.0/n;
    f[0]  *= f[0] * v;
//    if ( nh>0 )
    {
        f[nh] *= f[nh] * v;
        for (ulong i=1,j=n-1;  i<nh;  ++i,--j)
        {
            f[i] = (f[i]*f[i] + f[j]*f[j]) * v;
            f[j] = 0;
        }
    }

    fht_complex_real_fft(f, ldn);
}
// -------------------------


void
fft_correlation0(double *f, double *g, ulong ldn)
// compute (real, linear) correlation of f[], g[]
// result is in g[]
// version for zero padded data:
//   f[k],g[k] == 0 for k=n/2 ... n-1
// ldn := base-2 logarithm of the array length
// n = 2**ldn  must be >=2
{
    const ulong n=(1<<ldn);
    const ulong nh=(n>>1);

    fht_real_complex_fft0(f, ldn);
    fht_real_complex_fft0(g, ldn);

    const double v = 1.0/n;
    g[0]  *= f[0] * v;
//    if ( nh>0 )
    {
        g[nh] *= f[nh] * v;
        for (ulong i=1,j=n-1; i<nh;  ++i,--j)
        {
            cmult_n(f[i], -f[j], g[i], g[j], v);
        }
    }

    fht_complex_real_fft(g, ldn);
}
// -------------------------


void
fft_auto_correlation0(double *f, ulong ldn)
// compute (real, linear) self correlation of f[]
// version for zero padded data:
//   f[k] == 0 for k=n/2 ... n-1
// ldn := base-2 logarithm of the array length
// n = 2**ldn  must be >=2
{
    const ulong n=(1<<ldn);
    const ulong nh=(n>>1);

    fht_real_complex_fft0(f,ldn);

    const double v = 1.0/n;
    f[0]  *= f[0] * v;
//    if ( nh>0 )
    {
        f[nh] *= f[nh] * v;
        for (ulong i=1,j=n-1;  i<nh;  ++i,--j)
        {
            f[i] = (f[i]*f[i] + f[j]*f[j]) * v;
            f[j] = 0;
        }
    }

    fht_complex_real_fft(f,ldn);
}
// -------------------------
