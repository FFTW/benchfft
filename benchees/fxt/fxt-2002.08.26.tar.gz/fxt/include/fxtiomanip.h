#if !defined HAVE_FXTIOMANIP_H__
#define      HAVE_FXTIOMANIP_H__


#include  <iomanip>
using namespace std;


#endif // !defined HAVE_FXTIOMANIP_H__
