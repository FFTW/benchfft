#if !defined HAVE_FXT_H__
#define      HAVE_FXT_H__

#include "fxttypes.h"      // ulong
#include "complextype.h"   // Complex

//<<
// General format of arguments: (double *f, ulong ldn)
// f := pointer to data array,
// ldn := base 2 log of array length (length n=2**n)
//
// A function some_func0(...) (note the '0')
// expects input data with higher half zeros ('zero padded' data).
//
// Data in the arrays without const modifier is generally modified.
//
// A comment 'aux' at the line end marks functions that are
// called by other routines and might not be of direct use
// for users of the library
//>>

// jjmagictag  (needed for automatic testing)

// aux/version.cc:
void print_fxt_version();


//: ------------- HARTLEY transforms --------------------
// fht/fhtdit.cc:
void dit_fht_core(double *f, ulong ldn); // aux
void dit_fht(double *f, ulong ldn);

// fht/fhtdif.cc:
void dif_fht_core(double *f, ulong ldn); // aux
void dif_fht(double *f, ulong ldn);

// fht/cfhtdit.cc:
void dit_fht_core(Complex *f, ulong ldn); // aux
void dit_fht(Complex *f, ulong ldn);

// fht/cfhtdif.cc:
void dif_fht_core(Complex *f, ulong ldn); // aux
void dif_fht(Complex *f, ulong ldn);

// fht/fht0.cc:
void fht0(double *f, ulong ldn);

// fht/cfht0.cc:
void fht0(Complex *f, ulong ldn);

// fht/hartleyshift.cc:
void hartley_shift_05(double *a, ulong n); // aux

// fht/fhtdit2.cc:
void dit2_fht_localized(double *f, ulong ldn);
void dit2_fht(double *f, ulong ldn);

// fht/fhtdif2.cc:
void dif2_fht_localized(double *f, ulong ldn);
void dif2_fht(double *f, ulong ldn);

// fht/skipfht.cc:
void skip_fht(double *f, ulong n, ulong d, double *w);
void skip_fht0(double *f, ulong n, ulong d, double *w);

// fht/twodimfht.cc:
void row_column_fht(double *f, ulong nr, ulong nc); // aux
void y_transform(double *f, ulong nr, ulong nc); // aux
void twodim_fht(double *f, ulong nr, ulong nc);


//: --------------- FOURIER transforms ------------------

//<<
// typical format of arguments: (double *fr, double *fi, ulong ldn, int is)
// fr := pointer to data array (real part),
// fi := pointer to data array (imag part),
// ldn := base 2 log of array length
// is := sign of exponent in fourier kernel

// naming (semi-) conventions:
// some_fft() := fft implementation with blabla-algorithm
// some_fft0() := fft for zero paddad data
//   (i.e. second half of the input data is expected to be zero)
//>>

// fht/fhtfft.cc:
void fht_fft(double *fr, double *fi, ulong ldn, int is);
void fht_fft0(double *fr, double *fi, ulong ldn, int is);
void fht_fft_conversion(double *fr, double *fi, ulong ldn, int is); // aux

// fht/fhtcfft.cc:
void fht_fft(Complex *f, ulong ldn, int is);
void fht_fft0(Complex *f, ulong ldn, int is);
void fht_fft_conversion(Complex *f, ulong ldn, int is); // aux


// fft/fftdif2.cc:
void dif2_fft_localized(Complex *f, ulong ldn, int is);
void dif2_fft(Complex *f, ulong ldn, int is);

// fft/fftdit2.cc:
void dit2_fft_localized(Complex *f, ulong ldn, int is);
void dit2_fft(Complex *f, ulong ldn, int is);

// fft/fftdif4l.cc:
void dif4l_fft(Complex *f, ulong ldn, int is);

// fft/fftdit4l.cc:
void dit4l_fft(Complex *f, ulong ldn, int is);

// fft/fftdif4.cc:
void dif4_fft(double *fr, double *fi, ulong ldn, int is);
void dif4_fft_core(double *fr, double *fi, ulong ldn); // aux

// fft/cfftdif4.cc:
void dif4_fft(Complex *f, ulong ldn, int is);
void dif4_fft_core(Complex *f, ulong ldn); // aux

// fft/fftdit4.cc:
void dit4_fft(double *fr, double *fi, ulong ldn, int is);
void dit4_fft_core(double *fr, double *fi, ulong ldn); // aux

// fft/cfftdit4.cc:
void dit4_fft(Complex *f, ulong ldn, int is);
void dit4_fft_core(Complex *f, ulong ldn); // aux


// fft/cfftsplitradix.cc:
void split_radix_dif_fft_core(Complex *f, ulong ldn); // aux
void split_radix_dit_fft_core(Complex *f, ulong ldn); // aux
void split_radix_fft(Complex *f, ulong ldn, int is);

// fft/fftsplitradix.cc:
void split_radix_fft_dif_core(double *fr, double *fi, ulong ldn); // aux
void split_radix_fft(double *fr, double *fi, ulong ldn, int is);

// fft/cfftwrap.cc: (wrappers for type complex fourier)
void complex_to_real_imag(Complex *c, long ldn);  // aux
void real_imag_to_complex(double *fr, double *fi, long ldn); // aux
void complex_fft(Complex *c, ulong ldn, int is);
void real_imag_fft(double *fr, double *fi, ulong ldn, int is);

// fft/fouriershift.cc:
void fourier_shift(Complex *a, ulong n, double v); // aux
void fourier_shift(double *fr, double *fi, ulong n, double v); // aux
void fourier_shift_imag0(double *fr, double *fi, ulong n, double v); // aux
void fourier_shift(double *fr, double *fi, ulong n, double v, ulong k0, ulong kn); // aux
void fourier_shift_imag0(double *fr, double *fi, ulong n, double v, ulong k0, ulong kn); // aux

// fft/skipfft.cc:
void skip_fft(double *fr, double *fi, ulong n, ulong d, double *wr, double *wi, int is); // aux
void skip_fft0(double *fr, double *fi, ulong n, ulong d, double *wr, double *wi, int is); // aux

// fft/fft8difcore.cc:
void fft8_dif_core(Complex *f); // aux
void fft8_dif_core(double *fr, double *fi); // aux

// fft/fft8ditcore.cc:
void fft8_dit_core(Complex *f); // aux
void fft8_dit_core(double *fr, double *fi); // aux

// fft/fft9.cc:
void fft9(Complex *x); // aux
void fft9(double *xr, double *xi); // aux


//: ---------- MATRIX (aka four step) transforms --------------

// matrixfft/matrixfft.cc:
void matrix_fft(double *fr, double *fi, ulong ldn, int is);
void matrix_fft0(double *fr, double *fi, ulong ldn, int is);
void matrix_fft(Complex *f, ulong ldn, int is);
void matrix_fft0(Complex *f, ulong ldn, int is);

// matrixfft/rowffts.cc:
void row_ffts(double *fr, double *fi, ulong nr, ulong nc, int is); // aux
void row_weighted_ffts(double *fr, double *fi, ulong nr, ulong nc, int is); // aux
void row_ffts(Complex *f, ulong nr, ulong nc, int is); // aux
void row_weighted_ffts(Complex *f, ulong nr, ulong nc, int is); // aux

// matrixfft/rowcnvls.cc:
void row_weighted_auto_convolutions(double *fr, double *fi, ulong nr, ulong nc, double v); // aux
void row_weighted_auto_convolutions(Complex *f, ulong nr, ulong nc, double v); // aux

// matrixfft/columnffts.cc:
void column_ffts(double *fr, double *fi, ulong nr, ulong nc, int is, int zp, double *tr, double *ti); // aux
void column_ffts(Complex *f, ulong nr, ulong nc, int is, int zp, Complex *tmp); // aux
void column_real_complex_ffts(double *fr, ulong nr, ulong nc, int zp, double *t); // aux
void column_complex_real_ffts(double *fr, ulong nr, ulong nc, double *t); // aux
void column_complex_imag_ffts(const double *fr, double *fi, ulong r, ulong c, double *tmp); // aux

// matrixfft/matrixfftcnvla.cc:
void matrix_fft_auto_convolution(double *f, ulong ldn);
void matrix_fft_auto_convolution0(double *f, ulong ldn);
void matrix_fft_auto_convolution(double *f, ulong r, ulong c, int zp=0);

// matrixfft/matrixfftcnvl.cc:
void matrix_fft_convolution(double *f, double *g, ulong ldn);
void matrix_fft_convolution0(double *f, double *g, ulong ldn);
void matrix_fft_convolution(double *f, double *g, ulong r, ulong c, int zp=0);

// matrixfft/matrixfftcocnvla.cc:
void matrix_fft_auto_convolution(Complex *f, ulong ldn);
void matrix_fft_auto_convolution0(Complex *f, ulong ldn);
void matrix_fft_auto_convolution(Complex *f, ulong nr, ulong nc, int zp=0);
void matrix_fft_complex_auto_convolution(double *fr, double *fi, ulong ldn);
void matrix_fft_complex_auto_convolution0(double *fr, double *fi, ulong ldn);
void matrix_fft_complex_auto_convolution(double *fr, double *fi, ulong nr, ulong nc, int zp=0);


//: --------------- REAL FFT ---------------------

// info about the ordering of the data is in each source file

// realfft/realfftbyfht.cc:
void fht_real_complex_fft(double *f, ulong ldn, int is=+1);
void fht_real_complex_fft0(double *f, ulong ldn, int is=+1);
void fht_complex_real_fft(double *f, ulong ldn, int is=+1);
void realisator(double *gr, const double *gi, ulong n, int is); // aux
void imaginator(const double *gr, double *gi, ulong n, int is); // aux
void separator(double *gr, double *gi, ulong n, int is); // aux

// realfft/realfftwrap.cc:
void wrap_real_complex_fft(double *f, ulong ldn, int is=+1);
void wrap_complex_real_fft(double *f, ulong ldn, int is=+1);

// realfft/realffteasyord.cc:
void easy_ordering_real_complex_fft(double *f, ulong ldn, int is=+1);
void easy_ordering_real_complex_fft0(double *f, ulong ldn, int is=+1);
void easy_ordering_complex_real_fft(double *f, ulong ldn, int is=+1);

// realfft/realfftsplitradix.cc:
void split_radix_real_complex_fft(double *x, ulong ldn, int is=-1);
void split_radix_real_complex_fft0(double *x, ulong ldn, int is=-1);
void split_radix_complex_real_fft(double *x, ulong ldn, int is=-1);
void split_radix_real_complex_fft_dit_core(double *x, ulong ldn); // aux
void split_radix_complex_real_fft_dif_core(double *x, ulong ldn); // aux

// realfft/skiprealfft.cc:
void skip_real_complex_fft(double *f, ulong n, ulong d, double *w); // aux
void skip_real_complex_fft0(double *f, ulong n, ulong d, double *w); // aux
void skip_complex_real_fft(double *f, ulong n, ulong d, double *w); // aux


//: --------------- REAL CONVOLUTION ------------------

// fht/fhtcnvl.cc:
void fht_convolution(double *f, double *g, ulong ldn);
void fht_convolution0(double *f, double *g, ulong ldn);
void fht_convolution_core(const double *x, double *y, ulong ldn, double v=0.0); // aux
void fht_convolution_revbin_permuted_core(const double *x, double *y, ulong ldn, double v=0.0); // aux

// fht/fhtcnvla.cc:
void fht_auto_convolution(double *f, ulong ldn);
void fht_auto_convolution0(double *f, ulong ldn);
void fht_auto_convolution_core(double *x, ulong ldn, double v=0.0); // aux
void fht_auto_convolution_revbin_permuted_core(double *x, ulong ldn, double v=0.0); // aux

// fht/fhtnegacnvl.cc:
void fht_negacyclic_convolution(double *f, double *g, ulong ldn);
void fht_negacyclic_convolution_core(const double *f, double *g, ulong ldn, double v=0.0); // aux
// fht/fhtnegacnvla.cc:
void fht_negacyclic_auto_convolution(double *x, ulong ldn, double v=0.0);
void fht_negacyclic_auto_convolution_core(double *x, ulong ldn, double v=0.0); // aux

// fft/fftcnvl.cc:
void fht_fft_convolution(double *f, double *g, ulong ldn);
void split_radix_fft_convolution(double *f, double *g, ulong ldn);
void fht_fft_convolution0(double *f, double *g, ulong ldn);
void split_radix_fft_convolution0(double *f, double *g, ulong ldn);
void fft_convolution_core1(const double *x, double *y, ulong ldn, double v=0.0); // aux
void fft_convolution_core2(const double *x, double *y, ulong ldn, double v=0.0); // aux

// fft/fftcnvla.cc:
void fht_fft_auto_convolution(double *f, ulong ldn);
void split_radix_fft_auto_convolution(double *f, ulong ldn);
void fht_fft_auto_convolution0(double *f, ulong ldn);
void split_radix_fft_auto_convolution0(double *f, ulong ldn);
void fft_auto_convolution_core1(double *x, ulong ldn, double v=0.0); // aux
void fft_auto_convolution_core2(double *x, ulong ldn, double v=0.0); // aux

// mult/diskcnvla.cc:
void disk_weighted_complex_auto_convolution(int fd1, int fd2,
                                            double *fr, ulong fn, ulong al,
                                            double v, double nx,
                                            int zq1=0, int zq3=0);

// fht/twodimfhtcnvl.cc:
void twodim_fht_convolution_core(const double *f, double *g, ulong nr, ulong nc); // aux


//: -------------- REAL CORRELATION ---------------
// fht/fhtcorr.cc:
void fht_correlation(double *f, double *g, ulong ldn);
void fht_auto_correlation(double *f, ulong ldn);
void fht_correlation0(double *f, double *g, ulong ldn);
void fht_auto_correlation0(double *f, ulong ldn);
void fht_auto_correlation_core(double *f, ulong ldn, double v=0.0);

// fft/fftcorr.cc:
void fft_correlation(double *f, double *g, ulong ldn);
void fft_auto_correlation(double *f, ulong ldn);
void fft_correlation0(double *f, double *g, ulong ldn);
void fft_auto_correlation0(double *f, ulong ldn);


//: ------------ COmplex COnvolution & COrrelation -----------------
// fht/cfhtcnvl.cc:
void fht_convolution(Complex *f, Complex *g, ulong ldn);
void fht_convolution0(Complex *f, Complex *g, ulong ldn);
void fht_convolution_core(const Complex *x, Complex *y, ulong ldn, double v=0.0); // aux
void fht_convolution_revbin_permuted_core(const Complex *x, Complex *y, ulong ldn, double v=0.0); // aux

// fht/cfhtcnvla.cc:
void fht_auto_convolution(Complex *f, ulong ldn);
void fht_auto_convolution0(Complex *f, ulong ldn);
void fht_auto_convolution_core(Complex *x, ulong ldn, double v=0.0); // aux
void fht_auto_convolution_revbin_permuted_core(Complex *x, ulong ldn, double v=0.0); // aux

// fft/fftcocnvl.cc:
void fft_complex_auto_convolution(Complex *f, ulong ldn, double v=0.0);
void fft_complex_convolution(Complex *f, Complex *g, ulong ldn, double v=0.0);
void fft_complex_auto_convolution(double *fr, double *fi, ulong ldn, double v=0.0);
void fft_complex_convolution(double *fr, double *fi, double *gr, double *gi, ulong ldn, double v=0.0);

// fft/fftcocorr.cc:
void fft_complex_auto_correlation(double *fr, double *fi, ulong ldn);
void fft_complex_correlation(double *fr, double *fi, double *gr, double *gi, ulong ldn);


//: --------------- SPECTRUM ------------------
// fht/fhtspect.cc:
void fht_spectrum(double *f, ulong ldn, int phasesq=0);

// fft/fftspect.cc:
void fft_spectrum(double *f, ulong ldn, int phasesq=0);


//: -------- OTHER FOURIER STUFF ------------------

// chirp/fftarblen.cc: (arbitrary length fft)
void fft_arblen(double *fr, double *fi, ulong n, int is);

// chirp/fftfract.cc: (fractional fft)
void fft_fract(double *x, double *y, ulong n, double v);

// ndimfft/twodimfft.cc:
void twodim_fft(double *fr, double *fi, ulong nr, ulong nc, int is);

// ndimfft/ndimfft.cc: (1...5 dim fft)
void ndim_fft(double *fr, double *fi, ulong ndim, const ulong *ldn, int is);

// chirp/makechirp.cc:
void make_fft_chirp(double *wr, double *wi, ulong n, int is); // aux
void complete_fft_chirp(double *wr, double *wi, ulong n, ulong nn); // aux
void make_fft_fract_chirp(double *wr, double *wi, double v, ulong n, ulong nn); // aux

// fft/gfft.cc:
void gfft_dif2_core(Complex *f, ulong ldn, int is); // aux
void gfft_dit2_core(Complex *f, ulong ldn, int is); // aux
void gfft(Complex *f, ulong ldn, int is);
void gfft_auto_convolution(Complex *f, ulong ldn);
void gfft_convolution(Complex *f, Complex *g, ulong ldn);


//: ---------- COSINE/SINE TRANSFORM ----------

// dctdst/dct.cc:
//void dct(double *x, ulong ldn, double *y=0);

// dctdst/dst.cc:
void dst(double *x, ulong ldn, double *y=0);

// dctdst/dcth.cc:
void dcth(double *x, ulong ldn, double *y=0);
void idcth(double *x, ulong ldn, double *y=0);

// dctdst/dctzapata.cc:
void dcth_zapata(double *x, ulong ldn, double *y=0);

// dctdst/dsth.cc:
void dsth(double *x, ulong ldn, double *y=0);
void idsth(double *x, ulong ldn, double *y=0);

// dctdst/cosrot.cc:
void cos_rot(const double *x, double *y, ulong n);

// dctdst/dct4.cc:
void dct4(double *f, ulong n);
void idct4(double *f, ulong n);


//: ---------- HAAR TRANSFORM ----------

// haar/haar.cc:
void haar(double *f, ulong ldn, double *ws=0);
void inverse_haar(double *f, ulong ldn, double *ws=0);

// haar/haarinplace.cc:
void inplace_haar(double *f, ulong ldn);
void inverse_inplace_haar(double *f, ulong ldn);

// haar/inthaar.cc:
void int_haar(double *f, ulong ldn, double *ws=0);
void inverse_int_haar(double *f, ulong ldn, double *ws=0);


//: ---------- WAVELET TRANSFORM ----------

//<<
// wavelet/waveletfilter.h and
// wavelet/waveletfilter.cc:
class wavelet_filter;
//>>

// wavelet/wavelet.cc:
void wavelet(double *f, ulong ldn, const wavelet_filter &wf);

// wavelet/invwavelet.cc:
void inverse_wavelet(double *f, ulong ldn, const wavelet_filter &wf);

// wavelet/harmonicwavelet.cc:
void harmonic_wavelet(double *fr, double *fi, ulong ldn);
void inverse_harmonic_wavelet(double *fr, double *fi, ulong ldn);


//: ---------- WEIGHTED TRANSFORM ----------

// weighted/weightedfft.cc:
void weighted_fft(double *fr, double *fi, ulong ldn, int is, double w);
void weighted_inverse_fft(double *fr, double *fi, ulong ldn, int is, double w);

// weighted/weightedconv.cc:
void weighted_complex_auto_convolution(double *fr, double *fi, ulong ldn, double w, double v=0.0);
void negacyclic_complex_auto_convolution(double *fr, double *fi, ulong ldn, double v=0.0);
void right_angle_complex_auto_convolution(double *fr, double *fi, ulong ldn, double v=0.0);
void weighted_complex_auto_convolution(Complex *f, ulong ldn, double w, double v=0.0);
void negacyclic_complex_auto_convolution(Complex *f, ulong ldn, double v=0.0);
void right_angle_complex_auto_convolution(Complex *f, ulong ldn, double v=0.0);

//: ---------- WALSH TRANSFORMS ----------
//: as templates; to be found in walsh/*.h

// walsh/slant.cc:
void slant(double *f, ulong ldn);
void inverse_slant(double *f, ulong ldn);
void slant_seq(double *f, ulong ldn);
void inverse_slant_seq(double *f, ulong ldn);


//: ---------- SLOW TRANSFORMS (mostly for testing) ----------

// slow/slowft.cc:
void slow_ft(Complex *f, long n, int is);
void slow_ft(double *fr, double *fi, ulong n, int is);
void slow_twodim_ft(Complex *f, ulong nr, ulong nc, int is);
void slow_twodim_ft(double *fr, double *fi, ulong r, ulong c, int is);

// slow/slowht.cc:
void slow_ht(double *f, ulong n);
void slow_ht(Complex *f, ulong n);
void slow_row_column_ht(double *f, ulong nr, ulong nc);
void slow_twodim_ht(double *f, ulong nr, ulong nc);

// slow/recfft2.cc:
void recursive_dit2_fft(Complex *a, ulong ldn, int is);
void recursive_dif2_fft(Complex *a, ulong ldn, int is);

// slow/recfht2.cc:
void recursive_dit2_fht(double *a, ulong ldn);
void recursive_dif2_fht(double *a, ulong ldn);

// slow/slowcocorr.cc:
void slow_complex_correlation(const double *fr, const double *fi,
                              const double *gr, const double *gi,
                              double *hr, double *hi, ulong n);
void slow_complex_correlation(const double *fr, const double *fi,
                              double *gr, double *gi, ulong n);
void slow_complex_auto_correlation(double *fr, double *fi, ulong n);

// slow/slowcocnvl.cc:
void slow_complex_convolution(const double *fr, const double *fi,
                              double *gr, double *gi, ulong n);
void slow_complex_auto_convolution(double *fr, double *fi, ulong n);

// slow/slowfracft.cc:
void slow_fract_ft(Complex *f, ulong n, double v);
void slow_fract_ft(double *fr, double *fi, ulong n, double v);

// slow/slowzt.cc:
void slow_zt(Complex *f, ulong n, Complex z);
void slow_zt(double *f, ulong n, double z);

// -------------------------
// jjmagictag  (needed for automatic testing)

//: ------- inlines give default implementations -------
inline void fft(double *fr, double *fi, ulong ldn, int is)
{ fht_fft(fr, fi, ldn, is); }

inline void fft(Complex *f, ulong ldn, int is)
{ fht_fft(f, ldn, is); }

inline void real_complex_fft(double *f, ulong ldn, int is)
{ fht_real_complex_fft(f, ldn, is); }

inline void complex_real_fft(double *f, ulong ldn, int is)
{ fht_complex_real_fft(f, ldn, is); }

inline void fht(double *f, ulong ldn)
{ dit_fht(f, ldn); }

inline void fht(Complex *f, ulong ldn)
{ dit_fht(f, ldn); }

// -------------------------


#endif // !defined HAVE_FXT_H__
