#if !defined HAVE_FXTAUXLAZY_H__
#define      HAVE_FXTAUXLAZY_H__


// include file for the lazy:
// include the whole planet here

#include "fxttypes.h"
#include "complextype.h"

#include "cmult.h"
#include "sumdiff.h"

#include "constants.h"

//#include "jjassert.h"

#include "auxbitlazy.h"
#include "sortlazy.h"
#include "auxlazy.h"
#include "aux2dlazy.h"
#include "auxbitlazy.h"
#include "permlazy.h"
#include "comblazy.h"
#include "modlazy.h"
#include "walshlazy.h"


#endif // !defined HAVE_FXTAUXLAZY_H__
