#if !defined HAVE_JJASSERT_H__
#define      HAVE_JJASSERT_H__

// if you don't have sys/cdefs.h just uncomment the next line:
#include <sys/cdefs.h>  // __STRING()


void
jjassert_fail(
              const char *func,
              const char *pretty_func,
              const char *file,
              const int   line,
              const char *expr,
              const char *bla
              );


#if defined  NDEBUG

#define jjassert(expr)
#define jjassert2(expr, bla)

#else // NDEBUG

#if !defined  __STRING
#define  __STRING(s)   __XSTRING(s)
#define  __XSTRING(s)  #s
#endif

#define jjassert(expr) \
do { \
if ( !(expr) )  \
jjassert_fail( \
__FUNCTION__, \
__PRETTY_FUNCTION__, \
__FILE__, \
__LINE__, \
__STRING(expr), \
0); \
} while (0)  // no semicolon


#define jjassert2(expr, bla) \
do { \
if ( !(expr) )  \
jjassert_fail( \
__FUNCTION__, \
__PRETTY_FUNCTION__, \
__FILE__, \
__LINE__, \
__STRING(expr), \
bla); \
} while (0)  // no semicolon


#endif // NDEBUG


#endif  // !defined HAVE_JJASSERT_H__
