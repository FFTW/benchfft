#if !defined HAVE_FXTIO_H__
#define      HAVE_FXTIO_H__


#include  <iostream>
using namespace std;


#endif // !defined HAVE_FXTIO_H__
