#if !defined HAVE_RESTRICT_H__
#define      HAVE_RESTRICT_H__


#define  restrict  __restrict


#endif // !defined HAVE_RESTRICT_H__
