#if !defined HAVE_TRANSPOSE2_BA_H__
#define      HAVE_TRANSPOSE2_BA_H__

#include "fxttypes.h"
#include "bitarray.h"
#include "bitrotate.h"
#include "bit2pow.h"
#include "transpose.h"

//#include "jjassert.h"
//#include "fxtio.h"


#define  SRC(k)  bit_rotate_left(k, ldnc, ldn)  // = (((k)*nc)%n1)
template <typename Type>
void transpose2_ba(Type *f, ulong nr, ulong nc, bitarray *ba)
// inplace transposition of an  nr X nc  array
// that lies in contiguous memory
//
// use bitarray for tagging moved elements
//
{
//    cout << "transpose_ba" << " " << nr << " x " << nc << endl;
    if ( 1>=nr )  return;
    if ( 1>=nc )  return;

    if ( nr==nc )  transpose_square(f, nr);
    else
    {
        const ulong n1 = nr * nc - 1;
        const ulong ldnc = ld(nc);
        const ulong ldn = ld(n1+1);

        bitarray *tba = 0;
        if ( 0==ba )  tba = new bitarray(n1);
        else          tba = ba;
        tba->clear_all();

        for (ulong k=0;  k<n1;  k=tba->next_clear_idx(++k) )  //  0 and n1 are fixed points
        {
            // do a cycle:
            ulong ks = SRC(k);
            ulong kd = k;
            tba->set(kd);
            Type t = f[kd];
            while ( ks != k )
            {
//                cout << k << " " << ks << endl;
                f[kd] = f[ks];
                kd = ks;
                tba->set(kd);
                ks = SRC(ks);
            }
            f[kd] = t;
        }

        if ( 0==ba )  delete tba;
    }
}
// -------------------------

#undef SRC
#undef DST



#endif // !defined HAVE_TRANSPOSE2_BA_H__
