
#include "fxttypes.h"
#include "array2d.h"


#if  ( ROW_ASSERTS==1 )  // array2d.h
#warning 'FYI: row range jjasserts for array2d are activated'
#endif


#if  ( ROW_ASSERTS==1 )
void
row_assert(ulong r, ulong nr)
{
    if ( r>=nr || (long)r<0 )
    {
        cerr << __PRETTY_FUNCTION__ << endl;
        cerr << " r=" << r << "  (nr=" << nr << ")" << endl;
        jjassert( r<nr );
        jjassert( (long)r>=0 );
    }
}
// -------------------------
#else
// inline member function in array2d.h
#endif // ROW_ASSERTS
