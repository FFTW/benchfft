#if !defined HAVE_GRAYCODE_H__
#define      HAVE_GRAYCODE_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitasm.h"


static inline ulong gray_code(ulong x)
// Return the gray-code of x
// ('bitwise derivative modulo 2')
{
    return  x ^ (x>>1);
}
// -------------------------


static inline ulong inverse_gray_code(ulong x)
// inverse of gray_code()
// note: the returned value contains at each bit position
// the parity of all bits of the input left from it (incl. itself)
//
{
// ----- VERSION 1 (integration modulo 2):
//    ulong h=1, r=0;
//    do
//    {
//        if ( x & 1 )  r^=h;
//        x >>= 1;
//        h = (h<<1)+1;
//    }
//    while ( x!=0 );
//    return r;

// ----- VERSION 2 (apply graycode BITS_PER_LONG-1 times):
//    ulong r = BITS_PER_LONG;
//    while ( --r )  x ^= x>>1;
//    return x;

// ----- VERSION 3 (use: gray ** BITSPERLONG == id):
    x ^= x>>1;  // gray ** 1
    x ^= x>>2;  // gray ** 2
    x ^= x>>4;  // gray ** 4
    x ^= x>>8;  // gray ** 8
    x ^= x>>16; // gray ** 16
    // here: x = gray**31(input)
    // note: the statements can be reordered at will

#if  BITS_PER_LONG >= 64
    x ^= x>>32;  // for 64bit words
#endif

    return  x;
}
// -------------------------


static inline ulong parity(ulong x)
// return 1 if the number of set bits is even, else 0
{
#if defined  BITS_USE_ASM    // use x86 asm code
#if  BITS_PER_LONG >= 64
    x ^= x>>32;  // for 64bit words
#endif
    return  asm_parity(x);
#else
    return  inverse_gray_code(x) & 1;
#endif
}
// -------------------------


static inline ulong grs_negative_q(ulong x)
// Return whether the Golay-Rudin-Shapiro sequence
// (A020985) is negative for index x
// returns 1 for x =
// 3,6,11,12,13,15,19,22,24,25,26,30,35,38,43,44,45,47,48,49,
//  50,52,53,55,59,60,61,63,67,70,75,76,77,79,83,86,88,89,90,94,
//  96,97,98,100,101,103,104,105,106,110,115,118,120,121,122,
//  126,131,134,139,140, ...
//
// algorithm: count bit pairs modulo 2
//
{
    return  parity( x & (x>>1) );
}
// -------------------------


static inline ulong byte_gray_code(ulong x)
// Return the gray-code of bytes in parallel
{
#if  BITS_PER_LONG == 32
    return  x ^ ((x & 0xfefefefe)>>1);
#endif

#if  BITS_PER_LONG == 64
    return  x ^ ((x & 0xfefefefefefefefe)>>1);
#endif
}
// -------------------------

static inline ulong byte_inverse_gray_code(ulong x)
// Return the inverse gray-code of bytes in parallel
{
#if  BITS_PER_LONG == 32
    x ^= ((x & 0xfefefefe)>>1);
    x ^= ((x & 0xfcfcfcfc)>>2);
    x ^= ((x & 0xf0f0f0f0)>>4);
#endif

#if  BITS_PER_LONG == 64
    x ^= ((x & 0xfefefefefefefefe)>>1);
    x ^= ((x & 0xfcfcfcfcfcfcfcfc)>>2);
    x ^= ((x & 0xf0f0f0f0f0f0f0f0)>>4);
#endif

    return  x;
}
// -------------------------

static inline ulong byte_parity(ulong x)
// Return the parities of bytes in parallel
{
#if  BITS_PER_LONG == 32
    return  byte_inverse_gray_code(x) & 0x01010101;
#endif

#if  BITS_PER_LONG == 64
    return  byte_inverse_gray_code(x) & 0x0101010101010101;
#endif
}
// -------------------------


#endif  // !defined HAVE_GRAYCODE_H__
