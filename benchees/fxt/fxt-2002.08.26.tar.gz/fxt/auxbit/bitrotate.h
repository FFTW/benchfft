#if !defined HAVE_BITROTATE_H__
#define      HAVE_BITROTATE_H__


#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitasm.h"


static inline ulong bit_rotate_left(ulong x, ulong r)
// return word rotated r bits
// to the left (i.e. toward the most significant bit)
//
// gcc 2.95.2 optimizes the function to asm 'roll %cl,%ebx'
{
#if defined  BITS_USE_ASM    // use x86 asm code
    return asm_rol(x, r);
#else
//    r &= (BITS_PER_LONG-1);  // modulo wordlength
    return  (x<<r) | (x>>(BITS_PER_LONG-r));
#endif
}
// -------------------------


static inline ulong bit_rotate_right(ulong x, ulong r)
// return word rotated r bits
// to the right (i.e. toward the least significant bit)
//
// gcc 2.95.2 optimizes the function to asm 'rorl %cl,%ebx'
{
#if defined  BITS_USE_ASM    // use x86 asm code
    return asm_ror(x, r);
#else
//    r &= (BITS_PER_LONG-1);  // modulo wordlength
    return  (x>>r) | (x<<(BITS_PER_LONG-r));
#endif
}
// -------------------------


static inline ulong bit_rotate_left(ulong x, ulong r, ulong ldn)
// return ldn-bit word rotated r bits
// to the left (i.e. toward the most significant bit)
// r must be <= ldn
{
    x  = (x<<r) | (x>>(ldn-r));
    if ( 0!=(ldn % BITS_PER_LONG) )  x &= ((1UL<<(ldn))-1);
    return  x;
}
// -------------------------


static inline ulong bit_rotate_right(ulong x, ulong r, ulong ldn)
// return ldn-bit word rotated r bits
// to the right (i.e. toward the least significant bit)
// r must be <= ldn
{
    x  =  (x>>r) | (x<<(ldn-r));
    if ( 0!=(ldn % BITS_PER_LONG) )  x &= ((1UL<<(ldn))-1);
    return  x;
}
// -------------------------



#endif  // !defined HAVE_BITROTATE_H__
