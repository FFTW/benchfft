#if !defined HAVE_BITARRAY_H__
#define      HAVE_BITARRAY_H__


#include "fxttypes.h"
#include "bitasm.h"
#include "bitsperlong.h"


#define  DIVMOD(n, d, bm) \
ulong d = n / BITS_PER_LONG; \
ulong bm = 1UL << (n % BITS_PER_LONG);

#define  DIVMOD_TEST(n, d, bm) \
ulong d = n / BITS_PER_LONG; \
ulong bm = 1UL << (n % BITS_PER_LONG); \
ulong t = bm & f_[d];


class bitarray
//
// bitarray class mostly for use as
// memory saving array of boolean values
// valid index is 0...nb_-1 (as usual in C arrays)
//
{
public:
    ulong nb_, nw_;  // number of bits/words
    ulong nfw_;  // number of words where all bits are used, may be zero
    ulong nbl_;  // number of bits used in last (partially used) word, 0 if mw==mfw
    ulong ml_;   // mask for last (partially used) word, ~0 if mw==mfw
    ulong *f_;   // data


public:
    bitarray(ulong nbits);
    ~bitarray()  { delete [] f_; }

    ulong test(ulong n)  const
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_bt(f_, n);
#else
        DIVMOD_TEST(n, d, bm);
        return  t;
#endif
    }

    void set(ulong n)
    {
        if ( n>=nb_ )  return;
#if defined  BITS_USE_ASM
        asm_b_s(f_, n);
#else
        DIVMOD(n, d, bm);
        f_[d] |= bm;
#endif
    }

    void clear(ulong n)
    {
        if ( n>=nb_ )  return;
#if defined  BITS_USE_ASM
        asm_b_r(f_, n);
#else
        DIVMOD(n, d, bm);
        f_[d] &= ~bm;
#endif
    }

    void change(ulong n)
    {
        if ( n>=nb_ )  return;
#if defined  BITS_USE_ASM
        asm_b_c(f_, n);
#else
        DIVMOD(n, d, bm);
        f_[d] ^= bm;
#endif
    }

    ulong test_set(ulong n)
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_bts(f_, n);
#else
        DIVMOD_TEST(n, d, bm);
        f_[d] |= bm;
        return  t;
#endif
    }

    ulong test_clear(ulong n)
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_btr(f_, n);
#else
        DIVMOD_TEST(n, d, bm);
        f_[d] &= ~bm;
        return  t;
#endif
    }

    ulong test_change(ulong n)
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_btc(f_, n);
#else
        DIVMOD_TEST(n, d, bm);
        f_[d] ^= bm;
        return  t;
#endif
    }


    void clear_all()
    {
        for (ulong k=0; k<nw_; ++k)  f_[k] = 0;
    }

    void set_all()
    {
        ulong k=0;
        for (  ; k<nw_; ++k)  f_[k] = ~0UL;
        // keep the excess bits unset:
        f_[k-1] &= ml_;  // nop iff there is no partially used word
    }


    int all_set_q()  const;    // return whether all bits are set
    int all_clear_q()  const;  // return whether all bits are clear

    ulong next_set_idx(ulong n)  const // return next set or one beyond end
    {
        if ( n>=nb_ )  n = nb_;
        else while ( (n<nb_) && (!test(n)) )  ++n;
        return  n;
    }

    ulong next_clear_idx(ulong n)  const // return next clear or one beyond end
    {
        if ( n>=nb_ )  n = nb_;
        else while ( (n<nb_) && (test(n)) )  ++n;
        return  n;
    }

    // note: todo: next_set/clear_idx_sparse()


    void dump()  const;
    void dump_bits()  const;
};
// -------------------------

#undef  DIVMOD
#undef  DIVMOD_TEST


#endif // !defined HAVE_BITARRAY_H__
