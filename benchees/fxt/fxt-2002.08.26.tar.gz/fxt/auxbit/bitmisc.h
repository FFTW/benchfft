#if !defined HAVE_BITMISC_H__
#define      HAVE_BITMISC_H__

#include "fxttypes.h"
#include "bitsperlong.h"

//<<
// some esoteric bit twiddeling
//
// assume that for all functions the bits 'beyond' are zero.
// therefore
// interior_values(v)
// is not the same as
// ( interior_bits(v) | interior_bits(~v) )
//>>


static inline ulong single_bits(ulong x)
// return word were only the single bits from x are set
{
    return  x & ~( (x<<1) | (x>>1) );
}
// -------------------------

static inline ulong single_zeros(ulong x)
// return word were only the single zeros from x are set
{
    return  single_bits( ~x );
}
// -------------------------

static inline ulong single_values(ulong x)
// return word were only the single bits and the
// single zeros from x are set
{
    return  (x ^ (x<<1)) & (x ^ (x>>1));
}
// -------------------------


static inline ulong border_bits(ulong x)
// return word were only those bits from x are set
// that lie next to a zero
{
    return  x & ~( (x<<1) & (x>>1) );
}
// -------------------------

static inline ulong border_values(ulong x)
// return word were those bits/zeros from x are set
// that lie next to a zero/bit
{
    ulong g = x ^ (x>>1);
    g |= (g<<1);
    return   g | (x & 1);
}
// -------------------------

static inline ulong high_border_bits(ulong x)
// return word were only those bits from x are set
// that lie right to (i.e. in the next lower bin of) a zero
{
    return  x & ( x ^ (x>>1) );
}
// -------------------------

static inline ulong low_border_bits(ulong x)
// return word were only those bits from x are set
// that lie left to (i.e. in the next higher bin of) a zero
{
    return  x & ( x ^ (x<<1) );
}
// -------------------------

static inline ulong block_border_bits(ulong x)
// return word were only those bits from x are set
// that are at the border of a block of at least 2 bits
{
    return  x & ( (x<<1) ^ (x>>1) );
}
// -------------------------

static inline ulong low_block_border_bits(ulong x)
// return word were only those bits from x are set
// that are at left of a border of a block of at least 2 bits
{
    ulong t = x & ( (x<<1) ^ (x>>1) );  // block_border_bits()
    return  t & (x>>1);
}
// -------------------------

static inline ulong high_block_border_bits(ulong x)
// return word were only those bits from x are set
// that are at right of a border of a block of at least 2 bits
{
    ulong t = x & ( (x<<1) ^ (x>>1) );  // block_border_bits()
    return  t & (x<<1);
}
// -------------------------

static inline ulong block_bits(ulong x)
// Return word were only those bits from x are set
// that are part of a block of at least 2 bits
{
    return  x & ( (x<<1) | (x>>1) );
}
// -------------------------

static inline ulong block_values(ulong x)
// return word were only those bits/values are set
// that do not lie next to an opposite value
{
    return  ~single_values(x);
}
// -------------------------

static inline ulong interior_bits(ulong x)
// return word were only those bits from x are set
// that do not have a zero to their left or right
{
    return  x & ( (x<<1) & (x>>1) );
}
// -------------------------

static inline ulong interior_values(ulong x)
// return word were only those bits/zeros from x are set
// that do have a zero/bit to their left or right
{
    return  ~border_values(x);
}
// -------------------------



static inline ulong bit_block(ulong p, ulong n)
// Return word with length-n bit block starting at bit p set.
// Both p and n are effectively taken modulo BITS_PER_LONG.
{
    ulong x = (1<<n) - 1;
    return  x << p;
}
// -------------------------

static inline ulong cyclic_bit_block(ulong p, ulong n)
// Return word with length-n bit block starting at bit p set.
// The result is possibly wrapped around the word boundary.
// Both p and n are effectively taken modulo BITS_PER_LONG.
{
    ulong x = (1<<n) - 1;
    return  (x<<p) | (x>>(BITS_PER_LONG-p));
}
// -------------------------


#endif  // !defined HAVE_BITMISC_H__
