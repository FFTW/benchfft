#if !defined HAVE_REVBIN_H__
#define      HAVE_REVBIN_H__


#include "fxttypes.h"
#include "bitswap.h"
#include "bitsperlong.h"
#include "bitasm.h"


static inline ulong revbin(ulong x)
//
// return x with bitsequence reversed
//
{
    x = bit_swap_1(x);
    x = bit_swap_2(x);
    x = bit_swap_4(x);

#if defined  BITS_USE_ASM
    x = asm_bswap(x);
#else
    x = bit_swap_8(x);
    x = bit_swap_16(x);
#endif

#if  BITS_PER_LONG >= 64
    x = bit_swap_32(x);
#endif
    return x;
}
// -------------------------


static inline ulong revbin(ulong x, ulong ldn)
//
// return word with the last ldn bits
//   (i.e. bit_0 ... bit_{ldn-1})
//   of x reversed
// the other bits are set to 0
{
//    ulong r = 0;
//    while ( ldn-- != 0 )
//    {
//        r <<= 1;
//        r += (x&1);
//        x >>= 1;
//    }
//    return  r;
    // =^=
    return  revbin(x) >> (BITS_PER_LONG-ldn);
}
// -------------------------


static inline ulong revbin_update(ulong r, ulong ldn)
// let r = revbin(x, ld(n)) at entry
// then return  revbin(x+1, ld(n))
{
    ldn >>= 1;
    while ( !((r^=ldn)&ldn) )  ldn >>= 1;
    return  r;
}
// -------------------------


#endif  // !defined HAVE_REVBIN_H__
