#if !defined HAVE_BITCYCLIC_H__
#define      HAVE_BITCYCLIC_H__


#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitrotate.h"


static inline ulong cyclic_match(ulong x, ulong y)
// return  r if x==rotate_right(y, r)
// else return ~0UL
// in other words: returns, how often
//   the right arg must be rotated right (to match the left)
// or, equivalently: how often
//   the left arg must be rotated left (to match the right)
{
    ulong r = 0;
    do
    {
        if ( x==y )  return r;
        y = bit_rotate_right(y, 1);
    }
    while ( ++r < BITS_PER_LONG );

    return ~0UL;
}
// -------------------------


static inline ulong cyclic_match(ulong x, ulong y, ulong ldn)
// return  r if x==rotate_right(y, r, ldn)
// else return ~0UL
{
    ulong r = 0;
    do
    {
        if ( x==y )  return r;
        y = bit_rotate_right(y, 1, ldn);
    }
    while ( ++r < ldn );

    return ~0UL;
}
// -------------------------


static inline ulong cyclic_min(ulong x)
// return  minimum of all rotations of x
{
    ulong r = 1;
    ulong m = x;
    do
    {
        x = bit_rotate_right(x, 1);
        if ( x<m )  m = x;
    }
    while ( ++r < BITS_PER_LONG );

    return  m;
}
// -------------------------


static inline ulong cyclic_max(ulong x)
// return  maximum of all rotations of x
{
    ulong r = 1;
    ulong m = x;
    do
    {
        x = bit_rotate_right(x, 1);
        if ( x>m )  m = x;
    }
    while ( ++r < BITS_PER_LONG );

    return  m;
}
// -------------------------



static inline ulong cyclic_min(ulong x, ulong ldn)
// return  minimum of all rotations of x
{
    ulong r = 1;
    ulong m = x;
    do
    {
        x = bit_rotate_right(x, 1, ldn);
        if ( x<m )  m = x;
    }
    while ( ++r < ldn );

    return  m;
}
// -------------------------


static inline ulong cyclic_max(ulong x, ulong ldn)
// return  maximum of all rotations of x
{
    ulong r = 1;
    ulong m = x;
    do
    {
        x = bit_rotate_right(x, 1, ldn);
        if ( x>m )  m = x;
    }
    while ( ++r < ldn );

    return  m;
}
// -------------------------


#endif  // !defined HAVE_BITCYCLIC_H__
