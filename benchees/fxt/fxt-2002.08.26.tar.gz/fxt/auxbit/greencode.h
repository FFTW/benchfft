#if !defined HAVE_GREENCODE_H__
#define      HAVE_GREENCODE_H__

#include "fxttypes.h"
#include "bitsperlong.h"


static inline ulong green_code(ulong x)
// Return the green-code of x
// ('bitwise derivative modulo 2 towards high bits')
//
// green_code(x) == revbin(gray_code(revbin(x)))
{
    return  x ^ (x<<1);
}
// -------------------------


static inline ulong inverse_green_code(ulong x)
// inverse of green_code()
// note: the returned value contains at each bit position
// the parity of all bits of the input right from it (incl. itself)
//
{
    // use: green ** BITSPERLONG == id:
    x ^= x<<1;  // green ** 1
    x ^= x<<2;  // green ** 2
    x ^= x<<4;  // green ** 4
    x ^= x<<8;  // green ** 8
    x ^= x<<16; // green ** 16
    // here: x = green**31(input)
    // note: the statements can be reordered at will

#if  BITS_PER_LONG >= 64
    x ^= x<<32;  // for 64bit words
#endif

    return  x;
}
// -------------------------



#endif  // !defined HAVE_GREENCODE_H__
