#if !defined HAVE_BITASM_H__
#define      HAVE_BITASM_H__

#include "fxttypes.h"

#if defined  __i386__  // ------- if x86 cpu
#if defined  __GNUC__  // if GNU-C

#ifndef NO_BITS_USE_ASM  // for automatic testing
// comment out the following line to disable asm usage:
#define  BITS_USE_ASM    // use x86 asm code
#endif // NO_BITS_USE_ASM

#endif // __GNUC__
#endif // __i386__



#if defined  BITS_USE_ASM    // use x86 asm code

static inline ulong asm_bsf(ulong x)
// Bit Scan Forward
{
    asm ("bsfl %0, %0" : "=r" (x) : "0" (x));
    return x;
}
// -------------------------


static inline ulong asm_bsr(ulong x)
// Bit Scan Reverse
{
    asm ("bsrl %0, %0" : "=r" (x) : "0" (x));
    return x;
}
// -------------------------


static inline ulong asm_bswap(ulong x)
// byte swap
{
    asm ("bswap %0" : "=r" (x) : "0" (x));
    return x;
}
// -------------------------


static inline ulong asm_rol(ulong x, ulong r)
// Rotate Left
{
    asm ("roll   %%cl, %0" : "=r" (x) : "0" (x), "c" (r));
    return x;
}
// -------------------------


static inline ulong asm_ror(ulong x, ulong r)
// Rotate Right
{
    asm ("rorl   %%cl, %0" : "=r" (x) : "0" (x), "c" (r));
    return x;
}
// -------------------------


static inline ulong asm_parity(ulong x)
// Return the parity of x (which is the
// _complement_ of x86's parity flag).
// As parity is for the low byte only,
// therefore we need to prepend
// x ^= (x>>16);  x ^= (x>>8);
// in the code
{
    x ^= (x>>16);
    x ^= (x>>8);
    asm ("addl  $0, %0  \n"
         "setnp %%al    \n"
         "movzx %%al, %0"
         : "=r" (x) : "0" (x) : "eax");

    return x;
}
// -------------------------


static inline ulong asm_bt(const ulong *f, ulong i)
// Bit Test
{
    ulong ret;
    asm ( "btl  %2, %1 \n" // carry = 0 or 1
          "sbbl %0, %0"    // ret = 0 or -1
          : "=r" (ret)
          : "m" (*f), "r" (i) );
    return ret;
}
// -------------------------

static inline ulong asm_bts(ulong *f, ulong i)
// Bit Test and Set
{
    ulong ret;
    asm ( "btsl %2, %1 \n"
          "sbbl %0, %0"
          : "=r" (ret)
          : "m" (*f), "r" (i) );
    return ret;
}
// -------------------------

static inline void asm_b_s(ulong *f, ulong i)
// Bit Set
{
    asm ( "btsl  %1, %0 \n"
          : /* void */
          : "m" (*f), "r" (i) );
}
// -------------------------

static inline ulong asm_btr(ulong *f, ulong i)
// Bit Test and Reset
{
    ulong ret;
    asm ( "btrl  %2, %1 \n"
          "sbbl %0, %0"
          : "=r" (ret)
          : "m" (*f), "r" (i) );
    return ret;
}
// -------------------------

static inline void asm_b_r(ulong *f, ulong i)
// Bit Reset
{
    asm ( "btrl  %1, %0 \n"
          : /* void */
          : "m" (*f), "r" (i) );
}
// -------------------------

static inline ulong asm_btc(ulong *f, ulong i)
// Bit Test and Complement
{
    ulong ret;
    asm ( "btcl  %2, %1 \n"
          "sbbl %0, %0"
          : "=r" (ret)
          : "m" (*f), "r" (i) );
    return ret;
}
// -------------------------

static inline void asm_b_c(ulong *f, ulong i)
// Bit Complement
{
    asm ( "btcl  %1, %0 \n"
          : /* void */
          : "m" (*f), "r" (i) );
}
// -------------------------


#endif // BITS_USE_ASM


#endif  // !defined HAVE_BITASM_H__
