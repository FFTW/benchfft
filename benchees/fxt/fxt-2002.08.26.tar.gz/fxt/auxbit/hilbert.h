#if !defined HAVE_HILBERT_H__
#define      HAVE_HILBERT_H__

#include "fxttypes.h"


// auxbit/hilbert.cc:
void hilbert(ulong t, ulong &x, ulong &y);


#endif  // !defined HAVE_HILBERT_H__
