#if !defined HAVE_AUXBITLAZY_H__
#define      HAVE_AUXBITLAZY_H__

// include file for the lazy

#include "bitsperlong.h"

#include "bitarray.h"
#include "bitcount.h"
#include "bitswap.h"
#include "bitrotate.h"
#include "bitcyclic.h"
#include "bitlow.h"
#include "bithigh.h"
#include "bit2pow.h"
#include "bitsubset.h"
#include "revbin.h"
#include "graycode.h"
#include "tinyfactors.h"

#include "bitasm.h"

#include "printbin.h"


// slightly esoteric stuff:
#include "bitcombination.h"
#include "bitcombminchange.h"
#include "zerobyte.h"
#include "branchless.h"

// clearly esoteric stuff:
#include "bitsequency.h"
#include "bitmisc.h"
#include "bitzip.h"
#include "greencode.h"
#include "hilbert.h"


#endif // !defined HAVE_AUXBITLAZY_H__
