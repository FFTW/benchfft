#if !defined HAVE_BITCOMBINATION_H__
#define      HAVE_BITCOMBINATION_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "revbin.h"


static inline ulong first_comb(ulong k)
// return the first combination of (i.e. smallest word with) k bits,
// i.e.  00..001111..1 (k low bits set)
// must have:  0 <= k <= BITS_PER_LONG
{
    ulong x = ~0UL;
    if ( BITS_PER_LONG != k )  x = ~(x<<k);
    return  x;
}
// -------------------------


static inline ulong last_comb(ulong k, ulong n=BITS_PER_LONG)
// return the last combination of (biggest n-bit word with) k bits
// i.e.  1111..100..00 (k high bits set)
// must have:  0 <= k <= n <= BITS_PER_LONG
{
    if ( BITS_PER_LONG == k )  return  ~0UL;
    else return  ((1UL<<k)-1) << (n - k);
}
// -------------------------

#define  COLEX_COMB_VERSION  0  // 0 (default) or 1

#if  COLEX_COMB_VERSION == 0
static inline ulong next_colex_comb(ulong x)
// return smallest integer greater than x with the same number of bits set.
//
// colex order: (5,3);
//  0  1  2   ..111
//  0  1  3   .1.11
//  0  2  3   .11.1
//  1  2  3   .111.
//  0  1  4   1..11
//  0  2  4   1.1.1
//  1  2  4   1.11.
//  0  3  4   11..1
//  1  3  4   11.1.
//  2  3  4   111..
//
//  Examples:
//    000001 -> 000010 -> 000100 -> 001000 -> 010000 -> 100000
//    000011 -> 000101 -> 000110 -> 001001 -> 001010 -> 001100 -> 010001 -> ...
//    000111 -> 001011 -> 001101 -> 001110 -> 010011 -> 010101 -> 010110 -> ...
//
//  Special cases:
//    0 -> 0
//    all bits on the high side (i.e. last combination) -> 0
//.
// based on code by Doug Moore / Glenn Rhoads
// note: might want to use bitscan near end
{
    ulong r = x & -x; // lowest set bit
    x += r;           // replace lowest block by a one left to it

    if ( 0==x )  return 0;  // input was last comb

    ulong l = x & -x; // first zero beyond lowest block
    l -= r;           // lowest block  (cf. lowest_block())

    while ( 0==(l&1) )  { l >>= 1; }  // move block to low end of word
    return  x | (l>>1);  // need one bit less of low block
}
// -------------------------

#else  COLEX_COMB_VERSION

static inline ulong next_colex_comb(ulong x)
//  alternative implementation
//  based on code taken from Torsten Sillke's bitmani.h:
//  http://www.mathematik.uni-bielefeld.de/~sillke/ALGORITHMS/
//  The algorithm can be found in hakmem, shortcut by me.
//
//  Example: (the bits marked by '.' remain fixed)
//    x         = ....01111100000000
//    z         = 000000000100000000   (the lowest set bit)
//    v=x+z     = ....10000000000000   (first zero beyond burst of ones)
//    v^x       = 000011111100000000
//    v^x/z     = 000000000000111111
//    v^x/z>>2  = 000000000000001111
//    next      = ....10000000001111
//
{
    // begin shortcut
    if ( x & 1 )  // avoid division for trivial update
    {
        ulong z = ~x;  z &= -z; // lowest unset bit
        if ( 0==z )  return  0;   // x was == 0xffffffff
        x += (z>>1);  // same as:  x ^= z;  x ^= (z>>1);
        return  x;
    }
    // end shortcut

    ulong z = x & -x;  // lowest set bit
    ulong v = x + z;   // zero beyond burst

    if ( v )  v += ((v^x)/z >> 2);  // note: use bitscan & shift

    return  v;  // ==0 if input was the biggest combo with that number of bits
}
// -------------------------

#endif //  COLEX_COMB_VERSION
#undef  COLEX_COMB_VERSION


static inline ulong prev_colex_comb(ulong x)
//
// inverse of next_colex_comb()
//
{
    x = next_colex_comb( ~x );
    if ( 0!=x )  x = ~x;
    return  x;
}
// -------------------------


static inline ulong next_lex_comb(ulong x)
//
// let the zeros move to the lower end in the same manner
// as the ones go to the higher end in next_colex_comb()
//
// lex order:  (5, 3):  (for a 5 bit word !)
//  0  1  2   ..111
//  0  1  3   .1.11
//  0  1  4   1..11
//  0  2  3   .11.1
//  0  2  4   1.1.1
//  0  3  4   11..1
//  1  2  3   .111.
//  1  2  4   1.11.
//  1  3  4   11.1.
//  2  3  4   111..
//
// start and end combo are the same as for next_colex_comb()
//
{
    x = revbin( ~x );
    x = next_colex_comb( x );
    if ( 0!=x )  x = revbin( ~x );
    return  x;
}
// -------------------------


static inline ulong prev_lex_comb(ulong x)
//
// inverse of next_lex_comb()
//
{
    x = revbin( x );
    x = next_colex_comb( x );
    if ( 0!=x )  x = revbin( x );
    return  x;
}
// -------------------------



#endif  // !defined HAVE_BITCOMBINATION_H__
