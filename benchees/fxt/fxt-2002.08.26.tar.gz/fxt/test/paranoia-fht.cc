
#include "fxt.h"
#include "copy.h"
#include "auxdouble.h"
#include "auxprint.h"
#include "arith.h"
#include "permlazy.h"

#include <cmath>
#include "fxtio.h"
#include <cstdlib>  // atol()

// note: todo: generated (short) versions
// note: todo: ntt


#include "paranoia.h"


int
main(int argc, char **argv)
{
  cout << "Running tests for FHTs ... " << endl;

  ulong minldn = 0, maxldn = 11;
  if ( argc>1 )  minldn = atol(argv[1]);
  if ( argc>2 )  maxldn = atol(argv[2]);

  int rep = 1;
  if ( argc>3 )  rep = atol(argv[3]);


  ulong n = 1<<maxldn;
  Complex ac[n], fc[n], gc[n];
  //  double *ar=(double *)ac;
  double *fr=(double *)fc, *gr=(double *)gc;
  for (int r=1; r<=rep; ++r)
  {
    cout << "+++++++++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") +++++++++++++++++++++++++" << endl;

    for (ulong ldn=minldn; ldn<=maxldn; ++ldn)
    {
      n = 1<<ldn;
      cout << "====================  LDN = " << ldn
           << "   N = " << n << " :" << endl;

//      ulong nh = n/2;
      double *fi=fr+n,  *gi=gr+n; // ,  *ai=ar+n;
      null(ac, n);
      //   ar[1] = ai[1] = 1;
      for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), white_noise());
      //   for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), 0.0 );
      //   set_seq(ar, 2*n, 1.0/n, 1.0/n);
      //   fill(ar, 2*n, 1.0);


      cout << "\n----- FHT: -----" << endl;
      ECHO( dit_fht(fr, ldn); );

      CHECK_REAL( dif_fht(gr, ldn); );
      CHECK( dit2_fht(gr, ldn); );
      CHECK( dif2_fht(gr, ldn); );

      if ( ldn<=SMALL_LDN )
      {
        CHECK_REAL( slow_ht(gr, n); );

        CHECK_REAL( recursive_dit2_fht(gr, ldn); );
        CHECK_REAL( recursive_dif2_fht(gr, ldn); );
        CHECK( dit2_fht_localized(gr, ldn); );
        CHECK( dif2_fht_localized(gr, ldn); );
      }

    } // === ldn ===

    cout << "+++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") ++++++ FINISHED +++++++++++++" << endl;

  } // === r ===


  cout << "\nOK, all passed." << endl;
  return 0;
}
// -------------------------
/*
Local variables:
mode: C++
c-basic-offset: 2
End:
*/
