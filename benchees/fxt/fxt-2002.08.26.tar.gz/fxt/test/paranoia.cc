
#include "fxt.h"
#include "copy.h"
#include "auxdouble.h"
#include "auxprint.h"
#include "arith.h"
#include "permlazy.h"
#include "walshlazy.h"

#include <cmath>
#include "fxtio.h"
#include <cstdlib>  // atol()

// note: todo: generated (short) versions
// note: todo: ntt


#include "paranoia.h"

int
main(int argc, char **argv)
{
  cout << "Running tests for other transforms ... " << endl;

  ulong minldn = 0, maxldn = 11;
  if ( argc>1 )  minldn = atol(argv[1]);
  if ( argc>2 )  maxldn = atol(argv[2]);

  int rep = 1;
  if ( argc>3 )  rep = atol(argv[3]);


  ulong n = 1<<maxldn;
  Complex ac[n], fc[n], gc[n];
  double *ar=(double *)ac, *fr=(double *)fc, *gr=(double *)gc;
  for (int r=1; r<=rep; ++r)
  {
    cout << "+++++++++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") +++++++++++++++++++++++++" << endl;

    for (ulong ldn=minldn; ldn<=maxldn; ++ldn)
    {
      n = 1<<ldn;
      cout << "====================  LDN = " << ldn
           << "   N = " << n << " :" << endl;

      //      ulong nh = n/2;

      double *fi=fr+n,  *gi=gr+n; //,  *ai=ar+n;
      null(ac, n);
      //   ar[1] = ai[1] = 1;
      for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), white_noise());
      //   for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), 0.0 );
      //   set_seq(ar, 2*n, 1.0/n, 1.0/n);
      //   fill(ar, 2*n, 1.0);

      cout << "\n----- FHT: -----" << endl;
      ECHO( dit_fht(fr, ldn); );
      CHECK_REAL( dif_fht(gr, ldn); );
      if ( ldn<=SMALL_LDN )
      {
        CHECK_REAL( recursive_dif2_fht(gr, ldn); );
        CHECK_REAL( recursive_dit2_fht(gr, ldn); );
        CHECK_REAL( dit2_fht_localized(gr, ldn); );
        CHECK_REAL( dif2_fht_localized(gr, ldn); );
      }


      cout << "\n----- IDENTITY (WALSH/invWALSH): -----" << endl;
      ECHO( copy(ac, fc, n); );
      CHECK_REAL( walsh_wal(gr, ldn); walsh_wal(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_wak(gr, ldn); walsh_wak(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_pal(gr, ldn); walsh_pal(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_seq(gr, ldn); inverse_walsh_seq(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_seq2(gr, ldn); inverse_walsh_seq2(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_gray(gr, ldn); inverse_walsh_gray(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_hartley_05_dif_core(gr, ldn); walsh_hartley_05_dit_core(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_hartley_05(gr, ldn); walsh_hartley_05(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( walsh_seq(gr, ldn); inverse_walsh_seq(gr, ldn); multiply_val(gr, n, 1.0/n); );

      EQUIV( copy(ar, fr, n); walsh_hartley_05_dif_core(fr, ldn);/**/
      copy(ar, gr, n); gray_permute(gr, n); walsh_wak(gr, ldn); );

      EQUIV( copy(ar, fr, n); walsh_hartley_05_dit_core(fr, ldn);/**/
      copy(ar, gr, n); walsh_wak(gr, ldn); inverse_gray_permute(gr, n); );


      cout << "\n----- IDENTITY (DCT/DST): -----" << endl;
      ECHO( copy(ac, fc, n); );
      CHECK_REAL( dsth(gr, ldn); idsth(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( dcth(gr, ldn); idcth(gr, ldn); multiply_val(gr, n, 1.0/n); );
      CHECK_REAL( dst(gr, ldn);  dst(gr, ldn);   multiply_val(gr, n, 2.0/n); );
      EQUIV( copy(ar, fr, n); dcth(fr, ldn);/**/ copy(ar, gr, n); dcth_zapata(gr, ldn); );


      cout << "\n----- EQUIV (WALSH): -----" << endl;
      EQUIV( copy(ar, fr, n); dif2_walsh_wak(fr, ldn);/**/ copy(ar, gr, n); dit2_walsh_wak(gr, ldn); );

      EQUIV( copy(ar, fr, n); dif2_walsh_wal(fr, ldn);/**/ copy(ar, gr, n); dit2_walsh_wal(gr, ldn); );

      EQUIV( copy(ar, fr, n); dif2_walsh_pal(fr, ldn);/**/ copy(ar, gr, n); dit2_walsh_pal(gr, ldn); );

    }  // === ldn ===

    cout << "+++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") ++++++ FINISHED +++++++++++++" << endl;
  } // === r ===

  cout << "\nOK, all passed." << endl;
  return 0;
}
// -------------------------
/*
Local variables:
mode: C++
c-basic-offset: 2
End:
*/
