
#include "auxbitlazy.h"
#include "inline.h"
#include "printbin.h"
#include "jjassert.h"

#include <cstdlib> // rand()
#include "fxtiomanip.h"

char str[BYTES_PER_LONG];

#define PP(x)  cout << setw(20) << #x << " = "; print_bin_nn((x),0,".1"); cout << endl;
void
do_some_tests(ulong v)
{
//    cout << "\n v = " << v  << hex << " = 0x" << v << dec << " = ";
//    print_bin_nn(v);  cout << endl;
//    PP((v));
//    PP(high_bits(v));
//    PP((~v));
//    PP(high_zeros(~v));

    ulong t;

    jjassert( v == butterfly_2(butterfly_2(v)) );
    jjassert( v == bit_unzip(bit_zip(v)) );

    jjassert( (low_bits(v) & low_zeros(v)) == 0 );
    jjassert( (low_bits(v) | low_zeros(v)) != 0 );

    jjassert( high_bits(v) == high_zeros(~v) );
    jjassert( (high_bits(v) & high_zeros(v)) == 0 );
    jjassert( (high_bits(v) | high_zeros(v)) != 0 );

    jjassert( (highest_bit_01edge(v) & highest_bit_10edge(v)) == highest_bit(v) ); // CHECK

    t = highest_bit_01edge(v);  jjassert( bit_count(t) == bit_count_01(t) ); // CHECK

    jjassert( (lowest_bit_01edge(v) & lowest_bit_10edge(v)) == lowest_bit(v) ); // CHECK

    jjassert( (v==0) || lowest_bit_idx(v) == BITS_PER_LONG-1 - highest_bit_idx(revbin(v)) ); // CHECK
    jjassert( (v!=0) || lowest_bit_idx(v) == highest_bit_idx(revbin(v)) ); // CHECK

    jjassert( lowest_bit(v) == lowest_zero(~v) ); // CHECK
    jjassert( highest_bit(v) == highest_zero(~v) ); // CHECK
    jjassert( revbin( highest_bit(v) ) == lowest_bit( revbin(v) ) ); // CHECK
    jjassert( revbin(v) == revbin(v, BITS_PER_LONG) ); // CHECK

    jjassert( single_values(v) == single_bits(v) | single_zeros(v) ); // CHECK
    jjassert( single_bits(v)  == single_zeros(~v) ); // CHECK
    jjassert( single_bits(~v) == single_zeros(v) ); // CHECK

    jjassert( border_bits(v) == high_border_bits(v) | low_border_bits(v) ); // CHECK
//    jjassert( border_bits(v) == border_bits(~v) );  // not true

    jjassert( block_border_bits(v) == low_block_border_bits(v) ^ high_block_border_bits(v) ); // CHECK
    jjassert( block_bits(v) == block_border_bits(v) | interior_bits(v) ); // CHECK

    jjassert( v == block_bits(v) | single_bits(v) ); // CHECK
    jjassert( bit_count(v) == bit_count_sparse(v) ); // CHECK

    jjassert( interior_bits(v) == (interior_bits(v) & interior_values(v)) ); // CHECK

//    jjassert( (interior_bits(v) | interior_bits(~v)) == interior_values(v) ); //  not true

    jjassert( parity(v) == (inverse_gray_code(v) & 1) ); // CHECK

    if ( v ) { jjassert( (1UL<<ld(v)) <= v ); }  else { jjassert( ld(v) == 0 ); } // CHECK

    for (ulong r=0; r<(BITS_PER_LONG); ++r)
    {
        jjassert( v==bit_rotate_right(bit_rotate_left(v,r), r) ); // CHECK
        jjassert( v==bit_rotate_right(bit_rotate_right(v,r), BITS_PER_LONG-r) ); // CHECK
        jjassert( v==bit_rotate_left(bit_rotate_left(v,r), BITS_PER_LONG-r) ); // CHECK
    }

    if ( contains_zero_byte(v) )
    {
        ulong x = v;
        for (ulong k=0; k<BYTES_PER_LONG; ++k)
        {
            str[k] = (char)(x & 0xff);
            x >>= 8;
        }
        ulong k;
        for (k=0; k<BYTES_PER_LONG; ++k)  if ( 0==str[k] )  break;
        if ( k==BYTES_PER_LONG )
        {
            cout << hex << " contains_zero_byte( 0x" << v << " )";
            cout        << "   gave  0x" << contains_zero_byte(v) << endl;
            jjassert2(0, " contains_zero_byte() failed ");
        }
    }
}
// -------------------------


int
main()
{
    cout << "Running tests for low level (bit-) functions "
#ifdef  NO_BITS_USE_ASM
        "WITHOUT asm-functions"
#else
        "with ASM-versions"
#endif
         "..." << endl;
//    cout << "RAND_MAX=" << (RAND_MAX) << endl;

    // some special values we'd like to test:
    do_some_tests( 0 );
    do_some_tests( ~0UL );
    do_some_tests( 1 );
    do_some_tests( 2 );

    ulong x = 1UL<<(BITS_PER_LONG-1);  // highest bit set
    do_some_tests( x );
    do_some_tests( x + 1 );
    do_some_tests( x - 1 );


    ulong n = 300*1000;  // this many tests with random values
    for (ulong i=0; i<n; ++i)
    {
        ulong v = (ulong)rand();
        v ^= ((ulong)rand())<<16; // also want high bit !=0

        do_some_tests(v);
        if ( 0==(i%1024) )  { cout << "."; cout.flush(); }
    }

    cout << "\nOK passed " << n << " tests." << endl;

    return 0;
}
// -------------------------
