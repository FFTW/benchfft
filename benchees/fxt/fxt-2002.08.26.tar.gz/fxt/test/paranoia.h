#if !defined  HAVE_PARANOIA_H__
#define       HAVE_PARANOIA_H__

#define  DO_CHECK() \
{ if ( rms_diff(fr, gr, 2*n) > 1e-10 ) \
 { cout << "  FAILED !"; \
   approx_eq(fr, gr, n,"\n1/2:\n",1e-10); \
   approx_eq(fi, gi, n,"\n2/2:\n",1e-10); \
 cout << " in LINE " << __LINE__ << endl; \
 cout << " n = " << n << endl; \
 exit (33); } \
 else  cout << "  OK." << endl; }

#define  DO_CHECK_IMAG() \
{ if ( rms_diff(fi, gi, n) > 1e-10 ) \
 { cout << "  FAILED !"; \
 approx_eq(fi, gi, n,"\nimag:\n",1e-10); \
 cout << " in LINE " << __LINE__ << endl; \
 cout << " n = " << n << endl; \
 exit (33); } \
 else  cout << "  OK." << endl; }

#define  DO_CHECK_REAL() \
{ if ( rms_diff(fr, gr, n) > 1e-10 ) \
 { cout << "  FAILED !"; \
 approx_eq(fr, gr, n,"\nreal:\n",1e-10); \
 cout << " in LINE " << __LINE__ << endl; \
 cout << " n = " << n << endl; \
 exit (33); } \
 else  cout << "  OK." << endl; }


#define  DO_CHECK_EXACT() \
{ int q=0; for (ulong k=0;k<n;++k) if(fr[k]!=gr[k]) { q=k+1;} \
 if ( q )  { cout << "  FAILED !"; \
 approx_eq(fr, gr, n,"\nexact:\n"); \
 cout << " in LINE " << __LINE__ << endl; \
 cout << " n = " << n << endl; \
 exit (33); } \
 else  cout << "  OK." << endl; }


#define  ECHO(x) \
{ copy(ac, fc, n); \
 cout << ": " << #x << endl;  x; }

#define  CHECK(x) \
{ copy(ac, gc, n); \
 cout << "== " << #x;  x; DO_CHECK(); }

#define  CHECK_IMAG(x) \
{ copy(ac, gc, n); \
 cout << "== " << #x;  x; DO_CHECK_IMAG(); }

#define  CHECK_REAL(x) \
{ copy(ac, gc, n); \
 cout << "== " << #x;  x; DO_CHECK_REAL(); }

#define  EQUIV(x) \
{ cout << "eq " << #x;  x; DO_CHECK(); }

#define  EQUIV_REAL(x) \
{ cout << "eq " << #x;  x; DO_CHECK_REAL(); }

#define  EQUIV_EXACT(x) \
{ cout << "eq " << #x;  x; DO_CHECK_EXACT(); }


#define SMALL_LDN  6  // slow_whatever() tested only for ldn<SMALL_LDN


#endif  // !defined HAVE_PARANOIA_H__
