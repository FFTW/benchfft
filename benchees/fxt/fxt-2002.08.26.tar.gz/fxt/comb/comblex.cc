
#include "comblex.h"
#include "fxttypes.h"

#include "fxtio.h"



ostream & operator << (ostream &os, const comb_lex &x)
{
    cout.width(2);
    os << x.x_[0];
    for (ulong i=1; i<x.k_; ++i)
    {
        os << " ";
        cout.width(2);
        cout << x.x_[i];
    }
    return os;
}
// -------------------------
