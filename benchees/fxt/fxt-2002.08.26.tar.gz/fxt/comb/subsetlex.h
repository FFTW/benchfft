#if !defined HAVE_SUBSETLEX_H__
#define      HAVE_SUBSETLEX_H__


#include "fxttypes.h"
#include "newop.h"
#include "bitcombination.h"


class subset_lex
{
protected:
    ulong *x;  // subset data
    ulong n;   // number of elements in set
    ulong k;   // index of last element in subset
    // number of elements in subset == k+1


public:
    subset_lex(ulong nn)
    {
        n = (nn ? nn : 1);  // not zero
        x = NEWOP(ulong, n+1);
        first();
    }

    ~subset_lex()  { delete [] x; }


    ulong first()
    {
        k = 0;
        x[0] = 0;
        return  k + 1;
    }

    ulong last()
    {
        k = 0;
        x[0] = n - 1;
        return  k + 1;
    }

    ulong next()
    // Generate next subset
    // Return number of elements in subset
    // Return zero if current == last
    {
        if ( x[k] == n-1 )  // last element is max ?
        {
            if ( 0==k )  { return 0; }  // note: user has to call first() again

            --k;     // remove last element
            x[k]++;  // increase last element
        }
        else  // add next element from set:
        {
            ++k;
            x[k] = x[k-1] + 1;
        }

        return  k + 1;
    }

    ulong prev()
    // Generate previous subset
    // Return number of elements in subset
    // Return zero if current == first
    {
        if ( k == 0 )  // only one lement ?
        {
            if ( x[0]==0 )  { return 0; }  // note: user has to call last() again

            x[0]--;  // decr first element
            x[++k] = n - 1;     // add element
        }
        else  // remove last element:
        {
            if ( x[k] == x[k-1]+1 )  --k;
            else
            {
                x[k]--;  // decr last element
                x[++k] = n - 1;     // add element
            }
        }

        return  k + 1;
    }

    const ulong * data()  { return x; }
};
// -------------------------



#endif  // !defined HAVE_SUBSETLEX_H__
