#if !defined HAVE_MODULARMIXEDRADIXGRAY_H__
#define      HAVE_MODULARMIXEDRADIXGRAY_H__

#include "fxttypes.h"
#include "newop.h"


class modular_mixed_radix_gray
//
// implementation following Knuth
//
{
public:
    ulong n_;
    ulong j_;
    ulong *a_;
    ulong *m1_;
    ulong *f_;
    ulong *s_;


public:
    modular_mixed_radix_gray(const ulong *m, ulong n)
        : n_(n)
    {
        a_ = NEWOP(ulong, 4*n_+1);
        m1_ = a_ + n_;
        s_ = m1_ + n_;  // m1_[j] == m[j] - 1 in Knuth
        f_ = s_ + n_;   // n_ + 1 elements
        for (ulong k=0; k<n_; ++k)  m1_[k] = m[k] - 1;
        init();
    }

    ~modular_mixed_radix_gray()
    {
        delete [] a_;
    }

    void init()
    {
        for (ulong k=0; k<n_; ++k)  a_[k] = 0;
        for (ulong k=0; k<n_; ++k)  s_[k] = m1_[k];
        for (ulong k=0; k<=n_; ++k)  f_[k] = k;
    }

    ulong *data()  const  { return a_; }

    ulong current()  const  { return j_; }

    ulong next()
    {
        j_ = f_[0];
        f_[0] = 0;

        if ( j_>=n_ )  { init(); return n_; }

        ++a_[j_];  if ( a_[j_] > m1_[j_] )  a_[j_] = 0;

        ulong aj = a_[j_];
        if ( s_[j_]==aj )
        {
            --s_[j_];  if ( s_[j_] == -1UL )  s_[j_] = m1_[j_];

            f_[j_] = f_[j_+1];
            f_[j_+1] = j_ + 1;
        }

        return j_;
    }
};
// -------------------------


#endif  // !defined HAVE_MODULARMIXEDRADIXGRAY_H__
