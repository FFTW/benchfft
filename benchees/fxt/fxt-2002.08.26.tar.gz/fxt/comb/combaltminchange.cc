
#include "fxttypes.h"
#include "fxtio.h"

#include "combaltminchange.h"


ostream & operator << (ostream &os, const comb_alt_minchange &x)
{
    cout.width(2);
    os << x.x_[0];
    for (ulong i=1; i<x.nk_; ++i)
    {
        os << " ";
        cout.width(2);
        cout << x.x_[i];
    }
    return os;
}
// -------------------------
