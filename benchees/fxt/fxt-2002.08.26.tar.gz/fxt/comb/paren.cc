
#include "paren.h"
#include "funcemu.h"

#define PAREN    0  // initial state
#define RETURN  20
//               args=(i, s)(k, t)=locals
#define EMU_CALL(func, i, s, k, t)  fe_->stpush(func);  fe_->push(i, s, k, t);


paren::paren(int nn)
{
    n = (nn>0 ? nn : 1);
    x = new int[n];

    str = new char[2*n+1];
    for (int i=0; i<2*n; ++i)  str[i] = ')'; // CLOSE_CHAR;
    str[2*n] = 0;

    fe_ = new funcemu<int>(n+1, 4*(n+1));

    //               i, s, k, t
    EMU_CALL( PAREN, 0, 0, 0, 0 );

    idx = 0;
    q = next_recursion();
}
// -------------------------

int
paren::next_recursion()
{
    int i, s; // args
    int k, t; // locals

 redo:
    fe_->peek(i, s, k, t);

 loop:
    switch ( fe_->stpeek() )
    {
    case 0:
        if ( i>=n )
        {
            x[i-1] = n - s;
            fe_->stnext( RETURN );  return 1;
        }
        fe_->stnext();

    case 1:
        if ( k>i-s ) // loop end ?
        {
            break;  // shortcut: nothing to do at end
        }
        fe_->stnext();

    case 2: // start of loop body
        x[i-1] = k;
        t = s + x[i-1];
        str[t+i] = '('; // OPEN_CHAR;

        fe_->poke(i, s, k, t);  fe_->stnext();
        EMU_CALL( PAREN, i+1, t, 0, 0 );
        goto redo;

    case 3:
        str[t+i] = ')'; // CLOSE_CHAR;
        ++k;
        if ( k>i-s ) // loop end ?
        {
            break;  // shortcut: nothing to do at end
        }

        fe_->stpoke(2);  goto loop; // shortcut: back to loop body

    default: ;
    }

    fe_->pop(4);  fe_->stpop();  // emu_return to caller

    if ( fe_->more() )  goto redo;

    return 0;  // return from top level emu_call
}
// -------------------------

// based on Glenn Rhoad's:
//void paren(long i, long s)
//{
//    long k, t;
//    if ( i<n )
//    {
//        for (k=0; k<=i-s;  ++k)
//        {
//            a[i-1] = k;
//            t = s + a[i-1];
//            q[t + i] = '(';
//            paren(i + 1, t);  // recursion
//            q[t + i] = ')';
//        }
//    }
//    else
//    {
//        a[i-1] = n - s;
//        Visit();  // next set of parens available
//    }
//}
////---------------------
