
#include "ntt.h"
#include "arith.h"

#include "jjassert.h"

#define MOD_FFT(x,y,z)   ntt_dit2(x,y,z)


static void
check_two_invertible()
{
    jjassert2( mod::modulus & 1,
               "need odd modulus to do length 2**ldn convolution" );
}
// -------------------------


void
ntt_auto_convolution(mod *f, ulong ldn)
//
// _cyclic_ (self-)convolution
// (use zero padded data for usual co.)
//
{
    check_two_invertible();

    int is = +1;

    MOD_FFT(f, ldn, is);

    const ulong n = (1<<ldn);
    for (ulong i=0; i<n; ++i)  f[i] *= f[i];

    MOD_FFT(f, ldn, -is);

    multiply_val(f, n, inv(n));
}
// -------------------------


void
ntt_convolution(mod *f, mod *g, ulong ldn)
//
// _cyclic_ convolution
// (use zero padded data for usual conv.)
//
// result in g[]
{
    check_two_invertible();

    jjassert( f!=g );

    int is=+1;

    MOD_FFT(f, ldn, is);
    MOD_FFT(g, ldn, is);

    const ulong n = (1<<ldn);
    for (ulong i=0; i<n; ++i)  g[i] *= f[i];

    MOD_FFT(g, ldn, -is);

    multiply_val(g, n, inv(n));
}
// -------------------------



// this is for the interface of fxtmult/hfloat:

void
ntt_convolution(double *f, double *g, ulong ldn)
{
    ntt_convolution((mod *)f, (mod *)g, ldn);
}
// -------------------------

void
ntt_auto_convolution(double *f, ulong ldn)
{
    ntt_auto_convolution((mod *)f, ldn);
}
// -------------------------
