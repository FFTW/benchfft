#if !defined HAVE_NTT_H__
#define      HAVE_NTT_H__


#include "fxttypes.h"
#include "mod.h"


// jjmagictag

// mod/nttdit4.cc:
void ntt_dit4(mod *f, ulong ldn, int is);

// mod/nttdif4.cc:
void ntt_dif4(mod *f, ulong ldn, int is);


// mod/nttdit2.cc:
void ntt_dit2(mod *f, ulong ldn, int is);

// mod/nttdif2.cc:
void ntt_dif2(mod *f, ulong ldn, int is);

// mod/nttdif2nc.cc:
void ntt_dif2_noncyclic(mod *f, ulong ldn, int is);

// mod/nttcnvl.cc:
void ntt_auto_convolution(mod *f, ulong ldn);
void ntt_convolution(mod *f, mod *g, ulong ldn);
void ntt_convolution(double *f, double *g, ulong ldn);
void ntt_auto_convolution(double *f, ulong ldn);

// mod/slownttcnvl.cc:
void slow_mod_convolution(mod *f, mod *g, ulong n);
void slow_mod_convolution(double *f, double *g, ulong n);


// mod/nttskip.cc:
void skip_ntt(mod *f, ulong n, ulong d, mod *w, int is);
void skip_ntt0(mod *f, ulong n, ulong d, mod *w, int is);

// mod/nttndim.cc:
void ntt_ndim(mod *f, ulong ndim, ulong *ldn, int is);


// mod/nttlearn.cc:
void ntt_dit2l(mod *f, ulong ldn, int is);
void ntt_dif2l(mod *f, ulong ldn, int is);


// mod/slowntt.cc:  (brute force (slow) mod ft)
void slow_ntt(mod *f, ulong n, int is);


// jjmagictag

// jj_end_autodoc


#endif // !defined HAVE_NTT_H__
