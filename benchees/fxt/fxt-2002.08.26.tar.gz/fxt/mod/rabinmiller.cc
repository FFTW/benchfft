
#include <cmath>

#include "primes.h"
#include "mtypes.h"
#include "modm.h"
#include "jjassert.h"


void
n2qt(const umod_t n, umod_t &q, int &t)
// set q,t so that  n-1 == q * 2^t
{
    q = n - 1;
    t = 0;

    while ( 0==(q & 1) )
    {
        q >>= 1;
        t++;
    }
}
// -------------------------


int
rabin_miller_pass(const umod_t n, const umod_t a, const umod_t q, const int t)
//
// test whether n is a strong pseudo prime for base a
// return 1 =--> passed
//
// q,t must be set that  n == q * 2^t + 1
{
    umod_t b = pow_mod(a, q, n);

    if ( 1==b )  return 1;  // passed
//    if ( n-1==b )  return -1;  // passed

    // squarings:
    int e = 1;
    while ( (b!=1) && (b!=(n-1)) && (e<t) )
    {
        b = mul_mod(b, b, n);
        e++;
    }

    if ( b!=(n-1) )  return 0;  // =--> COMPOSITE

    return  -e;  // ==-1...-t  (!=0)  passed
}
// -------------------------


int
is_pseudo_prime(umod_t n, uint cm/*=0*/)
//
// Rabin Miller test
// return 1 if n is (with probability (1/4)^cm) prime
// cf. Cohen p.414
//
{
    if ( n<65000 )  // eliminate tiny n
    {
        return  is_small_prime( (ulong)n );
    }

    // initialize q,t so that  n == q * 2^t + 1
    umod_t q;
    int t;
    n2qt(n, q, t);

    if ( cm==0 )  cm = 20;  // default

    uint c = 0;
    while ( c<cm )
    {
        // choose new a:
        umod_t a = prime(c);
        jjassert2( (a!=0), "is_prime(): need more primes ! " );

//        if ( a >= n )  return 1;

        if ( !rabin_miller_pass(n, a, q, t) )  return 0;  // =--> COMPOSITE

        c++;
    }

    return 1;  // strong pseudo prime
}
// -------------------------
