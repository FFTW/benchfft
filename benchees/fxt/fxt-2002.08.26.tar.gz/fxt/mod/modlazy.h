#if !defined HAVE_MODLAZY_H__
#define      HAVE_MODLAZY_H__


// include file for the lazy

#include "mtypes.h"

#include "mod.h"
#include "ntt.h"
#include "primes.h"
#include "factor.h"
#include "testnum.h"

#include "modarith.h"
#include "modm.h"
#include "moduli.h"


#endif // !defined HAVE_MODLAZY_H__
