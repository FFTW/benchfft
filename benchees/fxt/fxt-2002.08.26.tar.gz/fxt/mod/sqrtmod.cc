
#include "mod.h"
#include "modm.h"
#include "jjassert.h"
#include "factor.h"
#include "primes.h" // n2qt()


static inline int is_quadratic_residue_2ex(umod_t a, ulong x)
//
// whether a is quadratic residue mod 2**x
//
{
    if ( x==1 )  return 1;
    if ( (x>=3 ) && (1==(a&7)) )  return 1;
    if ( (x==2 ) && (1==(a&3)) )  return 1;

    return 0;
}
// -------------------------


umod_t
sqrt_modp(umod_t a, umod_t p)
//
// p an odd prime
// if a is not a quadratic residue mod p return 0
// else return x so that x*x==a (mod p)
// cf. Cohen p.33
//
{
    if ( 1!=kronecker(a,p) )  return 0;  // not a quadratic residue

    // initialize q,t so that  p == q * 2^t + 1
    umod_t q;
    int t;
    n2qt(p, q, t);

    // find generator:
    umod_t z = 0;
    umod_t n = 0;
    for (n=1; n<p; ++n)
    {
        if ( -1==kronecker(n, p) )
        {
            z = pow_mod(n, q, p);
            break;
        }
    }
    jjassert2( n<p, " sqrt_modp(): no generator found ! " );

    // (generator found)

    // initialize:
    umod_t y = z;
    uint r = t;
    umod_t x = pow_mod(a, (q-1)/2, p);
    umod_t b;
    b = mul_mod(a, x, p);
    b = mul_mod(b, x, p);
    x = mul_mod(x, a, p);


    // step3:
    do
    {
        // find exponent:
//        jjassert( mul_mod(a, b, p)==mul_mod(x, x, p) );
//        jjassert( r>0 );
//        jjassert( pow_mod(y, 1ULL<<(r-1), p)==p-1 );
//        jjassert( pow_mod(b, 1ULL<<(r-1), p)==1ULL );

        if ( 1==b )  return x;

        uint m;
        for (m=1; m<r; ++m)
        {
            if ( 1==pow_mod(b, 1ULL<<m, p) )  break;
        }

        if ( m==r )  return  0;  // a is not a quadratic residue mod p

        // reduce exponent:
        umod_t v = pow_mod(y, 1ULL<<(r-m-1), p);
        y = mul_mod(v, v, p);
        r = m;
        x = mul_mod(x, v, p);
        b = mul_mod(b, y, p);
    }
    while ( 1 );
}
// -------------------------


umod_t
sqrt_modpp(umod_t a, umod_t p, long ex)
//
// return r with r^2 == a (mod p^ex)
//
{
    umod_t z = a % p;
    umod_t r;

    if ( 2==p )
    {
        if ( 0==is_quadratic_residue_2ex(a, ex) )  return  0;
        else  r = 1;
    }
    else
    {
        r = sqrt_modp(z, p);
        if ( r==0 )  return  0;  // no sqrt exists
    }
    // here r^2 == a (mod p)

    if ( 1==ex )  return  r;


    umod_t m = ipow(p, ex);
    if ( 2==p )
    {
        long x = 1;
        while ( x<ex )  // newton iteration for inverse sqrt, 2adic case
        {
            x *= 2;
            // z = (3 - a * r * r);
            umod_t z = a;
            z = mul_mod(z, r, m);
            z = mul_mod(z, r, m);
            z = sub_mod(3, z, m);

            // r *=  z / 2;
            r = mul_mod(r, z/2, m);
        }
        r = mul_mod(r, a, m);
    }
    else
    {
        umod_t h = inv_modpp(2, p, ex);
        long x = 1;
        while ( x<ex )  // newton iteration
        {
            x *= 2;

            umod_t ri = inv_modpp(r, p, ex);    // 1/r
//            umod_t ri = inv_mod(r, m);          // 1/r

            umod_t ar = mul_mod(a, ri, m);      // a/r
            r = add_mod(r, ar, m);              // r+a/r
            r = mul_mod(r, h, m);               // (r+a/r)/2
        }
    }
    return  r;
}
// -------------------------


umod_t
sqrt_modf(umod_t a, const factorization &mf)
{
//    jjassert( is_quadratic_residue(a,mf) );

    umod_t x[ mf.nprimes() ];  // residues mod p_i go here

    for (int i=0; i<mf.nprimes(); ++i)
    {
        x[i] = sqrt_modpp( a, mf.prime(i), mf.exponent(i) );

        if ( x[i]==0 )  return 0;  // no sqrt exists
    }

    return  chinese(x, mf);
}
// -------------------------



int
is_quadratic_residue(const factorization &af, umod_t m)
//
// whether af is quadratic residue mod m
//
// use (a*b/c) == (a/c) * (b/c)
//
{
    int k = 1;

    for (int i=0; i<af.nprimes(); ++i)
    {
        int s = kronecker(af.prime(i), m);
        if ( 1 & (af.exponent(i)) )  s = -s;
        k *= s;
    }

    return k;
}
// -------------------------



int
is_quadratic_residue(umod_t a, const factorization &mf)
//
// whether a is quadratic residue mod mf
//
{
    for (int i=0; i<mf.nprimes(); ++i)
    {
        umod_t p = mf.prime(i);
        if ( 2==p )
        {
            ulong x = mf.exponent(i);
            return  is_quadratic_residue_2ex(a, x);
        }

        if ( 1!=kronecker(a, p) )  return 0;
    }

    return 1;
}
// -------------------------
