
#include "fxtio.h"
#include <cmath>

#include "mod.h"
#include "modm.h"
#include "newop.h"
#include "jjassert.h"


#define  INIT_DEBUG  0  // 0 (default) or 1 (for debug)
#if  ( INIT_DEBUG==1 )
#warning 'FYI:  INIT_DEBUG == 1'
#endif


uint count_bits(uint64 m)
{
    uint k = 0;
    while ( m )  { k++; m>>=1; }
    return k;
}
// -------------------------



mod_init::~mod_init()
{
    delete [] mod::root_2pow;

    mod::minus1 = 0;
    mod::m1dd = 0.0;
    mod::modfact.init();

    mod::mbitsd = 0.0;
    mod::mbits = 0;

    mod::maxorder = 0;
    mod::xfact.init();
    mod::max2pow = 0;

    mod::phi = 0;
    mod::phifact.init();

    mod::maxordelem.x_ = 0;
    mod::invmaxordelem.x_ = 0;
    mod::zero.x_ = 0;
    mod::one.x_ = 0;
    mod::two.x_ = 0;
    mod::half.x_ = 0;
    mod::minus_one.x_ = 0;

    mod::root_2pow = 0;
    mod::root_m2pow = 0;
}
// -------------------------


mod_init::mod_init(umod_t m, umod_t *primes/*=0*/)
{
    mod::modulus = m;
    mod::m1dd = (ldouble)1/(ldouble)m;

#if  ( INIT_DEBUG==1 )
    mod_info0();
#endif

#if  ( !USE_64BIT_MODULUS )
    jjassert2( !(m&((umod_t)1<<63)) ,
               " modulus must have less than 64 bits " );
#endif

#if  ( USE_LEQ_62BIT_MODULUS )
    jjassert2( !(m&((umod_t)3<<62)),
               " modulus must have less than 62 bits " );
#endif

    // +++++ only after this point we can multiply mods !
#if  ( INIT_DEBUG==1 )
    cout << "MOD_INIT(): can multiply mods" << endl;
#endif

    mod::minus1 = m-1;

    mod::zero = (uint)0;
    mod::one =  (uint)1;
    if ( m>2 ) mod::two = (uint)2;
    else       mod::two = (uint)0;
    mod::minus_one = m-1;

    umod_t mb = count_bits(m);
    mod::mbits = mb;
    double mbd = log((double)m)/log(2.0);
    if ( (umod_t(1)<<(mb-1))==m )  mbd = mb;
    mod::mbitsd = mbd;

    mod::modfact.make_factorization(m,primes);

    jjassert2( mod::modfact.is_factorization_of(m),
               "factorization of the modulus failed" );


    // +++++ have modulus, modfact
#if  ( INIT_DEBUG==1 )
    cout << "MOD_INIT(): have modulus, modfact" << endl;
    mod_info1();
#endif


    if ( mod::modfact.is_prime() )
    {
        mod::phi = m-1;
    }
    else
    {
        mod::phi = phi(mod::modfact);
    }

    mod::phifact.make_factorization(mod::phi);
    jjassert2( mod::phifact.is_factorization_of(mod::phi),
               "factorization of phi failed" );


    // +++++ have phi, phifact
#if  ( INIT_DEBUG==1 )
    cout << "MOD_INIT(): have phi, phifact" << endl;
#endif

    mod::maxorder = maxorder_mod(mod::modfact);

    mod::xfact.make_factorization(mod::maxorder);
    jjassert2( mod::xfact.is_factorization_of(mod::maxorder),
               "factorization of the maximal order failed");


    // +++++ have maxorder, xfact
#if  ( INIT_DEBUG==1 )
    cout << "MOD_INIT(): have maxorder, xfact" << endl;
    mod_info2();
#endif


    mod::maxordelem = maxorder_element_mod(mod::modfact, mod::phifact);

    umod_t rr = order(mod::maxordelem);
    jjassert2( rr != 0, "oops, order of primitive root is ==0" );
    jjassert2( rr == mod::maxorder,
               "oops, order of primitive root is != maxorder" );

    mod::invmaxordelem = inv(mod::maxordelem);
    jjassert2( (mod::maxordelem * mod::invmaxordelem)==mod::one,
               "oops, inverse(primroot)*primroot is != 1" );


    // +++++ have element of maximal order (primitive root if m cyclic)
#if  ( INIT_DEBUG==1 )
    cout << "MOD_INIT(): have element of maximal order" << endl;
    mod_info3();
#endif


//    cout << "XFACT: " << mod::xfact << endl;
    mod::max2pow = mod::xfact.exponent_of(2);
    umod_t z = mod::maxorder / pow2( mod::max2pow );
    mod t = pow(mod::maxordelem, z);
    mod ti = pow(mod::invmaxordelem, z);

    int m2 = mod::max2pow;

    {
        const ulong nn = (m2+1);
        mod *p = NEWOP(mod, 6*nn);

        mod::root_2pow = p;
        mod::root_m2pow = p + 1*nn;
        mod::cos = p + 2*nn;
        mod::isin = p + 3*nn;
        mod::cosm = p + 4*nn;
        mod::isinm = p + 5*nn;
    }


    // set up roots of order 2**+-k:
    mod::root_2pow[m2] = t;
    mod::root_m2pow[m2] = ti;
    for (int k=m2-1; k>=0; --k)
    {
        t = mod::root_2pow[k+1];
        t *= t;
        mod::root_2pow[k] = t;

        ti = mod::root_m2pow[k+1];
        ti *= ti;
        mod::root_m2pow[k] = ti;
    }

    if ( mod::modulus % 2 )  mod::half = inv(2);


    // set up sin/cos of order 2**+-k:
    for (int k=0; k<=m2; ++k)
    {
        mod tr = mod::root_2pow[k];
        mod ti = mod::root_m2pow[k];
        mod tc;

        tc = (tr * tr + 1) / ti * mod::half;
        mod::cos[k] = tc;  mod::isin[k] = tr - tc;

        tc = (ti * ti + 1) / tr * mod::half;
        mod::cosm[k] = tc;  mod::isinm[k] = tr - tc;
    }

//    for (int k=0; k<=m2; ++k)
//    {
//        mod tc = mod::cos[k], ts = mod::isin[k];
//        jjassert( mod::one == tc*tc +
//    }

    // +++++ from now on we can do ffts ...
#if  ( INIT_DEBUG==1 )
    cout << "MOD_INIT(): can do ffts" << endl;
    mod_info4();
#endif

    for (int k=0; k<=m2; ++k)
    {
        umod_t r, p2k = pow2((uint)k);

        r = order(mod::root2pow(k));
        jjassert2( r==p2k, "order(root_2pow(k)) is != 2**k" );

        r = order(mod::root2pow(-k));
        jjassert2( r==p2k, "order(root2pow(-k)) is != 2**k" );

        mod t = (mod::root2pow(k))*(mod::root2pow(-k));
        jjassert2( t==mod::one,  "root2pow(k) * root2pow(-k) is != 1" );
    }


//    // ------- montgomery section:
//    ulong mb = 8*sizeof( umod_t );
//    mod::mg_bits = mb;
//    if ( vb )  cout << " mod_initialiser: mg_bits=" << mod::mg_bits << endl;
//
//    umod_t mm = 0;
//    for (ulong k=0; k<mb; ++k)
//    {
//        mm <<= 1;
//        mm += 1;
//    }
//
//    mod::mg_mask = mm;
//    if ( vb )  cout << " mod_initialiser: mg_mask=" << mod::mg_mask << endl;
//
//    umod_t mr = montgomery_r(mb,m);
//    mod::mg_r = mr;
//    if ( vb )  cout << " mod_initialiser: mg_r=" << mod::mg_r << endl;
//
//    umod_t mrp = montgomery_r_prime(mb,m);
//    mod::mg_r_prime = mrp;
//    if ( vb )  cout << " mod_initialiser: mg_r_prime=" << mod::mg_r_prime << endl;
//    jjassert( mod((umod_t)1)==mod(mr)*mod(mrp) );
//
//    umod_t mmp = montgomery_m_prime(mb,m,mm);
//    mod::mg_m_prime = mmp;
//    if ( vb )  cout << " mod_initialiser: mg_m_prime=" << mod::mg_m_prime << endl;


#if  ( INIT_DEBUG==1 )
    mod_info99();
#endif
}
// -------------------------
