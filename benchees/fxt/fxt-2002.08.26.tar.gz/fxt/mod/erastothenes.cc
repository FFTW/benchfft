
#include "mtypes.h"
#include "jjassert.h"
#include "newop.h"
//#include "bitarray.h"

//#include <cmath>


uint
erastothenes(uint *&ptab, uint m)
{
    uint i,k;
    char p[m];

    for (i=0; i<m; ++i)  p[i]=0;

    uint ct = 0;
    for (i=2; i<m; ++i)
    {
        if ( 0==p[i] )
        {
            ct++;
            for (k=i*i; k<m; k+=i)  p[k] = 1;
        }
    }

    if ( ptab )  delete [] ptab;
    ptab = NEWOP(uint, ct+1);
    ptab[ct] = 0;

    k = 0;
    for (i=2; i<m; ++i)
    {
        if ( 0==p[i] )
        {
            ptab[k] = i;
            k++;
        }
    }
    jjassert( k==ct );

    return ct;
}
// -------------------------
