
#include "mtypes.h"
#include "factor.h"
#include "intarith.h"  // ipow()
#include "primes.h"
#include "modm.h"
#include "newop.h"
#include "jjassert.h"

#include "fxtio.h"

#include <cmath>


#define  FACT_DEBUG  0  // 0 or 1 (for debug)
#if  ( FACT_DEBUG==1 )
#warning 'FYI:  FACT_DEBUG == 1'
#endif

const int factorization::maxprimes = 30;
// worst case: 2*3*5*7*11*...
// 16 primes are enough for 64 bit
// 27 primes are enough for 128 bit

void
factorization::ctor_core()
{
    prime_ = NEWOP(umod_t, maxprimes+1);
    expon_ = NEWOP(long, maxprimes+1);
    fact_ = NEWOP(umod_t, maxprimes+1);
    init();
}
// -------------------------


factorization::factorization()
    : prime_(0), expon_(0), npr_(0), fact_(0), prod_(0)
{
    ctor_core();
}
// -------------------------


factorization::factorization(umod_t n)
    : prime_(0), expon_(0), npr_(0), fact_(0), prod_(0)
{
    ctor_core();
    make_factorization(n);
    sort();
}
// -------------------------


factorization::factorization(umod_t n, umod_t *f)
    : prime_(0), expon_(0), npr_(0), fact_(0), prod_(0)
//
// initialize from zero-terminated (complete!)
// list of factors of n
// setup exponents
//
{
    ctor_core();
    make_factorization(n,f);
    sort();
}
// -------------------------


factorization::~factorization()
{
    delete [] prime_;
    delete [] expon_;
    delete [] fact_;
}
// -------------------------


void
factorization::init()
{
    for (int k=0; k<maxprimes; k++)  prime_[k] = expon_[k] = fact_[k] = 0;
    npr_ = 0;
    prod_ = 0;
}
// -------------------------


void
factorization::make_factorization(umod_t n, umod_t *f)
{
//    cout << "MAKE_FACTORIZATION(): \n";
//    cout << " n=" << n << endl;
//    if  ( f ) for (int i=0; f[i]!=0; ++i)  cout << " f[" << i << "]=" << f[i] << endl;

    if ( 0==f )
    {
        make_factorization(n);
        return;
    }

    init();
    prod_ = n;

    uint k = 0;
    while ( 1 )
    {
        umod_t v = f[k];
//        cout << "\n n=" << n << "  v=" << v;  cout.flush();

        long ex = divide_out_factor(n,v);
//        cout << "  --> ex=" << ex << "  n=" << n << endl;
        if ( 0==ex )
        {
            cerr << " n=" << n << "  v=" << v << endl;
            cerr << " v does not divide n " << endl;
            jjassert2( 0, "got false factor v for n" );
        }

        prime_[k] = v;
        expon_[k] = ex;
        fact_[k] = ipow(v, ex);
        k++;

        if ( 1==n )  break;
    }

    npr_ = k;

    jjassert( 1==n );

#if  ( FACT_DEBUG==1 )
    check();
#endif
//    print("MAKE_FACTORIZATION(n,f): \n");
}
// -------------------------

void
factorization::make_factorization(umod_t n)
{
    init();
    prod_ = n;

    if ( ::is_pseudo_prime(n,100) )
    {
        prime_[0] = n;
        expon_[0] = 1;
        fact_[0] = n;
        npr_ = 1;
        return;
    }

    umod_t maxv = (umod_t)( sqrt((double)n) + 1 );
    umod_t v;
    long ex;
    uint kp = 0;
    uint k = 0;
    while ( 1 )
    {
        v = ::prime(kp);
        if ( 0==v )  break;
        if ( maxv<v )  break;
        kp++;

        ex = divide_out_factor(n, v);

        if ( ex )
        {
            prime_[k] = v;
            expon_[k] = ex;
            fact_[k] = ipow(v, ex);
            k++;

            maxv = (umod_t)(sqrt((double)n)+1);
        }
    }

    long pw = 1;
    if ( n>((umod_t)1<<31) )  // check whether n is a perfect square
    {
        umod_t w = int_sqrt(n);
        if ( w*w==n )
        {
            n = w;
            pw = 2;
            maxv = (umod_t)(sqrt((double)n)+1);
        }
    }

    v = ::prime(kp-1) + 2;
    for ( ; v<=maxv; v+=2)
    {
        ex = divide_out_factor(n, v);

        if ( ex )
        {
            ex *= pw;
            prime_[k] = v;
            expon_[k] = ex;
            fact_[k] = ipow(v,ex);
            k++;

            maxv = (umod_t)(sqrt((double)n)+1);
        }
    }

    if ( n!=1 )
    {
        prime_[k] = n;
        expon_[k] = pw;
        fact_[k] = n;
        k++;
    }

    npr_ = k;

#if  ( FACT_DEBUG==1 )
    check();
#endif
//    print("MAKE_FACTORIZATION(n): \n");
}
// -------------------------


void
factorization::sort()
{
    static umod_t pr[maxprimes+1];
    static long   ex[maxprimes+1];
    static umod_t fc[maxprimes+1];

    for (int i=0; i<npr_; ++i)
    {
        pr[i] = prime_[i];
        ex[i] = expon_[i];
        fc[i] = fact_[i];
        prime_[i] = 0;
        expon_[i] = 0;
        fact_[i] = 0;
    }


    for (int i=0; i<npr_; ++i)
    {
        umod_t mi = (umod_t)(~0);
        int f = 0;
        for (int j=0; j<npr_; ++j)
        {
            if ( pr[j]<mi )
            {
                mi = pr[j];
                f = j;
            }
        }

        prime_[i] = pr[f];
        expon_[i] = ex[f];
        fact_[i] = fc[f];
        pr[f] = (umod_t)(~0);
    }

#if  ( FACT_DEBUG==1 )
    check();
#endif
}
// -------------------------


long
factorization::exponent_of(umod_t p) const
// return exponent of prime p in factorization
{
    for (int i=0; i<npr_; ++i)  if ( p==prime_[i] )  return expon_[i];
    return 0;
}
// -------------------------


void
factorization::print(const char *bla, ostream &os) const
{
    if ( bla )  os << bla;

    int k;
    for (k=0; k<npr_-1; ++k)
    {
        os << prime_[k] ;
        if ( expon_[k]>1 )  os << "^" << expon_[k];
        os << " * ";
    }

    if ( npr_>0 )
    {
        os << prime_[k] ;
        if ( expon_[k]>1 )  os << "^" << expon_[k];
    }

//    os << "  (npr=" << npr_ <<")";
//    os << endl;
}
// -------------------------


//istream&  operator >> (istream& is, factorization& h);
//{ is >> ; return is; }


ostream&  operator << (ostream& os, const factorization& h)
{
    h.print(0,os);
    return os;
}
// -------------------------


void
factorization::check()
{
    umod_t m = 1;
    for (int i=0; i<npr_; ++i)
    {
//        cout << "fact[" << i << "] = " << prime_[i] << endl;
        jjassert( ::is_pseudo_prime(prime_[i], 100) );
        m *= factor(i);
    }

    jjassert( m == product() );
}
// -------------------------


// auxiliary functions:

umod_t
is_factor(umod_t n, umod_t f)
//
// if f divides n  return n/f
// else            return 0
//
{
    umod_t q = n/f;

    if ( q*f==n )  return q;
    else           return 0;
}
// -------------------------

long
divide_out_factor(umod_t &n, umod_t v)
//
// while v divides  n
//   divide n by v
// return how often divided
//
{
    umod_t q = is_factor(n,v);

    if ( q==0 )  return 0;
    else
    {
        long ex = 0;
        do
        {
            n = q;
            ex++;

            q = is_factor(n,v);
        }
        while ( q!=0 );

        return ex;
    }
}
// -------------------------


umod_t
int_sqrt(umod_t d)
// cf. Cohen p.38
{
    umod_t x = (umod_t)ceil(sqrt((double)d));
    umod_t y = (x + d/x)/2;
    while ( y<x )
    {
        x = y;
        y = (x + d/x)/2;
    }

//    cout << "int_sqrt():  d=" << d << "  x=" << x << endl;
    return x;
}
// -------------------------
