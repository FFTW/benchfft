#if !defined HAVE_PRIMES_H__
#define      HAVE_PRIMES_H__

#include "mtypes.h"
#include "bitarray.h"


// mod/primes.cc:
uint prime(uint n);
int  is_small_prime(uint n);
int  is_small_prime(const bitarray *ba, uint n);
uint  next_small_prime(const bitarray *ba, uint n);
bitarray *make_oddprime_bitarray(ulong n);


// mod/erastothenes.cc:
uint erastothenes(uint *&ptab, uint m);


// mod/rabinmiller.cc:
void n2qt(const umod_t n, umod_t &q, int &t);
int rabin_miller_pass(const umod_t n, const umod_t a, const umod_t q, const int t);
int is_pseudo_prime(umod_t n, uint cm=0);


#endif  // !defined HAVE_PRIMES_H__
