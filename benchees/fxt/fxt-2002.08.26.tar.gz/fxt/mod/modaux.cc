
#include <cmath>
#include "fxtio.h"
#include <cstdlib>  // rand()

#include "mod.h"
#include "modm.h"
#include "jjassert.h"


void
rand(mod *f, ulong n, umod_t m)
{
    for (ulong i=0; i<n; ++i)
    {
        umod_t t = (umod_t)((double)(m-1)*rand()/(RAND_MAX+1.0));
//        jjassert( t<m );
        f[i] = t;
    }
}
// -------------------------

