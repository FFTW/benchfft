
#include "fxt.h"
#include "fhtmulsqr.h"
#include "restrict.h"



void
fht_negacyclic_convolution(double * restrict f, double * restrict g,
                           ulong ldn)
// (negacyclic, real) convolution
// ldn := base-2 logarithm of the array length
{
    const ulong n = (1<<ldn);

    hartley_shift_05(f, n);
    fht(f, ldn);
    hartley_shift_05(g, n);
    fht(g, ldn);

    fht_negacyclic_convolution_core(f, g, ldn);

    fht(g, ldn);
    hartley_shift_05(g, n);
}
// -------------------------


void
fht_negacyclic_convolution_core(const double * restrict f, double * restrict g,
                                ulong ldn,
                                double v/*=0.0*/) // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
// n = 2**ldn  must be >=2
{
    const ulong n = (1<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    v *= 0.5;
    for (ulong i=0,j=n-1; i<j; i++,j--)
    {
        fht_mul(f[i], f[j], g[i], g[j], v);
    }
}
// -------------------------
