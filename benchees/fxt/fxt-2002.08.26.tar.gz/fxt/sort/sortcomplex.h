#if !defined HAVE_SORTCOMPLEX_H__
#define      HAVE_SORTCOMPLEX_H__


#include "fxttypes.h"
#include "complextype.h"

// sort/sortcomplex.cc:
void complex_sort(Complex *f, ulong n);
int is_complex_sorted(Complex *f, ulong n);

ulong bsearch_complex(const Complex *f, ulong n, Complex v);


#endif // !defined HAVE_SORTCOMPLEX_H__
