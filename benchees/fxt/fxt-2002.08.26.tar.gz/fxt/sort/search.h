#if !defined HAVE_SEARCH_H__
#define      HAVE_SEARCH_H__


#include "fxttypes.h"


template <typename Type>
ulong bsearch(const Type *f, ulong n, Type v)
//
// return index of first element in f[] that is == v
// return ~0 if there is no such element
// f[] must be sorted in ascending order
//
{
    ulong nlo=0, nhi=n-1;
    while ( nlo != nhi )
    {
        ulong t = (nhi+nlo)/2;

        if ( f[t] < v )  nlo = t + 1;
        else             nhi = t;
    }

    if ( f[nhi]==v )  return nhi;
    else              return ~0UL;
}
// -------------------------


template <typename Type>
ulong bsearch_ge(const Type *f, ulong n, Type v)
//
// return index of first element in f[] that is >= v
// return ~0 if there is no such element
// f[] must be sorted in ascending order
//
{
    ulong nlo=0, nhi=n-1;
    while ( nlo != nhi )
    {
        ulong t = (nhi+nlo)/2;

        if ( f[t] < v )  nlo = t + 1;
        else             nhi = t;
    }

    if ( f[nhi]>=v )  return nhi;
    else              return ~0UL;
}
// -------------------------


template <typename Type>
ulong bsearch_approx(const Type *f, ulong n, Type v, Type da)
//
// return index of first element x in f[] for which  |(x-v)| <= a
// return ~0 if there is no such element
// f[] must be sorted in ascending order
// da must be positive
// makes sense only with inexact types (float or double)
//
{
    ulong i = bsearch_ge(f, n, v);
    if ( ~0UL==i )  return i;
    else
    {
        Type d;
        d = ( f[i] > v ? f[i]-v : v-f[i]);
        if ( d <= da )  return i;

        if ( i>0 )
        {
            --i;
            d = ( f[i] > v ? f[i]-v : v-f[i]);
            if ( d <= da )  return i;
        }
    }

    return ~0UL;
}
// -------------------------


template <typename Type>
inline long search_down(const Type *f, Type v, ulong &i)
// search v in f[], starting at i (so i must be < length)
// f[i] must be greater or equal v
// f[] must be sorted in ascending order
// returns index k if f[k]==v or ~0 if no such k is found
// i is updated so that it can be used for a following
// search for an element u where u < v
{
    while ( (f[i]>v) && (i>0) )  --i;

    if ( f[i]==v )  return i;
    else            return ~0UL;
}
// -------------------------



#endif // !defined HAVE_SEARCH_H__
