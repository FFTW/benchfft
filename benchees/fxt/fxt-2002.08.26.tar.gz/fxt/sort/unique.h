#if !defined HAVE_UNIQUE_H__
#define      HAVE_UNIQUE_H__

#include "fxttypes.h"


template  <typename Type>
int test_unique(const Type *f, ulong n)
// for a sorted array test whether all values are unique
//   (i.e. whether no value is repeated)
//
// returns 0 if all values are unique
// else returns index of the second element in the first pair found
//
// with inexact (i.e. float or double) types you
//   may want to prepare f[] by calling quantise(f, n)
//   before using test_unique();
//
// this function is not called "is_unique()" because it
// returns 0 (=="false") for a positive answer
{
    for (ulong k=1; k<n; ++k)
    {
        if ( f[k] == f[k-1] )  return  k;  // k != 0
    }

    return  0;
}
// -------------------------


template  <typename Type>
int test_unique_approx(const Type *f, ulong n, Type da)
// for a sorted array test whether all values are
// unique within some tolerance
//   (i.e. whether no value is repeated)
//
// returns 0 if all values are unique
// else returns index of the second element in the first pair found
//
// makes mostly sense with inexact types (float or double)
{
    if ( da<=0 )  da = -da;  // want positive tolerance

    for (ulong k=1; k<n; ++k)
    {
        Type d = (f[k] - f[k-1]);
        if ( d<=0 )  d = -d;

        if ( d < da )  return k;  // k != 0
    }

    return  0;
}
// -------------------------


template  <typename Type>
int unique_count(const Type *f, ulong n)
// for a sorted array return the number of unique values
// the number of (not necessarily distinct) repeated
//   values is n - unique_count(f, n);
{
    if ( 1>=n )  return n;

    ulong ct = 1;
    for (ulong k=1; k<n; ++k)
    {
        if ( f[k] != f[k-1] )  ++ct;
    }

    return  ct;
}
// -------------------------


template  <typename Type>
ulong unique(Type *f, ulong n)
// for a sorted array squeeze all repeated values
// and return the number of unique values
// e.g.:  [1, 3, 3, 4, 5, 8, 8] --> [1, 3, 4, 5, 8]
// the routine also works for unsorted arrays as long
//   as identical elements only appear in contiguous blocks
//   e.g. [4, 4, 3, 7, 7] --> [4, 3, 7]
// the order is preserved
{
    ulong u = unique_count(f, n);

    if ( u == n )  return n;  // nothing to do

    Type v = f[0];
    for (ulong j=1, k=1;  j<u;  ++j)
    {
        while ( f[k] == v )  ++k;  // search next different element

        v = f[j] = f[k];
    }

    return u;
}
// -------------------------


#endif // !defined HAVE_UNIQUE_H__
