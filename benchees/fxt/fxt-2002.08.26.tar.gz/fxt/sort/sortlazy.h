#if !defined HAVE_SORTLAZY_H__
#define      HAVE_SORTLAZY_H__

// include file for the lazy

#include "sort.h"
#include "sortidx.h"
#include "sortptr.h"
#include "sortfunc.h"
#include "sortcomplex.h"

#include "search.h"
#include "searchidx.h"
#include "searchptr.h"

#include "unique.h"
#include "monotone.h"
#include "convex.h"


#endif // !defined HAVE_SORTLAZY_H__
