#if !defined HAVE_SEARCHPTR_H__
#define      HAVE_SEARCHPTR_H__


#include "fxttypes.h"

template <typename Type>
ulong ptr_bsearch(const Type *f, ulong n, Type const*const*x, Type v)
//
// return index of ptr i to first element in f[] that is == v
// i.e. *x[i] == v, with i minimal
// return ~0 if there is no such element
// x[] must be (ptr-)sorted in ascending order:
// *x[i] <= *x[i+i]
//
{
    ulong nlo=0, nhi=n-1;
    while ( nlo != nhi )
    {
        ulong t = (nhi+nlo)/2;

        if ( *x[t] < v )  nlo = t + 1;
        else              nhi = t;
    }

    if ( *x[nhi]==v )  return nhi;
    else               return ~0UL;
}
// -------------------------


template <typename Type>
ulong ptr_bsearch_ge(const Type *f, ulong n, Type const*const*x, Type v)
//
// return index of ptr of first element in f[] that is >= v
// i.e. *x[i] >= v, with i minimal
// return ~0 if there is no such element
// x[] must be (ptr-)sorted in ascending order:
// *x[i] <= *x[i+i]
//
{
    ulong nlo=0, nhi=n-1;
    while ( nlo != nhi )
    {
        ulong t = (nhi+nlo)/2;

        if ( x[t] < v )  nlo = t + 1;
        else             nhi = t;
    }

    if ( *x[nhi]>=v )  return nhi;
    else               return ~0UL;
}
// -------------------------


#endif // !defined HAVE_SEARCHPTR_H__
