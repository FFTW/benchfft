

#include "sortfunc.h"
#include "sortcomplex.h"
#include "complextype.h"

//#define  USE_STDLIB_QSORT  // for debugging

#ifdef  USE_STDLIB_QSORT
#include <cstdlib>  // qsort()

static int
cmp_complex(const void *f, const void *g)
{
    int  ret = 0;
    Complex *fc = (Complex *)f;
    Complex *gc = (Complex *)g;
    double fr = fc->real();
    double gr = gc->real();
    if ( fr==gr )
    {
        double fi = fc->imag();
        double gi = gc->imag();
        if ( fi!=gi )  ret = (fi>gi ? +1 : -1);
    }
    else    ret = (fr>gr ? +1 : -1);

    return  ret;
}
// -------------------------

#else // USE_STDLIB_QSORT

static inline int
cmp_complex(const Complex &f, const Complex &g)
{
    int  ret = 0;
    double fr = f.real();
    double gr = g.real();
    if ( fr==gr )
    {
        double fi = f.imag();
        double gi = g.imag();
        if ( fi!=gi )  ret = (fi>gi ? +1 : -1);
    }
    else    ret = (fr>gr ? +1 : -1);

    return  ret;
}
// -------------------------
#endif // USE_STDLIB_QSORT


void
complex_sort(Complex *f, ulong n)
// major order wrt. real part
// minor order wrt. imag part
{
#ifdef  USE_STDLIB_QSORT
    qsort(f, n, sizeof(Complex), cmp_complex);
#else
    quick_sort(f, n, cmp_complex);
#endif
}
// -------------------------

int
is_complex_sorted(Complex *f, ulong n)
{
    return  is_sorted(f, n, cmp_complex);
}
// -------------------------

ulong
bsearch_complex(const Complex *f, ulong n, Complex v)
//
// return index of first element in f[] that is == v
// return ~0 if there is no such element
// f[] must be sorted in ascending (major-real, minor-imag) order
//
{
    ulong nlo=0, nhi=n-1;
    while ( nlo != nhi )
    {
        ulong t = (nhi+nlo)/2;

#ifdef  USE_STDLIB_QSORT
        if  ( cmp_complex(f+t, &v) < 0 )  nlo = t + 1;
#else
        if  ( cmp_complex(f[t], v) < 0 )  nlo = t + 1;
#endif
        else                              nhi = t;
    }

    if ( f[nhi]==v )  return nhi;
    else              return ~0UL;
}
// -------------------------

