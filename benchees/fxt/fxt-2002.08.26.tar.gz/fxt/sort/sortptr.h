#if !defined HAVE_SORTPTR_H__
#define      HAVE_SORTPTR_H__

#include "fxttypes.h"
#include "inline.h"
#include "minmax.h"

//#include "jjassert.h"

// pointer sort routines (not thoroughly tested)


template <typename Type>
void ptr_selection_sort(const Type *f, ulong n, Type **x)
{
    for (ulong i=0; i<n; ++i)
    {
        Type v = *x[i];
        ulong m = i; // position-ptr of minimum
        ulong j = n;
        while ( --j > i )  // search (index of) minimum
        {
            if ( *x[j]<v )
            {
                m = j;
                v = *x[m];
            }
        }

        swap(x[i], x[m]);
    }
}
// -------------------------


template  <typename Type>
int is_ptr_sorted(const Type *f, ulong n, Type const*const*x)
{
    if ( 0==n )  return 1;

    while ( --n )  // n-1 ... 1
    {
        if ( *x[n] < *x[n-1] )  break;
    }

    return  !n;
}
// -------------------------

template <typename Type>
Type ptr_min(const Type *f, ulong n, Type const*const*x)
// returns minimum (value) of array elements
//   {*x[0], *x[1], .. , *x[n-1]}
{
    Type v = *x[0];
    while ( n-- )
    {
        if ( *x[n]<v )
        {
            v = *x[n];
        }
    }
    return  v;
}
// -------------------------

template <typename Type>
Type ptr_max(const Type *f, ulong n, Type const*const*x)
// returns maximum (value) of array elements
//   {*x[0], *x[1], .. , *x[n-1]}
{
    Type v = *x[0];
    while ( n-- )
    {
        if ( *x[n]>v )
        {
            v = *x[n];
        }
    }
    return v;
}
// -------------------------

template  <typename Type>
int is_ptr_partitioned(const Type *f, ulong n, Type const*const*x, ulong k)
{
    ++k;
    Type lmax = ptr_max(f,   k,   x);
    Type rmin = ptr_min(f,   n-k, x+k);

    return  ( lmax<=rmin );
}
// -------------------------


template <typename Type>
ulong ptr_partition(const Type *f, ulong n, Type **x)
// rearrange index array, so that for some index p
// max(f[x[0]] ... f[x[p]]) <= min(f[x[p+1]] ... f[x[n-1]])
{
    swap( x[0], x[n/2]);
    const Type v = *x[0];

    ulong i = 0UL - 1;
    ulong j = n;
    while ( 1 )
    {
        do  ++i;
        while ( *x[i]<v );

        do  --j;
        while ( *x[j]>v );

        if ( i<j )  swap(x[i], x[j]);
        else        return j;
    }
}
// -------------------------


template <typename Type>
void ptr_quick_sort(const Type *f, ulong n, Type **x)
{
 start:
    if ( n<8 ) // parameter: threshold for nonrecursive algorithm
    {
        ptr_selection_sort(f, n, x);
        return;
    }

    ulong p = ptr_partition(f, n, x);
    ulong ln = p + 1;
    ulong rn = n - ln;

    if ( ln>rn )  // recursion for shorter subarray
    {
        ptr_quick_sort(f, rn, x+ln);  // f[x[ln]] ... f[x[n-1]]  right
        n = ln;
    }
    else
    {
        ptr_quick_sort(f, ln, x);  // f[x[0]]  ... f[x[ln-1]]  left
        n = rn;
        x += ln;
    }

    goto start;
}
// -------------------------


#endif // !defined HAVE_SORTPTR_H__
