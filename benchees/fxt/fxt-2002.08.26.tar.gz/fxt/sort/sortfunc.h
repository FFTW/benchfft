#if !defined HAVE_SORTFUNC_H__
#define      HAVE_SORTFUNC_H__

#include "fxttypes.h"
#include "inline.h"
#include "minmax.h"

//#include "jjassert.h"


template <typename Type>
void selection_sort(Type *f, ulong n, int (*cmp)(const Type &, const Type &))
{
    for (ulong i=0; i<n; ++i)
    {
        Type v = f[i];
        ulong m = i; // position of minimum
        ulong j = n;
        while ( --j > i )  // search (index of) minimum
        {
            if ( cmp(f[j],v) < 0 )
            {
                m = j;
                v = f[m];
            }
        }

        swap(f[i], f[m]);
    }
}
// -------------------------


template  <typename Type>
int is_sorted(const Type *f, ulong n, int (*cmp)(const Type &, const Type &))
{
    if ( 0==n )  return 1;

    while ( --n )  // n-1 ... 1
    {
        if ( cmp(f[n], f[n-1]) < 0 )  break;
    }

    return  !n;
}
// -------------------------

template <typename Type>
Type min(const Type *f, ulong n, int (*cmp)(const Type &, const Type &))
// returns minimum (value) of array elements
// wrt. to comparison function
{
    Type v = f[0];
    while ( n-- )
    {
        if ( cmp(f[n],v) < 0 )
        {
            v = f[n];
        }
    }
    return  v;
}
// -------------------------

template <typename Type>
Type max(const Type *f, ulong n, int (*cmp)(const Type &, const Type &))
// returns maximum (value) of array elements
// wrt. to comparison function
{
    Type v = f[0];
    while ( n-- )
    {
        if ( cmp(f[n],v) > 0 )
        {
            v = f[n];
        }
    }
    return v;
}
// -------------------------

template  <typename Type>
int is_partitioned(const Type *f, ulong n, ulong k, int (*cmp)(const Type &, const Type &))
{
    ++k;
    Type lmax = max(f,   k,   cmp);
    Type rmin = min(f+k, n-k, cmp);

    return  ( cmp(lmax, rmin) <= 0 );
}
// -------------------------


template <typename Type>
ulong partition(Type *f, ulong n, int (*cmp)(const Type &, const Type &))
// rearrange array, so that for some index p
// max(f[0] ... f[p]) <= min(f[p+1] ... f[n-1])
{
    swap( f[0], f[n/2]);
    const Type v = f[0];

    ulong i = 0UL - 1;
    ulong j = n;
    while ( 1 )
    {
        do  ++i;
        while ( cmp(f[i],v) < 0 );

        do  --j;
        while ( cmp(f[j],v) > 0 );

        if ( i<j )  swap(f[i], f[j]);
        else        return j;
    }
}
// -------------------------


template <typename Type>
void quick_sort(Type *f, ulong n, int (*cmp)(const Type &, const Type &))
{
 start:
    if ( n<8 ) // parameter: threshold for nonrecursive algorithm
    {
        selection_sort(f, n, cmp);
        return;
    }

    ulong p = partition(f, n, cmp);
    ulong ln = p + 1;
    ulong rn = n - ln;

    if ( ln>rn )  // recursion for shorter subarray
    {
        quick_sort(f+ln, rn, cmp);  // f[ln] ... f[n-1]   right
        n = ln;
    }
    else
    {
        quick_sort(f, ln, cmp);  // f[0]  ... f[ln-1]  left
        n = rn;
        f += ln;
    }

    goto start;
}
// -------------------------


#endif // !defined HAVE_SORTFUNC_H__
