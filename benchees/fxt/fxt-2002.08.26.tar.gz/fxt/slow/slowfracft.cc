
#include <cmath>

#include "copy.h"
#include "sincos.h"
#include "cmult.h"
#include "complextype.h"


void
slow_fract_ft(double *fr, double *fi, ulong n, double v)
//
// (slow) fractional fourier transform
// (for v=+-1 this is the usual fourier transform)
//
{
    double hr[n];
    double hi[n];
    const double ph0 = v * 2.0*M_PI/n;
    for (ulong w=0; w<n; ++w)
    {
        double sr=0.0, si=0.0;
        for (ulong k=0; k<n; ++k)
        {
            double c,s;
            SinCos(ph0*k*w, &s, &c);

            double r,i;
            cmult(c, s, fr[k], fi[k], r, i);

            sr += r;
            si += i;
        }
        hr[w] = sr;
        hi[w] = si;
    }
    copy(hr, fr, n);
    copy(hi, fi, n);
}
// -------------------------


void
slow_fract_ft(Complex *f, ulong n, double v)
//
// (slow) fractional fourier transform
// (for v=+-1 this is the usual fourier transform)
//
{
    Complex h[n];
    const double ph0 = v * 2.0*M_PI/n;
    for (ulong w=0; w<n; ++w)
    {
        Complex sum = 0.0;
        for (ulong k=0; k<n; ++k)
        {
            double c,s;
            SinCos(ph0*k*w, &s, &c);
            sum += f[k] * Complex(c,s);
        }
        h[w] = sum;
    }
    copy(h, f, n);
}
// -------------------------
