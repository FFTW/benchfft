#if !defined  HAVE_SLOWLAZY_H__
#define       HAVE_SLOWLAZY_H__


#include "slowcnvl.h"
#include "slowtwodimcnvl.h"
#include "slowcorr.h"


#endif  // !defined HAVE_SLOWLAZY_H__
