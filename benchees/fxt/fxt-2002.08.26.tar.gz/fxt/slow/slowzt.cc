
#include "copy.h"
#include "complextype.h"

#include <cmath> // pow()


void
slow_zt(Complex *f, ulong n, Complex z)
//
// (slow) z-transform
//
{
    Complex res[n];
    for (ulong w=0; w<n; ++w)
    {
        Complex sum = 0.0;
        Complex t = 1.0;  // == z**0
        Complex m = pow(z, w);
        for (ulong k=0; k<n; ++k)
        {
            sum += f[k] * t;  // t == pow(z, k*w);
            t *= m;
        }
        res[w] = sum;
    }
    copy(res, f, n);
}
// -------------------------


void
slow_zt(double *f, ulong n, double z)
//
// (slow) z-transform
//
{
    double res[n];
    for (ulong w=0; w<n; ++w)
    {
        double sum = 0.0;
        double t = 1.0;  // == z**0
        double m = pow(z, w);
        for (ulong k=0; k<n; ++k)
        {
            sum += f[k] * t;  // t == pow(z, k*w);
            t *= m;
        }
        res[w] = sum;
    }
    copy(res, f, n);
}
// -------------------------
