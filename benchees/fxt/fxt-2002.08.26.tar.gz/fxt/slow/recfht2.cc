
#include "fxttypes.h"
#include "copy.h"
#include "fxt.h" // hartley_shift_05()


static void
even_odd_copy(const double *a, double *ev, double *od, ulong n)
{
    for (ulong k=0,j=0; j<n; k+=2,j++)
    {
        ev[j] = a[k];
        od[j] = a[k+1];
    }
}
// -------------------------


static void
recursive_dit2_fht_core(const double *a, ulong n, double *x)
{
    if ( n==1 )  { x[0] = a[0]; return; }

    ulong nh = n/2;
    double b[nh];
    double c[nh];
    double ev[nh];
    double od[nh];

    even_odd_copy(a, ev, od, nh);
    recursive_dit2_fht_core(ev, nh, b);
    recursive_dit2_fht_core(od, nh, c);

    hartley_shift_05(c, nh);
    for (ulong k=0; k<nh; k++)
    {
        x[k]    = b[k] + c[k];
        x[k+nh] = b[k] - c[k];
    }
}
// -------------------------

void
recursive_dit2_fht(double *a, ulong ldn)
//
// very inefficient, just to demonstrate the
// recursive fast hartley transform
//
{
    ulong n = (1<<ldn);
    double x[n];
    recursive_dit2_fht_core(a, n, x);
    copy(x, a, n);
}
// -------------------------


static void
left_right_copy(const double *a, double *le, double *ri, ulong n)
{
    for (ulong j=0; j<n; j++)
    {
        le[j] = a[j];
        ri[j] = a[n+j];
    }
}
// -------------------------


static void
recursive_dif2_fht_core(const double *a, ulong n, double *x)
{
    if ( n==1 )  { x[0] = a[0]; return; }

    ulong nh = n/2;
    double b[nh];
    double c[nh];
    double le[nh];
    double ri[nh];

    left_right_copy(a, le, ri, nh);

    for (ulong k=0; k<nh; k++)
    {
        double t =   (le[k] + ri[k]);
        ri[k] =       (le[k] - ri[k]);
        le[k] = t;
    }

    hartley_shift_05(ri, nh);

    recursive_dif2_fht_core(le, nh, b);
    recursive_dif2_fht_core(ri, nh, c);

    for (ulong k=0, j=0; k<nh; k++,j+=2)
    {
        x[j]   = b[k];
        x[j+1] = c[k];
    }
}
// -------------------------

void
recursive_dif2_fht(double *a, ulong ldn)
//
// very inefficient, just to demonstrate the
// recursive fast hartley transform
//
{
    ulong n = (1<<ldn);
    double x[n];
    recursive_dif2_fht_core(a, n, x);
    copy(x,a,n);
}
// -------------------------

