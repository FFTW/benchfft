
#include "fxttypes.h"
#include "copy.h"
#include "fxt.h" // fourier_shift()

static void
even_odd_copy(const Complex *a, Complex *ev, Complex *od, ulong n)
{
    for (ulong k=0,j=0; j<n; k+=2,j++)
    {
        ev[j] = a[k];
        od[j] = a[k+1];
    }
}
// -------------------------

static void
recursive_dit2_fft_core(const Complex *a, ulong n, Complex *x, int is)
{
    if ( n==1 )  { x[0] = a[0]; return; }

    ulong nh = n/2;
    Complex b[nh];
    Complex c[nh];
    Complex ev[nh];
    Complex od[nh];

    even_odd_copy(a, ev, od, nh);
    recursive_dit2_fft_core(ev, nh, b, is);
    recursive_dit2_fft_core(od, nh, c, is);

    fourier_shift(c, nh, is*0.5);

    for (ulong k=0; k<nh; k++)
    {
        x[k]    = b[k] + c[k];
        x[k+nh] = b[k] - c[k];
    }
}
// -------------------------

void
recursive_dit2_fft(Complex *a, ulong ldn, int is)
//
// very inefficient, just to demonstrate the
// recursive fast fourier transform
//
{
    ulong n = (1<<ldn);
    Complex x[n];
    recursive_dit2_fft_core(a, n, x, is);
    copy(x, a, n);
}
// -------------------------


static void
left_right_copy(const Complex *a, Complex *le, Complex *ri, ulong n)
{
    for (ulong j=0; j<n; j++)
    {
        le[j] = a[j];
        ri[j] = a[n+j];
    }
}
// -------------------------


static void
recursive_dif2_fft_core(const Complex *a, ulong n, Complex *x, int is)
{
    if ( n==1 )  { x[0] = a[0]; return; }

    ulong nh = n/2;
    Complex b[nh];
    Complex c[nh];
    Complex le[nh];
    Complex ri[nh];

    left_right_copy(a, le, ri, nh);

    for (ulong k=0; k<nh; k++)
    {
        Complex t =   (le[k] + ri[k]);
        ri[k] =       (le[k] - ri[k]);
        le[k] = t;
    }

    fourier_shift(ri, nh, is*0.5);

    recursive_dif2_fft_core(le, nh, b, is);
    recursive_dif2_fft_core(ri, nh, c, is);

    for (ulong k=0, j=0; k<nh; k++,j+=2)
    {
        x[j] =   b[k];
        x[j+1] = c[k];
    }
}
// -------------------------

void
recursive_dif2_fft(Complex *a, ulong ldn, int is)
//
// very inefficient, just to demonstrate the
// recursive fast fourier transform
//
{
    ulong n = (1<<ldn);
    Complex x[n];

    recursive_dif2_fft_core(a, n, x, is);
    copy(x, a, n);
}
// -------------------------

