#if !defined  HAVE_SLOWTWODIMCNVL_H__
#define       HAVE_SLOWTWODIMCNVL_H__

#include "copy.h"
#include "restrict.h"


template <typename Type>
void slow_twodim_convolution(const Type *f, const Type *g,
                             Type * restrict h,
                             ulong nr, ulong nc)
//
// (cyclic) two-dimensional convolution:  h[][] :=  f[][] (*) g[][]
// nr := number of rows
// nc := number of columns
//
// (use zero padded data for linear convolution)
//
{
    long nrs = (long)nr;
    long ncs = (long)nc;
    for (long rtau=0; rtau<nrs; ++rtau)
    {
        for (long ctau=0; ctau<ncs; ++ctau)
        {
            Type s=0.0;
            for (long r=0; r<nrs; ++r)
            {
                long r2 = rtau - r;
                if ( r2<0 )  r2 += nrs;

                for (long c=0; c<ncs; ++c)
                {
                    long c2 = ctau - c;
                    if ( c2<0 )  c2 += ncs;

                    s += ( f[r*ncs+c] * g[r2*ncs+c2] );
                }
            }
            h[rtau*ncs+ctau] = s;
        }
    }
}
// -------------------------

template <typename Type>
void slow_twodim_convolution(const Type *f, Type *g, ulong nr, ulong nc)
//
// (cyclic) two-dimensional convolution:  g[][] :=  f[][] (*) g[][]
// nr := number of rows
// nc := number of columns
//
// (use zero padded data for linear convolution)
//
// f may overlap with g
//
{
    Type h[nr*nc];
    slow_twodim_convolution(f, g, h, nr, nc);
    copy(h, g, nr*nc);
}
// -------------------------


#endif  // !defined HAVE_SLOWTWODIMCNVL_H__
