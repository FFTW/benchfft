#if !defined  HAVE_SLOWCORR_H__
#define       HAVE_SLOWCORR_H__

#include "fxttypes.h"


template <typename Type>
void slow_correlation(const Type *f, const Type *g, Type *h, ulong n)
// compute (cyclic) correlation of f[], g[]
// n := array length
//
// slow_correlation(f, g, h, n)  =^=
// reverse_nh(g, n); slow_convolution(f, g, h, n); reverse_nh(g, n);
{
    long ns = (long)n;
    for (long tau=0;  tau<ns;  ++tau)
    {
        Type s = 0.0;
        for (long k=0; k<ns; ++k)
        {
             long k2 = k + tau;
             if ( k2>=ns )  k2-=ns;
             s += (g[k]*f[k2]);
        }
        h[tau] = s;
    }
}
// -------------------------


template <typename Type>
void slow_correlation0(const Type *f, const Type *g, Type *h, ulong n)
// compute (linear) correlation of f[], g[]
// n := array length
//
// version for zero padded data:
//   f[k],g[k] == 0 for k=n/2 ... n-1
//
// n must be >=2
{
    long ns = (long)n,  nh = ns/2;
    long tau;
    for (tau=0; tau<nh; ++tau)
    {
        Type s = 0.0;
        // k2 == tau + k
        for (long k=0, k2=tau;  k2<nh;  ++k,++k2)  s += (f[k]*g[k2]);
        h[tau] = s;
    }

    for (  ; tau<ns; ++tau)
    {
        Type s = 0.0;
        // k2 == tau + k
        for (long k=ns-tau, k2=0;  k<nh  ; ++k,++k2)  s += (f[k]*g[k2]);
        h[tau] = s;
    }
}
// -------------------------



template <typename Type>
void slow_auto_correlation(const Type *f, Type *g, ulong n)
// (cyclic) correlation:  g[] :=  f[] (*) g[]
// n := array length
{
    slow_correlation(f, f, g, n);
}
// -------------------------

template <typename Type>
void slow_auto_correlation0(const Type *f, Type *g, ulong n)
// (linear) self correlation:  g[] :=  f[] (*0) g[]
// n := array length
//
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n  must be >=2
{
    slow_correlation0(f, f, g, n);
}
// -------------------------


template <typename Type>
void slow_correlation(const Type *f, Type *g, ulong n)
// (cyclic) correlation:  g[] :=  f[] (*) g[]
// n := array length
{
    Type h[n];
    slow_correlation(f, g, h, n);
    copy(h, g, n);
}
// -------------------------

template <typename Type>
void slow_correlation0(const Type *f, Type *g, ulong n)
// (linear) correlation:  g[] :=  f[] (*0) g[]
// n := array length
//
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n  must be >=2
{
    Type h[n];
    slow_correlation0(f, g, h, n);
    copy(h, g, n);
}
// -------------------------


template <typename Type>
void slow_auto_correlation(Type *f, ulong n)
// (cyclic) self correlation:  f[] :=  f[] (*) f[]
// n := array length
{
    Type h[n];
    slow_correlation(f, f, h, n);
    copy(h, f, n);
}
// -------------------------

template <typename Type>
void slow_auto_correlation0(Type *f, ulong n)
// (linear) self correlation:  g[] :=  f[] (*0) g[]
// n := array length
//
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0
// n  must be >=2
{
    Type h[n];
    slow_correlation0(f, f, h, n);
    copy(h, f, n);
}
// -------------------------


#endif  // !defined HAVE_SLOWCORR_H__
