#! /usr/bin/env bash


#set -vx

# from environment:
CH="${SRC} ${FXTHDRS}"

function echo2
{
    echo $* 1>&2;
}

function chk
{
    echo2 "W=[$W]"  "H=[$H]";
#    echo2 "H=[$H]";
    W='\b'"$W"'\b';
    H='\b'"$H"'\b';
    X=$(grep -Pl $W $CH);
#    echo -e "X=[[\n$X\n]]";
#    { echo $X | grep $W; } || { echo " oops "; }
    Z=$(grep -PL $H $X);
#    echo2  'Z=[[';
    echo $Z;
#    echo2 ']]';


}


W='BITS_PER_LONG'; H='bits/bitsperlong\.h'; chk;
W='restrict'; H='(restrict)\.h'; chk;
W='ulong'; H='(fxttypes)\.h'; chk;
W='uint'; H='(fxttypes)\.h'; chk;
W='uchar'; H='(fxttypes)\.h'; chk;
#W='Complex'; H='(complextype)\.h'; chk;
W='SinCos'; H='(sincos)|(csincos)\.h'; chk;
W='(jjassert)|(jjassert2)'; H='(jjassert)\.h'; chk;
W='(sumdiff)|(sumdiff05)|(diffsum)|(sumdiff_r)'; H='(sumdiff)\.h'; chk;
W='(sqrt\()'; H='cmath'; chk;


exit 0;
####################################
