#! /usr/bin/env zsh


DEMOBIN=./bin
#RUNDEMO=$DEMOBIN
TMPDIR=/tmp
DTMP=$TMPDIR/tmp-demo-out
DEMODIR=./demo
MAKE=make


test -n "$WHICH" || WHICH=all

#set -vx

rm -f $DTMP;
find $DEMODIR -name '*-demo.cc' >  $DTMP;


# do all demos:
if [ "$WHICH" = "all" ]; then DSRC=$(<$DTMP); fi;


# do demos where included header matches the pattern PAT:
if [ "$WHICH" = "header" ]; then
    if [ -z "$PAT" ]; then echo "Empty pattern"; exit 1; fi;
    DSRC=$(grep -lE -- "\#include[ ]+.*$PAT" $DEMODIR/*/*-demo.cc);
    if [ -z "$DSRC" ]; then echo "Pattern did not match"; fi;
fi;

# do demos where the source contains the pattern PAT:
if [ "$WHICH" = "grep" ]; then
    if [ -z "$PAT" ]; then echo "Empty pattern"; exit 1; fi;
    DSRC=$(grep -i -lE -- "$PAT" $DEMODIR/*/*-demo.cc);
    if [ -z "$DSRC" ]; then echo "Pattern did not match"; fi;
fi;

# do demos whose filesnames contain the pattern PAT:
if [ "$WHICH" = "files" ]; then
    if [ -z "$PAT" ]; then echo "Empty pattern"; exit 1; fi;
    DSRC=$(grep -E -- ".*$PAT" $DTMP);
    if [ -z "$DSRC" ]; then echo "Pattern did not match"; fi;
fi;

# do demos that are newer than their output:
if [ "$WHICH" = "nt" ]; then
    DSRC='';
    for f in $(<$DTMP); do
#        OUT=$DEMODIR/$(basename $f -demo.cc)-out.txt;
        OUT=$(dirname $f)/$(basename $f -demo.cc)-out.txt;
        if test -f $OUT; then test $f -nt $OUT  ||  continue; fi;
        DSRC="$DSRC $f";
    done;
fi;


#echo "DSRC=[[$DSRC]]"; exit
if [ -z "$DSRC" ]; then
    echo "Nothing to do.  (?)";
    exit 0;
fi;


#set -vx

DSRC=$(\ls -1t ${=DSRC}); # time ordered
#echo "DSRC = [[$DSRC]]"

#exit 0;

#set -vx

for f in ${=DSRC}; do
#    OUT=$DEMODIR/$(basename $f -demo.cc)-out.txt;
    OUT=$(dirname $f)/$(basename $f -demo.cc)-out.txt;
    echo -n "$f --> $OUT";

    if test -n "$DEMO_DRY_RUN"; then
        echo ' (dry-run)';
        continue;
    fi

    $MAKE -s 1demo  DSRC=$f > $DTMP

    if test "$?" != "0"; then
        echo "OOPS !  check $DTMP";
        test -n "$DEMO_KEEP_GOING" && continue;
        ls -l $DTMP; exit 1;
    fi;

    if test -f $OUT; then #  *-out.txt already there
        if diff $DTMP $OUT &>/dev/null ; then  # output unchanged
            rm $DTMP;
        else # output did change
            echo -n "  (CHANGED)";
            cp -a $OUT $TMPDIR; ## old version --> /tmp
            mv $DTMP $OUT;
        fi
    else
        echo -n "  (NEW)";
        mv $DTMP $OUT;
    fi

    # make sure output is not older than source:
    if test $f -nt $OUT; then  touch -r $f $OUT;  fi
    echo;
done;



exit 0;
##############################

# diff:
#  An exit status of
#     0 means no differences were found,
#     1 means some differences were found, and
#     2 means trouble.
