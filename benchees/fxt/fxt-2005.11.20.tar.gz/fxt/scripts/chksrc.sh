#! /usr/bin/env bash

exit 1 ## OBSOLETE

#echo "[[$SRC]]"

Q='ok';
for f in $SRC; do
    test -f $f || { echo " *** MISSING: $f"; Q=''; };
done;

#echo "[$Q]"

#exit 5;

if test -z $Q; then exit 1; fi

exit 0;


######################


