Everything in this directory (bucket/)
is hereby officially declared nonexistent.

 ... with the exception of this file  ;-)

