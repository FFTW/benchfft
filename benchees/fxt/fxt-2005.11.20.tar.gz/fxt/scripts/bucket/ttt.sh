
mv -i aux0lazy.h   aux0-all.h
mv -i aux1lazy.h   aux1-all.h
mv -i aux2lazy.h   aux2-all.h
mv -i auxbitlazy.h bits-all.h
mv -i bpollazy.h   bpol-all.h
mv -i comblazy.h   comb-all.h
mv -i dslazy.h     ds-all.h
mv -i fxtauxlazy.h fxtaux-all.h
mv -i haarlazy.h   haar-all.h
mv -i modlazy.h    mod-all.h
mv -i permlazy.h   perm-all.h
mv -i slowlazy.h   slow-all.h
mv -i sortlazy.h   sort-all.h
mv -i walshlazy.h  walsh-all.h
