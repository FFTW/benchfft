#! /usr/bin/env zsh


# from environment: FXTSRCDIRS ALOG

#set -vx
rm -f ${ALOG}
for d in ${=FXTSRCDIRS}; do
    echo " [$d]";
    test -d $d || { echo " *** Not a directory: [$d]"; exit 1; }
    x=${d#src/}
    scripts/autodoc.zsh $d/*h > doc/$x-doc.txt 2>> ${ALOG}
done

exit 0;
