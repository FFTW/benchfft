
#include "perm/permq.h"
#include "perm/permapplyfunc.h"
#include "perm/permrand.h"
#include "bits/graycode.h"
#include "bits/greencode.h"
#include "bits/bittransforms.h"
#include "bits/bit2pow.h"
#include "aux1/copy.h"

#include "bits/printbin.h"

#include "fxttypes.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()

//% Periods of a permutation.


int
main(int argc, char **argv)
{
    ulong n = 11;
    if ( argc>1 )  n = atol(argv[1]);
    ulong ldn = ld(n);
    if ( (long)n<0 )
    {
        ldn = -(long)n;
        n = 1UL<<ldn;
        cout << "ldn=" << ldn;
    }
    cout << "  n=" << n << endl;

    ulong a1 = 4;
    if ( argc>2 )  a1 = atol(argv[2]);


    ulong *y = new ulong[n];
    set_seq(y, n);


//    cout << " Apply some permutation(s):" << endl;
    for (ulong k=0; k<a1; ++k)  random_permute(y, n);
//    apply_inverse_permutation(gray_code, y, n);

    // ... and print periods:
    ulong *p = new ulong[n];
    ulong nt = get_periods(y, n, p);
    for (ulong k=0; k<n; ++k)
    {
        cout << setw(4) << k << ": ";
        cout << "  " << setw(4) << y[k];
        print_bin_nn("  ", y[k], ldn);
        cout << "  " << setw(4) << p[k];
        cout << endl;
    }
    cout << "nt=" << nt << endl;

    return 0;
}
// -------------------------
