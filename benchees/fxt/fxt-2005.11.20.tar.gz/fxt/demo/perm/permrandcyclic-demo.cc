
#include "perm/permrand.h" // random_cyclic_permutation()

#include "perm/printperm.h"


#include "fxtiomanip.h"
#include "aux0/swap.h"
#include "fxttypes.h"

#include "perm/permq.h" // is_cyclic(), ...
#include "jjassert.h"

#include "demo/nextarg.h" // NXARG()

//% Random cyclic permutations.


void visit(const ulong *f, ulong n, ulong ct)
// What to do with valid permutations.
// Here: simply print them
{
    cout << setw(3) << ct << ": ";
    for (ulong i=0; i<n; ++i)  cout << " " << f[i];

    cout << "    ";
    print_cycle(f, 0);

//    if ( is_indecomposable(f, n) )  cout << "  Ind";  // always true
    if ( is_updown_permutation(f, n) )  cout << "  UpD";
//    if ( is_derangement(f, n) )  cout << "  Der"; // always true
//    if ( is_cyclic(f, n) )  cout << "  Cyc";
    cout << endl;
    jjassert( is_cyclic(f, n) );
}
// -------------------------



int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "Permutations of n>0 elements");

    ulong c = 20;
    NXARG(c, "Number of permutations");

    ulong *f = new ulong[n];
//    ulong *fc = new ulong[n-1];
    for (ulong k=0; k<c; ++k)
    {
        random_cyclic_permutation(f, n);
        visit(f, n, k);

//        perm2fact(f, n, fc);
//        cout << " [ ";
//        for (ulong i=0; i<n-1; ++i)  cout << " " << fc[i];
//        cout << " ]" << endl;
    }

    return 0;
}
// -------------------------
