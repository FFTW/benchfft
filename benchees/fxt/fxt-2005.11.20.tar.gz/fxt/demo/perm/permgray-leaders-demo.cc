
// demo-is-self-contained

#include "bits/graycode.h"
#include "bits/printbin.h"
#include "bits/bit2pow.h"
#include "bits/bitsubset.h"
#include "bits/bitcount.h"

#include "fxtiomanip.h"
#include "demo/nextarg.h"
#include "fxttypes.h"

//% Cycle leaders (maxima) for gray permutation


void gray_leaders(ulong ldn, bool cq)
{
    ulong n = 1UL << ldn;
    ulong pn = ldn + 1;  // print precision (int bits)
    ulong z = 1; // mask for cycle maxima
    ulong v = 0; // (partial) complement of mask z
    ulong cl = 1;  // cycle length
    for (ulong ldm=1, m=2;  m<n;  ++ldm, m<<=1)
    {
        z <<= 1;
        v <<= 1;
        if ( is_pow_of_2(ldm) )  // m = 1, 2, 4, 16, 256, ..., 2**(2**x), ...
        {
            cout << "--------------------------" << endl;
            ++z;
            cl <<= 1;
        }
        else  ++v;

        ulong bv = bit_count(v);
        ulong num = (1<<bv);
        ulong len = 1UL<<(ldm-bv);
        cout << "  k =" << setw(2) << ldm << ":";
        cout << setw(3) << num << " cycles of length=" << setw(2) << len << "";
        cout  << " [" << m << " ... " << m+m-1 << "]  ";
        cout << endl;

        bit_subset b(v);
        ulong c = ~0UL;
        do
        {
            ulong i = z | b.next();  // start of cycle
            c &= i;

            cout << "  " << setw(3) << i;
            print_bin_nn(" =  ", i, pn);
            if ( cq ) // print cycle:
            {
                ulong ci = i; // cycle minimum
                for (ulong w=gray_code(i); w!=i; w=gray_code(w) )
                {
                    print_bin_nn(" --> ", w, pn);
                    if ( w<ci )  ci = w;
                }
                print_bin_nn("  [min = ", ci, pn);  cout << " = " << setw(3) << ci << "]";
            }
            cout << endl;
        }
        while ( b.current() );

        cout <<   "    maxima = z xor subsets(v)  where" << endl;
        print_bin("    z =  ", c, pn);
        print_bin("    v =  ", v, pn);
        cout << endl;
    }
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong ldn = 7;
    NXARG(ldn, "Up to 2**ldn");
    bool cq = 1;
    NXARG(cq, "Whether to print cycles");

    gray_leaders(ldn, cq);

    cout << endl;

    return 0;
}
// -------------------------


