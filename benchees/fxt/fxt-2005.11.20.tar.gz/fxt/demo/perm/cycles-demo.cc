
#include "perm/cycles.h"
#include "perm/graypermute.h"
#include "perm/revbinpermute.h"
#include "perm/zip.h"
#include "aux1/copy.h"

//#include "perm-all.h"  // all permutation stuff
#include "perm/haarpermute.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Decomposition of a permutation into cycles.


// Print And Doit:
#define  PAD( x )  { cout << "Using: " << #x << endl;  x; }

int
main(int argc, char **argv)
{
    ulong n = 16;
    NXARG(n, "Number of elements (must be a power of two)");
    ulong ldn = ld(n);
    if ( (long)n<0 )
    {
        ldn = -(long)n;
        n = 1UL<<ldn;
    }
    cout << "ldn=" << ldn << "  n=" << n << endl;

    ulong pcq = 1;
    NXARG(pcq, "Whether to print C code for the permutation and its inverse.");


    ulong *y = new ulong[n];
    set_seq(y, n);


    cout << " Apply some permutation:" << endl;
    // choose one or more ...:
//    PAD( revbin_permute(y, n) );
//    PAD( reverse(y, n) );
    PAD( gray_permute(y, n) );
//    PAD( inverse_gray_permute(y, n) );
//    PAD( haar_permute(y, n) );
//    PAD( zip(y, n) );


//    for (ulong k=0; k<n; ++k)  cout << y[k] << ", ";
//    cout << endl;

    cout << "Computing cycles:" << endl;
    cycles cc(n);
    cc.make_cycles(y, n);
    cc.print();
//    cc.print_leaders();


    if ( pcq )
    {
        // ... and print source code:
        cc.print_code("foo_perm", n, 1, 0);

//        cc.invert();  cc.print_code("inverse_foo_perm", n, 1);
    }

    return 0;
}
// -------------------------
