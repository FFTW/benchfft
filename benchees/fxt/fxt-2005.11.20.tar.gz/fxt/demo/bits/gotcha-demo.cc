
// demo-is-self-contained

#include "fxtiomanip.h"
#include "bits/printbin.h"

//% A pitfall with two's complement: one nonzero value equals its own negative.

#define TYPE short int

#define TYPE_BITS  (8*sizeof(TYPE))

void
Print(TYPE c)
{
    const char c01[]=".1";  // characters for printing zero and one
    print_bin_nn("  c=", c, TYPE_BITS, c01);
    print_bin_nn("  -c=", -c, TYPE_BITS, c01);
    cout << "   c=" << setw(6) << (TYPE)+c;
    cout << "  -c=" << setw(6) << (TYPE)-c;
    if ( (signed char)c==(signed char)-c )  cout << "  <--=";
    cout << endl;
}
// -------------------------

int
main()
{
    TYPE c;

    for (c=0; c<7; ++c)  Print(c);
    cout << " [--snip--]" << endl;

    c = 1;   c <<= (TYPE_BITS-1);  
    for (TYPE i=-3; i<7; ++i)  Print(c+i);
    cout << " [--snip--]" << endl;

    for (c=0-7; c!=0; ++c)  Print(c);


    return 0;
}
// -------------------------
