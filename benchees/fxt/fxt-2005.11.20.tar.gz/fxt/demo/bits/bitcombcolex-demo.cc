
#include "bits/bitcombcolex.h"

#include "fxttypes.h"
#include "bits/printbin.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtio.h"


//% Generating combinations of bits (as binary words) in co-lexicographic order.

//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    NXARG(n, "Colex combinations (n over k):  n  (n>0)");
    NXARG(k, "  (0<k<=n)");

    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    const ulong pd = n;
    ulong last = last_comb(k, n);
    ulong g = first_comb(k);
    ulong gg = 0;
    do
    {
#ifndef TIMING
        print_bin_nn("    ", g, pd);
        if ( gg )  print_bin_diff_nn("    ", gg, g, pd, ".1+-");
        cout << endl;
#endif // TIMING
        gg = g;
        g =  next_colex_comb(g);
    }
    while ( gg!=last );

    return 0;
}
// -------------------------

/*
Timing:
 % time ./bin 32 20
arg 1: 32 == n  [Colex combinations (n over k):  n  (n>0)]  default=7
arg 2: 20 == k  [  (0<k<=n)]  default=4
./bin 32 20  1.37s user 0.00s system 99% cpu 1.367 total
 ==> 165,173,986 comb/sec

% time ./bin 32 12
arg 1: 32 == n  [Colex combinations (n over k):  n  (n>0)]  default=7
arg 2: 12 == k  [  (0<k<=n)]  default=4
./bin 32 12  1.64s user 0.02s system 100% cpu 1.664 total
 ==> 135,692,812 comb/sec
*/
