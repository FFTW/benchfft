
#include "bits/bitcombminchange.h"

#include "fxttypes.h"
#include "bits/printbin.h"
#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtio.h"

//% Generating all combinations of bits (as binary words) in minimal-change order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    NXARG(n, "Minchange combinations (n over k):  n  (n>0)");
    NXARG(k, "  (0<k<=n)");

    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    const ulong pd = n;
    ulong last = igc_last_comb(k, n);
    ulong c, nc = first_sequency(k);
    ulong g, gg = 0;
    do
    {
        c = nc;
        nc = igc_next_minchange_comb(c);

#ifndef TIMING
        print_bin_nn("    ", c, pd);
        print_bin_nn("    ", nc-c, pd);
        g = gray_code(c);
        print_bin_nn("    ", g, pd);
        if ( gg )  print_bin_diff_nn("    ", gg, g, pd, ".1+-");
        gg = g;
        cout << endl;
#endif // TIMING
    }
    while ( c!=last );

    cout << endl;

    return 0;
}
// -------------------------

/*
 % time ./bin 32 12
arg 1: 32 == n  [Minchange combinations (n over k):  n  (n>0)]  default=7
arg 2: 12 == k  [  (0<k<=n)]  default=4
./bin 32 12  2.47s user 0.02s system 99% cpu 2.498 total
 ==> 90,389,447 comb/sec

 % time ./bin 32 20
arg 1: 32 == n  [Minchange combinations (n over k):  n  (n>0)]  default=7
arg 2: 20 == k  [  (0<k<=n)]  default=4
./bin 32 20  2.85s user 0.01s system 99% cpu 2.863 total
 ==> 78,865,819 comb/sec
*/
