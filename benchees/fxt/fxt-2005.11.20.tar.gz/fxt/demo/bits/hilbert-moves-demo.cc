
#include "bits/hilbert.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong

//% Hilbert moves and turns.


int
main(int argc, char **argv)
{
    ulong ldn = 6;
    NXARG(ldn,"number of moves == 2**ldn");

    ulong n = 1UL << ldn;
    cout << " dx+dy: ";
    for (ulong k=1; k<n; ++k)  cout << "+-"[ hilbert_p(k) ];
    cout << endl;

    cout << " dx-dy: ";
    for (ulong k=1; k<n; ++k)  cout << "+-"[ hilbert_m(k) ];
    cout << endl;

    cout << "   dir: ";
    for (ulong k=1; k<n; ++k)
    {
        ulong d = hilbert_dir(k);
//        cout << "v><^"[ d ];
        cout << ">v^<"[ d ];
    }
    cout << endl;

    cout << "  turn: ";
    for (ulong k=1; k<n; ++k)
    {
        int u = hilbert_turn(k);
        cout << ("-0+")[u+1];
    }
    cout << endl;

//    cout << "  turn: ";
//    for (ulong k=1; k<n; ++k)
//    {
//        ulong d1 = hilbert_dir(k);
//        ulong d2 = hilbert_dir(k-1);
//        d1 ^= (d1>>1);
//        d2 ^= (d2>>1);
//        cout << ("+.-0+.-")[ d1-d2 + 3];
//    }
//    cout << endl;

    return 0;
}
// -------------------------

// dx+dy: ++-+++-+++----++++-+++-+++----++++-+++-+++----+---+---+---++++-
// dx-dy: +----+++-+++-+++-++++---+---+----++++---+---+----++++---+---+--
//   dir: >^<^^>v>^>vv<v>>^>v>>^<^>^<<v<^^^>v>>^<^>^<<v<^<<v>vv<^<v<^^>^<
//  turn: 0--+0++--++0+--0-++-0--++--0-++00++-0--++--0-++-0--+0++--++0+--
