
#include "bits/bittransforms.h"

//#include "bits/graycode.h"
//#include "bits/bitlex.h"

#include "bits/bitcount.h"
#include "bits/bit2pow.h"
#include "bits/bitsperlong.h"
#include "fxttypes.h"
#include "bits/printbin.h"

#include "demo/nextarg.h"

#include "fxtio.h"
#include "fxtiomanip.h"


//% Transforms of binary words that are involutions: red code and cyan code.


int
main(int argc, char **argv)
{
    ulong ldn = 5;
    NXARG(ldn, "List transforms of first 2**ldn numbers");
    ulong n = 1UL<<ldn;

//    ulong pn = ld(n)+1;
    for (ulong k=0; k<n;  ++k)
    {
        cout << setw(4) << k << ":";

//        ulong l = k;
//        l = blue_code(l);
//        l = i2l(l); l = inverse_gray_code(l); l = i2l(l);  // parity
//        l = gray_code(l); l = l2i(l); l = gray_code(l);  // parity
//        print_bin_nn("   l=", l , BITS_PER_LONG);
//        cout << " " << setw(2) << bit_count(l);

        ulong r = red_code(k);
        print_bin_nn("   r=", r , BITS_PER_LONG);
        cout << " " << setw(2) << bit_count(r);

        ulong c = k;
        c = cyan_code(c);
        print_bin_nn("   c=", c , BITS_PER_LONG);
        cout << " " << setw(2) << bit_count(c);

        cout << endl;
    }

    cout << endl;

    return 0;
}
// -------------------------
