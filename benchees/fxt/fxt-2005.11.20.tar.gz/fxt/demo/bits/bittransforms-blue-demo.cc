
#include "bits/bittransforms.h"

#include "bits/bit2pow.h"
#include "bits/bitcount.h"
#include "bits/bitsperlong.h"
#include "fxttypes.h"
#include "bits/printbin.h"

#include "demo/nextarg.h"

#include "fxtio.h"
#include "fxtiomanip.h"


//% Transforms of binary words that are involutions: blue code and yellow code.


int
main(int argc, char **argv)
{
    ulong ldn = 5;
    NXARG(ldn, "List transforms of first 2**ldn numbers");
    ulong n = 1UL<<ldn;

    ulong pn = ld(n)+1;
    for (ulong k=0; k<n;  ++k)
    {
        cout << setw(4) << k << ":";
        print_bin_nn("   k=", k , pn);
        cout << " " << setw(2) << bit_count(k);

        ulong b = blue_code(k);
        print_bin_nn("   b=", b , pn);
        cout << " " << setw(2) << bit_count(b);
        cout << ( b == k ? "*" : " ");

        ulong y = yellow_code(k);
//        y = bit_rotate_right(y, 1);  y = yellow_code(y);  // ==> gray^shift
        print_bin_nn("   y=", y , BITS_PER_LONG);
        cout << " " << setw(2) << bit_count(y);

        cout << endl;
    }

    cout << endl;

    return 0;
}
// -------------------------
