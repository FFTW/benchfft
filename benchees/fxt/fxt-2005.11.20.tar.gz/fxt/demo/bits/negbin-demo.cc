
#include "bits/negbin.h"
#include "bits/graycode.h"

//#include "bits/bitlow.h"
#include "bits/printbin.h"
#include "perm/permq.h" // is_valid_permutation()

#include "fxtiomanip.h"
#include "jjassert.h"
#include "fxttypes.h"  // ulong

#include "demo/nextarg.h"  // ulong



//% Representation in radix(-2).
// see HAKMEM item 128.


int
main(int argc, char **argv)
{
    ulong ldn = 5;
    NXARG(ldn, "Number of bits");
    ulong n = 1UL<<ldn;
    ulong pn = ldn+2;
    ulong *f = new ulong[n];

    ulong gg = 0;
    cout << setw(3) << "  k :";
    cout << setw(pn+2) << "bin(k)";
    cout << "  ";
    cout << setw(pn+2) << "m=negbin(k)";
    cout << "  ";
    cout << setw(pn+2) << "g=gray(m)";
    cout << setw(3+2) << "   bin(g)";
    cout << endl;

    for (ulong k=0; k<n; ++k)
    {
        cout << setw(3) << k;
        print_bin_nn(" : ", k, pn);

        ulong m = bin2neg(k);
        print_bin_nn("    ", m, pn);

        ulong g = gray_code(m);
        print_bin_nn("    ", g, pn);
//        print_bin_nn("  ",g^gg,pn);  // negbin ruler function

        ulong bg = neg2bin(g);
        f[k] = bg;
//        print_bin_nn("    ", bg, pn);
        cout << "    " << setw(4) << bg;

        if ( is_valid_permutation(f,k+1) )  cout << " <= " << k;

//        if ( m==k )  cout << " %";

        cout << endl;

        jjassert( neg2bin(m) == k );

        gg = g;
    }

    // sequence of fixed points:
//    for (ulong k=0; k<n/2; ++k)
//    {
//        ulong fx = negbin_fixed_point(k);
//        cout << setw(4) << k << ": ";
//        print_bin_nn("    ", fx, pn);
//        cout << " == " << setw(4) << fx;
//        cout << endl;
//    }

    cout << endl;

    return 0;
}
// -------------------------
