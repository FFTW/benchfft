
#include "bits/bin2paul.h"
#include "bits/printbin.h"
// demo-include "bits/printbindiff.cc"

#include "bits/bit2pow.h"
#include "aux0/swap.h"

#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"


#include "demo/nextarg.h" // NXARG()


//% M.Paul's sparse signed binary representation.

int
main(int argc, char **argv)
{
    ulong n = 32;
    NXARG(n, "Max");
    ulong pn = ld(n)+2;
    ulong n0 = 0;
    NXARG(n0, "Min");
    if ( n0>n )  swap2(n, n0);

    bool q = 1;
    NXARG(q, "Whether to print sum");

    for (ulong k=n0; k<=n; ++k)
    {
        ulong x = k;
        cout << setw(3) << x << ":";
        print_bin_nn("    ", x, pn);

        ulong pp, pm;
        bin2paul(x, pp, pm);
//        print_bin_nn("    ", pp, pn);
//        print_bin_nn("    ", pm, pn);
        print_bin_diff_nn("    ", pm, pp, pn, "..PM");

        if ( q )
        {
            cout << "    " << setw(3) << x << " = ";
            ulong xp = pp, xm = pm;
            while ( xm|xp )
            {
                ulong m = highest_bit(xm|xp);
                cout << ' ' << (m&xp?'+':'-') << m;
                xm &= ~m;  xp &= ~m;
                m >>= 1;
            }
        }

        cout << endl;

        jjassert( paul2bin(pp,pm)==x );
    }

    return 0;
}
// -------------------------
