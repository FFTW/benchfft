
#include "bits/bitfibgray.h"
// demo-include "bits/graycode.h"
// demo-include "bits/negbin.h"
#include "bits/fibrep.h" // fibrep2bin()

#include "bits/printbin.h"
#include "fxtio.h"
#include "demo/nextarg.h"

//% Fibonacci Gray code with binary words.

//#define TIMING  // define to disable printing

int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "Number of bits in Gray code");

    bit_fibgray fg(n);
    ulong z, ct = 0;
    ulong kl = fg.k_;
    do
    {
        ++ct;
#ifndef TIMING
        ulong k = fg.k_;
        cout << setw(6) << ct << ":";
        print_bin_nn("    ", k, n+3);
        print_bin_nn("    ", kl-k, n+3);
        print_bin_nn("    ", bin2neg(k), n+3);
        print_bin_nn("    ", fg.x_, n+3);
//        cout << " = " << setw(3) << fg.x_;
        cout << " = " << setw(3) << fibrep2bin(fg.x_);
        cout << endl;
        kl = k;
#endif

        z = fg.next();
    }
    while ( (long)z>=0 );

    cout << "  ct=" << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:
 time ./bin 40
arg 1: 40 == n  [Number of bits in Gray code]  default=7
  ct=267914296
./bin 40  2.34s user 0.01s system 99% cpu 2.350 total
 267914296/2.350 == 114,006,083 objects per second
*/
