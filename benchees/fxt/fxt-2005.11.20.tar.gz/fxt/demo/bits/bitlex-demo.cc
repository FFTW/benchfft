
#include "bits/bitlex.h"

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "bits/printbin.h"

//#include "bits/graycode.h"

#include "demo/nextarg.h"


//% Generating binary words in lexicographic order.

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "n-bit binary words");
    ulong m = 1UL<<n;

    ulong x = 1UL<<(n-1);
    ulong ct = 0;
    do
    {
        ++ct;
        cout << setw(2) << ct << ":  ";
        print_bin_nn("", x, n);  cout << "  = " << setw(2) << x;
        x = next_lexrev(x);
        cout << endl;
    }
    while ( x );

    cout << " ... and back:" << endl;

    ct = 1;
    do
    {
        x = prev_lexrev(x);
        cout << setw(2) << ct << ":  ";
        print_bin_nn("", x, n);  cout << "  = " << setw(2) << x;

//        print_bin_nn("  ", negidx2lexrev(ct), n+1);  // == x

        ulong z = x ^ next_lexrev(x);
        print_bin_nn("  ", z, n+1);
        if ( is_lexrev_fixed_point(x) )  cout << " *";
        ++ct;
        cout << endl;
    }
    while ( x<m );

    return  0;
}
// -------------------------
