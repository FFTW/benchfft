
#include "bits/pcrc64.h"

#include "bits/printbin.h"
#include "fxtiomanip.h"
#include "demo/nextarg.h"
#include "fxttypes.h"
#include "jjassert.h"

//% Parallel Cyclic Redundancy Check (CRC)


#define Type uint

void
Print(const pcrc64<Type> &P, const ulong pn)
{
    for (uint k=0; k<64; ++k)
    {
        cout << setw(3) << k << ":";
        print_bin("  ", P.x_[k], pn );
    }
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 32768;
    NXARG(n, "Will feed values 0,1,2...,n-1 into CRC");
    const ulong pn = 8 * sizeof(Type);

    pcrc64<Type> P;
    for (ulong k=0; k<n; ++k)  P.word_in((Type)k);

//    pcrc.zero_pos();

    Print(P, pn);
    cout << endl;

    print_bin(" sum= ", P.sum(), pn );
    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:

. With Type ulong (64 bit):
./bin $((1<<30))  4.35s user 0.02s system 99% cpu 4.408 total
 ==> 0.90744 GB / sec

 With Type uint:
./bin $((1<<30))  4.40s user 0.02s system 99% cpu 4.452 total
 ==> 0.89847 GB / sec

 With Type uchar:
./bin $((1<<30))  4.65s user 0.03s system 99% cpu 4.701 total
 ==>  0.85088 GB / sec

*/
