
#include "bits/revbin-upd.h"

#include "bits/printbin.h"
#include "demo/nextarg.h"

#include "fxtio.h"
#include "jjassert.h"
#include "fxttypes.h"  // ulong

//% Revbin-update routines.


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong ldn = 5;
    NXARG(ldn, "Reverse the first 2**n binary words.");
    const ulong n = 1UL<<ldn;
    const ulong h = n/2;
    make_revbin_upd_tab(h);
//    for (ulong k=0; k<ldn; ++k)  print_bin("  ",revbin_upd_tab[k],ldn);


#ifdef TIMING
    ulong wh = 0;
    NXARG(wh, "TIMING: Which routine: 0=>xor-tables,  1=>bit-wise.");
    ulong r = 0;
    if ( wh )
    {
        // 5.915 sec for 2**30 words:
        for (ulong k=0; k<n-1; ++k)  { r = revbin_upd(r, h); }
    }
    else
    {
        // 6.173 sec for 2**30 words:
        for (ulong k=0; k<n-1; ++k)  { r = revbin_tupd(r, k); }
    }
    return r & 1;

#else
    ulong r1 = 0,  r2 = 0;
    for (ulong k=0; k<n-1; ++k)
    {
        print_bin_nn("  ", k, ldn);
        print_bin("  :  ", r1, ldn);
//        print_bin("  ", r2, ldn);  cout << endl;
        jjassert( r1==r2 );

        r1 = revbin_upd(r1, h);
        r2 = revbin_tupd(r2, k);
    }
#endif // TIMING

    return  0;
}
// -------------------------
