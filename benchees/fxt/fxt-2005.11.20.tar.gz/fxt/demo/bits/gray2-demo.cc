
#include "bits/graycode.h"
#include "bits/parity.h"
#include "bits/printbin.h"
#include "aux1/auxprint.h"

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "demo/nextarg.h"


//% Binary Gray code.

int
main(int argc, char **argv)
{
    ulong n =5;
    NXARG(n, "Number of bits");

    ulong nn = 1UL << n;
    ulong pd = n + 2;

    cout << setw(4) << "k" << ":  ";
    cout << setw(pd+4) << "k ";
    cout << setw(pd+4) << "g(k) ";
    cout << setw(pd+4) << "g(g(k))";
    cout << setw(pd+4) << "g(2*k)";
    cout << setw(pd+4) << "g(2*k+1)";
    cout << "    ";
    cout << setw(pd+4) << "diff(g(k),g(k-1))";
    cout << endl;

    for (ulong k=0; k<nn; ++k)
    {
        cout << setw(4) << k << ":  ";
        print_bin_nn("    ", k, pd);
        print_bin_nn("    ", gray_code(k), pd);
        print_bin_nn("    ", gray_code( gray_code (k) ) , pd);
        print_bin_nn("    ", gray_code(2*k), pd);
        print_bin_nn("    ", gray_code(2*k+1), pd);

        print_bin_diff_nn("    ", gray_code(k-1), gray_code(k), pd);
        cout << " " << ".1"[k&1];
        print_bitset_as_set("    ", gray_code(k), n);

        cout << endl;
    }

    return 0;
}
// -------------------------
