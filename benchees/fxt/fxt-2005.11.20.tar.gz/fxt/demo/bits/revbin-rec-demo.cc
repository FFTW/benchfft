
// demo-is-self-contained

#include "bits/printbin.h"

#include "fxttypes.h"
#include "demo/nextarg.h"

//% Recursive algorithm for the bit-reversed binary words in order.

ulong ldn;
ulong N, ct;
void revbin_rec(ulong f, ulong n)
{
    print_bin_nn("  ", ct, ldn);    print_bin("  ", f, ldn);
    ++ct;
    for (ulong m=N>>1; m>n; m>>=1)  revbin_rec(f+m, m);
}
// -------------------------

int
main(int argc, char **argv)
{
    ldn = 5;
    NXARG(ldn, "Number of bits");
    N = 1UL<<ldn;
    ct = 0;

    revbin_rec(0, 0);

    return 0;
}
// -------------------------
