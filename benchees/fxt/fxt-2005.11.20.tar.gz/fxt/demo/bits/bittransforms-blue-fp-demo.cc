
#include "bits/blue-fixed-points.h"
#include "bits/bittransforms.h"

#include "bits/printbin.h"

#include "jjassert.h"
#include "demo/nextarg.h"
#include "fxttypes.h"

#include "fxtio.h"


//% Fixed points of the blue code.


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Number of bits");
    ulong N = 1UL<<n;
    cout << endl;

    for (ulong k=0; k<N; ++k)
    {
        ulong f = blue_fixed_point(k);
        ulong s = blue_fixed_point_idx(f);

        cout << setw(4) << k;
        print_bin_nn(" = ", k, n+1);
        cout << " :  ";
        print_bin_nn("  ", f, 2*n);
        cout << " = ";
        cout << setw(6) << f;
        cout << endl;

        jjassert( f==blue_code(f) );
        jjassert( s==k );

//        ulong z = (f<<1) ^ (f<<2);
//        jjassert( z==blue_code(z) );
//        z ^= 1;
//        jjassert( z==blue_code(z) );
    }

    cout << endl;

    return 0;
}
// -------------------------

