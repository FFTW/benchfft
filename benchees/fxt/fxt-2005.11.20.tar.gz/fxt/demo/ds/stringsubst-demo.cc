
#include "comb/stringsubst.h"

#include "fxtiomanip.h"
//#include "jjassert.h"
#include "fxttypes.h"  // ulong
#include "demo/nextarg.h" // NXARG()

//% String substitution engine.


void
usage(const char *argv0)
{
    cout << "Usage:" << endl;
    cout << "  " << argv0 << " maxdepth starts symbol0 rule0 symbol1 rule1 ... " << endl;
    cout << "For each symbol a rule must be supplied. " << endl;
    cout << "At least two symbol/rule pairs are needed. " << endl;
    cout << "Example 1:  (rabbit sequence)" << endl;
    cout << "  " << argv0 << "  9   0   0 1      1 10 " << endl;
    cout << "Example 2:  (Thue sequence)" << endl;
    cout << "  " << argv0 << "  4   0   0 111   1 110 " << endl;
}
// -------------------------

int
run_substitutions(ulong maxn, char *start, ulong nsym, char *args[])
{
    ulong cmax = 10000;
    string_subst strs(cmax, nsym, args);

    strs.print_rules(start);
    cout << "-------------" << endl;
    if ( 0!=strs.verify(start) )  return 1;

    for (ulong j=0; j<=maxn; ++j)
    {
        ulong ctc = strs.subst(j, start);

        cout << j << ": ";
        cout << "  (#=" << ctc << ")" << endl;
        cout << "  " << strs.string();
        cout << endl;
    }
    return  0;
}
// -------------------------

// P=./bin
// rabbit:  $P  9   0  0 1  1 10
// Pell:    $P  6   0  0 1  1 110
// Thue:    $P  4   0  0 111  1 110

// Thue-Morse:  $P  6   0  0 01  1 10
// related (with sign):
//  $P  6   0  0 L1  1 10 L L0
// using other symbols:
//  $P  6   0  0 -+  + +0  - -0

// oscillating machines:
// osc2: $P  10  0  0 1  1 01
// osc2: $P  10  .  . A  A B.  B A.
// osc3: $P  10  .  . A  A B.  B .A


int
main(int argc, char *argv[])
{
    ulong maxn = 7;
    NXARG(maxn, "Max depth");

    char *start;
    NXARGSTR(start, "Start symbol(s)", "A");

    RESTARGS("Rules:  sym1 rep1  sym2 rep2  [... symN repN]");
    cout << "Example: " << argv[0] << " 7 A  A x  x xA" << endl; 


    int ret;
    if ( argc > 1 )
    {
        int rem = argc - 3;
        // need at least two rules (4 more args):
        if ( rem < 4 )  { usage( argv[0] ); return 1; }
        // need an even number of args:
        if ( 0!=(rem%2) )  { usage( argv[0] ); return 1; }

        ulong nsym = rem / 2;
        ret = run_substitutions( maxn, start, nsym, argv+3 );
    }
    else // defaults:
    {
        cout << "\n------------- rabbit sequence: -------------" << endl;
        char *rabbit_rules[] = { "0", "1",
                                 "1", "10" };
        ret = run_substitutions( 7, "0", 2, rabbit_rules );

        cout << "\n------------- modified rabbit sequence: -------------" << endl;
        char *fibonacci_rules[] = { ".", "A",
                                    "A", "B.",
                                    "B", "B." };
        ret = run_substitutions( 10, ".", 3, fibonacci_rules );

        cout << "\n------------- Thue-Morse sequence: -------------" << endl;
        char *thue_morse_rules[] = { "0", "01",
                                     "1", "10" };
        ret = run_substitutions( 6, "0", 2, thue_morse_rules );

        cout << "\n------------- Taylor series of 1+sum(n>=1,x^(2^n-1)): -------------" << endl;
        char *taylor_rules[] = { "0", "0",
                                 "1", "110",
                                 "A", "A" };
        ret = run_substitutions( 5, "1A", 3, taylor_rules );

        cout << "\n------------- Dragon curve: -------------" << endl;
        char *dragon_rules[] = { "F", "F+G+",
                                 "G", "-F-G",
                                 "+", "+",
                                 "-", "-",};
        ret = run_substitutions( 6, "F", 4, dragon_rules );

        cout << "\n------------- Hilbert curve (90deg turns): -------------" << endl;
        char *hilbert_rules[] = { "a", "-bF+aFa+Fb-",
                                  "b", "+aF-bFb-Fa+",
                                  "+", "+",
                                  "-", "-",
                                  "F", "F" };
        ret = run_substitutions( 3, "a", 5, hilbert_rules );

//        cout << "\n------------- 3D Hilbert curve (90deg turns): -------------" << endl;
//        char *hilbert3d_rules[] = { "a", "^<aF^<aFa-F^>>aFavF+>>aFa-F>a->",
//                                    "F", "F"
//                                    "<", "<",
//                                    ">", ">",
//                                    "^", "^",
//                                    "v", "v",
//                                    "+", "+",
//                                    "-", "-" };
//        ret = run_substitutions( 3, "a", 8, hilbert3d_rules );

        cout << "\n------------- tree (20deg turns): -------------" << endl;
        char *tree_rules[] = { "L", "R[+L]R[-L]+L",
                               "R", "RR",
                               "+", "+",
                               "-", "-",
                               "[", "[",
                               "]", "]" };
        ret = run_substitutions( 3, "L", 6, tree_rules );
    }

    return ret;
}
// -------------------------
