
// demo-is-self-contained

#include "bits/bitcombcolex.h" // first_comb()
#include "bits/printbin.h"


#include "fxtiomanip.h"

#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong


//% Towers of Hanoi, recursive algorithm.


int n;
ulong *f;

static void
print_hanoi(ulong s)
{
    // print the towers:
    for (ulong j=0; j<3; ++j)  print_bin_nn("    ", f[j], n, ".1");

    // print move:
    print_bin_nn("    ", s, n, ".1");

    // print summary:
    cout << "   ";
    for (ulong k=n-1,b=1<<(n-1);  0!=b;  --k,b>>=1)
    {
        cout << ' ';
        if ( b & f[0] )  cout << '0';
        else
        {
            if ( b & f[1] )  cout << '+';
            else             cout << '-';
        }
    }

    cout << endl;
}
// -------------------------


void
hanoi(int k, ulong from, ulong aux, ulong to)
{
    if ( k<0 ) return;

    hanoi(k-1, from, to, aux);

    // move disk k from 'from' to 'to':
    ulong b = 1UL<<k;
    f[from] ^= b;
    f[to] ^= b;
    print_hanoi(b);

    hanoi(k-1, aux, from, to);
}
// -------------------------


int
main(int argc, char **argv)
{
    n = 5;
    NXARG(n, "Number of disks");

    f = new ulong[3];
    f[0] = first_comb(n);  f[1] = 0;  f[2] = 0;  // Initial configuration
    print_hanoi(0);
    hanoi(n-1, 0, 1, 2);

    delete [] f;

    return  0;
}
// -------------------------
