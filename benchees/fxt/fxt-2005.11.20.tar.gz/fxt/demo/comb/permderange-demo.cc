
#include "comb/permderange.h"
#include "comb/permtrotter.h"

#include "fxttypes.h"
#include "fxtiomanip.h"

#include "demo/nextarg.h" // NXARG()

//% Generate all permutations in derangement order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements");

    perm_derange perm(n);
#ifdef TIMING
    while ( perm.next() )  {;}
#else
    const ulong *x = perm.data();
    ulong ct = 0;
    do
    {
        cout << "   " << setw(3) << ct << ":   ";
        ++ct;
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
        cout << endl;
    }
    while ( perm.next() );
#endif

    return 0;
}
// -------------------------


/*
 Timing:
 time ./bin 12
./bin 12  12.55s user 0.07s system 99% cpu 12.672 total
 ==> 12!/12.672 == 37,800,000 permutations per second
*/
