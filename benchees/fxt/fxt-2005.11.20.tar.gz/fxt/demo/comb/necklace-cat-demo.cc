
// demo-is-self-contained

#include "fxtio.h"
#include "demo/nextarg.h"

//% Generate (pre-)necklaces as described by Cattell, Ruskey, Sawada, Miers, Serra.
//% Recursive CAT algorithm.

ulong *f; // data in f[1..N],  f[0] = 0
ulong N; // word length
ulong K; // K-ary

ulong pct;  // count pre-necklaces

//#define TIMING // uncomment to disable printing

void
visit(ulong p)
{
    ++pct;
#ifndef TIMING
    cout << setw(3) << pct << ":  ";
    for (ulong j=1; j<=N; ++j)  cout << " " << f[j];
    if ( N%p==0 )  cout << "  N";
    if ( N==p )  cout << "  L";
    cout << endl;
#endif  // TIMING
}
// -------------------------

void
crsms_gen(ulong n, ulong p)
{
    if ( n > N )  visit(p);  // pre-necklace in f[1,...,N]
    else
    {
        f[n] = f[n-p];
        crsms_gen(n+1, p);

        for (ulong j=f[n-p]+1; j<K; ++j)
        {
            f[n] = j;
            crsms_gen(n+1, n);
        }
    }
}
// -------------------------


int
main(int argc, char **argv)
{
    N = 6;
    NXARG(N, "Length of necklaces (n>=1)");
    K = 2;
    NXARG(K, "Number of different beads (k>=2)");
    
    f = new ulong[N+1];
    for (ulong j=0; j<=N; ++j)  f[j] = 0;
    pct = 0;
    crsms_gen(1, 1);
    cout << "  # pre-necklaces=" << pct << endl;

    return 0;
}
// -------------------------

/*
Timing:
 time ./bin 32
arg 1: 32 == N  [Length of necklaces (n>=1)]  default=6
arg 2: 2 == K  [Number of different beads (k>=2)]  default=2
  # pre-necklaces=277737797
./bin 32  3.88s user 0.02s system 99% cpu 3.904 total
 71,141,853 pre-necklaces per second
*/
