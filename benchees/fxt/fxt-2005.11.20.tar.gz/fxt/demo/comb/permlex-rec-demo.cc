
#include "comb/permlex-rec.h"

#include "fxtio.h"
#include "demo/nextarg.h"
#include "fxttypes.h"

//#include "perm/permq.h"
#include "perm/perminvert.h"

#include "comb/perm2fact.h"


//% All permutations in lexicographic order.
//% Recursive algorithm.

//#define TIMING // uncomment to disable printing

void
print(const char *bla, const ulong *f, ulong n)
{
    if ( bla )  cout << bla;
    cout << "[ ";
    for (ulong k=0; k<n; ++k)  cout << f[k] << (k<n-1?", ":"");
    cout << " ]";
}
// -------------------------

#ifdef TIMING
void visit(const perm_lex_rec &)  {;}
#else
void visit(const perm_lex_rec &P)  // function to call with each permutation
{
    static ulong ct = 0;
    static ulong ff[32];

    cout << setw(4) << ct << ":  ";
    ++ct;

    ulong n = P.n_;
    const ulong * p = P.pp_;

    print("    ", p, n);

    static ulong ii[32];
    make_inverse(p, ii, n);
    print("    ", ii, n);

    perm2ffact(p, n, ff);
    print("    ", ff, n-1);

    cout << endl;
}
// -------------------------
#endif


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");
    bool cq = 0;
    NXARG(cq, "Whether to generate only cyclic permutations");

    perm_lex_rec P(n);

    if ( cq )  P.generate_cyclic(visit);
    else       P.generate(visit);

//    cout << "ct=" << P.ct_ << endl;
//    cout << "rct=" << P.rct_ << endl;

    return 0;
}
// -------------------------

/*
Timing:
 time ./bin 12
./bin 12  10.88s user 0.06s system 99% cpu 10.944 total
 ==> 12!/10.944 == 43,768,421 objects per second
*/
