
#include "comb/permlex.h"

#include "comb/perm2fact.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in lexicographic order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");

    perm_lex perm(n);
#ifdef TIMING
    while ( perm.next() )  {;}
#else
    const ulong *x = perm.data();
    ulong *fc = new ulong[n-1];
    ulong ct = 0;
    do
    {
        cout << "   " << setw(3) << ct << ":   ";
        ++ct;
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm2ffact(x, n, fc);
        cout << "    ";
        for (ulong i=0; i<n-1; ++i)  cout << fc[i] << " ";

        cout << endl;
    }
    while ( perm.next() );
#endif

    return 0;
}
// -------------------------

/*
Timing:
time ./bin 12
arg 1: 12 == n  [Permutations of n elements.]  default=4
./bin 12  4.76s user 0.02s system 100% cpu 4.785 total
 12!/4.785 == 100,104,827 permutations per second
*/
