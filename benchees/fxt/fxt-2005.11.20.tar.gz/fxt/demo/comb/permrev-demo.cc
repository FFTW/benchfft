
#include "comb/permrev.h"

#include "fxtio.h"
#include "demo/nextarg.h"
#include "fxttypes.h"

//#include "perm/perminvert.h"


//% Permutations, CAT algorithm.

//#define TIMING // uncomment to disable printing

void
print(const char *bla, const ulong *f, ulong n)
{
    if ( bla )  cout << bla;
    cout << "[";
    for (ulong k=0; k<n; ++k)  cout << f[k] << (k<n-1?", ":"");
    cout << "]";
}
// -------------------------



int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");

    perm_rev P(n);
    P.first();
//    P.last();

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(4) << ct << ": ";
//        P.goto_d(P.d_);
        print("  p=", P.p_, n);
        print("  d=", P.d_, n-1);
//        cout << "  " << setw(2) << jf;
        cout << endl;
#endif
    }
    while ( P.next() );
//    while ( P.prev() );


    cout << endl;
    cout << " ct=" << ct << endl;
    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:
 time ./bin 12
 ct=479001600
./bin 12  4.56s user 0.02s system 99% cpu 4.584 total
 ==> 479001600/4.437 ==  104,494,240 permutations per second
*/
