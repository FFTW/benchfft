
#include "comb/composition-rank.h"
// demo-include "comb/composition-rank.h"
#include "comb/comp2comb.h"  // comp2comb()


#include "demo/nextarg.h"

#include "jjassert.h"
#include "fxttypes.h"
#include "fxtiomanip.h"


//% Ranking and unranking combinations in near-perfect order


int
main(int argc, char **argv)
{
    ulong N = 7;
    NXARG(N, "Combinations (N choose K): (n>=1)");
    ulong K = 3;
    NXARG(K, " (1<=K<=N) ");
    bool rq = 0;
    NXARG(rq, "Option: let combinations start with [0,1,2,...,K-1]");
    ulong zq = 2;
    NXARG(zq, "Option: choose order: 0=lex, 1=gray, 2=near-perfect");

    ulong k = N-K+1,  n = K;
    cout << "\nUsing " << k << "-compositions of " << n << endl;
    ulong *c = new ulong[K];

    composition_rank cr(n, k);


    ulong *x = new ulong[k];
    ulong nc = cr.num_comp(n,k);
    for (ulong j=0; j<nc; ++j)
    {
        switch ( zq )
        {
        case 0:  cr.unrank_lex(x, n, k, j);  break;
        case 1:  cr.unrank_gray(x, n, k, j);  break;
        default: cr.unrank_nearperfect(x, n, k, j);
        }

        comp2comb(x, k, c);

        if ( rq )  reverse_combination(c, N, K);

        cout << "  " << setw(3) << j << ":   ";

//        cr.print(x, k);
        cr.print_x(x,k);
//        cr.print_set(x,k);
        cr.print_nset(x,k);

        cout << "    [ ";
        for (ulong z=0; z<K; ++z)  cout << c[z] << ", ";
        cout << "]";

        cout << endl;


//        ulong r = cr.rank_lex(x, n, k);
//        ulong r = cr.rank_gray(x, n, k);
//        ulong r = cr.rank_nearperfect(x, n, k);
//        jjassert( r == j );
    }

    cout << "  #= " << nc << endl;

    return 0;
}
// -------------------------

