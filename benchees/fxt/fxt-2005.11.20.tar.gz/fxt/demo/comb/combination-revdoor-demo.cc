
#include "comb/combination-revdoor.h"

#include "aux0/binomial.h"
#include "aux1/auxprint.h" // print_set_as_bitset()

#include "fxttypes.h"
#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtio.h"

//%  Generating all combinations in minimal-change order: revolving door algorithm.


int
main(int argc, char **argv)
{
    ulong n = 6;
    NXARG(n, "(n choose k): n>=1");
    ulong k = 3;
    NXARG(k, "(n choose k):  1<=k<=n");

    bool rq = 1;
    NXARG(rq, "Option: print in reverse order");

    if ( (k>n) || ( k==0 ) || ( n==0 ) )  { return 1; }

    combination_revdoor rd(n,k);

    ulong ct = 0;
    do
    {
        const ulong *x = rd.get();
        cout << setw(3) << ct << " : ";
        if ( rq )  for (ulong j=0; j<k; ++j)  cout << " " << x[k-1-j];
        else       for (ulong j=0; j<k; ++j)  cout << " " << x[j];

//        cout << "  ";
//        for (ulong j=0,i=0; j<n; ++j)  cout << " " << x[j];
        print_set_as_bitset("   ", x, k, n);

        cout << endl;
        ++ct;
    }
    while ( rd.next() );

    ulong bnk =  binomial(n, k);
    cout << "binomial(" << n << ", " << k << ")=" << bnk << endl;
    jjassert( bnk==ct );
    cout << endl;

    return 0;
}
// -------------------------

// for n in $(seq 1 10); do for k in $(seq 1 $n); do ./bin $n $k || break 2; done; done
