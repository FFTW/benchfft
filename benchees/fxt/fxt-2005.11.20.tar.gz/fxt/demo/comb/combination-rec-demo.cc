
#include "comb/combination-rec.h"
// demo-include "comb/combination-rec.cc"

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "aux0/binomial.h"
#include "aux1/auxprint.h"
#include "jjassert.h"
#include "demo/nextarg.h"

//% Combinations in lex-, Gray-, near-perfect, and diagonal Gray order.

//#define TIMING // uncomment to disable printing

void visit(const comb_rec &C)
{
#ifndef TIMING
    cout << setw(4) << C.ct_ << ":";
    print_set_as_bitset("    ", C.rv_, C.k_, C.n_);
    cout << "   ";
    for (ulong j=0; j<C.k_; ++j)  cout << " " << C.rv_[j];
    cout << endl;
#endif
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "Combination (n choose k)");
    ulong k = 3;
    NXARG(k, " 0 < k <= n");
    ulong rq = 2;
    NXARG(rq, "Order: 0==>lex,  1==>Gray,  2==>near-perfect,  3==>diagonal Gray");
    ulong nq = 0;
    NXARG(nq, "Whether to reverse order.");

    comb_rec C(n,k);
    C.generate(visit, rq, nq);

#ifndef TIMING
    ulong rct = C.rct_;
    cout << "rct=" << rct << endl;
    cout << "work/object=" << 1.0*(rct)/(C.ct_) << endl;  // ratio <= n
    jjassert( C.ct_==binomial(n,k) );
#else
    cout << " ct = " << C.ct_ << endl;
#endif

    return 0;
}
// -------------------------

/*
Timing:
 % time ./bin 32 20
arg 1: 32 == n  [Combination (n choose k)]  default=7
arg 2: 20 == k  [ 0 < k <= n]  default=3
arg 3: 2 == rq  [Order: 0==>lex,  1==>Gray,  2==>near-perfect,  3==>diagonal Gray]  default=2
arg 4: 0 == nq  [Whether to reverse order.]  default=0
 ct = 225792840
./bin 32 20  7.00s user 0.03s system 99% cpu 7.024 total
 ==> 32,145,905 comb/sec

 % time ./bin 32 12
arg 1: 32 == n  [Combination (n choose k)]  default=7
arg 2: 12 == k  [ 0 < k <= n]  default=3
arg 3: 2 == rq  [Order: 0==>lex,  1==>Gray,  2==>near-perfect,  3==>diagonal Gray]  default=2
arg 4: 0 == nq  [Whether to reverse order.]  default=0
 ct = 225792840
./bin 32 12  4.97s user 0.02s system 99% cpu 4.995 total
 ==> 45,203,771 comb/sec
*/


// ./bin 7 4 | tr '.1' '1.' | tac | rev
// n=10; for (( k=0; k<=n; ++k )); do ./bin $n $k 0 | grep work ; done


//  for (( n=0; n<=7; ++n )); do echo "$n:  "; for (( k=0; k<=n; ++k )); do ./bin $n $k 0 | grep rct | sed -r 's/rct=/ /;' ; done; done
//
//  0:   0
//  1:   0 0
//  2:   0 1 0
//  3:   0 1 2 0
//  4:   0 1 3 3 0
//  5:   0 1 4 6 4 0
//  6:   0 1 5 10 10 5 0
//  7:   0 1 6 15 20 15 6 0
