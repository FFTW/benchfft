

#include "comb/permrestrpref.h" // class perm_restrpref

#include "fxtiomanip.h"
#include "aux0/swap.h"
#include "fxttypes.h"

//#include "perm/permq.h" // is_involution(), is_indecomposable()
//#include "jjassert.h"

#include "demo/nextarg.h" // NXARG()

//% Permutation with restricted prefixes


void visit(const ulong *a, ulong n, ulong ct)
// What to do with valid permutations.
// Here: simply print them
{
    cout << setw(3) << ct << ": ";
    for (ulong i=1; i<=n; ++i)  cout << "  " << a[i];

//    ulong z[n];  for (ulong k=0; k<n; ++k) z[k] = a[k+1]-1;
//    if ( is_cyclic(z, n) )  cout << "  Cyc";
//    if ( is_indecomposable(z, n) )  cout << "  Ind";
//    if ( is_involution(z, n) )  cout << "  Inv";
//    if ( is_updown_permutation(z, n) )  cout << "  UpD";
//    if ( is_derangement(z, n) )  cout << "  Der";

    cout << endl;
}
// -------------------------


bool cond_0(const ulong *, ulong)
// trivial (empty) condition
{
    return true;
}
// -------------------------

bool cond_inv(const ulong *a, ulong k)
// involution condition
{
    ulong ak = a[k];
    if ( (ak<=k) && (a[ak]!=k) )  return false;
    return true;
}
// -------------------------

bool cond_updown(const ulong *a, ulong k)
// up-down condition: a1<a2>a3<a4> ...
{
//    if ( k<3 ) return true;
//    if ( a[k]>a[k-1] )   return ( a[k-1]<a[k-2] );
//    else                 return ( a[k-1]>a[k-2] );
    if ( k<2 ) return true;
    if ( (k%2) )  return ( a[k]<a[k-1] );
    else          return ( a[k]>a[k-1] );
}
// -------------------------

ulong N;  // set to n in main()
bool cond_indecomp(const ulong *a, ulong k)
// indecomposable condition: {a1,...,ak} != {1,...,k} for all k<n
{
    if ( k==N )  return true;
    for (ulong i=1; i<=k; ++i)  if ( a[i]>k )  return true;
    return false;
}
// -------------------------

bool cond_derange(const ulong *a, ulong k)
// derangement condition: f[k]!=k for all k
{
    return ( a[k]!=k );
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Permutations of {1,2,...,n}");
    N = n;

    ulong c = 2;
    NXARG(c, "Condition function: "
          "\n      (0: empty), (1: involutions),"
          "\n      (2: up-down), (3: indecomp), (4: derangement)");

    perm_restrpref *perm;
    switch ( c )
    {
    case 0: perm = new perm_restrpref(n, cond_0, visit);  break;
    case 1: perm = new perm_restrpref(n, cond_inv, visit);  break;
    case 2: perm = new perm_restrpref(n, cond_updown, visit);  break;
    case 3: perm = new perm_restrpref(n, cond_indecomp, visit);  break;
    case 4: perm = new perm_restrpref(n, cond_derange, visit);  break;
    default: return 1;
    }
    ulong ct = perm->all();
    cout << " #perm = " << ct << endl;
    delete perm;

    return 0;
}
// -------------------------

// involutions:
//   1 #perm = 1
//   2 #perm = 2
//   3 #perm = 4
//   4 #perm = 10
//   5 #perm = 26
//   6 #perm = 76
//   7 #perm = 232
//   8 #perm = 764
//   9 #perm = 2620
//  10 #perm = 9496
//  11 #perm = 35696
//  12 #perm = 140152
//  13 #perm = 568504

// up-down:
//   1 #perm = 1
//   2 #perm = 1
//   3 #perm = 2
//   4 #perm = 5
//   5 #perm = 16
//   6 #perm = 61
//   7 #perm = 272
//   8 #perm = 1385
//   9 #perm = 7936
//  10 #perm = 50521
//  11 #perm = 353792

// indecomp:
//   1 #perm = 1
//   2 #perm = 1
//   3 #perm = 3
//   4 #perm = 13
//   5 #perm = 71
//   6 #perm = 461
//   7 #perm = 3447
//   8 #perm = 29093
//   9 #perm = 273343
//  10 #perm = 2829325

// derangement:
//   1 #perm = 0
//   2 #perm = 1
//   3 #perm = 2
//   4 #perm = 9
//   5 #perm = 44
//   6 #perm = 265
//   7 #perm = 1854
//   8 #perm = 14833
//   9 #perm = 133496
//  10 #perm = 1334961
