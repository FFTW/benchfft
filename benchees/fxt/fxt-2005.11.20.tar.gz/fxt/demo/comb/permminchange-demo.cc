
#include "comb/permminchange.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in minimal-change order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");
    bool piq = 0;
    NXARG(piq, "Option: print internal data.");

    perm_minchange perm(n);

#ifdef TIMING
    while ( perm.next() ) {;}
#else
    const ulong *x = perm.data();
    const ulong *ix = perm.invdata();
    ulong ct = 0;
    ulong sw1, sw2;
    do
    {
        cout << "   " << setw(3) << ct << ":   ";
        ++ct;

        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm.get_swap(sw1, sw2);
        cout << "  swap: (" << sw1 << ", " << sw2 << ") ";

        cout << "  inv= ";
        for (ulong i=0; i<n; ++i)  cout << ix[i] << " ";

        if ( piq )
        {
            cout << "    d= ";
            for (ulong i=0; i<n; ++i)  cout << (perm.d_[i]==1 ? '+' : '-' ) << " ";

            cout << "  ii= ";
            for (ulong i=0; i<n; ++i)  cout << perm.ii_[i] << " ";
        }

        cout << endl;
    }
    while ( perm.next() );
#endif

    return 0;
}
// -------------------------


/*
Timing:
time ./bin 12
./bin 12  5.47s user 0.03s system 100% cpu 5.508 total
 ==> 12!/ 5.508 == 86,964,705 permutations per second
*/
