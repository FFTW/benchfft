
#include "comb/mixedradix-lex.h"

#include "aux1/copy.h" // fill()

#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"
#include "fxtalloca.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()

//% Mixed radix numbers in lexicographic order.

//#define TIMING // uncomment to disable printing

void
print_mr(const ulong *x, ulong n)
{
    for (ulong j=0; j<n; ++j)
    {
        ulong v = x[j];
        cout << " ";
        if ( 0==v )  cout << '.';
        else         cout << v;
    }
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n,"Number of digits")

    ALLOCA(ulong, r, n);
    ulong rr = 3;
    NXARG(rr, "Base (radix) of digits");
    fill(r, n, rr);
    RESTARGS("Optionally supply radix for second...last digit")
    for (ulong k=3;  k<(ulong)argc; ++k)  r[k-2] = atol(argv[k]);

    mixedradix_lex mrl(r, n);
//    mrl.last();

    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << " " << setw(4) << ct << ":  ";
        print_mr( mrl.data(), n );
        cout << endl;
#endif // TIMING
        ++ct;
    }
    while ( mrl.next() );
//    while ( mrl.prev() );

    cout << " # = " << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:
% time ./bin 30 2  ## binary is worst case
arg 1: 30 == n  [Number of digits]  default=4
arg 2: 2 == rr  [Base (radix) of digits]  default=3
args 3,4,... : [Optionally supply radix for second...last digit]
 # = 1073741824
./bin 30 2  8.97s user 0.04s system 99% cpu 9.050 total
 ==> 1073741824/9.050 == 118,645,505 objects per second

% time ./bin 16 4
arg 1: 16 == n  [Number of digits]  default=4
arg 2: 4 == rr  [Base (radix) of digits]  default=3
args 3,4,... : [Optionally supply radix for second...last digit]
 # = 4294967296
./bin 16 4  25.13s user 0.13s system 99% cpu 25.265 total
 ==> 4294967296/25.26 == 170,030,375 objects per second

% time ./bin 10 8
arg 1: 10 == n  [Number of digits]  default=4
arg 2: 8 == rr  [Base (radix) of digits]  default=3
args 3,4,... : [Optionally supply radix for second...last digit]
 # = 1073741824
./bin 10 8  4.74s user 0.02s system 99% cpu 4.756 total
 ==> 1073741824/4.756 == 225,765,732 objects per second

% time ./bin 8 16
arg 1: 8 == n  [Number of digits]  default=4
arg 2: 16 == rr  [Base (radix) of digits]  default=3
args 3,4,... : [Optionally supply radix for second...last digit]
 # = 4294967296
./bin 8 16  15.69s user 0.08s system 99% cpu 15.795 total
 ==> 4294967296/15.795 == 271,919,423 objects per second
*/
