
// demo-include "comb/cyclic2fact.cc"
// demo-include "comb/mixedradix-gray.h"

#include "comb/perm2fact.h"
#include "comb/cyclic-perm.h"

#include "perm/perminvert.h"
#include "perm/printperm.h"

#include "fxtio.h"
#include "fxttypes.h"
#include "demo/nextarg.h"

#include "jjassert.h"
#include "perm/permq.h"  // is_cyclic()


//% Generate all cyclic permutations in minimal-change order, CAT algorithm.


//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Cyclic permutations of n elements.");
    ulong nmax = 0;
    NXARG(nmax, "Stop after that many permutations (0==>don't stop).");

    cyclic_perm perm(n);
    ulong *t = new ulong[n];
    const ulong *x = perm.data();
    const ulong *ix = perm.invdata();
    const ulong *a = perm.mrg_->data();
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << "   " << setw(3) << perm.current() << ":";

        cout << "    ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
//        cout << "    ";
//        for (ulong i=0; i<n; ++i)  cout << ix[i] << " ";

        ulong z = perm.mrg_->n_;
        cout << "    a= ";
        for (ulong i=0; i<z; ++i)  cout << a[i] << " ";

        cout << "    ";
        print_cycle(x, n-1);
        cout << endl;

        ffact2cyclic(a, n, t);
        for (ulong i=0; i<n; ++i)  { jjassert(t[i]==ix[i]); }

        jjassert( is_cyclic(x, n) );
        jjassert( is_inverse(x, ix, n) );

        ++ct;
        if ( nmax && (ct > nmax) )  break;
#endif
    }
    while ( perm.next() );

    return 0;
}
// -------------------------

// Timing: (2Ghz AMD Athlon XP)
// ./bin 12  1.79s user 0.00s system 99% cpu 1.796 total
// (12-1)! == 11!  permutations
// 1.796*2*10^9/11!  == 90 cycles/perm
// time*(cycles/sec)/num == cycles/perm
