

#include "comb/perm2fact.h"
// demo-include "comb/cyclic2fact.cc"
#include "comb/mixedradix-modular-gray.h"
#include "perm/perminvert.h"  // make_inverse()
#include "perm/permq.h"  // is_cyclic()

#include "perm/printperm.h"

#include "comb/permgray.h"
#include "comb/mixedradix.h"
#include "comb/mixedradix-lex.h"
#include "comb/mixedradix-gray.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "demo/nextarg.h"  // NXARG()
#include "fxtio.h"

#include <cstdlib> // atol()



//% Generate all cyclic permutations from mixed radix numbers.

void
print(const char *bla, const ulong *f, ulong n)
{
    if ( bla )  cout << bla;
    cout << "[ ";
    for (ulong k=0; k<n; ++k)
    {
        ulong z = ((long)f[k]);
        if ( z ) cout << z;  else cout << '.';
        cout << (k<n-1?", ":"");
    }
    cout << " ]";
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Number of elements to permute");
    bool rq = 1;
    NXARG(rq, "Whether to use reversed base with mixed radix counting");

    ulong n2 = n - 2;
    ulong *m = new ulong[n2];

    if ( rq )  for (ulong k=0; k<n2; ++k)  m[k] = k+2;  // factorial base
    else       for (ulong k=0; k<n2; ++k)  m[k] = n-1-k;  // reversed factorial base

    print(" Radix: ", m, n2);  cout << endl;

//    mixedradix_gray mr(m, n2);
    mixedradix_modular_gray mr(m, n2);
//    mixedradix mr(m, n2);
//    mixedradix_lex mr(m, n2);
    const ulong *a = mr.data();

    ulong *p = new ulong[n];  // permutation
    ulong *ip = new ulong[n];  // inverse permutation
    ulong ct = 0;
    do
    {
        cout << " " << setw(3) << ct << ":";

        if ( rq )  rfact2cyclic(a, n, p);
        else       ffact2cyclic(a, n, p);

        print("    ", a, n2);
        print("  ", p, n);
        cout << "    ";   print_cycle(p, 0);


        cout << "    |  ";
        make_inverse(p, ip, n);
        print("    ", ip, n);

        ++ct;
        cout << endl;

        jjassert( is_cyclic(p, n) );
//        jjassert( is_cyclic(ip, n) );
    }
    while ( mr.next() );

    return 0;
}
// -------------------------


