
#include "comb/ksubset-rec.h"
// demo-include "comb/ksubset-rec.cc"

#include "aux0/binomial.h"
#include "aux1/auxprint.h"
#include "bits/printbin.h"
#include "bits/bitcount.h"

#include "jjassert.h"
#include "fxtiomanip.h"
#include "demo/nextarg.h"
#include "fxttypes.h"


//% k-subsets where kmin<=k<=kmax in various orders.
//% Recursive CAT algorithm.

//#define TIMING // uncomment to disable printing

inline bool max2adj(ulong x)
{
    ulong c = bit_count(x);
    if ( c<=1 )  return true;
    if ( c>2 )  return false;
    if ( x&(x>>1) ) return true;
    if ( x&(x<<1) ) return true;
    return false;
}
// -------------------------

#ifdef TIMING
void visit(const ksubset_rec &, long ) {;}
#else
ulong bo=0;
void visit(const ksubset_rec &C, long k)
{
    cout << setw(4) << C.ct_ << ":";
    const ulong *rv = (const ulong *)C.rv_;
//    print_set_as_bitset("    ", rv, k, C.n_);
    ulong b = 0;  for (long j=0; j<k; ++j)  b |= (1UL<<(C.n_-1-rv[j]));
    print_bin_nn("   ", b, C.n_);
    if ( C.ct_==0 )  bo = b;
    print_bin_diff_nn("   ", bo, b, C.n_, "..PM");
//    cout << "   %" << k;
    cout << "   ";
    for (long j=0; j<k; ++j)  cout << " " << C.rv_[j];
//    ulong x = b ^ bo;
//    if ( 2 < bit_count(x) )  cout << " %";
//    if ( !max2adj(x) )  cout << " %";
    cout << endl;
    bo = b;
}
// -------------------------
#endif // TIMING


int
main(int argc, char **argv)
{
    ulong n = 6;
    NXARG(n, "Subsets of n-element set.");
    ulong rq = 7;
    NXARG(rq, "Type of ordering 0<=rq<16.");
    long kmin = 0;
    NXARG(kmin, "Minimal number of elements in subsets.");
    long kmax = n;
    NXARG(kmax, "Maximal number of elements in subsets.");
    ulong nq = 0;
    NXARG(nq, "Whether to reverse order (zero or one).");

    ksubset_rec C(n);

    C.generate(visit, kmin, kmax, rq, nq);

    cout << "num=" << C.ct_ << endl;

    ulong rct = C.rct_;
    cout << "rct=" << rct << endl;
    cout << "work/object=" << 1.0*(rct)/(C.ct_) << endl;  // ratio <= n

    ulong z = 0;
    for (long k=kmin; k<=kmax; ++k)  z += binomial(n,k);
    jjassert( C.ct_==z );

    return 0;
}
// -------------------------

/*
 ./bin n rq kmin kmax nq

Try these:

 ./bin 6  4
 ./bin 6  7
 ./bin 6  8
 ./bin 6  9
 ./bin 6 10
 ./bin 6 11

 ./bin 7  0 3 3
 ./bin 7  1 3 3
 ./bin 7  2 3 3
 ./bin 7  3 3 3

 ./bin 7  6 2 3
 ./bin 7  7 2 3
 ./bin 7  9 2 3
 ./bin 7 10 2 3
*/

/*
Timing:
 time ./bin 27 
arg 1: 27 == n  [Subsets of n-element set.]  default=6
arg 2: 7 == rq  [Type of ordering.]  default=7
arg 3: 0 == kmin  [Minimal number of elements in subsets.]  default=0
arg 4: 27 == kmax  [Maximal number of elements in subsets.]  default=27
arg 5: 0 == nq  [Whether to modify order.]  default=0
num=134217728
rct=134217728
work/object=1
./bin 27  2.76s user 0.02s system 99% cpu 2.777 total

 134217728/2.777
 == 48,331,915.016 objects per second
 == (2.2*10^9)/(134217728/2.777) == 45.518  cycles per objects (2.2GHz AMD64)

without conditional print statements in recursion:
 134217728/2.300
 == 58,355,533.9130 objects per second
 == 38 cycles per objects (2.2GHz AMD64)
*/

