
#include "comb/partition.h"

#include "fxttypes.h"
#include "aux1/copy.h" // set_seq()

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtio.h"

//% Generate all integer partitions.

//#define TIMING // uncomment to disable printing

void
print_part(ulong n)
{
        partition pp(n);
        ulong ct = 0;

        while ( pp.next() < n )
        {
#ifndef TIMING
            cout << "    #" << setw(2) << ct << ": ";
            cout << setw(4) << pp.x_ << " == ";
            pp.print2();
            cout << "  ==  ";
            pp.print();
            cout << endl;
#endif // TIMING
            ++ct;
        }
        cout << " " << n << ":  ct=" << ct << endl;
        cout << endl;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong nmax = 6;
    NXARG(nmax, "Shown all partitions for n<=nmax");
    ulong cmax = 30;
    NXARG(cmax, "Count number of partitions for n<=cmax");

#ifndef TIMING
    for (ulong j=1; j<nmax; ++j)
    {
        print_part(j + 1);
    }
    cout << endl;


    if ( cmax )
    {
        cout << "----------- Number of partitions of n into 1,2,3,...,n:" << endl;
        for (ulong j=1; j<cmax; ++j)
        {
            ulong x = j;
            ulong len = x;  // ==ceil(x/min(v_i))
            partition pp(len);
            ulong ct = pp.count(x);
            cout << " ct=" << x << ":  " << ct << endl;
        }
    }
#else // TIMING
        print_part(nmax);
#endif // TIMING

    return 0;
}
// -------------------------

/*
Timing:
 % time ./bin 100
arg 1: 100 == nmax  [Shown all partitions for n<=nmax]  default=6
arg 2: 30 == cmax  [Count number of partitions for n<=cmax]  default=30
 100:  ct=190569292
./bin 100  10.55s user 0.04s system 99% cpu 10.615 total
 ==> 17,952,830 part/sec
*/
