

#include "comb/perm2fact.h"
// demo-include "comb/perm2fact.cc"
#include "perm/perminvert.h"  // make_inverse()
// demo-include "perm/perminvert.cc"
#include "comb/mixedradix-modular-gray.h"

#include "comb/permgray.h"
#include "comb/mixedradix.h"
#include "comb/mixedradix-lex.h"
#include "comb/mixedradix-gray.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "demo/nextarg.h"  // NXARG()
#include "fxtio.h"

#include <cstdlib> // atol()



//% Generate all permutations from mixed radix numbers.

void
print(const char *bla, const ulong *f, ulong n)
{
    if ( bla )  cout << bla;
    cout << "[ ";
    for (ulong k=0; k<n; ++k)
    {
        ulong z = ((long)f[k]);
        if ( z ) cout << z;  else cout << '.';
        cout << (k<n-1?", ":"");
    }
    cout << " ]";
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");
    bool rq = 0;
    NXARG(rq, "Whether to use reversed base with mixed radix counting");

    ulong n1 = n - 1;
    ulong *m = new ulong[n1];

    if ( rq )  for (ulong k=0; k<n1; ++k)  m[k] = k+2;  // factorial base
    else       for (ulong k=0; k<n1; ++k)  m[k] = n-k;  // reversed factorial base

    print(" Radix: ", m, n1);  cout << endl;

//    mixedradix_gray mr(m, n1);
    mixedradix_modular_gray mr(m, n1);
//    mixedradix mr(m, n1);
//    mixedradix_lex mr(m, n1);

    const ulong *a = mr.data();
    ulong *ia = new ulong[n1];
    ulong *t = new ulong[n];  // for testing

    ulong *p = new ulong[n];  // permutation
    ulong *ip = new ulong[n];  // inverse permutation
    ulong ct = 0;
    do
    {
        cout << " " << setw(3) << ct << ":";

        if ( rq )  rfact2perm(a, n, p);
        else       ffact2perm(a, n, p);

        print("    ", a, n1);
        print("  ", p, n);

        cout << "    |  ";
        make_inverse(p, ip, n);
        if ( rq ) perm2rfact(ip, n, ia);
        else      perm2ffact(ip, n, ia);
        print("    ", ip, n);
        print("  ", ia, n1);

        ++ct;
        cout << endl;


        // Testing that Xfact2perm() is inverse of perm2Xfact():
        if ( rq )  perm2rfact(p, n, t);
        else       perm2ffact(p, n, t);
//        print("    ", t, n);  cout << endl;
        for (ulong j=0; j<n-1; ++j)  { jjassert(t[j]==a[j]); }
    }
    while ( mr.next() );

    return 0;
}
// -------------------------


