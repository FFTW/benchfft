
#include "comb/permtrotter.h"

#include "perm/perminvert.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in minimal-change order using Trotter's algorithm.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements (n>=2).");
    if ( n<2 )  n = 2;

    perm_trotter perm(n);
#ifdef TIMING
    while ( perm.next() )  {;}
#else
    const ulong *x = perm.data();
    ulong *ii = new ulong[n];
    ulong ct = 0;
    ulong sw1, sw2;
    do
    {
        cout << "   " << setw(3) << ct << ":   ";
        ++ct;

        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm.get_swap(sw1, sw2);
        cout << "    swap: (" << sw1 << ", " << sw2 << ") ";

//        cout << "  p_= ";
//        for (ulong i=0; i<n; ++i)  cout << perm.p_[i] << " ";

        make_inverse(x, ii, n);
        cout << "    i= ";
        for (ulong i=0; i<n; ++i)  cout << ii[i] << " ";

        cout << endl;
    }
    while ( perm.next() );
#endif

    return 0;
}
// -------------------------

/*
 Timing:
 time ./bin 12
./bin 12  3.39s user 0.01s system 100% cpu 3.400 total
 12!/3.400 == 140,882,823 permutations per second
 ==> about 15 cycles per update
*/
