
// demo-is-self-contained

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "jjassert.h"
#include "demo/nextarg.h"


//% Gray code for Pell words, recursive CAT algorithm

ulong n; // Length of words
ulong *rv;  // record of visits in graph

ulong ct;   // count objects
ulong rct;  // count recursions (==work)

bool zq;  // 0==>Lex  1==>Gray


void visit()
{
    cout << setw(4) << ct << ":";
    cout << "   ";
    for (ulong j=0; j<n; ++j)
    {
        cout << " ";
        if ( 0==rv[j] )   cout << '.';
        else   cout << rv[j];
    }
    cout << endl;
}
// -------------------------


void pell_rec(ulong d, bool z)
{
    if ( d>=n )
    {
        ++ct;  // count objects
        visit();
    }
    else
    {
        ++rct;  // measure computational work
        if ( 0==z )
        {
            rv[d]=0;  pell_rec(d+1, z);
            rv[d]=1;  pell_rec(d+1, zq^z);
            rv[d]=2;  rv[d+1]=0;  pell_rec(d+2, z);
        }
        else
        {
            rv[d]=2;  rv[d+1]=0;  pell_rec(d+2, z);
            rv[d]=1;  pell_rec(d+1, zq^z);
            rv[d]=0;  pell_rec(d+1, z);
        }
    }
}
// -------------------------


int
main(int argc, char **argv)
{
    n = 4;
    NXARG(n, "Length of words");
    rv = new ulong[n+2];
    zq = 1;
    NXARG(zq, " 0==>Lex order  1==>Gray code");
    bool rq = 0;
    NXARG(rq, "Whether to reverse order");

    ct = 0;
    rct = 0;
    pell_rec(0, rq);

//    cout << "rct=" << rct << endl;
    cout << "work/object=" << 1.0*(rct)/(ct) << endl;  // ratio <= 0.5

    return 0;
}
// -------------------------
