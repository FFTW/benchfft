
#include "comb/combination-minchange.h"

#include "fxttypes.h"
#include "jjassert.h"
//#include "aux1/auxprint.h"

#include "bits/printbin.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include "demo/nextarg.h"

//% Generating all combinations in minimal-change order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    NXARG(n, "Combinations (n choose k)");
    NXARG(k,"");

    ulong ct = 0;
    combination_minchange comb(n, k);

    comb.first();
//    comb.last();
    do
    {
#ifndef TIMING
        ulong bits = comb.bits_;
        cout << "   ";
        for (long k=n-1; k>=0; --k)  cout << ((bits>>k)&1 ? '1' : '.');
        cout << "   [ " << comb << " ]  ";
        cout << "  swap: (" << comb.sw1_ << ", " << comb.sw2_ << ") ";
        cout << "  #" << setw(3) << ct;
        cout << endl;
#endif // TIMING
        ++ct;
    }
    while ( comb.next() );
//    while ( comb.prev() );

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:
 % time ./bin 32 20
arg 1: 32 == n  [Combinations (n choose k)]  default=7
arg 2: 20 == k  []  default=4
 ct = 225792840
./bin 32 20  32.09s user 0.17s system 99% cpu 32.324 total
 ==> 6,985,300 comb/sec (slow!)
*/
