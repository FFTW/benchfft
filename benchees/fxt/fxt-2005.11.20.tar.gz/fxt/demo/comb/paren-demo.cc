
#include "comb/paren.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "aux1/auxprint.h"

#include "demo/nextarg.h"
#include "jjassert.h"


//% Generate all well-formed pairs of parenthesis.

//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong k = 5;
    NXARG(k, "Number of paren pairs >=2");

    bool bwq = 0;
    NXARG(bwq, "Whether to also generate in backward direction");

    ulong n = 2*k;
    ulong ct = 0;

    paren par(k);

    do
    {
#ifndef TIMING
        cout << "  " << par.string() << "  ";
        print_set_as_bitset("", par.data(), k, n );
        cout << "  #" << setw(3) << ct;
        cout << endl;
        jjassert( par.OK() );
#endif // TIMING
        ++ct;
    }
    while ( par.next() );

#ifndef TIMING
    cout << endl;
    if ( bwq )
    {
        par.last();
        do
        {
            --ct;
            cout << "  " << par.string() << "  ";
            print_set_as_bitset("", par.data(), k, n );
            cout << "  #" << setw(3) << ct;
//            for (ulong j=0; j<k; ++j)  cout << "  " << par.data()[j];
            cout << endl;
            jjassert( par.OK() );
        }
        while ( par.prev() );
        cout << endl;
        jjassert( 0==ct );
    }
#else // TIMING
    cout << " ct = " << ct << endl;
#endif // TIMING

    return 0;
}
// -------------------------


/*
Timing:
 % time ./bin 18
arg 1: 18 == k  [Number of paren pairs >=2]  default=5
arg 2: 0 == bwq  [Whether to also generate in backward direction]  default=0
 ct = 477638700
./bin 18  7.39s user 0.03s system 99% cpu 7.433 total
 ==> 64,259,208 objects/sec
*/
