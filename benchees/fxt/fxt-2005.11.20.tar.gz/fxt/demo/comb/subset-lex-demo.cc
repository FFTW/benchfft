
#include "comb/subset-lex.h"

#include "bits/printbin.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "fxtiomanip.h"
#include "aux1/auxprint.h"
#include "demo/nextarg.h"


//% Generate all subsets in lexicographic order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Size of the set");
    subset_lex sl(n);

#ifdef TIMING
    while ( sl.next() )  {;}

#else // TIMING
    ulong idx = 0;
    ulong num = sl.first();
    const ulong *x = sl.data();
    do
    {
        cout << setw(2) << idx;
        ++idx;

        cout << "  #=" << setw(2) << num << ":  ";
        print_set_as_bitset("  ", x, num, n);
        print_set("  ", x, num);
        cout << endl;
    }
    while ( (num = sl.next()) );

    cout << endl;
    num = sl.last();
    do
    {
        cout << setw(2) << idx;
        ++idx;

        cout << "  #=" << setw(2) << num << ":  ";
        print_set_as_bitset("  ", x, num, n);
        print_set("  ", x, num);
        cout << endl;
    }
    while ( (num = sl.prev()) );
#endif // TIMING

    return 0;
}
// -------------------------

/*
Timing:
% time ./bin 30
arg 1: 30 == n  [Size of the set]  default=5
./bin 30  4.56s user 0.02s system 99% cpu 4.582 total
 ==> 2^30/4.582 == 234,339,114 subsets per second
*/
