
#include "comb/permstar.h"

#include "perm/permq.h"
#include "jjassert.h"

#include "fxttypes.h"
#include "demo/nextarg.h"  // NXARG()
#include "fxtio.h"

#include <cstdlib> // atol()

//% Generate all permutations in star-transpostion order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements to permute");

    perm_star perm(n);
#ifdef TIMING
    while ( perm.next() )  {;}
#else
    const ulong *x = perm.data();
    const ulong *xi = perm.invdata();
    ulong ct = 0;
    do
    {
        cout << "   " << setw(3) << ct << ":   ";
        ++ct;
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
        cout << "  swap: (" << 0 << ", " << perm.get_swap() << ") ";

        cout << "  inv= ";
        for (ulong i=0; i<n; ++i)  cout << xi[i] << " ";
        cout << endl;
        jjassert ( is_inverse(x, xi, n) );
    }
    while ( perm.next() );
#endif

    return 0;
}
// -------------------------

/*
Timing:
time ./bin 12

./bin 12  6.14s user 0.02s system 99% cpu 6.163 total
 ==> 12!/6.163 == 77,722,148 permutations per second (with inverse)

./bin 12  4.15s user 0.02s system 100% cpu 4.173 total
 ==>  12!/4.173 == 114,785,909 (without inverse)
*/
