
#include "comb/combination-chase.h"
#include "aux0/binomial.h"

#include "fxttypes.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtiomanip.h"

//%  Generating all combinations in near-perfect minimal-change order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "(n choose k): n>=1");
    ulong k = 3;
    NXARG(k, "(n choose k):  1<=k<=n");
    bool rq = 0;
    NXARG(rq, "Option: print in reverse order");

    if ( (k>n) || ( k==0 ) || ( n==0 ) )  { return 1; }

    combination_chase cnp(n,k);

    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << setw(3) << ct << ":  ";

        const ulong *x = cnp.get();
        if ( rq )
        {
            for (ulong j=0; j<n; ++j)  if ( x[n-1-j] ) cout << " " << (n-1-j);
            cout << "    ";
            for (ulong j=0; j<n; ++j)  cout << " " << (x[n-1-j] ? '1' : '.');
        }
        else
        {
            for (ulong j=0; j<n; ++j)  if ( x[j] ) cout << " " << j;
            cout << "    ";
            for (ulong j=0; j<n; ++j)  cout << " " << (x[j] ? '1' : '.');
        }

        cout << endl;
#endif
        ++ct;
    }
    while ( cnp.next() );

    ulong bnk =  binomial(n, k);
    cout << "binomial(" << n << ", " << k << ")=" << bnk << endl;
    jjassert( bnk==ct );
    cout << endl;

    return 0;
}
// -------------------------

// for n in $(seq 1 10); do for k in $(seq 1 $n); do ./bin $n $k || break 2; done; done

/*
Timing:
% time ./bin 35 10
arg 1: 35 == n  [(n choose k): n>=1]  default=7
arg 2: 10 == k  [(n choose k):  1<=k<=n]  default=3
arg 3: 0 == rq  [Option: print in reverse order]  default=0
binomial(35, 10)=183579396
./bin 35 10  2.75s user 0.00s system 99% cpu 2.756 total
 ==> 66,610,811 objects per second
*/
