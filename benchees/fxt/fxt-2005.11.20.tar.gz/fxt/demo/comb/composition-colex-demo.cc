
#include "comb/composition-colex.h"
#include "bits/bit2composition.h"

#include "bits/printbin.h"
#include "demo/nextarg.h"

#include "fxttypes.h"
#include "fxtio.h"


//% Generating all k-compositions of n in co-lexicographic (colex) order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong k = 5, n = 3;
    NXARG(k, "k-compositions of n (k>=1) ");
    NXARG(n, " (n>=1)");

    composition_colex p(n, k);
    ulong wn = n+k-1;
    const ulong *x = p.data();
    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << " #" << setw(3) << ct << ":   ";
        for (ulong i=0; i<k; ++i)  cout << x[i] << " ";
        ulong w = composition2bit(x, wn);
        print_binv_nn("   ", w, wn);
        cout << endl;
#endif
        ++ct;
    }
    while ( p.next() );

    cout << "  #= " << ct << endl;

    return 0;
}
// -------------------------


/*
Timing:
% time ./bin 30 10
arg 1: 30 == k  [k-compositions of n (k>=1) ]  default=5
arg 2: 10 == n  [ (n>=1)]  default=3
  #= 635745396
./bin 30 10  5.82s user 0.04s system 99% cpu 5.869 total
  ==> 108,322,609 combinations per second
*/
