
#include "comb/composition-chase.h"
#include "aux0/binomial.h"

#include "fxttypes.h"

#include "jjassert.h"
#include "demo/nextarg.h"

#include "fxtiomanip.h"

//%  Generating all k-compositions of n in a near-perfect order (Chase's sequence).

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong k = 5, n = 3;
    NXARG(k, "k-compositions of n (k>=1) ");
    NXARG(n, " (n>=1)");

    composition_chase cnp(n,k);
    ulong N = cnp.N_,  K=cnp.K_;
    ulong bnk =  binomial(N, K);
    cout << "Using (" << N << " choose " << K << ") combinations." << endl;
    cout << "binomial(" << N << ", " << K << ")=" << bnk << endl;

    ulong ct = 0;
    do
    {
#ifndef TIMING
        cout << setw(3) << ct << ":   ";
        const ulong *x = cnp.get_combination();
        for (ulong j=0; j<N; ++j)  if ( x[j] ) cout << " " << j;
        cout << "    ";
        for (ulong j=0; j<N; ++j)  cout << " " << (x[j] ? '1' : '.');

        const ulong *p = cnp.get();
        cout << "    ";
        for (ulong j=0; j<k; ++j)  cout << " " << p[j];

        cout << endl;
#endif
        ++ct;
    }
    while ( cnp.next() );

    jjassert( bnk==ct );
    cout << endl;

    return 0;
}
// -------------------------

// for n in $(seq 1 10); do for k in $(seq 1 $n); do ./bin $n $k || break 2; done; done

/*
Timing:
% time ./bin-chase 25 10
arg 1: 25 == k  [k-compositions of n (k>=1) ]  default=5
arg 2: 10 == n  [ (n>=1)]  default=3
Using (34 choose 10) combinations.
binomial(34, 10)=131128140
./bin-chase 25 10  21.79s user 0.11s system 99% cpu 21.936 total
 ==> 5,977,759 compositions per second (SLOW due to method comb2comp())
*/
