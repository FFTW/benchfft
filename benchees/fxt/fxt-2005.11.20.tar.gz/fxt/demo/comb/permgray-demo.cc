
#include "comb/permgray.h"

#include "comb/permgray2.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "demo/nextarg.h"


//% Generate all permutations in minimal-change order using a loopless algorithm.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Permutations of n elements.");

    perm_gray perm(n);
//    perm_gray2 perm(n);

#ifdef TIMING
    while ( perm.next() ) {;}
#else
    const ulong *x = perm.data();
    const ulong *ix = perm.invdata();
    ulong ct = 0;
    ulong sw1, sw2;
    do
    {
        cout << "   " << setw(3) << ct << ":   ";
        ++ct;

        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm.get_swap(sw1, sw2);
        cout << "  sw(" << sw1 << ", " << sw2 << ")";

        cout << "    ";
        for (ulong i=0; i<n; ++i)  cout << ix[i] << " ";

        const ulong *a = perm.mrg_->data();
        cout << "    a= ";
        for (ulong i=0; i<n-1; ++i)  cout << a[i] << " ";

        cout << endl;
    }
    while ( perm.next() );
#endif // TIMING

    return 0;
}
// -------------------------


/*
 Timing:

 time ./bin 12  // class perm_gray
./bin 12  7.36s user 0.04s system 100% cpu 7.395 total
 12!/7.395 == 64,773,711 permutations per second

 time ./bin 12  // class perm_gray2
./bin 12  5.50s user 0.02s system 99% cpu 5.519 total
12!/5.519 == 86,791,375 permutations per second
*/
