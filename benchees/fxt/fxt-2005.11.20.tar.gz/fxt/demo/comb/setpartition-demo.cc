
#include "comb/setpartition.h"
// demo-include "comb/setpartition.cc"

//#include "jjassert.h"
#include "fxtiomanip.h"
#include "fxttypes.h"

#include "demo/nextarg.h"

//% Set partitions.


//#define TIMING // uncomment to disable printing


int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Partition set of n elements");
    bool xdr = true;
    NXARG(xdr, "Change direction in recursion ==> minimal change order");
    int dr0 = +1;
    NXARG(dr0, "Starting direction in recursion (+-1)");
    dr0 = ( (dr0>0) ? +1 : -1 );
    ulong maxct = 0;
    NXARG(maxct, "Stop after maxct partitions (0: never stop)");
    bool priq = true;
    NXARG(priq, "Option: print internal state with each partition");

    set_partition sp(n, xdr, dr0);

    ulong ct = 0;
    do
    {
        ++ct;
#ifndef TIMING
        cout << setw(3) << ct << ":  ";
        if ( priq )  sp.print_internal();
        sp.print();
        cout << endl;
        if ( maxct && (ct>maxct) )  break;
#endif // TIMING
    }
    while ( sp.next() );

    cout << " ct = " << ct << endl;

    return 0;
}
// -------------------------

/*
Timing:
  % time ./bin 13
arg 1: 13 == n  [Partition set of n elements]  default=4
arg 2: 1 == xdr  [Change direction in recursion ==> minimal change order]  default=1
arg 3: 1 == dr0  [Starting direction in recursion (+-1)]  default=1
arg 4: 0 == maxct  [Stop after maxct partitions (0: never stop)]  default=0
arg 5: 1 == priq  [Option: print internal state with each partition]  default=1
 ct = 27644437
./bin 13  2.40s user 0.02s system 99% cpu 2.419 total
 ==> 11,428,043 setpart/sec

 % time ./bin 14
 ct = 190899322
./bin 14  17.17s user 0.09s system 99% cpu 17.287 total
 ==> 11,042,941 setpart/sec
*/
