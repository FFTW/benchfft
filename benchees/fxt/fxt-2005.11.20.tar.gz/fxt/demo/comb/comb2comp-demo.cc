
#include "comb/combination-minchange.h"
#include "bits/bit2composition.h"

#include "bits/printbin.h"
#include "demo/nextarg.h"

#include "fxttypes.h"
#include "fxtalloca.h"
#include "fxtiomanip.h"
#include "jjassert.h"


//% Relation between combinations and compositions.


int
main(int argc, char **argv)
{
    ulong n = 7;
    NXARG(n, "Combinations: binomial(n,k): n>=1 ");

    ulong k = 5;
    NXARG(k, " ... k<=n.");

    combination_minchange c(n, k);
    ulong pn = k;
    ulong pk = n-k+1;
    ALLOCA(ulong, p, pn);
    const ulong *cx = c.data();
    ulong ct = 0;
    do
    {
        cout << " #" << setw(3) << ct << ":   ";
        for (ulong i=0; i<k; ++i)  cout << cx[i] << " ";
        ulong w = comb2bit(cx, k);
        print_binv_nn("   ", w, n);
        bit2composition(w, p, pn);
        cout << "    ";
        for (ulong i=0; i<pk; ++i)  cout << p[i] << " ";
        cout << endl;

//        bit2comb( w, (ulong *)cx, n );

        ++ct;
    }
    while ( c.next() );

    cout << "  #= " << ct << endl;

    return 0;
}
// -------------------------


