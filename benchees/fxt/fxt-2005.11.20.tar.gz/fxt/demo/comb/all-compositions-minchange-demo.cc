
#include "comb/all-compositions-minchange.h"
// demo-include "comb/all-compositions-minchange.cc"
// demo-include "comb/composition-colex.h"

#include "jjassert.h"

//% Generating all k-compositions of n in minimal-change order

#include "fxtiomanip.h"
#include "fxttypes.h"
#include "demo/nextarg.h"


int
main(int argc, char **argv)
{
    ulong k = 5, n = 3;
    NXARG(k, "k-compositions of n (k>=1) ");
    NXARG(n, " (n>=1)");

    ulong N = n+k-1,  K = n;
    jjassert( k == N-K+1 );
    jjassert( n == K );
    ulong b = binomial(N,K);
    cout << "binomial(" << N << ", " << K << ")=" << b << endl;

    all_compositions_minchange rd(n, k);

    ulong ct = 0;
    while ( rd.get(ct) )
    {
        cout << setw(3) << ct << ": ";
        rd.print(ct);
        cout << endl;
        ++ct;
    }

    cout << " ct=" << ct << endl;
    jjassert( b==ct );

    return 0;
}
// -------------------------

/*

    lex order            V            V            V
    3 . . . .    3 . . . .      3 . . . .      3 . . . .
    2 1 . . .    2 1 . . .      2 1 . . .      2 1 . . . *
    1 2 . . .    1 2 . . .      1 2 . . .      1 2 . . .
    . 3 . . .    . 3 . . .      . 3 . . .      . 3 . . .
    2 . 1 . .    2 . 1 . .      2 . 1 . .      . 2 1 . . *
    1 1 1 . .    1 1 1 . .      1 1 1 . .      1 1 1 . . *
    . 2 1 . .    . 2 1 . .      . 2 1 . .      2 . 1 . . *
    1 . 2 . .    1 . 2 . .      1 . 2 . .      1 . 2 . .
    . 1 2 . .    . 1 2 . .      . 1 2 . .      . 1 2 . .
    . . 3 . .    . . 3 . .      . . 3 . .      . . 3 . . *
    2 . . 1 .    2 . . 1 .      . . 2 1 . *    . . 2 1 .
    1 1 . 1 .    1 1 . 1 .      . 1 1 1 . *    1 . 1 1 . *
    . 2 . 1 .    . 2 . 1 .      1 . 1 1 . *    . 1 1 1 . *
    1 . 1 1 .    1 . 1 1 .      . 2 . 1 . *    . 2 . 1 .
    . 1 1 1 .    . 1 1 1 .      1 1 . 1 . *    1 1 . 1 .
    . . 2 1 .    . . 2 1 .      2 . . 1 . *    2 . . 1 .
    1 . . 2 .    1 . . 2 .      1 . . 2 .      1 . . 2 .
    . 1 . 2 .    . 1 . 2 .      . 1 . 2 .      . 1 . 2 .
    . . 1 2 .    . . 1 2 .      . . 1 2 .      . . 1 2 . *
    . . . 3 .    . . . 3 .      . . . 3 . *    . . . 3 .
    2 . . . 1    . . . 2 1 *    . . . 2 1      . . . 2 1
    1 1 . . 1    . . 1 1 1 *    1 . . 1 1 *    1 . . 1 1
    . 2 . . 1    . 1 . 1 1 *    . 1 . 1 1 *    . 1 . 1 1
    1 . 1 . 1    1 . . 1 1 *    . . 1 1 1 *    . . 1 1 1
    . 1 1 . 1    . . 2 . 1 *    . . 2 . 1      . . 2 . 1
    . . 2 . 1    . 1 1 . 1 *    . 1 1 . 1      1 . 1 . 1 *
    1 . . 1 1    1 . 1 . 1 *    1 . 1 . 1      . 1 1 . 1 *
    . 1 . 1 1    . 2 . . 1 *    . 2 . . 1      . 2 . . 1
    . . 1 1 1    1 1 . . 1 *    1 1 . . 1      1 1 . . 1
    . . . 2 1    2 . . . 1 *    2 . . . 1      2 . . . 1
    1 . . . 2    1 . . . 2      1 . . . 2      1 . . . 2
    . 1 . . 2    . 1 . . 2      . 1 . . 2      . 1 . . 2
    . . 1 . 2    . . 1 . 2      . . 1 . 2      . . 1 . 2 *
    . . . 1 2    . . . 1 2      . . . 1 2 *    . . . 1 2
    . . . . 3    . . . . 3 *    . . . . 3      . . . . 3

*/
