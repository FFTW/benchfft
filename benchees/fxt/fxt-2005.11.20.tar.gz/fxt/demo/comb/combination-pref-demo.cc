
#include "comb/combination-pref.h"

#include "aux1/auxprint.h"

#include "fxtiomanip.h"
#include "demo/nextarg.h"

//% Combinations via prefix shifts ("cool-lex" order)

//#define TIMING // uncomment to disable printing

ulong ct = 0;
void
visit(const combination_pref &C)
{
    cout << setw(4) << ct << ":  ";
    for (ulong k=0; k<C.n_; ++k)  cout << (C.b_[k] ? '1' : '.');
    print_delta_set_as_set("  ", C.b_, C.n_);
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong s = 3;
    NXARG(s, " (s,t)-combinations, s!=0");
    ulong t = 3;
    NXARG(t, "t!=0");

    combination_pref C(s, t);
    do
    {
#ifndef TIMING
        visit( C );
#endif
        ++ct;
    }
    while ( C.next() );

    cout << " ct = " << ct << endl;
    return 0;
}
// -------------------------

/*
Timing:

 % time ./bin 20 12
arg 1: 20 == s  [ (s,t)-combinations, s!=0]  default=3
arg 2: 12 == t  [t!=0]  default=3
 ct = 225792840 // == binomial(20+12, 12)
./bin 20 12  2.65s user 0.00s system 99% cpu 2.647 total
 ==> 85,301,412 comb/sec

 % time ./bin 12 20
arg 1: 12 == s  [ (s,t)-combinations, s!=0]  default=3
arg 2: 20 == t  [t!=0]  default=3
 ct = 225792840
./bin 12 20  2.33s user 0.02s system 99% cpu 2.348 total
 ==>  96,163,901 comb/sec

*/

/*

 % n=5; for ((t=1; t<n; ++t)); do ./bin $(( n-t )) $t; done | g '^  '
   0:  1....
   1:  .1...
   2:  ..1..
   3:  ...1.
   4:  ....1
   0:  11...
   1:  .11..
   2:  1.1..
   3:  .1.1.
   4:  ..11.
   5:  1..1.
   6:  .1..1
   7:  ..1.1
   8:  ...11
   9:  1...1
   0:  111..
   1:  .111.
   2:  1.11.
   3:  11.1.
   4:  .11.1
   5:  1.1.1
   6:  .1.11
   7:  ..111
   8:  1..11
   9:  11..1
   0:  1111.
   1:  .1111
   2:  1.111
   3:  11.11
   4:  111.1

*/




//+++++++++++++++++++++++++++++++++++
#if 0 // code from the paper

ulong *b;
ulong n;

void iterate(int s, int t)
// Must have: s!=0, t!=0
{
    visit(b, n);  // missing in paper
    b[t] = 1;  b[0] = 0;
    visit(b, n);
    ulong x = 1, y = 0;
    while ( x<n-1 )
    {
        b[x++] = 0;  b[y++] = 1;       // X(s,t)
        if ( b[x]==0 )
        {
            b[x] = 1;  b[0] = 0;       // Y(s,t)
            if ( y>1 )  x = 1;         // Z(s,t)
            y = 0;
        }
        visit(b, n);
    }
}
// -------------------------

    n = s + t;
    b = new ulong[n];
    for (ulong j=0; j<n; ++j)  b[j] = 0;
    for (ulong j=0; j<t; ++j)  b[j] = 1;

    iterate(s, t);

#endif // 0
//+++++++++++++++++++++++++++++++++++
