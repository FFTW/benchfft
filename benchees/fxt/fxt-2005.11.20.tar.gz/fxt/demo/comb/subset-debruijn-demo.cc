
#include "comb/subset-debruijn.h"

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "aux1/auxprint.h"
#include "demo/nextarg.h"


//% Generate all subsets in De Bruijn order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Size of the set");

    subset_debruijn sdb(n);

    for (ulong j=0; j<=n; ++j)  sdb.next();  // cosmetics: end with empty set
#ifdef TIMING
    while ( sdb.next() )  {;}

#else // TIMING
    ulong ct = 0;
    do
    {
        cout << "    " << setw(2) << ct << ":";
        ulong num = print_delta_set_as_set("    ", sdb.data(), n, 1);
        cout << "   #=" << num;
        print_delta_set_as_set("    ", sdb.data(), n);
        cout << endl;

        sdb.next();
    }
    while ( ++ct < (1UL<<n) );
#endif // TIMING

    return 0;
}
// -------------------------

/*
Timing:
% time ./bin 28
arg 1: 28 == n  [Size of the set]  default=5
./bin 28  13.68s user 0.09s system 99% cpu 13.791 total
 ==> 2^28/13.791 == 19,464,538 subsets per second
*/
