

#include "comb/binaryprimestring.h"
#include "bits/tinyfactors.h"

#include "fxtiomanip.h"
#include "fxttypes.h"  // ulong

#include "demo/nextarg.h" // NXARG()

//% Binary pre-necklaces, necklaces and Lyndon words: CAT generation.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 8;
    NXARG(n, "Number of bits");

    binary_prime_string bps(n);

    const ulong *x = bps.data();

    ulong tfb = tiny_factors_tab[n];  // for fast factor lookup

    ulong nct = 0;  // count necklaces (prime strings)
    ulong lct = 0;  // count lyndon words
    ulong ct = 0;   // count pre-necklaces (pre-prime strings)
    ulong j = bps.current();  // first string is zero word (period==1)
    do
    {
#ifndef TIMING
        cout << setw(4) << ct << ": ";

        for (ulong i=0; i<n; ++i)  cout << (x[i] ? '1' : '.' );
        cout << "  ";
        cout << setw(2) << j;
        cout << "  ";
        // fast lookup if j is a factor of n:
        if ( (tfb>>j) & 1 )
        {
            ++nct;
            cout << "  N";  // necklace
        }

        if ( j==n )
        {
            ++lct;
            cout << "  L";  // Lyndon word
        }
        cout << endl;
#endif  // TIMING

        j = bps.next();
        ++ct;
    }
    while ( j );

    cout << " n = " << n << ":  ";
//    cout << endl;
    cout << "  # pre-necklaces=" << ct-1;
    cout << "  # necklaces=" << nct;
    cout << "  # Lyndon words=" << lct;
    cout << endl;


    return 0;
}
// -------------------------

/*
Timing:
% time ./bin 32
arg 1: 32 == n  [Number of bits]  default=8
 n = 32:    # pre-necklaces=277737796  # necklaces=0  # Lyndon words=0
./bin 32  3.53s user 0.01s system 100% cpu 3.546 total
  78,324,251 pre-necklaces per second
*/
