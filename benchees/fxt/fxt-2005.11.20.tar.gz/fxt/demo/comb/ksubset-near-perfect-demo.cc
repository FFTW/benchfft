
#include "comb/ksubset-near-perfect.h"
// demo-include "comb/ksubset-near-perfect.cc"

#include "aux1/auxprint.h"  // print_delta_set_as_set()
#include "aux0/binomial.h"

#include "bits/bitset2set.h"  // deltaset2bitset()
#include "bits/bitcount.h"
#include "bits/bit2pow.h"
#include "bits/bitlow.h"
#include "bits/printbin.h"

#include "fxtiomanip.h"
#include "jjassert.h"
#include "demo/nextarg.h"
#include "fxttypes.h"


//% k-subsets (kmin<=k<=kmax) in near-perfect order.
//% Recursive algorithm.

// With kmin==kmax one obtains a near-perfect order for combinations (n choose k).


//#define TIMING // uncomment to disable printing

#ifdef TIMING
void visit(const ksubset_near_perfect &)  {;}
#else
void visit(const ksubset_near_perfect &C)
{
    static ulong bo = 0;  // bitset
    const ulong *rv = C.rv_;
    ulong n = C.n_;
//    ulong ne = C.k_;  // number of elements
    ulong b = deltaset2bitset(rv, n);   // bitset
    if ( C.ct_==1 )  bo = b;

    cout << "    ";
    cout << setw(3) << C.ct_ << ":  ";
    for (ulong j=0; j<C.n_; ++j)  cout << "" << (rv[j] ? '1' : '.');
//    cout << "  #" << ne;
    // =^= print_binv_nn("  ", b, C.n_);
    print_binv_diff_nn("  ", bo, b, C.n_, "..PM");
    print_delta_set_as_set("  ", rv, C.n_);
    cout << endl;

    // check whether changes are near-perfect:
    ulong x = bo ^ b;  // changes
    jjassert( bit_count(x)<=2 );  // at most 2 changes
    if ( ! one_bit_q(x) )  // check that change is near-perfect
    {
        ulong x1 = lowest_bit_idx(x);
        x ^= (1UL<<x1);
        ulong x2 = lowest_bit_idx(x);  // x2>x1
        jjassert( (x2-x1)<=2 );
    }
    bo = b;
}
// -------------------------
#endif  // TIMING


int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Subsets of n-element set.");
    ulong kmin = 2;
    NXARG(kmin, "Minimal number of elements in subsets.");
    ulong kmax = 4;
    NXARG(kmax, "Maximal number of elements in subsets.");
    ulong nq = 0;
    NXARG(nq, "Whether to reverse order.");

    ksubset_near_perfect C(n);
    C.generate(visit, kmin, kmax, nq);

//    cout << "C.rct=" << C.rct_ << endl;
    cout << "work/object=" << 1.0*(C.rct_)/(C.ct_) << endl;
    cout << "ct=" << C.ct_ << endl;

    ulong z = 0;
    for (ulong k=kmin; k<=kmax; ++k)  z += binomial(n,k);
    jjassert( C.ct_==z );

    return 0;
}
// -------------------------


/*
Timing:
 time ./bin 26 0 26
ct=67108864
./bin 26 0 26  1.49s user 0.02s system 99% cpu 1.507 total
 67108864/1.508 == 44,501,899  objects/sec
*/
