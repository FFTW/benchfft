
#include "comb/subset-gray.h"

#include "aux1/auxprint.h"  // print_set()
#include "demo/nextarg.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "fxtiomanip.h"


//% Generate all subsets in minimal-change order.

//#define TIMING // uncomment to disable printing

void
print_set1_as_bitset(const char *bla, const ulong *x, ulong n, ulong N)
// Print x[0,..,n-1] ( a n-subset of {1,2,...,N}) as bit-set.
// Example:  x[]=[1,2,4,5,9]  ==> "11.11...1"
{
    if ( bla )  cout << bla;

    ulong j = 0;
    for (ulong k=0; k<n; ++k)
    {
        for (  ; j<x[k]-1; ++j)  cout << '.';
        cout << '1';
        ++j;
    }

    while ( j++ < N )  cout << '.';
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 5;
    NXARG(n, "Size of the set");
    bool rq = 0;
    NXARG(rq, "Whether to generate subsets in reversed order");

    subset_gray sg(n);
    const ulong *x = sg.data();

    sg.empty();
#ifdef TIMING
    while ( sg.next() )  {;}

#else // TIMING
    ulong num, idx = 0;
    do
    {
        num = sg.num();
        cout << setw(2) << idx << ":  ";
        print_set1_as_bitset("   ", x, num, n);
        cout << "   #=" << num;
        print_set("   set=", x, num);
        cout << endl;

        ++idx;
        num = ( rq ? sg.prev() : sg.next() );
    }
    while ( num );
#endif // TIMING

    return 0;
}
// -------------------------

/*
Timing:
% time ./bin 30
arg 1: 30 == n  [Size of the set]  default=5
arg 2: 0 == rq  [Whether to generate subsets in reversed order]  default=0
./bin 30  6.59s user 0.04s system 99% cpu 6.628 total
 ==> 2^30/6.628 == 162,000,878 subsets per second
*/
