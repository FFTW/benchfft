
#include "comb/permcyclic.h"

#include "fxttypes.h"
#include "fxtio.h"

#include "demo/nextarg.h" // NXARG()

//% Demo of cyclic permutations.

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Number of elements");

    perm_cyclic perm(n);
    const ulong *x = perm.data();

    ulong ct = 0;
    do
    {
        cout << " #" << setw(3) << ct << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
        cout << endl;

        ++ct;
    }
    while ( perm.next() );

    return 0;
}
// -------------------------


