
#include "comb/combination-colex.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "aux1/auxprint.h"

#include "demo/nextarg.h"

//% Generating all combinations in co-lexicographic order.

//#define TIMING // uncomment to disable printing

int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    NXARG(n, "Combinations (n choose k):  n>0");
    NXARG(k, " 0 < k <= n");
    ulong ct = 0;
    combination_colex comb(n, k);

    do
    {
#ifndef TIMING
        cout << endl;
        cout << "    [" << comb << " ]";
        print_set_as_bitset("    ", comb.data(), k, n );
        cout << "    #" << setw(3) << ct;
#endif // TIMING
        ++ct;
    }
    while ( comb.next() );
    cout << " ct = " << ct << endl;

//    cout << endl;
//    cout << " reversed order: " << endl;
//    comb.last();
//    do
//    {
//        --ct;
//        cout << "   [ " << comb << " ]  ";
//        print_set_as_bitset("", comb.data(), k, n );
//        cout << "  #" << setw(3) << ct;
//        cout << endl;
//    }
//    while ( comb.prev() );
//    cout << endl;

    return 0;
}
// -------------------------

/*
Timing:
% time ./bin 32 20
arg 1: 32 == n  [Combinations (n choose k):  n>0]  default=7
arg 2: 20 == k  [ 0 < k <= n]  default=4
 ct = 225792840
./bin 32 20  1.51s user 0.01s system 99% cpu 1.518 total
 ==> 148,743,636 comb/sec

 % time ./bin 32 12
arg 1: 32 == n  [Combinations (n choose k):  n>0]  default=7
arg 2: 12 == k  [ 0 < k <= n]  default=4
 ct = 225792840
./bin 32 12  1.14s user 0.01s system 100% cpu 1.155 total
 ==> 195,491,636 comb/sec
*/
