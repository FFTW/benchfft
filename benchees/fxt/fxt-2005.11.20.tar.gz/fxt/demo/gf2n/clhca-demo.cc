
// demo-is-self-contained

#include "bmat/bitmat.h"  // bitmat_charpoly()

#include "bpol/bitpolirred.h"
#include "bpol/bitpoldegree.h"

#include "bits/bitrotate.h"
#include "bits/bitcount.h"
//#include "bits/bittransforms.h"
#include "fxtalloca.h"

#include "fxttypes.h"
#include "bits/printbin.h"
#include "jjassert.h"
#include "fxtiomanip.h"
#include "demo/nextarg.h"


//% Cyclic (additive) Linear Hybrid Cellular Automata (CLHCA).


inline ulong clhca_next(ulong x, ulong r, ulong n)
// Compute next state of a linear hybrid cellular automaton
//  with cyclic boundary condition (CLHCA).
{
    r &= x;
    ulong t = x ^ bit_rotate_right(x, 1, n);
    t ^= r;
    return  t;
}
// -------------------------

ulong clhca2poly(ulong r, ulong n)
// Compute the binary polynomial corresponding
//   to the length-n CLHCA with rule r.
{
    ALLOCA(ulong, M, n);
    for (ulong k=0; k<n; ++k)
    {
        M[k] = clhca_next( 1UL<<k, r, n );
//        print_binv("  ", M[k], n);
    }
    ulong c = bitmat_charpoly(M, n);
//    ulong c = bitmat_hessenberg2charpoly(M, n);

    return c;
}
// -------------------------

ulong clhca2poly_too(ulong r, ulong n)
// Compute the binary polynomial corresponding
//   to the length-n CLHCA with rule r.
{
    ulong c = 1UL << n;
    for (ulong k=0; k<n; ++k)  if ( 0==(r & (1UL<<k)) )  c ^= (c>>1);
    c ^= 1;
    return c;
}
// -------------------------


bool max_order_q(ulong r, ulong n)
// Return whether CLHCA has maximal period.
// Brute force algorithm.
{
    const ulong end = (1UL<<n)-1;
    ulong x = 1;
    ulong k = 0;
    do
    {
        ++k;
        x = clhca_next(x, r, n);
        if ( k>end )  return false;
    }
    while ( x!=1 );
    return (k==end);
}
// -------------------------

bool show(ulong r, ulong n)
// Print all words in period.
{
    const ulong end = (1UL<<n)-1;
    ulong x = 1;
    ulong k = 0;
    do
    {
        ++k;
        cout << setw(4) << k << ":  ";
        print_bin_nn("    ", x, n);
        cout << endl;
        x = clhca_next(x, r, n);
        if ( k>end )  return false;
    }
    while ( x!=1 );
//    cout << setw(4) << k << ":  ";  print_bin("  ", x, n);
    return (k==end);
}
// -------------------------



int
main(int argc, char **argv)
{
    ulong n = 17;
    NXARG(n, "Number of bits");
    const ulong pn  = n;

    ulong ct = 0;
    const ulong end = (1UL<<n)-1;
    for (ulong r=0;  r<=end;  r|=(r<<1),r|=1)
//    for (ulong r=1; r<=end; ++r)
    {
//        ulong r = bn.data();
//        if ( ! max_order_q(r, n) )  continue;
        ulong c = clhca2poly(r, n);
//        cout << setw(4) << ct;
        cout << setw(4) << n;
        cout << setw(3) << bit_count(r) << ": ";
        print_bin_nn("    r = ", r, pn);
        print_bin_nn("    c = ", c, pn+1);
//        print_bin_nn("    b = ", blue_code(c), pn+1);  // C(x+1)
        if ( bitpol_irreducible_q(c, bitpol_h(c) ) )  cout << " I";  // poly irreducible

        bool q = max_order_q(r, n);
        if ( q )
        {
            cout << " P";  // max period
            ++ct;
        }
        cout << endl;

        jjassert( clhca2poly_too(r, n)==c );

//        if ( q )  { show(r, n); cout << endl; }
    }

    return 0;
}
// -------------------------

/*
 for n in $(seq 2 21); do ./bin $n; done | g %
   2 %  r = 1.
   3 %  r = 1..
   4 %  r = 111.
   5 %  r = 11...
   6 %  r = 1.....
   7 %  r = 1......

   9 %  r = 1111.....
  10 %  r = 111.......
  11 %  r = 11.........



  15 %  r = 1111...........

  17 %  r = 111..............
  18 %  r = 1111111...........

  20 %  r = 111.................
  21 %  r = 11...................
*/
