
// demo-include "bpol/bitpol2lhca.cc"
#include "bpol/bitpolmodsolvequadratic.h"
#include "bpol/lhca.h"

//#include "bpol/bitpolarith.h"
#include "bpol/bitpoldegree.h"
//#include "bpol/bitpolderiv.h"
//#include "bpol/bitpolmodarith.h"

#include "fxtio.h"
#include "bits/printbin.h"
#include "demo/nextarg.h"
#include "fxttypes.h"
#include "jjassert.h"


//% Computation of the LHCA rule corresponding to an irreducible binary polynomial.

int
main(int argc, char **argv)
{
    const ulong e = 1;
//    ulong c = (e<<5) | (e<<2) | (e<<0);
    ulong c = (e<<20) | (e<<3) | (e<<0);
//    ulong c = (e<<40) | (e<<21) | (e<<19) |  (e<<2) |  (e<<0);
//    ulong c = (e<<60) | (e<<1) | (e<<0);

//    ulong c = (e<<18) | (e<<9) | (e<<0);
//    ulong c = (e<<6) | (e<<3) | (e<<0);
//    ulong c = (e<<19) - 1;  // full poly

    RESTARGS("Optionally supply nonzero coefficients of polynomial");
    if ( argc>1 )
    {
        c = 0;
        for (ulong j=1; j<(ulong)argc; ++j)
        {
            c |= (e << atol(argv[j]));
        }
    }



    ulong n = bitpol_deg(c);

    print_bin("  c=", c, n+1);

    ulong r = poly2lhca(c);
    print_bin("   r=", r, n);

    ulong t = lhca2poly(r, n);
//    print_bin("  t=", t, n+1);
    jjassert( t==c );

    return 0;
}
// -------------------------
