
#include "bpol/allirredpol.h"
// demo-include "bits/bitnecklace.h"
// demo-include "bpol/necklace2bitpol.h"
#include "bpol/normalbasis.h"
// demo-include "bpol/bitpolnormal.cc"
#include "bmat/bitmat.h"

#include "bits/printbin.h"
#include "bits/bitcount.h"

#include "fxttypes.h"  // ulong
#include "demo/nextarg.h" // NXARG()

#include "fxtio.h"
#include "jjassert.h"
#include "fxtalloca.h"


//% Find all normal binary polynomials of degree n.
//% Print all corresponding multiplier matrices.


//#define TIMING // uncomment to disable printing

ulong
max_row_count(const ulong *M, ulong n)
{
    ulong m = 0;
    for (ulong j=0; j<n; ++j)
    {
        ulong b = bit_count(M[j]);
        if ( b > m )  m = b;
    }
    return m;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 9;
    NXARG(n, "Degree of the polynomials");

    ulong wh = 1;
    NXARG(wh, "What to print: 2==>poly+matrix 1==>poly 0==>just count");

    ALLOCA(ulong, M, n);  // multiplier matrix
    for (ulong j=0; j<n; ++j)  M[j] = 0;
    all_irredpol ip(n);
    ulong *Mp = M;
    if ( 0==wh )  Mp = 0; // suppress computation of multiplier matrix

//    ulong tm = 99999;  // min type
    ulong nct = 0;  // count normal polynomials
    ulong pct = 0;  // count primitive normal polynomials
    ulong xct = 0;  // count polynomials with coeff('x')==1
//    ulong h = 1UL<<(n-1);
    ulong p = ip.data();
    do
    {
        ulong nq = bitpol_normal_q(p, n, 1, Mp);
        if ( nq )
        {
            ++nct;
            ulong pq = ip.is_primitive();
            if ( pq )  ++pct;

            if ( p & 2 )  ++xct;

#ifndef TIMING
//            ulong t = max_row_count(M, n);
//            if ( tm > t )  tm = t;

            if ( 0==wh )  goto next;  // just count

            cout << setw(3) << nct << ":";
            print_bin_nn("  c=", p, n+1);
            if ( pq )  cout << "  P";  // primitive polynomial
            cout << endl;

            if ( wh<=1 )  goto next;  // do not show matrix

            bitmat_print("M=", M, n);
//            cout << " t = " << t << endl;

            cout << endl;
#endif
        }

    next:
        p = ip.next();
    }
    while ( p );

    cout << "  n=" << n;
//    if ( wh>=2 )  cout << "  min(t) = " << tm;
    cout << "   #= " << nct << "   #primitive = " << pct;
    cout << "   #non-primitive = " << nct-pct;
//    cout << "   xct = " << xct;
    cout << endl;

    return 0;
}
// -------------------------

/*
for f in $(seq 2 30) ; do ./bin $f 0; done \
  | grep --line-buffered \#  | sed -u s/non-primitive/N/ | sed -u s/primitive/P/

    n=2   #= 1   #P = 1   #N = 0
    n=3   #= 1   #P = 1   #N = 0
    n=4   #= 2   #P = 1   #N = 1
    n=5   #= 3   #P = 3   #N = 0
    n=6   #= 4   #P = 3   #N = 1
    n=7   #= 7   #P = 7   #N = 0
    n=8   #= 16   #P = 7   #N = 9
    n=9   #= 21   #P = 19   #N = 2
    n=10   #= 48   #P = 29   #N = 19
    n=11   #= 93   #P = 87   #N = 6
    n=12   #= 128   #P = 52   #N = 76
    n=13   #= 315   #P = 315   #N = 0
    n=14   #= 448   #P = 291   #N = 157
    n=15   #= 675   #P = 562   #N = 113
    n=16   #= 2048   #P = 1017   #N = 1031
    n=17   #= 3825   #P = 3825   #N = 0
    n=18   #= 5376   #P = 2870   #N = 2506
    n=19   #= 13797   #P = 13797   #N = 0
    n=20   #= 24576   #P = 11255   #N = 13321
    n=21   #= 27783   #P = 23579   #N = 4204
    n=22   #= 95232   #P = 59986   #N = 35246
    n=23   #= 182183   #P = 178259   #N = 3924
    n=24   #= 262144   #P = 103680   #N = 158464
    n=25   #= 629145   #P = 607522   #N = 21623
    n=26   #= 1290240   #P = 859849   #N = 430391
    n=27   #= 1835001   #P = 1551227   #N = 283774
    n=28   #= 3670016   #P = 1815045   #N = 1854971
    n=29   #= 9256395   #P = 9203747   #N = 52648
    n=30   #= 11059200   #P = 5505966   #N = 5553234

*/

/*
Timing (without printing):

  n=24   #= 262144   #primitive = 103680   #non-primitive = 158464
./bin 24  31.65s user 0.15s system 99% cpu 31.924 total

  n=23   #= 182183   #primitive = 178259   #non-primitive = 3924
./bin 23  15.60s user 0.07s system 99% cpu 15.677 total

  n=22   #= 95232   #primitive = 59986   #non-primitive = 35246
./bin 22  7.29s user 0.05s system 99% cpu 7.338 total

*/
