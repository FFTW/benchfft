
#include "bpol/lhca.h"
#include "bpol/bitpolirred.h"
//#include "bpol/minweightlhcarule.cc"

#include "bpol/bitpolprimitive.h"  // test needs factorization
#include "bpol/gf2n.h"  // for factorization of mersenne numbers

#include "bits/printbin.h"

#include "jjassert.h"
#include "fxtiomanip.h"

#include "fxttypes.h"
#include "bits/bitsperlong.h"

#include "demo/nextarg.h" // NXARG()

//% Convert LHCA rules to binary polynomials.


void
print_rules(ulong rr, ulong cc, ulong pn)
{
    print_bin_nn("  r=", rr, pn);
    print_bin_nn("  c=", cc, pn);
    print_idx_seq_nn("  r= ", rr);
//    print_idx_seq_nn("  c= ", cc);
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = BITS_PER_LONG - 1;
    NXARG(n, "Max number of bits");
    ulong pn  = n + 1;

    cout << setw(pn) << "LHCA rule";
    cout << setw(pn) << "polynomial";
    cout << endl;

    ulong h = 1;
    for (ulong k=1; k<=n; ++k)
    {
        GF2n::init(k);  // for factorization of Mersenne number
        cout << setw(2) << k << ":  ";

        ulong r = minweight_lhca_rule[k];

        ulong c = lhca2poly(r, k);
        print_rules(r, c, pn);

        jjassert( bitpol_irreducible_q(c, h) );
        jjassert( 0==test_bitpol_primitive(c, h, GF2n::mfact_) );

//        ulong c2 = lhca2poly(~r, k);
//        jjassert( c2==bitpol_compose_xp1(c) );

        h <<= 1;
    }

    return 0;
}
// -------------------------

