
#include "bpol/necklace2bitpol.h"
#include "bits/bitcyclic-minmax.h"
#include "bits/bitcyclic-period.h"

#include "mod/gcd.h"

#include "bpol/primpoly.h"

#include "bpol/bitpolirred.h"

#include "bits/printbin.h"

//#include "jjassert.h"
#include "fxttypes.h"  // ulong
#include "fxtio.h"

#include "demo/nextarg.h" // NXARG()


//% Convert necklaces to binary polynomials, especially irreducible and primitive ones.


void
bitpol_print_coefficients(const char *bla, ulong c)
{
    if ( bla )  cout << bla;
    ulong y =c;
    while ( y )
    {
        ulong i = highest_bit_idx(y);
        cout << " " << i;
        y ^= (1UL << i);
    }
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    NXARG(n, "Degree of polynomials");

    ulong c = 0;  // 0==> default primpoly
//    c = lowbit_primpoly[n];
    c = rand_primpoly[n];
//    c = (1UL<<n)+1+ (1UL<<(1));
//    c = minweight_primpoly[n];

    RESTARGS("Optionally supply nonzero coefficients of field poly c");
    if ( argc>2 )
    {
        c = 1UL<<n;
        for (ulong j=2; j<(ulong)argc; ++j)  c |= (1UL << atol(argv[j]));
        n = highest_bit_idx(c);
    }

    bitpol_print_coefficients("modulus= ", c);

    ulong h = highest_bit(c) >> 1;
    if ( bitpol_irreducible_q(c, h) )  cout << " Irreducible." << endl;

    const ulong a = 2;  // 'x'
    necklace2bitpol n2b(n, c, a);
    const ulong mers = (1UL<<n)-1;
    for(ulong b = 1; b<(h<<1); ++b)
    {
//        cout << a << ": --------- " << endl;
        ulong per = bit_cyclic_period(b, n);
        ulong bm = bit_cyclic_min(b, n);
//        if ( b != bm )  continue;
//        if ( per<n )  continue;

        ulong p2 = n2b.poly(b);

        print_bin_nn("    b=", b, n+2);
        cout << " " << per;
        cout << " " << (b==bm?'m':' ');
        print_bin_nn("    e=", n2b.e_, n+1);
        print_bin_nn("    p=", p2, n+2);
        if ( 0==bitpol_irreducible_q(p2, h) )  cout << " reducible";
        if ( 1UL==gcd(b, mers) )  cout << " P";  // only true for primitive c
        cout << endl;
    }
    return 0;
}
// -------------------------
