
#include "bpol/allirredpol.h"
// demo-include "bits/bitnecklace.h"
// demo-include "bpol/necklace2bitpol.h"
// demo-include "bpol/bitpolnormal.cc"

#include "bpol/normalbasis.h"

#include "bits/printbin.h"

#include "fxtio.h"
#include "fxttypes.h"  // ulong

#include "demo/nextarg.h"  // NXARG()



//% Generate all irreducible binary polynomials of given degree (from Lyndon words).
//% Indicate which are primitive (P) and normal (N).

#define TEST_NORMALITY  // define to include normality test
//#define TIMING // uncomment to disable printing

void
bitpol_print_coefficients(const char *bla, ulong c)
{
    if ( bla )  cout << bla;
    ulong y =c;
    while ( y )
    {
        ulong i = highest_bit_idx(y);
        cout << " " << i;
        y ^= (1UL << i);
    }
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 9;
    NXARG(n, "Degree of polynomials 2<=n<BITS_PER_LONG");
    if ( (n<2) || (n>32) )  n = 6;
    bool hexq = 0;
    NXARG(hexq, "Whether to print hexadecimal");

    ulong c = 0;  // 0==> default primpoly
    if ( argc>2 )
    {
        c = 1UL<<n;
        for (ulong j=2; j<(ulong)argc; ++j)  c |= (1UL << atol(argv[j]));
    }

    all_irredpol ip(n, c);

//    bitpol_print_coefficients("modulus= ", c);

    ulong ict = 0;  // count lyndon words (irreducible polynomials)
    ulong pct = 0;  // count primitive polynomials
#ifdef TEST_NORMALITY
    ulong nct = 0;
    ulong npct = 0;  // count normal primitive polynomials
#endif
    ulong p = ip.data();
    do
    {
        ++ict;
        ulong pq = ip.is_primitive();
        pct += pq;

#ifndef TIMING
        if ( hexq )  cout << "  0x" << hex << p << dec;
        else         print_bin_nn("  ", p, n+1);
        if ( pq )  cout << "  P";  // primitive polynomial
        else       cout << "   ";
#endif

#ifdef TEST_NORMALITY
        ulong nq = bitpol_normal_q(p, n, 1, 0);
        nct += nq;
        npct += (nq && pq);
#ifndef TIMING
        if ( nq )  cout << " N";
        else       cout << "  ";
#endif
#endif
#ifndef TIMING
        cout << endl;
#endif
        p = ip.next();
    }
    while ( p );


    cout << endl;
    cout << " n = " << n << ":  ";
    cout << "  #irred. =" << ict;
    cout << "  #prim. =" << pct;
#ifdef TEST_NORMALITY
    cout << "  #normal =" << nct;
    cout << " = ( " << npct << " prim. + " << (nct-npct) << " non-prim.)";
#endif
    cout << endl;


    return 0;
}
// -------------------------

/*
for ((n=1;n<=25;++n)); do ./bin $n; done | grep -F ' n = '
 n = 2:    #irred. =1  #prim. =1  #normal =1 = ( 1 prim. + 0 non-prim.)
 n = 3:    #irred. =2  #prim. =2  #normal =1 = ( 1 prim. + 0 non-prim.)
 n = 4:    #irred. =3  #prim. =2  #normal =2 = ( 1 prim. + 1 non-prim.)
 n = 5:    #irred. =6  #prim. =6  #normal =3 = ( 3 prim. + 0 non-prim.)
 n = 6:    #irred. =9  #prim. =6  #normal =4 = ( 3 prim. + 1 non-prim.)
 n = 7:    #irred. =18  #prim. =18  #normal =7 = ( 7 prim. + 0 non-prim.)
 n = 8:    #irred. =30  #prim. =16  #normal =16 = ( 7 prim. + 9 non-prim.)
 n = 9:    #irred. =56  #prim. =48  #normal =21 = ( 19 prim. + 2 non-prim.)
 n = 10:    #irred. =99  #prim. =60  #normal =48 = ( 29 prim. + 19 non-prim.)
 n = 11:    #irred. =186  #prim. =176  #normal =93 = ( 87 prim. + 6 non-prim.)
 n = 12:    #irred. =335  #prim. =144  #normal =128 = ( 52 prim. + 76 non-prim.)
 n = 13:    #irred. =630  #prim. =630  #normal =315 = ( 315 prim. + 0 non-prim.)
 n = 14:    #irred. =1161  #prim. =756  #normal =448 = ( 291 prim. + 157 non-prim.)
 n = 15:    #irred. =2182  #prim. =1800  #normal =675 = ( 562 prim. + 113 non-prim.)
 n = 16:    #irred. =4080  #prim. =2048  #normal =2048 = ( 1017 prim. + 1031 non-prim.)
 n = 17:    #irred. =7710  #prim. =7710  #normal =3825 = ( 3825 prim. + 0 non-prim.)
 n = 18:    #irred. =14532  #prim. =7776  #normal =5376 = ( 2870 prim. + 2506 non-prim.)
 n = 19:    #irred. =27594  #prim. =27594  #normal =13797 = ( 13797 prim. + 0 non-prim.)
 n = 20:    #irred. =52377  #prim. =24000  #normal =24576 = ( 11255 prim. + 13321 non-prim.)
 n = 21:    #irred. =99858  #prim. =84672  #normal =27783 = ( 23579 prim. + 4204 non-prim.)
 n = 22:    #irred. =190557  #prim. =120032  #normal =95232 = ( 59986 prim. + 35246 non-prim.)
 n = 23:    #irred. =364722  #prim. =356960  #normal =182183 = ( 178259 prim. + 3924 non-prim.)
 n = 24:    #irred. =698870  #prim. =276480  #normal =262144 = ( 103680 prim. + 158464 non-prim.)
 n = 25:    #irred. =1342176  #prim. =1296000  #normal =629145 = ( 607522 prim. + 21623 non-prim.)
*/

/*
Timing:

Without normality test:
 n = 24:    #irred. =698870  #prim. =276480
./bin 24  14.51s user 0.07s system 99% cpu 14.574 total

With normality test:
 n = 24:    #irred. =698870  #prim. =276480  #normal =262144 = ( 103680 prim. + 158464 non-prim.)
./bin 24  28.36s user 0.14s system 99% cpu 28.511 total
 n = 23:    #irred. =364722  #prim. =356960  #normal =182183 = ( 178259 prim. + 3924 non-prim.)
./bin 23  13.45s user 0.07s system 99% cpu 13.540 total
 n = 22:    #irred. =190557  #prim. =120032  #normal =95232 = ( 59986 prim. + 35246 non-prim.)
./bin 22  6.28s user 0.02s system 99% cpu 6.306 total

*/
