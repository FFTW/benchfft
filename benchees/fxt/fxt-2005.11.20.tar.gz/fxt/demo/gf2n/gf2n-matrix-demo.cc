
#include "bmat/bitmat.h"
#include "bpol/primpoly.h"

#include "bits/printbin.h"
#include "fxtiomanip.h"
#include "fxtalloca.h"
#include "fxttypes.h"  // ulong
#include "jjassert.h"

#include <cstdlib>  // atol()

//% Matrix representation of GF(2**n).


#define PRINT_MATPOW  // uncomment to print matrix powers

int
main(int argc, char **argv)
{
//    set_fail_action(JJ_ASSERT_STOP);

    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    ulong c = minweight_primpoly[n];
    if ( argc>2 )  c = (1UL<<n);
    for (ulong k=2;  (ulong)argc>k;  ++k)  c |= (1UL << atol(argv[k]));

    print_bin(" c=", c, n+1);

    ALLOCA(ulong, T, n);
    ALLOCA(ulong, G, n);
    bitmat_companion(c, n, G);
//    bitmat_transpose(G, n, T);  bitmat_set(T, n, G);
    bitmat_print("G=", G, n);

    ALLOCA(ulong, M, n);
    ALLOCA(ulong, Mi, n);
    bitmat_unit(M, n);
    for (ulong k=0; k<(1UL<<n); ++k)
    {
        cout << " k = " << setw(2) << k;

        // c0 and r0 reversed so that print_bin() gives element zero on the left:
        ulong c0 = 0;  // first column
        for (ulong j=0; j<n; ++j)  {  c0<<=1;  c0 |= (M[j] & 1UL); }
        print_bin_nn("   c0 = ", c0, n);
        ulong r0 = M[0];  // first row
        print_binv_nn("   r0 = ", r0, n);

        ulong t = bitmat_trace(M, n);
        cout << "  t = " << ".1"[t];

        cout << endl;

        ulong qi = bitmat_inverse(M, n, Mi);
        jjassert( qi );  // matrices are invertible
        bitmat_mult(M, Mi, n, T);

#ifdef PRINT_MATPOW
        bitmat_print("M_k = M^k =", M, n);
//        bitmat_print("(M_k)^(-1) = ", Mi, n);
//        bitmat_print(" id = ", T, n);
//        ALLOCA(ulong, H, n);
//        bitmat_hessenberg(M, n, H);
//        bitmat_print("H =", H, n);
//        jjassert( bitmat_is_hessenberg(H, n) );
#endif

        ulong cp = bitmat_charpoly(M, n);
        print_binv(" charpoly = ", cp, n+1);  // == minpoly
        cout << endl;

        jjassert( bitmat_is_unit(T, n) );  // assert inversion works

        bitmat_mult(M, G, n, T);
        bitmat_set(T, n, M);
    }

    return 0;
}
// -------------------------
