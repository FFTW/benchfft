
#include "bpol/gf2n.h"
//demo-include "bpol/gf2n.cc"

#include "bits/printbin.h"
#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong
#include "jjassert.h"


//% Arithmetics over GF(2**n).


void
doit(ulong n)
{
    cout << "" << endl;
    cout << "------------------------------------------------------------" << endl;
    GF2n::print_info();
    cout << "" << endl;

    ulong pn = n;
    GF2n f(1);
    GF2n g;  g.v_ = GF2n::g_;

    cout << "   k   :   f:=g**k  t:=trace(f)               s:=f*f  q:=sqrt(f)" << endl;
    cout << "                          r:=order(f)  " << endl;
    ulong k = 0;
    do
    {
        ulong t = f.trace();
        GF2n s = f.sqr();
        GF2n q = f.sqrt();
        ulong r = f.order();

        print_bin_nn(" ", k, pn); cout << " : ";
        cout << "  f= " << f;
        cout << "  t= " << t;
        cout << "  r= " << setw(4) << r;
        cout << "    ";
        cout << "  s= " << s;
        cout << "  q= " << q;

        jjassert( q*q==f );
        jjassert( f*f==s );

        GF2n i = f.inv();
//        cout << "    ";
//        cout << "  i= " << i;
        jjassert( i.inv() == f );

        GF2n e = f.pow(GF2n::mm_);
        jjassert( 1==e );

        cout << endl;

        f *= g;
        ++k;
    }
    while ( f!=1 );
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong dq = 1;
    NXARG(dq, "whether default behavior");

    ulong n = 4;
    NXARG(n, "degree of field");

    ulong c = 0;
    RESTARGS("Optionally supply nonzero coefficients of field poly c");
    for (ulong k=2;  (ulong)argc>k;  ++k)  c |= (1UL << atol(argv[k]));
    if ( 0!=c )  c |= (1UL<<n);

//    bitmat_print("NT=", p2n_tab, n);

    GF2n::init(n, c);
    doit(n);

    if ( dq )  // default
    {
        n = 4;
        c = 31;  // irreducible but not primitive
        GF2n::init(n, c);
        doit(n);
    }

    return 0;
}
// -------------------------
