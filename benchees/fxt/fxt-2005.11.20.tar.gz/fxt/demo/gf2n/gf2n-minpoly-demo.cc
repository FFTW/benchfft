

#include "bpol/gf2n.h"
//demo-include "bpol/minpoly.cc"

#include "bits/bitsperlong.h"
#include "bpol/bitpolirred.h"
#include "bpol/bitpolprimitive.h"
#include "bits/printbin.h"
#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong
#include "fxtiomanip.h"
#include "jjassert.h"


//% Minimal polynomials in GF(2**n).


void
doit(ulong n)
{
    cout << "" << endl;
    cout << "------------------------------------------------------------" << endl;
    GF2n::print_info();
    cout << "" << endl;

    ulong pn = n;
    GF2n f(1);
    GF2n g;  g.v_ = GF2n::g_;

    cout << "   k        :";
    cout << "   f:=g**k  r:=order(f)   p:=minpoly(f)  t:=trace(f) d:=deg(p) " << endl;
    ulong k = 0;
    do
    {
        cout << setw(4) << k;
        print_bin_nn(" = ",k,pn); cout << " : ";
        cout << "  f= " << f;

        cout << "  r= " << setw(4) << f.order();
//        cout << "  " << (f.is_generator() ? 'G' : ' ');  // whether element is primitive

        ulong p, d;  // minpoly, degree(minpoly)
        d = minpoly(f, p);
        print_bin_nn("   p=",p,pn+2);
        cout << "  t= " << f.trace();
        cout << "  d= " << setw(2) << d;
//        cout << "  " << (d==n ? 'D' : ' ');  // whether deg(minpoly) is maximal

        ulong h = 1UL << (d-1); // == highest_bit(p)>>1;
        if ( d < BITS_PER_LONG )
        {
            jjassert( bitpol_irreducible_q(p, h) );
            GF2n v = eval_poly(f, p);
            jjassert( 0==v );
        }

        if ( d==n )
        {
            ulong q = test_bitpol_primitive(p, h, GF2n::mfact_);
            if ( 0!=q )  cout << " N"; // Non-primitive
        }

        f *= g;
        ++k;

        cout << endl;
    }
    while ( f!=1 );
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 6;
    NXARG(n, "The n in GF(2**n).");

    RESTARGS("Optionally supply nonzero coefficients of field poly c.");
    ulong c = 0;
    for (ulong k=2;  (ulong)argc>k;  ++k)  c |= (1UL << atol(argv[k]));
    if ( 0!=c )  c |= (1UL<<n);

    GF2n::init(n, c);
    doit(n);

    return 0;
}
// -------------------------
