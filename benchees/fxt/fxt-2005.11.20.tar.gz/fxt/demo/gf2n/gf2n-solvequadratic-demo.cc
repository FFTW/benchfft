
#include "bpol/gf2n.h"

#include "bits/printbin.h"
#include "jjassert.h"
#include "fxttypes.h"  // ulong

#include <cstdlib>  // atol()


//% Solving the reduced quadratic equation z^2+z==C  over GF(2**n).


void
doit(ulong n)
{
    cout << "" << endl;
    cout << "------------------------------------------------------------" << endl;
    GF2n::print_info();
    cout << "" << endl;

    ulong pn = n;
    GF2n f(1);
    GF2n g;  g.v_ = GF2n::g_;

    cout << "   k   :   f:=g**k  t:=trace(f)  s:=rootof(z^2+z=f)" << endl;
    ulong k = 0;
    do
    {
        ulong t = f.trace();

        print_bin_nn(" ",k,pn); cout << " : ";
        cout << "  f= " << f;
        cout << "  t= " << t;
        cout << "    ";

        // solve  z*z+z = f:
        GF2n s, s2s;
        bool qq = solve_reduced_quadratic(f, s);
        if ( qq )
        {
            cout << "  s=" << s;
//            cout << "  t= " << s.trace();
            s2s = s.sqr() + s;
//            cout << "  s2s=" << s2s;
            ulong chk = (s2s - f).v_;
//            cout << "  chk=" << chk;
            jjassert( (1==t) || (0==chk) );

            s += GF2n::one;
            s2s = s.sqr() + s;
            chk = (s2s - f).v_;
//            cout << "  chk=" << chk;
            jjassert( (1==t) || (0==chk) );
        }


        cout << endl;

        f *= g;
        ++k;
    }
    while ( f!=1 );
}
// -------------------------

int
main(int argc, char **argv)
{
    bool dq = true;  // whether default behavior
    if ( argc>1 )  dq = false;

    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    ulong c = 0;
    for (ulong k=2;  (ulong)argc>k;  ++k)  c |= (1UL << atol(argv[k]));
    if ( 0!=c )  c |= (1UL<<n);

    GF2n::init(n, c);
    doit(n);

    if ( dq )  // default
    {
        n = 4;  c = 31;  // irreducible but not primitive
        GF2n::init(n, c);
        doit(n);
    }

    return 0;
}
// -------------------------
