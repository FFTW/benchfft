
#include "mod/primes.h"
#include "mod/modarith.h"

#include "mod/factor.h"
#include "demo/nextarg.h"
#include "fxttypes.h"  // ulong


//% Find moduli where all quadratic (or higher) residues are non-prime.


int
main(int argc, char **argv)
{
    ulong n = 2000;
    NXARG(n,"Search limit for moduli");
    bitarray *ba = make_oddprime_bitarray(n);
    ulong e = 2;
    NXARG(e,"Exponent (2==>squares, 3==>cubes, ...)");

    ulong ct = 0;
    for ( umod_t m=2; m<n; ++m)
    {
        bool q = 0;
        for ( umod_t x=0; x<m; ++x )
        {
            umod_t z = pow_mod(x, e, m);
            q |= is_small_prime( z, ba );
        }

        if ( 0==q )
        {
            factorization fm(m);
            ++ct;
            cout << m;
            cout << " == " << fm;
            cout << endl;
        }
    }

    cout << endl;
    cout << " #=" << ct << endl;

    return 0;
}
// -------------------------
