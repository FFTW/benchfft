
// demo-is-self-contained

#include "aux0/swap.h"
#include "fxtio.h"
#include "demo/nextarg.h"
#include "fxttypes.h"

//% Multiplication table with hypercomplex numbers (Cayley-Dickson construction)


//#define TIMING // uncomment to disable printing

#define USE_REC // define to use recursive version

#ifdef USE_REC

int CD_sign(ulong r, ulong c, ulong n)
// Signs in the multiplication table for the
//   algebra of n-ions (where n is a power of two)
//   that is obtained by the Cayley-Dickson construction:
// If component r is multiplied with component c then the
//   result is CD_sign(r,c,n) * (r XOR c).
// Rule (a,b)*(A,b) = (a*A - B*conj(b),  conj(a)*B + A*b)
//   where conj(a,b) := (conj(a), -b) and conj(x):=x for x real
// [ Transposed rule/table is
//    (a,b)*(A,b) = (a*A - conj(B)*b,  b*conj(A) + B*a)  ]
// Must have: r<n, c<n.
// Example (octionions, n==8):
// (er*ec) e0   e1   e2   e3    e4   e5   e6   e7
//   e0:  +e0  +e1  +e2  +e3   +e4  +e5  +e6  +e7
//   e1:  +e1  -e0  -e3  +e2   -e5  +e4  +e7  -e6
//   e2:  +e2  +e3  -e0  -e1   -e6  -e7  +e4  +e5
//   e3:  +e3  -e2  +e1  -e0   -e7  +e6  -e5  +e4
//
//   e4:  +e4  +e5  +e6  +e7   -e0  -e1  -e2  -e3
//   e5:  +e5  -e4  +e7  -e6   +e1  -e0  +e3  -e2
//   e6:  +e6  -e7  -e4  +e5   +e2  -e3  -e0  +e1
//   e7:  +e7  +e6  -e5  -e4   +e3  +e2  -e1  -e0
// Signs at row r, column c equal CD_sign(r,c,8): 
//   + + + + + + + +
//   + - - + - + + -
//   + + - - - - + +
//   + - + - - + - +
//   + + + + - - - -
//   + - + - + - + -
//   + - - + + - - +
//   + + - - + + - -
// This is a (8 x 8) Hadamard matrix.
// The second row is the (signed) Thue-Morse sequence.
// We have: er*ec = -ec*er iff er!=e0 and ec!=e0
{
    if ( (r==0) || (c==0) )  return +1;
    if ( c>=r )
    {
        if ( c>r )   return  -CD_sign(c, r, n);
        else  return -1;  // r==c
    }
    // here r>c (triangle below diagonal)

    ulong h = n>>1;
    if ( c>=h )  // right
    {
        // (upper right unreached)
        return   CD_sign(c-h, r-h, h); // lower right
    }
    else  // left
    {
        if ( r>=h )  return   CD_sign(c, r-h, h); // lower left
        else         return   CD_sign(r, c, h); // upper left
    }
}
// -------------------------

#else // USE_REC

inline void cp2(ulong a, ulong b, ulong &u, ulong &v)  { u=a; v=b; }
//
inline int CD_sign(ulong r, ulong c, ulong n)
{
    int s = +1;
start:
    if ( (r==0) || (c==0) )  return s;
    if ( c==r )  return -s;
    if ( c>r )   { swap2(r,c); s=-s; }
    n >>= 1;
    if ( c>=n )  cp2(c-n, r-n, r, c);
    else if ( r>=n )  cp2(c, r-n, r, c);
    goto start;
}
// -------------------------

#endif // USE_REC

int
main(int argc, char **argv)
{
    ulong ldn = 5;
    NXARG(ldn, "Multiplication table for (2**ldn)-ions");
    ulong n = 1UL << ldn;
    bool q = 0;
    NXARG(q, "Whether to include indices of components");

#ifdef TIMING
    int x = 0;
    for (ulong r=0; r<n; ++r)
        for (ulong c=0; c<n; ++c) { x ^= CD_sign(r, c, n); }
    return x;
#else
    for (ulong r=0; r<n; ++r)
    {
        cout << setw(3) << r << ":  ";
        for (ulong c=0; c<n; ++c)
        {
            int s = CD_sign(r, c, n);
            if ( 0==q )  cout << " " << (s<0 ? '-' : '+');
            else
            {
                cout << setw(3) << (r^c) << (s<0 ? '-' : '+');
            }
        }
        cout << endl;
    }
    return 0;
#endif
}
// -------------------------

/*
Timing: (ldn==2**12 ==> 2**24==16,777,216 computations)
recursive:
% time ./bin 12
./bin 12  1.84s user 0.01s system 99% cpu 1.859 total
  ==  9,024,860 signs per second

iterative:
% time ./bin 12
./bin 12  1.30s user 0.00s system 99% cpu 1.297 total
  == 12,935,401 signs per second

*/
