
#include "sort/equivclasses.h"  // equivalence_classes()
#include "sort/sortbykey.h"  // sort_by_key()

#include "bits/bitcyclic-dist.h"  // bit_cyclic_dist()
#include "bits/revbin.h" // revbin()


//#include "perm/permrand.h" // random_permute()

#include "bits/printbin.h" // print_bin_nn()
#include "demo/nextarg.h" // NXARG()
#include "fxttypes.h"  // ulong
//#include "bits/bitsperlong.h"

#include "fxtiomanip.h"
#include "fxtalloca.h"


//% Equivalence classes: binary bracelets.


static ulong b;  // number of bits
static ulong mm;  // mask to complement

bool b_equiv_q(ulong x, ulong y)  // bracelets
{
    ulong d = bit_cyclic_dist(x, y, b);
    if ( 0!=d )  d = bit_cyclic_dist(revbin(x,b), y, b);
    return  (0==d);
}
// -------------------------

bool bu_equiv_q(ulong x, ulong y)  // unlabeled bracelets
{
    ulong d = bit_cyclic_dist(x, y, b);
    x ^= mm;
    if ( 0!=d )  d = bit_cyclic_dist(x, y, b);

    x = revbin(x,b);
    if ( 0!=d )  d = bit_cyclic_dist(x, y, b);
    x ^= mm;
    if ( 0!=d )  d = bit_cyclic_dist(x, y, b);

    return  (0==d);
}
// -------------------------


int
main(int argc, char **argv)
{
    b = 6;
    NXARG(b, "Number of bits of bracelets (0<b<BITS_PER_LONG).");
    ulong n = 1UL<<b;
    mm = n-1;

    ulong cq = 0;
    NXARG(cq, "Whether equivalence includes complements (==> unlabeled bracelets).");

    ulong ksq = 0;
    NXARG(ksq, "Whether to print key-sorted array.");

    ALLOCA(ulong, s, n);
    for (ulong k=0; k<n; ++k)  s[k] = k;
//    random_permute(s, n);

    ulong *e;
    if ( 0==cq )  e = equivalence_classes(s, n, b_equiv_q);
    else          e = equivalence_classes(s, n, bu_equiv_q);

    // --- print all elements with 'coset leaders':
    for (ulong k=0; k<n; ++k)
    {
        cout << setw(3) << k << ": ";
        print_bin_nn(" ", s[k], b);
        cout << "  " << setw(2) << e[k];
        cout << endl;
    }
    cout << endl;


    sort_by_key(s, n, e, 1);
    if ( ksq )
    {
        for (ulong k=0; k<n; ++k)
        {
            cout << setw(3) << k << ": ";
            print_bin_nn(" ", s[k], b);
            cout << "  " << setw(2) << e[k];
            cout << endl;
        }
        cout << endl;
    }

    // --- print all elements in each equivalence class:
    ulong cct = 0; // count number of classes
    for (ulong k=0; k<n; /**/ )
    {
        ++cct;
        ulong el = e[k];
        cout << setw(3) << el << ": ";
        ulong ct;
        for (ct=0; k<n; ++ct,++k)
        {
            ulong ek = e[k];
            if ( ek != el )
            {
                break;
            }
            print_bin_nn("  ", s[k], b);
        }
        cout << "  [#=" << ct << "]";
        cout << endl;
    }
    cout << endl;
    cout << "  # of equivalence classes = " << cct << "";
    cout << endl;

    return 0;
}
// -------------------------

/*
 # of bracelets:
% for n in $(seq 1 14); do echo -n "$n: "; ./bin $n 0 | grep 'equivalence classes' | cut -d= -f2; done
1:  2
2:  3
3:  4
4:  6
5:  8
6:  13
7:  18
8:  30
9:  46
10:  78
11:  126
12:  224
13:  380
14:  687

 # of unlabeled bracelets:
% for n in $(seq 1 14); do echo -n "$n: "; ./bin $n 1 | grep 'equivalence classes' | cut -d= -f2; done
1:  1
2:  2
3:  2
4:  4
5:  4
6:  8
7:  9
8:  18
9:  23
10:  44
11:  63
12:  122
13:  190
14:  362

*/
