
#include "sort/sortcomplex.h"
#include "sort/bsearch.h"

#include "fxttypes.h"
#include "complextype.h"
#include "aux0/randf.h"  // rnd01()
#include "sort/quantize.h"  // quantize()

#include "jjassert.h"

#include "fxtiomanip.h"

#include "demo/nextarg.h" // NXARG()

//% Demo of sort for complex numbers.

void
print(const char *bla, const Complex *f, ulong n)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        Complex r = f[k];

        cout.flags(ios::right);
        cout << setw(4) << k << ":  ";
//        cout.flags(ios::left);

        cout.precision(5);
        cout << "(";
        cout.width(5);
        cout << r.real();
        cout << ", ";
        cout.width(5);
        cout << r.imag();
        cout << ")";
        cout << endl;
    }
    cout << endl;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 25;
    NXARG(n, "Number of elements");
    ulong nr = 2 * n;

    double *fr = new double[nr];

    rnd01(fr, n);
    quantize(fr, nr, 1.0/10); // we want repeated real parts

    Complex *f = (Complex *)fr;
    print("random values:", f, n);

    Complex v = f[n/2];

    complex_sort(f, n);
    print("sorted values:", f, n);

    jjassert( is_complex_sorted(f, n) );

    cout << "searching for v=" << v << endl;
    ulong i = bsearch_complex(f, n, v);
    jjassert( i<n );
    cout << "found at index " << i << endl;

    return 0;
}
// -------------------------
