#if !defined HAVE_FXTIOMANIP_H__
#define      HAVE_FXTIOMANIP_H__

#include  "fxtio.h"

#include  <iomanip>
//using namespace std;
using std::setw;
using std::setfill;
using std::setprecision;
using std::setbase;
using std::hex;
using std::dec;


#endif // !defined HAVE_FXTIOMANIP_H__
