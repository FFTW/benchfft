#if !defined HAVE_FXTAUXLAZY_H__
#define      HAVE_FXTAUXLAZY_H__


//: include file for the super-lazy: include all headers */*lazy.h
//: that is, include most of the known universe


#include "fxttypes.h"
#include "complextype.h"

#include "cmult.h"
#include "sumdiff.h"

#include "constants.h"

//#include "jjassert.h"

#include "auxbitlazy.h"
#include "sortlazy.h"
#include "aux0lazy.h"
#include "aux1lazy.h"
#include "aux2lazy.h"
#include "auxbitlazy.h"
#include "permlazy.h"
#include "comblazy.h"
#include "modlazy.h"
#include "walshlazy.h"
#include "haarlazy.h"


#endif // !defined HAVE_FXTAUXLAZY_H__
