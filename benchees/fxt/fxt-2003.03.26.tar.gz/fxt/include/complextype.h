#if !defined HAVE_COMPLEXTYPE_H__
#define      HAVE_COMPLEXTYPE_H__


//#include "complextype.h" // this file

#include <complex>
//using namespace std;
//#define  Complex  complex<double>
//typedef  complex<double>  Complex;

using std::complex;
typedef  complex<double>  Complex;


#endif // !defined HAVE_COMPLEXTYPE_H__
