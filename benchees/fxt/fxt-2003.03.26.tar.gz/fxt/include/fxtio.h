#if !defined HAVE_FXTIO_H__
#define      HAVE_FXTIO_H__


#include  <iostream>
//using namespace std;
using std::ios;
using std::cout;
using std::cerr;
using std::cin;
using std::endl;
using std::flush;

//class ostream;
//using std::ostream;


#endif // !defined HAVE_FXTIO_H__
