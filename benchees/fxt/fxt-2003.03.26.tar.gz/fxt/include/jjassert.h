#if !defined HAVE_JJASSERT_H__
#define      HAVE_JJASSERT_H__

//#include "jjassert.h" // this file

// aux0/jjassert.cc:
// options for last action of jjassert_fail():
#define JJ_ASSERT_IGNORE  0
#define JJ_ASSERT_ABORT   1
//#define JJ_ASSERT_PAUSE   2
#define JJ_ASSERT_SEGV    4
#define JJ_ASSERT_STOP    8
//
#define JJ_ASSERT_DEFAULT  1  // abort should be default

// can be modified at runtime using
void set_fail_action(int a=JJ_ASSERT_DEFAULT);

void jjassert_fail(const char *func, const char *pretty_func,
                   const char *file, const int   line,
                   const char *expr, const char *bla);


#if defined  NDEBUG

#define jjassert(expr)
#define jjassert2(expr, bla)

#else // NDEBUG

// we use the equivalent of __STRING() as defined in
// #include <sys/cdefs.h>  however, using a different name
// to make avoid portability trouble:
// was;
////#define  __STRING(s)   __XSTRING(s)
////#define  __XSTRING(s)  #s
// now, instead:
#define __JJSTRING(s) #s

#define jjassert(expr) \
do { \
if ( !(expr) )  \
jjassert_fail( \
__FUNCTION__, \
__PRETTY_FUNCTION__, \
__FILE__, \
__LINE__, \
__JJSTRING(expr), \
0); \
} while (0)  // no semicolon


#define jjassert2(expr, bla) \
do { \
if ( !(expr) )  \
jjassert_fail( \
__FUNCTION__, \
__PRETTY_FUNCTION__, \
__FILE__, \
__LINE__, \
__JJSTRING(expr), \
bla); \
} while (0)  // no semicolon


#endif // NDEBUG


#endif  // !defined HAVE_JJASSERT_H__
