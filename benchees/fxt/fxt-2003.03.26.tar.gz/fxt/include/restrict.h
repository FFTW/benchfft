#if !defined HAVE_RESTRICT_H__
#define      HAVE_RESTRICT_H__

//#include "restrict.h"  // this file

// From the gcc info pages:
//  Because you cannot compile C++ by specifying the `-std=c99'
//  language flag, `restrict' is not a keyword in C++.
#define  restrict  __restrict


#endif // !defined HAVE_RESTRICT_H__
