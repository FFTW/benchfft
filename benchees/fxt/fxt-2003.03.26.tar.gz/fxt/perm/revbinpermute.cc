
#include  "revbinpermute.h"
#include  "revbinpermute0.h"


// tuning parameter in revbinpermute.h:
#if  ( RBP_SYMM == 1 )
#  warning  "FYI:  RBP_SYMM == 1  for revbin_permute()"
#else // !=1
#  if  ( RBP_SYMM == 2 )
#    warning  "FYI:  RBP_SYMM == 2  for revbin_permute()"
#  else  // !=2
#    if  ( RBP_SYMM == 4 )
#      warning  "FYI:  RBP_SYMM == 4  for revbin_permute()"
#    else
#      error 'RBP_SYMM must be 1, 2 or 4  for revbin_permute()'
#    endif //  ( RBP_SYMM == 4 )
#  endif //  ( RBP_SYMM == 2 )
#endif //  ( RBP_SYMM == 1 )

#if defined RBP_USE_ASM
#  warning  "FYI:  asm-bitscan used in revbin_permute()"
#endif


// tuning parameter in revbinpermute0.h:
#if  ( RBP0_SYMM == 2 )
#  warning  "FYI:  RBP0_SYMM == 2  for revbin_permute0()"
#else  // !=2
#  if  ( RBP0_SYMM == 4 )
#    warning  "FYI:  RBP0_SYMM == 4  for revbin_permute0()"
#  else // !=4
#    error 'RBP0_SYMM must be 2 or 4  for revbin_permute0()'
#  endif //  ( RBP0_SYMM == 4 )
#endif //  ( RBP0_SYMM == 2 )


