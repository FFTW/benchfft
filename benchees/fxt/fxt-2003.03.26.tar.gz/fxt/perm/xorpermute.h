#if !defined HAVE_XORPERMUTE_H__
#define      HAVE_XORPERMUTE_H__


#include "fxttypes.h"

#include "inline.h"  // swap()
#define swap fxtaux::swap // avoid unwanted std::swap


template <typename Type>
void xor_permute(Type *f, ulong n, ulong x)
// self-inverse
// n must be divisible by the smallest power of two
//   that is greater than x
// e.g. x=1  --> n must be even
// e.g. x=2,3  --> n must be divisible by four
// With n a power of two and x<n one is on the safe side
{
    if ( 0==x )  return;
    for (ulong k=0; k<n; ++k)
    {
        ulong r = k^x;
        if ( r>k )  swap(f[r], f[k]);
    }
}
// -------------------------


#undef swap // end (avoid unwanted std::swap)

#endif // !defined HAVE_XORPERMUTE_H__
