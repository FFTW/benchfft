#if !defined HAVE_PERMAPPLY_H__
#define      HAVE_PERMAPPLY_H__


#include "fxttypes.h"
#include "bitarray.h"
#include "restrict.h"


template <typename Type>
void apply_permutation(const ulong *x, const Type *f, Type * restrict g, ulong n)
//
// apply x[] on f[]
//
// i.e.  g[k] <-- f[x[k]]  \forall k
//
// e.g. after
// idx_quick_sort(f, n, x);  apply(x, f, g, n);
//  g[] == sorted( f[] )
//
// if  f[] is a permutation, then after sort_idx()
// x[] is its inverse and
// idx_quick_sort(f, n, x);  apply(f, x, g, n);
// (note that x, f are swapped in apply())
//  will make x[] == sorted( f[] )
// ... i.e.  x @ f == f @ x
//
{
    for (ulong k=0; k<n; ++k)  g[k] = f[x[k]];
}
// -------------------------


template <typename Type>
void apply_permutation(const ulong *x, Type *f, ulong n, bitarray *bp=0)
//
// apply x[] on f[]  (in-place operation)
//
// i.e.  f[k] <-- f[x[k]]  \forall k
//
{
    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags
    tp->clear_all();

    for (ulong k=0; k<n; ++k)
    {
        if ( tp->test_clear(k) )  continue;  // already processed
        tp->set(k);

        // --- do cycle: ---
        ulong i = k;  // start of cycle
        Type t = f[i];
        ulong g = x[i];
        while ( 0==(tp->test_set(g)) )  // cf. inverse_gray_permute()
        {
            f[i] = f[g];
            i = g;
            g = x[i];
        }
        f[i] = t;
        // --- end (do cycle) ---
    }

    if ( 0==bp )  delete tp;
}
// -------------------------



template <typename Type>
void apply_inverse_permutation(const ulong *x, const Type *f, Type * restrict g, ulong n)
//
// apply inverse of x[] on f[]
//
// i.e.  g[x[k]] <-- f[k]  \forall k
//
{
    for (ulong k=0; k<n; ++k)  g[x[k]] = f[k];
}
// -------------------------


template <typename Type>
void apply_inverse_permutation(const ulong *x, Type * restrict f, ulong n, bitarray *bp=0)
//
// apply inverse of x[] on f[]  (in-place operation)
//
// i.e.  f[x[k]] <-- f[k]  \forall k
//
{
    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags
    tp->clear_all();

    for (ulong k=0; k<n; ++k)
    {
        if ( tp->test_clear(k) )  continue;  // already processed
        tp->set(k);

        // --- do cycle: ---
        ulong i = k;  // start of cycle
        Type t = f[i];
        ulong g = x[i];
        while ( 0==(tp->test_set(g)) )  // cf. gray_permute()
        {
            Type tt = f[g];
            f[g] = t;
            t = tt;
            g = x[g];
        }
        f[g] = t;
        // --- end (do cycle) ---
    }

    if ( 0==bp )  delete tp;
}
// -------------------------


#endif // !defined HAVE_PERMAPPLY_H__
