#if !defined HAVE_ZIP_H__
#define      HAVE_ZIP_H__


#include "fxttypes.h"
#include "revbinpermute.h"
#include "bitrotate.h"
#include "restrict.h"

// perm/zip.cc:
void zip(double *f, long n);
void unzip(double *f, long n);


template <typename Type>
void zip(const Type * restrict f, Type * restrict g, ulong n)
// n must be even
{
    ulong nh = n/2;
    for (ulong k=0,  k2=0;  k<nh;  ++k, k2+=2)  g[k2] = f[k];

//    if ( n>1 )  // make it also work for length == 1
    {
        for (ulong k=nh, k2=1;  k<n;   ++k, k2+=2)  g[k2] = f[k];
    }
}
// -------------------------


template <typename Type>
void zip(Type *f, ulong n)
//
// lower half --> even indices
// higher half --> odd indices
//
// same as transposing the array as 2 x n/2 - matrix
//
// useful to combine real/imag part into a complex array
//
// n must be a power of two
{
    ulong nh = n/2;
    revbin_permute(f, nh);  revbin_permute(f+nh, nh);
    revbin_permute(f, n);
}
// -------------------------


template <typename Type>
void unzip(const Type * restrict f, Type * restrict g, ulong n)
// n must be even
{
    ulong nh = n/2;
    for (ulong k=0,  k2=0;   k<nh;  ++k, k2+=2)  g[k] = f[k2];
//    if ( n>1 )  // make it also work for length == 1
    {
        for (ulong k=nh, k2=1;   k<n;   ++k, k2+=2)  g[k] = f[k2];
    }
}
// -------------------------


template <typename Type>
void unzip(Type *f, ulong n)
//
// inverse of zip():
// put part of data with even indices
// sorted into the lower half,
// odd part into the higher half
//
// same as transposing the array as n/2 x 2 - matrix
//
// useful to separate a complex array into real/imag part
//
// n must be a power of two
{
    ulong nh = n/2;
    revbin_permute(f, n);
    revbin_permute(f, nh);  revbin_permute(f+nh, nh);
}
// -------------------------


#endif // !defined HAVE_ZIP_H__
