#if !defined HAVE_PERMLAZY_H__
#define      HAVE_PERMLAZY_H__

//: include file for the lazy: include all headers from perm/

#include "cycles.h"
#include "graypermute.h"
#include "grayrevpermute.h"
#include "greenpermute.h"
#include "greenrevpermute.h"
#include "xorpermute.h"
#include "haarpermute.h"
#include "permapply.h"
#include "permderange.h"
#include "permlex.h"
#include "permminchange.h"
#include "permtrotter.h"
#include "permutation.h"
#include "permvisit.h"
#include "permcyclic.h"
#include "permstar.h"
#include "radixpermute.h"
#include "revbinpermute.h"
#include "revbinpermute0.h"
#include "reverse.h"
#include "rotate.h"
#include "mrotate.h"
#include "shortgraypermute.h"
#include "shortrevbinpermute.h"
#include "shortrevbinpermute0.h"
#include "zip.h"
#include "ziprev.h"


#endif  // !defined HAVE_PERMLAZY_H__
