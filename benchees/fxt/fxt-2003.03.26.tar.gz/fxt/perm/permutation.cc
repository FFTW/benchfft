
#include "fxttypes.h"
#include "restrict.h"

#include "permutation.h"
#include "bitarray.h"
#include "bit2pow.h"

#include "copy.h"

#include "inline.h" // swap()
#define swap fxtaux::swap // avoid unwanted std::swap

#include <stdlib.h>  // rand()


void
make_inverse(const ulong *f, ulong * restrict g, ulong n)
//
// set g[] to the inverse of f[]
{
    for (ulong k=0; k<n; ++k)  g[f[k]] = k;
}
// -------------------------


void
make_inverse(ulong *f, ulong n, bitarray *bp/*=0*/)
//
// set f[] to its own inverse
{
    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags
    tp->clear_all();

    for (ulong k=0; k<n; ++k)
    {
        if ( tp->test_clear(k) )  continue;  // already processed
        tp->set(k);

        // invert a cycle:
        ulong i = k;
        ulong g = f[i];  // next index
        while ( 0==(tp->test_set(g)) )
        {
            ulong t = f[g];
            f[g] = i;
            i = g;
            g = t;
        }
        f[g] = i;
    }

    if ( 0==bp )  delete tp;
}
// -------------------------


void
boothroyd(ulong *f, ulong n, bitarray *bp/*=0*/)
//
// set f[] to its own inverse
// Boothroyds algorithm
// complexity is n*log(n), so make_inverse() is better
// ... but Knuth says the algorithm is ingenious, so its here
//
{
    bp = 0;
    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags
    tp->clear_all();

    for (ulong m=0; m<n; ++m)
    {
        ulong j = m;
        ulong i = f[j];
        while ( tp->test(j) )  // already processed
        {
            j = i;
            i = f[j];  // next index
        }

        f[j] = f[i];
        f[i] = m;

        tp->set(i);
        //  j stays untagged !
    }

    if ( 0==bp )  delete tp;
}
// -------------------------



void
make_square(const ulong *f, ulong * restrict g, ulong n)
//
// set g[] = f[] * f[]
//
{
    for (ulong k=0; k<n; ++k)  g[k] = f[f[k]];
}
// -------------------------


void
make_square(ulong *f, ulong n, bitarray *bp/*=0*/)
//
// set f[] to f[] * f[]
//
{
    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags
    tp->clear_all();

    for (ulong k=0; k<n; ++k)
    {
        if ( tp->test_clear(k) )  continue;  // already processed
        tp->set(k);

        // square a cycle:
        ulong i = k;
        ulong t = f[i];  // save
        ulong g = f[i];  // next index
        while ( 0==(tp->test_set(g)) )
        {
            f[i] = f[g];
            i = g;
            g = f[g];
        }
        f[i] = t;
    }

    if ( 0==bp )  delete tp;
}
// -------------------------


void
compose(const ulong *f, const ulong *g, ulong * restrict h, ulong n)
//
// set h[] = f[] * g[]
//
{
    for (ulong k=0; k<n; ++k)  h[k] = f[g[k]];
}
// -------------------------


void
compose(const ulong *f, ulong * restrict g, ulong n)
//
// set  g[] = f[] * g[]
//
{
    for (ulong k=0; k<n; ++k)  g[k] = f[g[k]]; // yes, this works
}
// -------------------------


void
power(const ulong *f, ulong * restrict g, ulong n,
      long e,
      ulong * restrict t/*=0*/)
//
// set  g[] = f[] ** e
//
{
    if ( e==0 )
    {
        for (ulong k=0; k<n; ++k)  g[k] = k;
        return;
    }

    if ( e==1 )
    {
        copy(f, g, n);
        return;
    }

    if ( e==-1 )
    {
        make_inverse(f, g, n);
        return;
    }

    // here:  abs(e) > 1
    ulong x = e>0 ? e : -e;

    if ( is_pow_of_2(x) )  // special case x==2^n
    {
        make_square(f, g, n);
        while ( x>2 )  { make_square(g, n);  x /= 2; }
    }
    else
    {
        ulong *tt = t;
        if ( 0==t )  { tt = new ulong[n]; }
        copy(f, tt, n);

        int firstq = 1;
        while ( 1 )
        {
            if ( x&1 )  // odd
            {
                if ( firstq )  // avoid multiplication by 1
                {
                    copy(tt, g, n);
                    firstq = 0;
                }
                else  compose(tt, g, n);

                if ( x==1 )   goto dort;
            }

            make_square(tt, n);
            x /= 2;
        }

    dort:
        if ( 0==t )  delete [] tt;
    }


    if ( e<0 )  make_inverse(g, n);
}
// -------------------------


void
random_permute(ulong *f, ulong n)
// randomly permute the elements of f[]
//
// algorithm given by Helmut Herold, attributed to C.L.Robinson
{
    for (ulong k=1; k<n; ++k)
    {
        ulong r = (ulong)rand();
        r ^= r>>16;  // avoid using low bits of rand alone

        ulong i = r % (k+1);
        swap(f[k], f[i]);
    }
}
// -------------------------


void
random_permutation(ulong *f, ulong n)
// create a random permutation
{
    for (ulong k=0; k<n; ++k)  f[k] = k;

    random_permute(f, n);
}
// -------------------------
