#if !defined HAVE_SHORTREVBINPERMUTE0_H__
#define      HAVE_SHORTREVBINPERMUTE0_H__


#include "inline.h" // swap0()

//template <typename Type>
//inline void
//revbin_permute0_2(Type *f)
//// unrolled version for length 2
//{
//}  // # of swaps = 0

template <typename Type>
inline void revbin_permute0_4(Type *f)
// unrolled version for length 4
{
 swap0(f[1], f[2]);
}  // # of swaps = 1

template <typename Type>
inline void revbin_permute0_8(Type *f)
// unrolled version for length 8
{
 swap0(f[1], f[4]);
 swap0(f[3], f[6]);
}  // # of swaps = 2

template <typename Type>
inline void revbin_permute0_16(Type *f)
// unrolled version for length 16
{
 swap0(f[1], f[8]);
 swap(f[2], f[4]);
 swap0(f[3], f[12]);
 swap0(f[5], f[10]);
 swap0(f[7], f[14]);
 swap0(f[11], f[13]);
}  // # of swaps = 6

template <typename Type>
inline void revbin_permute0_32(Type *f)
// unrolled version for length 32
{
 swap0(f[1], f[16]);
 swap(f[2], f[8]);
 swap0(f[3], f[24]);
 swap0(f[5], f[20]);
 swap(f[6], f[12]);
 swap0(f[7], f[28]);
 swap0(f[9], f[18]);
 swap0(f[11], f[26]);
 swap0(f[13], f[22]);
 swap0(f[15], f[30]);
 swap0(f[19], f[25]);
 swap0(f[23], f[29]);
}  // # of swaps = 12

template <typename Type>
inline void revbin_permute0_64(Type *f)
// unrolled version for length 64
{
 swap0(f[1], f[32]);
 swap(f[2], f[16]);
 swap0(f[3], f[48]);
 swap(f[4], f[8]);
 swap0(f[5], f[40]);
 swap(f[6], f[24]);
 swap0(f[7], f[56]);
 swap0(f[9], f[36]);
 swap(f[10], f[20]);
 swap0(f[11], f[52]);
 swap0(f[13], f[44]);
 swap(f[14], f[28]);
 swap0(f[15], f[60]);
 swap0(f[17], f[34]);
 swap0(f[19], f[50]);
 swap0(f[21], f[42]);
 swap(f[22], f[26]);
 swap0(f[23], f[58]);
 swap0(f[25], f[38]);
 swap0(f[27], f[54]);
 swap0(f[29], f[46]);
 swap0(f[31], f[62]);
 swap0(f[35], f[49]);
 swap0(f[37], f[41]);
 swap0(f[39], f[57]);
 swap0(f[43], f[53]);
 swap0(f[47], f[61]);
 swap0(f[55], f[59]);
}  // # of swaps = 28


// Local variables:
// mode: C++
// c-basic-offset: 1
// End:

#endif // HAVE_SHORTREVBINPERMUTE0_H__
