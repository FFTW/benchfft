#if !defined HAVE_PERMLEX_H__
#define      HAVE_PERMLEX_H__

//#include "newop.h"
#include "fxttypes.h"


class perm_lex
{
protected:
    ulong n;   // number of elements to permute
    ulong *p;  // current permutation of {0, 1, ..., n-1}
    ulong idx; // incremented with each call to next()
    ulong sgn; // sign of the permutation

public:
    perm_lex(ulong nn)
    {
        n = (nn > 0 ? nn : 1);
        p = new ulong[n];
        first();
    }

    ~perm_lex() { delete [] p; }

    void first()
    {
        for (ulong i=0; i<n; i++)  p[i] = i;
        sgn = 0;
        idx = 0;
    }

    ulong next();
    ulong current()  const  { return idx; }
    ulong sign()  const  { return sgn; }  // 0 for sign +1,  1 for sign -1
    const ulong *data()  const  { return p; }
};
// -------------------------



#endif  // !defined HAVE_PERMLEX_H__
