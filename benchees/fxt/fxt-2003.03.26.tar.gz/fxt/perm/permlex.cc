
#include "fxttypes.h"
#include "inline.h"
#include "permlex.h"


ulong
perm_lex::next()
// based on code by Glenn Rhoads
// (who ascribes the algorithm to Dijkstra)
//
// added modulo 2 count of transpositions (sign)
{
    const ulong n1 = n - 1;
    ulong i = n1;
    do
    {
        --i;
        if ( (long)i<0 )  return  0;  // last sequence is falling seq.
    }
    while ( p[i] > p[i+1] );

    ulong j = n1;
    while ( p[i] > p[j] )  --j;

    swap(p[i], p[j]);  sgn ^= 1;

    ulong r = n1;
    ulong s = i + 1;
    while ( r > s )
    {
        swap(p[r], p[s]);  sgn ^= 1;
        --r;
        ++s;
    }

    ++idx;
    return  idx;
}
// -------------------------
