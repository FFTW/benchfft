#if !defined HAVE_PERMTROTTER_H__
#define      HAVE_PERMTROTTER_H__

#include "fxttypes.h"


class perm_trotter
{
public:
    ulong n_;   // number of elements to permute
    ulong *x_;  // current permutation (of {0, 1, ..., n-1})
    ulong *d_;  // aux
    ulong *p_;  // aux
    ulong idx_; // incremented with each call to next()
    ulong sw1_, sw2_; // index of elements swapped most recently

public:
    perm_trotter(ulong nn); // nn>=2
    ~perm_trotter();

    void first();
    ulong next()  { make_next();  return idx_; }
    ulong current()  const  { return idx_; }
    ulong sign()  const  { return  idx_ & 1; }  // 0 for sign +1,  1 for sign -1
    const ulong *data()  const  { return x_; }
    void get_swap(ulong &s1, ulong &s2)  const  { s1=sw1_; s2=sw2_; }

    void make_next();
};
// -------------------------


#endif  // !defined HAVE_PERMTROTTER_H__
