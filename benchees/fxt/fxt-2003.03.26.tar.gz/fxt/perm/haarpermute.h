#if !defined HAVE_HAARPERMUTE_H__
#define      HAVE_HAARPERMUTE_H__

#include "fxttypes.h"
#include "revbinpermute.h"


template <typename Type>
void haar_permute(Type *f, ulong ldn)
// reorder autoput of inplace_haar() as in haar()
// to be called after inplace_haar()
{
    revbin_permute(f, 1UL<<ldn);
    // here: high freq are in higher half

    for (ulong ldm=1; ldm<=ldn-1; ++ldm)
    {
        ulong m = (1UL<<ldm);  // m=2, 4, 8, ..., n/2
        revbin_permute(f+m, m);
    }
}
// -------------------------


template <typename Type>
void inverse_haar_permute(Type *f, ulong ldn)
// reorder autoput of inverse_inplace_haar() as in inverse_haar()
// to be called before inverse_inplace_haar()
{

    for (ulong ldm=1; ldm<=ldn-1; ++ldm)
    {
        ulong m = (1UL<<ldm);  // m=2, 4, 8, ..., n/2
        revbin_permute(f+m, m);
    }

    revbin_permute(f, 1UL<<ldn);
}
// -------------------------


#endif // !defined HAVE_HAARPERMUTE_H__
