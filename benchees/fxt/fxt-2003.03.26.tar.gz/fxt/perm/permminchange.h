#if !defined HAVE_PERMMINCHANGE_H__
#define      HAVE_PERMMINCHANGE_H__

#include "fxttypes.h"


class perm_minchange
{
protected:
    ulong n;   // number of elements to permute
    ulong *p;  // p[n] contains a permutation of {0, 1, ..., n-1}
    ulong *ip; // ip[n] contains the inverse permutation of p[]
    ulong *d;  // aux
    ulong *ii; // aux
    ulong sw1, sw2; // index of elements swapped most recently
    ulong idx; // incremented with each call to next()

public:
    perm_minchange(ulong nn);
    ~perm_minchange();
    void first();

    ulong next()  { return make_next(n-1); }  // return 0 if on last permutation
    ulong current()  const  { return idx; }
    ulong sign()  const  { return  idx & 1; }  // 0 for sign +1,  1 for sign -1
    const ulong *data()  const  { return p; }
    const ulong *invdata()  const  { return ip; }
    void get_swap(ulong &s1, ulong &s2)  const  { s1=sw1; s2=sw2; }

protected:
    ulong make_next(ulong m);
};
// -------------------------


#endif  // !defined HAVE_PERMMINCHANGE_H__
