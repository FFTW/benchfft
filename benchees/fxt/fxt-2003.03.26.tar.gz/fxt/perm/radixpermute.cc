
#include "fxttypes.h"
#include "bitsperlong.h"  // BITS_PER_LONG

ulong radix_permute_nt[BITS_PER_LONG];
ulong radix_permute_kt[BITS_PER_LONG];

