#if !defined HAVE_PERMCYCLIC_H__
#define      HAVE_PERMCYCLIC_H__


#include "fxttypes.h"
//#include "newop.h"


class perm_cyclic
//
// algorithm of G.G.Langdon Jr., as given in Knuth
//
{
public:
    ulong n_;
    ulong k_;
    ulong *x_;
    ulong *a_;

public:
    perm_cyclic(ulong n)
        : n_(n)
    {
        x_ = new ulong[2*n_];
        a_ = x_ + n_;
        first();
    }

    ~perm_cyclic()  { delete [] x_; }

    void first()
    {
        for (ulong k=0; k<n_; ++k)  a_[k] = x_[k] = k;
        k_ = n_;
    }

    ulong next()
    {
        k_ = n_;
        do
        {
            ulong a0 = a_[0];
            ulong k1 = k_ - 1;
            for (ulong k=0; k<k1; ++k)  a_[k] = a_[k+1];
            a_[k1] = a0;

            if ( a_[k1] != x_[k1] )  break;
        }
        while ( 0 != --k_ );

        return k_;
    }

    ulong current()  const  { return k_; }

    const ulong *data()  const  { return a_; }
};
// -------------------------


#endif  // !defined HAVE_PERMCYCLIC_H__
