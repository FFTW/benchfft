
#include "fxttypes.h"
#include "mtypes.h"
#include "primes.h"
#include "bitarray.h"

#include <cmath>

// automatic initialisation (see end of file)


uint * prime_tab = 0;
bitarray * oddprime_bitarray = 0;

static uint ct = 0;
#define MAX_PRIME  66000  //  >500, use 66000 or so

uint
prime(uint n)
{
    if ( n>=ct )  return 0;
    else          return prime_tab[n];
}
// -------------------------


bool
is_small_prime(uint n)
// using lookup here
{
    // n even:   2 is prime, else composite
    if ( 0==(n&1) )  return  (2==n);
    if ( n<=1 )  return  0;  // zero or one
    return  0 != oddprime_bitarray->test( n/2 );
}
// -------------------------


bool
is_small_prime(const bitarray *ba, uint n)
// using lookup here
{
    // n even:   2 is prime, else composite
    if ( 0==(n&1) )  return  (2==n);
    if ( n<=1 )  return  0;  // zero or one
    return  0 != ba->test( n/2 );
}
// -------------------------

uint
next_small_prime(const bitarray *ba, uint n)
{
    if ( is_small_prime(ba, n) )  return n;
    n = ba->next_set_idx( n/2 );
    if ( n==(ba->nb_) )  return 0;
    return  2 * n + 1;
}
// -------------------------


bitarray *
make_oddprime_bitarray(ulong n)
// Erastothenes
{
    bitarray *ba = new bitarray( n/2 + 1 );
    ba->set_all();

    for (ulong i=3, ih=i/2, i2=i*i;  i2<n;  i+=2, ++ih, i2+=2*i+1)
    {
        if ( ba->test( ih ) )
        {
            for (ulong k=i*i, kh=k/2;  k<n;  k+=2*i, kh+=i)  ba->clear( kh );
        }
    }

    return ba;
}
// -------------------------


//#include "fxtio.h"
//
//void
//print_primes(int *p, int m)
//{
//    cout << "\n// this is a generated file, do not edit!";
//    cout << "\n// (see makeprimes.cc)\n";
//    cout << "\n// primes below " << m << "\n";
//
//    cout << "\n// total " << ct << " primes \n";
//    cout << "\nextern const uint prime_tab[] =\n{\n";
//
//    for (i=2; i<m; ++i)
//    {
//        if ( 1==(i%50) )  cout << "\n";
//        if ( 0==p[i] )  cout << i << ", ";
//    }
//
//    cout << "\n0  // zero terminated\n};\n";
//}
//// ------------------------


class  init_primes
{
public:
    init_primes(uint n)
    {
        ct = erastothenes(prime_tab, n);
        oddprime_bitarray = make_oddprime_bitarray(n);
    }
};
// -------------------------

static init_primes initialise_primes(MAX_PRIME);
