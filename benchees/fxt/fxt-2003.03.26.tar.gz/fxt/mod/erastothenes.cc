
#include "fxttypes.h"
#include "mtypes.h"

#include "jjassert.h"

//#include "newop.h"


uint
erastothenes(uint *&ptab, uint m)
{
//    uint i,k;
    char p[m];

    for (uint i=0; i<m; ++i)  p[i]=0;

    uint ct = 0;
    for (uint i=2; i<m; ++i)
    {
        if ( 0==p[i] )
        {
            ct++;
            for (uint k=i*i; k<m; k+=i)  p[k] = 1;
        }
    }

    if ( ptab )  delete [] ptab;
    ptab = new uint[ct+1];
    ptab[ct] = 0;

    uint k = 0;
    for (uint i=2; i<m; ++i)
    {
        if ( 0==p[i] )
        {
            ptab[k] = i;
            k++;
        }
    }
    jjassert( k==ct );

    return ct;
}
// -------------------------
