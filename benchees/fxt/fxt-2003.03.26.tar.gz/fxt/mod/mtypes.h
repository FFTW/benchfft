#if !defined HAVE_MTYPES_H__
#define      HAVE_MTYPES_H__

#include  "fxttypes.h"


// set to 1:
#define  USE_64BIT_MOD_T  1   // 1/0 for 64/32bit type

// must set this to 0:
#define  USE_64BIT_MODULUS  0   // 1 or 0 for modulus <=63bit

// restricting moduli to <=62bit allows faster mod multiplication:
#define  USE_LEQ_62BIT_MODULUS  1  // 0 or 1 for modulus <=62bit


// types for class mod:
#if  ( USE_64BIT_MOD_T )
typedef  uint64               umod_t;
typedef   int64               smod_t;
#else
typedef  uint32               umod_t;
typedef   int32               smod_t;
#endif // ( USE_64BIT_MOD_T )



#endif  // !defined HAVE_MTYPES_H__
