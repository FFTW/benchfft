

#include "fxttypes.h"
#include "mod.h"
#include "bit2pow.h" // ld()


void
slow_ntt(mod *f, ulong n, int is)
//
// Number theoretic transform by definition (slow!)
//
{
    const mod rn = mod::root2pow( is>0 ? ld(n) : -ld(n) );

    mod g[n];
    for (ulong k=0; k<n; ++k)
    {
        mod t = mod::zero;
        mod w = mod::one;
        mod dw = pow(rn,k);

        for (ulong x=0; x<n; ++x)
        {
            t += (w*f[x]);
            w *= dw;
        }

        g[k] = t;
    }

    for (ulong x=0; x<n; ++x)  f[x] = g[x];
}
// -------------------------
