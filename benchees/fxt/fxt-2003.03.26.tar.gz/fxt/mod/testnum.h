#if !defined HAVE_TESTNUM_H__
#define      HAVE_TESTNUM_H__


#include "fxttypes.h"
#include "search.h"

#define  ARSZ(x)  (sizeof(x)/sizeof(typeof(x[0])))

extern const ulong idoneal_tab[] =
// idoneal numbers
{
    1,2,3,4,5,6,7,8,9,10,12,13,15,16,18,21,22,24,25,28,30,
    33,37,40,42,45,48,57,58,60,70,72,78,85,88,93,102,105,
    112,120,130,133,165,168,177,190,210,232,240,253,273,280,
    312,330,345,357,385,408,462,520,760,840,1320,1365,1848
};
// -------------------------

inline ulong test_idoneal(ulong x)
{
    ulong idx = bsearch(idoneal_tab, ARSZ(idoneal_tab), x);
    return  ~0 ^ idx;
}
// -------------------------


extern const ulong npqr_tab[] =
// Only non-prime quadratic residues for these moduli.
// All of them (with the exception of 56) are idoneal.
{
    2, 3, 4, 5, 8, 12, 15, 16, 24, 28, 40, 48, 56, 60, 72, 88,
    112, 120, 168, 232, 240, 280, 312, 408, 520, 760, 840,
    1320, 1848
};
// -------------------------

inline ulong test_npqr(ulong x)
{
    ulong idx = bsearch(npqr_tab, ARSZ(npqr_tab), x);
    return  ~0 ^ idx;
}
// -------------------------


extern const ulong mersx_tab[] =
// Known exponents of mersenne primes.
{
    2, 3, 5, 7, 13,
    17, 19, 31, 61, 89,
    107, 127, 521, 607, 1279,
    2203, 2281, 3217, 4253, 4423,
    9689, 9941,11213,19937, 21701,
    23209, 44497, 86243, 110503, 132049,
    216091, 756839, 859433,
    1257787, 1398269, 2976221, 3021377, 6972593,
    13466917
};
// -------------------------

inline ulong test_mersx(ulong x)
{
    ulong idx = bsearch(mersx_tab, ARSZ(mersx_tab), x);
    return  ~0 ^ idx;
}
// -------------------------


#endif // !defined HAVE_TESTNUM_H__
