#if !defined HAVE_MODM_H__
#define      HAVE_MODM_H__


#include "fxttypes.h"
#include "mtypes.h"
#include "factor.h"
#include "intarith.h"  // ipow()


inline umod_t pow2(uint x)  { return (1ULL<<x); }

// mod/arithmodm.cc:
umod_t set_mod(umod_t x, umod_t m);
umod_t incr_mod(umod_t a, umod_t m);
umod_t decr_mod(umod_t a, umod_t m);
umod_t sub_mod(umod_t a, umod_t b, umod_t m);
umod_t add_mod(umod_t a, umod_t b, umod_t m);
umod_t mul_mod(umod_t a, umod_t b, umod_t m);
inline umod_t sqr_mod(umod_t a, umod_t m)  { return mul_mod(a, a, m); }
umod_t pow_mod(umod_t a, umod_t ex, umod_t m);
umod_t inv_modp(umod_t a, umod_t p);
umod_t inv_modpp(umod_t a, umod_t p, long ex);
umod_t inv_mod(umod_t a, umod_t m);
umod_t div_mod(umod_t a, umod_t b, umod_t m);

// mod/kronecker.cc:
int kronecker(umod_t a, umod_t b);
//int reciprocity(umod_t a, umod_t b);

// mod/phi.cc:
umod_t phi(umod_t n);
umod_t phi(umod_t pr, int ex);
umod_t phi(const factorization &ff);

// mod/chinese.cc:
umod_t chinese(const umod_t *x, const factorization &f);

// mod/gcd.cc:
//mod_t sgcd(mod_t a, mod_t b);
umod_t ugcd(umod_t a, umod_t b);
smod_t binary_sgcd(smod_t a, smod_t b);
umod_t binary_ugcd(umod_t a, umod_t b);
umod_t ulcm(umod_t a, umod_t b);
smod_t egcd(smod_t a, smod_t b, smod_t &s, smod_t &v);


// mod/order.cc:
umod_t order_mod(umod_t x, umod_t m, const factorization &phifact);

// mod/maxorder.cc:
umod_t maxorder_mod(const factorization &mf);
umod_t maxorder_element_mod(const factorization &mf, const factorization &pf);

// mod/sqrtmod.cc:
umod_t sqrt_modp(umod_t a, umod_t p);
umod_t sqrt_modpp(umod_t a, umod_t p, long ex);
umod_t sqrt_modf(umod_t a, const factorization &mf);
bool is_quadratic_residue(umod_t a, const factorization &mf);


#endif  // !defined HAVE_MODM_H__
