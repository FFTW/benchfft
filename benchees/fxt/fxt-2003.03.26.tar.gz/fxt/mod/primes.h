#if !defined HAVE_PRIMES_H__
#define      HAVE_PRIMES_H__

#include "fxttypes.h"
#include "mtypes.h"
#include "bitarray.h"


// mod/primes.cc:
uint prime(uint n);
bool  is_small_prime(uint n);
bool  is_small_prime(const bitarray *ba, uint n);
uint  next_small_prime(const bitarray *ba, uint n);
bitarray *make_oddprime_bitarray(ulong n);


// mod/erastothenes.cc:
uint erastothenes(uint *&ptab, uint m);


// mod/rabinmiller.cc:
void n2qt(const umod_t n, umod_t &q, int &t);
bool is_strong_pseudo_prime(const umod_t n, const umod_t a, const umod_t q, const int t);
bool rabin_miller(umod_t n, uint cm=0);


#endif  // !defined HAVE_PRIMES_H__
