#if !defined HAVE_FACTOR_H__
#define      HAVE_FACTOR_H__


#include "mtypes.h"
#include "fxtio.h"


class  factorization
{
protected:
    umod_t *prime_;
    long   *expon_;
    int     npr_;
    umod_t *fact_;
    umod_t  prod_;

public:
    static const int  maxprimes;


    friend class mod_init;
    friend class mod;

public:
    factorization();
    factorization(umod_t n);
    factorization(umod_t n, umod_t*f);
    ~factorization();

    int nprimes()  const  { return npr_; }
    umod_t prime(int i) const  { return prime_[i]; }
    long  exponent(int i) const  { return expon_[i]; }
    long  exponent_of(umod_t p) const; // exponent of prime p
    umod_t product() const  { return prod_; }
    umod_t factor(int i) const  { return fact_[i]; }

    void make_factorization(umod_t n);
    void make_factorization(umod_t n, umod_t *f);
    bool  is_factorization_of(umod_t n) const  { return  ( n == product() ); }

    bool  is_prime() const;

    void print(const char *bla, std::ostream &os) const;

    void  check();

protected:
    void init();
    void sort();
    void ctor_core();

private:
    factorization(const factorization &); // forbidden
    const factorization & operator = (const factorization &); // forbidden
};
// -------------------------


inline bool factorization::is_prime() const
{
    return ((1==npr_) && (1==expon_[0]));
}
// -------------------------

// mod/factor.cc:
umod_t get_factor_q(umod_t n, umod_t f);
long divide_out_factor(umod_t &n, umod_t v);
umod_t int_sqrt(umod_t d);

//istream&  operator >> (istream& is, factorization& h);
std::ostream&  operator << (std::ostream& os, const factorization& h);


#endif  // !defined HAVE_FACTOR_H__
