
#include "fxttypes.h"
#include "mod.h"
#include "modm.h"


//#define PARANOIA  // define to enable for this file
#ifdef PARANOIA
#warning  'PARANOIA tests enabled in order.cc'
#include "jjassert.h"
#endif // PARANOIA


umod_t
order_mod(umod_t x, umod_t m, const factorization &phifact)
//
// Returns the order of x mod m
//
// cf. Cohen, p.25
//
{
    // pari says:  ***   not an element of (Z/nZ)* in order
    if ( 1!=ugcd(m,x) )  return 0;

    umod_t h = phifact.product();
    umod_t e = h;
    for (int i=0; i<phifact.nprimes() ; ++i)
    {
        umod_t p = phifact.prime(i);
        umod_t f = phifact.factor(i);

#ifdef PARANOIA
        long v = phifact.exponent(i);
#endif
        e /= f;
        umod_t g1 = pow_mod(x, e, m);

        while ( g1!=1 )
        {
            g1 = pow_mod(g1, p, m);
            e *= p;

#ifdef PARANOIA
            --v;
            jjassert ( g1!=(uint)0 );
            jjassert( e!=0 );
            jjassert( e<=h );  // e==h only possible if g1==1
            jjassert( v>=0 );
#endif // PARANOIA
        }
    }

    return e;
}
// -------------------------
