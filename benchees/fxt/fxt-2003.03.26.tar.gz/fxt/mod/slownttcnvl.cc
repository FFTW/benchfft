
#include "fxttypes.h"
#include "mod.h"
#include "modm.h"
#include "ntt.h"

#include "copy.h"
//using namespace fxtaux;
//#define copy fxtaux::copy // avoid unwanted std::copy

//#include "newop.h"


#define  SLOW_MOD_CONVOLUTION_VERSION  0  // 1 or 2

#if  ( SLOW_MOD_CONVOLUTION_VERSION==1 )

void
slow_mod_convolution(mod *f, mod *g, ulong n)  // version 1
// (cyclic) convolution:  g[] :=  f[] (*) g[]
// n := array length
//
// (use zero padded data for linear convolution)
//
{
    mod r[n];
    for (ulong tau=0; tau<n; ++tau)
    {
        mod t = mod::zero;
        for (ulong k=0; k<n; ++k)
        {
            ulong k2;

            if ( tau>=k )  k2 = tau - k;
            else           k2 = n + tau - k;

            t += (f[k2]*g[k]);
        }

        r[tau] = t;
    }

    copy(r, g, n);
}
// -------------------------

#else // ( SLOW_MOD_CONVOLUTION_VERSION==1 )


void
slow_mod_convolution(mod *f, mod *g, ulong n)  // version 2
// (cyclic) convolution:  g[] :=  f[] (*) g[]
// n := array length
//
// (use zero padded data for linear convolution)
//
{
    long ns = (long)n;
    mod r[n];
    for (long tau=0; tau<ns; ++tau)
    {
        mod s = mod::zero;
        for (long k=0; k<ns; ++k)
        {
             long k2 = tau - k;

             if ( k2<0 )  k2 += ns;

             s += (f[k]*g[k2]);
        }
        r[tau] = s;
    }

    copy(r, g, n);
}
// -------------------------

#endif // ( SLOW_MOD_CONVOLUTION_VERSION==1 )


//void
//slow_mod_convolution(double *f, double *g, ulong n)
//{
//    double_to_mod_by_force(f,n);
//    double_to_mod_by_force(g,n);
//    slow_mod_convolution((double*)f,(double*)g,n);
//}
//// ============== end ================

