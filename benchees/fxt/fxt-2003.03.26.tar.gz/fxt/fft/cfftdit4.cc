
#include <cmath>

#include "fxt.h"
#include "cmult.h"
#include "sumdiff.h"
#include "revbinpermute.h"
#include "csincos.h"
#include "reverse.h"


static const ulong RX = 4;
static const ulong LX = 2;


void
fft_dit4(Complex *f, ulong ldn, int is)
// Fast Fourier Transform
// ldn := base-2 logarithm of the array length
// is := sign of the transform (+1 or -1)
// radix 4 decimation in time algorithm
{
    const ulong n = 1UL<<ldn;
    revbin_permute(f, n);

    fft_dit4_core(f, ldn);

    if ( is>0 )  // note: ugly: explicit reordering
    {
        reverse_nh(f, n);
    }
}
// -------------------------



void
fft_dit4_core(Complex *f, ulong ldn)
// auxiliary routine for fft_dit4()
// radix 4 decimation in frequency fft
// ldn := base-2 logarithm of the array length
// isign = -1
// input data must be in revbin_permuted order
{
    const ulong n = (1UL<<ldn);

    if ( n<=2 )
    {
        if ( n==2 )  sumdiff(f[0], f[1]);
        return;
    }

    ulong ldm = ldn & 1;
    if ( ldm!=0 )  // n is not a power of 4, need a radix 8 step
    {
        for (ulong i0=0; i0<n; i0+=8)  fft8_dit_core(f+i0);
    }
    else
    {
        for (ulong i0=0; i0<n; i0+=4)
        {
            ulong i1 = i0 + 1;
            ulong i2 = i1 + 1;
            ulong i3 = i2 + 1;

            Complex x, y, u, v;
            sumdiff(f[i0], f[i1], x, u);
            sumdiff(f[i2], f[i3], y, v);
            v *= Complex(0, -1);  // isign
            sumdiff(u, v, f[i1], f[i3]);
            sumdiff(x, y, f[i0], f[i2]);
        }
    }
    ldm += 2 * LX;


    for ( ; ldm<=ldn; ldm+=LX)
    {
        ulong m = (1UL<<ldm);
        ulong m4 = (m>>LX);
        const double ph0 = -2.0*M_PI/m;  // isign

        for (ulong j=0; j<m4; j++)
        {
            double phi = j * ph0;
            Complex e  = SinCos(phi);
            Complex e2 = e * e;
            Complex e3 = e2 * e;

            for (ulong r=0, i0=j+r;  r<n;  r+=m, i0+=m)
            {
                ulong i1 = i0 + m4;
                ulong i2 = i1 + m4;
                ulong i3 = i2 + m4;

                Complex x = f[i1] * e2;
                Complex u;
                sumdiff3_r(x, f[i0], u);

                Complex v = f[i3] * e3;
                Complex y = f[i2] * e;
                sumdiff(y, v);
                v *= Complex(0, -1);  // isign

                sumdiff(u, v, f[i1], f[i3]);
                sumdiff(x, y, f[i0], f[i2]);
            }
        }
    }
}
// -------------------------

