
#include "complextype.h"  // Complex

#include <cmath> // M_SQRT1_2

// swap (1 with 4) and (3 with 6) in all _input_ expressions f[.]

void
fft8_dif_core(Complex *f)
// 8-point decimation in frequency FFT
// isign = +1
// output data is in revbin_permuted order
//.
// cf. nussbaumer p.148f
{
    Complex t1 = f[0] + f[4];
    Complex m3 = f[0] - f[4];

    Complex t4 = f[1] + f[5];
    Complex t3 = f[1] - f[5];

    Complex t5 = f[3] + f[7];
    Complex t6 = f[3] - f[7];

    Complex t2 = f[2] + f[6];
    Complex t7 = t1 + t2;
    Complex m2 = t1 - t2;
    Complex t8 = t4 + t5;

    f[0] = t7 + t8;
    f[1] = t7 - t8;
    Complex m4 = M_SQRT1_2 * (t3 - t6);

    // isign = +1:
    Complex m7 = Complex(0, -M_SQRT1_2) * (t3 + t6);
    Complex m5 = (t5 - t4) * Complex(0, 1);
    Complex m6 = (f[6] - f[2]) * Complex(0, 1);

//    // isign = -1:
//    Complex m7 = Complex(0, M_SQRT1_2) * (t3 + t6);
//    Complex m5 = (t4 - t5) * Complex(0, 1);
//    Complex m6 = (f[2] - f[6]) * Complex(0, 1);

#define s1 t1
#define s2 t2
#define s3 t3
#define s4 t4
    s1 = m3 + m4;
    s2 = m3 - m4;

    s3 = m6 + m7;
    s4 = m6 - m7;

    f[7] = s1 + s3;
    f[4] = s1 - s3;

    f[6] = s2 + s4;
    f[5] = s2 - s4;

    f[3] = m2 + m5;
    f[2] = m2 - m5;
#undef s1
#undef s2
#undef s3
#undef s4
}
// -------------------------



void
fft8_dif_core(double *fr, double *fi)
// 8-point decimation in frequency fft, isign = +1
// output data is in revbin_permuted order
//.
// cf. nussbaumer p.148f
{
    // INPUT_RE:
    double t1r = fr[0] + fr[4];
    double t2r = fr[2] + fr[6];
    double t7r = t1r + t2r;
    double t3r = fr[1] - fr[5];
    double t4r = fr[1] + fr[5];
    double t5r = fr[3] + fr[7];
    double t8r = t4r + t5r;
    double t6r = fr[3] - fr[7];

    double m0r = t7r + t8r;
    double m1r = t7r - t8r;
    double m2r = t1r - t2r;
    double m3r = fr[0] - fr[4];
    double m4r = M_SQRT1_2 * (t3r - t6r);

#define m5i t6r
#define m6i t7r
#define m7i t8r
    m7i =  -(M_SQRT1_2 * (t3r + t6r));
    m5i = t5r - t4r;
    m6i = fr[6] - fr[2];

    // INPUT_IM:
    double t1i = fi[0] + fi[4];
    double t2i = fi[2] + fi[6];
    double t7i = t1i + t2i;
    double t3i = fi[1] - fi[5];
    double t4i = fi[1] + fi[5];
    double t5i = fi[3] + fi[7];
    double t8i = t4i + t5i;
    double t6i = fi[3] - fi[7];

    double m0i = t7i + t8i;
    double m1i = t7i - t8i;
    double m2i = t1i - t2i;
    double m3i = fi[0] - fi[4];
    double m4i = M_SQRT1_2 * (t3i - t6i);

#define m5r t6i
#define m6r t7i
#define m7r t8i
    m7r = M_SQRT1_2 * (t3i + t6i);
    m5r = t4i - t5i;
    m6r = fi[2] - fi[6];

#define s1r t1r
#define s2r t2r
#define s3r t3r
#define s4r t4r
    s1r = m3r + m4r;
    s2r = m3r - m4r;
    s3r = m6r + m7r;
    s4r = m6r - m7r;

    // OUTPUT_RE:
    fr[0] = m0r;
    fr[7] = s1r + s3r;
    fr[3] = m2r + m5r;
    fr[5] = s2r - s4r;
    fr[1] = m1r;
    fr[6] = s2r + s4r;
    fr[2] = m2r - m5r;
    fr[4] = s1r - s3r;

#define s1i t1r
#define s2i t2r
#define s3i t3r
#define s4i t4r
    s1i = m3i + m4i;
    s2i = m3i - m4i;
    s3i = m6i + m7i;
    s4i = m6i - m7i;

    // OUTPUT_IM:
    fi[0] = m0i;
    fi[7] = s1i + s3i;
    fi[3] = m2i + m5i;
    fi[5] = s2i - s4i;
    fi[1] = m1i;
    fi[6] = s2i + s4i;
    fi[2] = m2i - m5i;
    fi[4] = s1i - s3i;

#undef s1r
#undef s2r
#undef s3r
#undef s4r

#undef s1i
#undef s2i
#undef s3i
#undef s4i

#undef m5r
#undef m6r
#undef m7r

#undef m5i
#undef m6i
#undef m7i
}
// -------------------------
