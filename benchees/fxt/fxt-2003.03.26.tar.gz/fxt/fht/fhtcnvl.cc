
#include "fxt.h"
#include "fhtmulsqr.h"
#include "restrict.h"



// tuning parameter:
#define  FHT_CONVOLUTION_VERSION  0  // 0 (default) or 1
//
#if  ( FHT_CONVOLUTION_VERSION==0 )
#warning 'FYI fht_convolution(double *, ulong) using revbin_permuted_core'
#else
#warning 'FYI fht_convolution(double *, ulong) using normal core'
#endif


void
fht_convolution(double * restrict f, double * restrict g, ulong ldn)
// (cyclic, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
{
#if  ( FHT_CONVOLUTION_VERSION==0 )

    fht_dif_core(f, ldn);
    fht_dif_core(g, ldn);

//    ulong n = 1UL<<ldn;
//    revbin_permute(f, n);
//    revbin_permute(g, n);
//    fht_convolution_core(f, g, ldn);
//    revbin_permute(g, n);
    // =^=
    fht_convolution_revbin_permuted_core(f, g, ldn);

    fht_dit_core(g, ldn);

#else

    fht(f, ldn);
    fht(g, ldn);
    fht_convolution_core(f, g, ldn);  // n>=2
    fht(g, ldn);

#endif
}
// -------------------------


void
fht_convolution0(double * restrict f, double * restrict g, ulong ldn)
// (linear, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n = 2**ldn  must be >=2
{
    fht0(f, ldn);
    fht0(g, ldn);
    fht_convolution_core(f, g, ldn);
    fht(g, ldn);
}
// -------------------------


void
fht_convolution_core(const double * restrict f, double * restrict g, ulong ldn,
                     double v/*=0.0*/) // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
{
    const ulong n = (1UL<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    g[0]  *=  (v * f[0]);
    const ulong  nh = n/2;

    if ( nh>0 )
    {
        g[nh] *= (v * f[nh]);
        v *= 0.5;
        for (ulong i=1,j=n-1; i<j; i++,j--)
        {
            fht_mul(f[i], f[j], g[i], g[j], v);
        }
    }
}
// -------------------------


void
fht_convolution_revbin_permuted_core(const double * restrict f,
                                     double * restrict g,
                                     ulong ldn,
                                     double v/*=0.0*/)  // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
//
// ldn := base-2 logarithm of the array length
//
// v!=0.0 chooses alternative normalization
//
// as fht_convolution_core() but with data access in revbin order
// i.e. this version avoids calls to revbin_permute()
//
// same as:
//    revbin_permute(f, n);
//    revbin_permute(g, n);
//    fht_convolution_core(f, g, ldn);
//    revbin_permute(g, n);
{
    const ulong n = (1UL<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    g[0] *= (v * f[0]);  // 0 == revbin(0)
    if ( n>=2 )  g[1] *= (v * f[1]); // 1 == revbin(nh)

    if ( n<4 )  return;

    v *= 0.5;
    const ulong nh = (n>>1);

    ulong r=nh, rm=n-1; // nh == revbin(1),  n1-1 == revbin(n-1)
    fht_mul(f[r], f[rm], g[r], g[rm], v);

    ulong k=2, km=n-2;
    while ( k<nh  )
    {
        // k even:
        rm -= nh;
        ulong tr = r;
        r^=nh;  for (ulong m=(nh>>1); !((r^=m)&m); m>>=1)  {;}
        fht_mul(f[r], f[rm], g[r], g[rm], v);
        --km;
        ++k;

        // k odd:
        rm += (tr-r);
        r += nh;
        fht_mul(f[r], f[rm], g[r], g[rm], v);
        --km;
        ++k;
    }
}
// -------------------------
