
// MACHINE GENERATED FILE, DO NOT EDIT !
// this file was generated from fhtcnvla.cc
#include "complextype.h"

#include "fxt.h"
#include "fhtmulsqr.h"

// tuning parameter:
#define  FHT_AUTO_CONVOLUTION_VERSION  0  // 0 (default) or 1
//
#if  ( FHT_AUTO_CONVOLUTION_VERSION==0 )
#warning 'FYI fht_auto_convolution(Complex *, ulong) using revbin_permuted_core'
#else
#warning 'FYI fht_auto_convolution(Complex *, ulong) using normal core'
#endif



void
fht_auto_convolution(Complex *f, ulong ldn)
// (cyclic, real) self convolution:  f[] :=  f[] (*) f[]
// ldn := base-2 logarithm of the array length
{
#if  ( FHT_AUTO_CONVOLUTION_VERSION==0 )
    fht_dif_core(f, ldn);
    fht_auto_convolution_revbin_permuted_core(f, ldn);
    fht_dit_core(f, ldn);
#else
    fht(f,ldn);
    fht_auto_convolution_core(f, ldn);
    fht(f,ldn);
#endif
}
// -------------------------


void
fht_auto_convolution0(Complex *f, ulong ldn)
// (linear, real) self convolution:  f[] :=  f[] (*0) f[]
// ldn := base-2 logarithm of the array length
// version for zero padded data:
//   f[k] == 0 for k=n/2 ... n-1
// n = 2**ldn  must be >=2
{
//    if ( ldn<=1 )
//    {
//        fr[0] *= fr[0];
//        return;
//    }

    fht0(f,ldn);
    fht_auto_convolution_core(f, ldn);
    fht(f,ldn);
}
// -------------------------


void
fht_auto_convolution_core(Complex *f, ulong ldn,
                          double v/*=0.0*/)  // jjkeep
// auxiliary routine for the computation of self convolutions
//   via Fast Hartley Transforms
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
{
    const ulong  n  = (1UL<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    f[0] *= (v * f[0]);

    if ( n>=2 )
    {
        const ulong  nh = n/2;
        f[nh] *= (v * f[nh]);

        v *= 0.5;
        for (ulong i=1,j=n-1; i<nh; i++,j--)
        {
            fht_sqr(f[i], f[j], v);
        }
    }
}
// -------------------------


void
fht_auto_convolution_revbin_permuted_core(Complex *f, ulong ldn,
                                          double v/*=0.0*/)  // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
//
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
//
// as fht_auto_convolution_core() but with data access in revbin order
// i.e. this version avoids two calls to revbin_permute()
{
    const ulong n = (1UL<<ldn);

    if ( v==0.0 )  v = 1.0/n;
    f[0] *= (v * f[0]);  // == [0]
    if ( n>=2 )  f[1] *= (v * f[1]); // == [nh]

    if ( n<4 )  return;

    v *= 0.5;
    const ulong nh = (n>>1);

    ulong r=nh, rm=n-1;
    fht_sqr(f[r], f[rm], v);

    ulong k=2, km=n-2;
    while ( k<nh  )
    {
        // k even:
        rm -= nh;
        ulong tr = r;
        r^=nh;  for (ulong m=(nh>>1); !((r^=m)&m); m>>=1)  {;}
        fht_sqr(f[r], f[rm], v);
        --km;
        ++k;

        // k odd:
        rm += (tr-r);
        r += nh;
        fht_sqr(f[r], f[rm], v);
        --km;
        ++k;
    }
}
// -------------------------

