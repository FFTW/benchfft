
#include "fxttypes.h"
#include "sincos.h" // SinCos()
#include "sumdiff.h" // sumdiff()
#include "inline.h" // swap()

#include <cmath>  // M_PI, M_SQRT1_2

#define  VERSION  1  // 0 or 1 (default, optimized)

void
hartley_shift_05(double *f, ulong n)
//
// n := length of array
// Hartley Transform analogue to fourier_shift(f, n, 0.5)
// used for negacyclic convolution and recursive FHTs
//
// with VERSION != 0  n must be a power of two
// self-inverse
{
    const double phi0 = M_PI/n;

#if  VERSION == 0

    double phi = 0.0;
    for (ulong i=1, j=n-1;  i<j;  ++i, --j)
    {
        phi += phi0;
        double s, c;
        SinCos(phi, &s, &c);

        double fi = f[i],  fj = f[j];
        f[i] = fi * c + fj * s;
        f[j] = fi * s - fj * c;
    }

#else // VERSION

    const ulong nh = n/2;
    if ( n>=4 )
    {
        ulong i=nh/2, j=3*i;
        double fi = f[i],  fj = f[j];
        double cs = M_SQRT1_2;
        f[i] = (fi + fj) * cs;
        f[j] = (fi - fj) * cs;

        if ( n>=8 )
        {
            double phi = 0.0;
            for (ulong i=1, j=n-1, k=nh-1, l=nh+1;  i<k;  ++i, --j, --k, ++l)
            {
                phi += phi0;
                double s, c;
                SinCos(phi, &s, &c);

                double fi, fj;
                fi = f[i];
                fj = f[j];
                f[i] = fi * c + fj * s;
                f[j] = fi * s - fj * c;

                // swap(c, s);
                fi = f[k];
                fj = f[l];
                f[k] = fi * s + fj * c;
                f[l] = fi * c - fj * s;
            }
        }
    }
#endif // VERSION
}
// -------------------------

