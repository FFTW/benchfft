
#include "fxt.h"


static inline  void
fht_sqr(double &xi, double &xj,
        double v) // jjkeep
// xi <-- v*( 2*xi*xj + xi*xi - xj*xj )
// xj <-- v*( 2*xi*xj - xi*xi + xj*xj )
// auxiliary routine for fht_negacyclic_auto_convolution_core()
{
    double a = xi,  b = xj;
    double s1 = (a + b) * (a - b);
    a *= b;
    a += a;
    xi = (a+s1) * v;
    xj = (a-s1) * v;
}
// -------------------------


void
fht_negacyclic_auto_convolution(double *x, ulong ldn, double v/*=0.0*/)
//
// Negacyclic self convolution using FHT
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
//
{
    if ( ldn==0 )
    {
        x[0] *= x[0];
        return;
    }

    const ulong n = (1UL<<ldn);
    hartley_shift_05(x, n);
    fht(x, ldn);
    fht_negacyclic_auto_convolution_core(x, ldn, v);
    fht(x, ldn);
    hartley_shift_05(x, n);
}
// -------------------------


void
fht_negacyclic_auto_convolution_core(double *x, ulong ldn, double v/*=0.0*/)
//
// auxiliary routine for fht_negacyclic_auto_convolution()
// ldn := base-2 logarithm of the array length
//
// v!=0.0 chooses alternative normalization
//
{
    const ulong  n  = (1UL<<ldn);

    if ( v==0.0 )  v = (1.0/n);
    v *= 0.5;

    for (ulong i=0,j=n-1; i<j; i++,j--)
    {
        fht_sqr(x[i], x[j], v);
    }
}
// -------------------------

