
#include "fxt.h"
#include "ldn2rc.h"
//#include "transpose.h"

#include "transpose2_ba.h"
#include "bit2pow.h"


//#define  TRANSPOSE2(f, nr, nc)  matrix_transpose2(f, nr, nc)  // obsolete
#define  TRANSPOSE2(f, nr, nc)  transpose2_ba(f, nr, nc, 0)

void
matrix_fft(double *fr, double *fi, ulong ldn, int is)
// matrix (aka four-step) fft
// useful for arrays larger than 2nd-level cache
{
    ulong nr, nc;
    ldn2rc(ldn, nr, nc);
    column_ffts(fr, fi, nr, nc, is, 0, 0, 0);
    row_weighted_ffts(fr, fi, nr, nc, is);
    TRANSPOSE2(fr, nr, nc);
    TRANSPOSE2(fi, nr, nc);
}
// -------------------------


void
matrix_fft0(double *fr, double *fi, ulong ldn, int is)
// matrix (aka four-step) fft
// useful for arrays larger than 2nd-level cache
// version for zero padded data
{
    ulong nr, nc;
    ldn2rc(ldn, nr, nc);
    column_ffts(fr, fi, nr, nc, is, 1, 0, 0);
    row_weighted_ffts(fr, fi, nr, nc, is);
    TRANSPOSE2(fr, nr, nc);
    TRANSPOSE2(fi, nr, nc);
}
// -------------------------


void
matrix_fft(Complex *f, ulong ldn, int is)
// matrix (aka four-step) fft
// useful for arrays larger than 2nd-level cache
{
    ulong nr, nc;
    ldn2rc(ldn, nr, nc);
    column_ffts(f, nr, nc, is, 0, 0);
    row_weighted_ffts(f, nr, nc, is);
    TRANSPOSE2(f, nr, nc);
}
// -------------------------


void
matrix_fft0(Complex *f, ulong ldn, int is)
// matrix (aka four-step) fft
// useful for arrays larger than 2nd-level cache
// version for zero padded data
{
    ulong nr, nc;
    ldn2rc(ldn, nr, nc);
    column_ffts(f, nr, nc, is, 1, 0);
    row_weighted_ffts(f, nr, nc, is);
    TRANSPOSE2(f, nr, nc);
}
// -------------------------
