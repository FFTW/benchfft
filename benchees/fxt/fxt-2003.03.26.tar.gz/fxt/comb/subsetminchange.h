#if !defined HAVE_SUBSETMINCHANGE_H__
#define      HAVE_SUBSETMINCHANGE_H__


#include "fxttypes.h"
//#include "newop.h"
#include "bitlow.h"

class subset_minchange
{
protected:
    ulong *x;  // current subset as delta-set
    ulong n;   // number of elements in set
    ulong num; // number of elements in current subset
    ulong chg; // element that was chnged with latest call to next()
    ulong idx;
    ulong maxidx;

public:
    subset_minchange(ulong nn)
    {
        n = (nn ? nn : 1);  // not zero
        x = new ulong[n];
        maxidx = (1UL<<nn) - 1;
        first();
    }

    ~subset_minchange()  { delete [] x; }


    ulong first()  // start with empty set
    {
        idx = 0;
        num = 0;
        chg = n - 1;
        for (ulong k=0; k<n; ++k)  x[k] = 0;
        return  num;
    }

    ulong next()  // return number of elements in subset
    {
        make_next();
        return  num;
    }

    const ulong * data() const { return x; }

    ulong get_change()  const  { return chg; }

    const ulong current()  const  { return idx; }

protected:
    void make_next()
    {
        ++idx;
        if ( idx > maxidx )
        {
            chg = n - 1;
            first();
        }
        else  // x[] essentially runs through the binary graycodes
        {
            chg = lowest_bit_idx( idx );
            x[chg] = 1 - x[chg];
            num += (x[chg] ? 1 : -1);
        }
    }
};
// -------------------------



#endif  // !defined HAVE_SUBSETMINCHANGE_H__
