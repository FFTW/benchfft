#if !defined HAVE_MIXEDRADIXLEX_H__
#define      HAVE_MIXEDRADIXLEX_H__

#include "fxttypes.h"


class mixed_radix_lex
// mixed radix (generalized) lexicographic sequence
{
public:
    ulong n_;
    ulong *a_;
    ulong *m1_;
    ulong e_;

public:
    mixed_radix_lex(const ulong *m, ulong n, ulong mm=0)
        : n_(n)
    {
        a_ = new ulong[2*n_ + 1];
        a_[0] = ~0UL; // sentinel
        ++a_;  // nota bene

        m1_ = a_ + n_;

        // if mm given it is used as radix for all digits:
        if ( 0==mm )  for (ulong k=0; k<n_; ++k)  m1_[k] = m[k] - 1;
        else          for (ulong k=0; k<n_; ++k)  m1_[k] = mm - 1;

        first();
    }

    ~mixed_radix_lex()
    {
        --a_;  // nota bene
        delete [] a_;
    }

    const ulong *data()  const  { return a_; }


    void first()
    {
        for (ulong k=0; k<n_; ++k)  a_[k] = 0;
        e_ = 0;
    }

    void last()
    {
        for (ulong k=0; k<n_; ++k)  a_[k] = 0;
        e_ = n_ - 1;
        a_[e_] = m1_[e_];
    }

    ulong next()
    // return n if current was last
    {
        ulong ae = a_[e_] + 1;
        if ( ae <= m1_[e_] )
        {
            a_[e_] = ae;
            if ( e_ < n_-1 )  ++e_;
        }
        else
        {
            a_[e_] = 0;
            long j = e_ - 1;
            while ( 0==a_[j] )  --j;  // can touch sentinel
            if ( j<0 )  { first();  return n_; }  // was last

            ulong aj = a_[j] + 1;
            if ( aj <= m1_[j] )  a_[j] = aj;
            else
            {
                a_[j] = 0;
                ++j;
                a_[j] = 1;
            }

            e_ = j;
            if ( e_ < n_-1 )  ++e_;
        }
        return  e_;
    }

    ulong prev()
    // return n if current was first
    // FIXME: setup e_ correctly
    {
        long j = e_;
        while ( 0==a_[j] )  --j;  // can touch sentinel
        if ( j<0 )  { last();  return n_; }  // was first

        ulong aj = a_[j];
        --aj;

        // can touch sentinel:
        if ( 0==aj )
        {
            if ( 0!=a_[j-1] )
            {
                a_[j] = aj;
                return e_;
            }

            a_[j-1] = m1_[j-1];
        }

        a_[n_-1] = m1_[n_-1];
        e_ = n_ - 1;

        if ( aj )  a_[j] = aj;
        if ( (ulong)j != n_-1 )  a_[j] = aj;

        return  e_;
    }
};
// -------------------------


#endif  // !defined HAVE_MIXEDRADIXLEX_H__
