#if !defined HAVE_COMBLAZY_H__
#define      HAVE_COMBLAZY_H__

//: include file for the lazy: include all headers from comb/

#include "paren.h"
#include "paren2.h"
#include "partition.h"
#include "subsetminchange.h"
#include "subsetmonotone.h"
#include "subsetlex.h"
#include "primestring.h"
#include "debruijn.h"
#include "subsetdebruijn.h"
#include "binaryprimestring.h"
#include "binarydebruijn.h"
#include "mixedradix.h"
#include "mixedradixlex.h"
#include "mixedradixgray.h"
#include "modularmixedradixgray.h"
#include "monotonegray.h"
#include "comblex.h"
#include "combcolex.h"
#include "combminchange.h"
#include "combaltminchange.h"
#include "compositionlex.h"
#include "compositionalt.h"


#endif  // !defined HAVE_COMBLAZY_H__
