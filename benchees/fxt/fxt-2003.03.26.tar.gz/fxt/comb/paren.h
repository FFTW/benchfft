#if !defined  HAVE_PAREN_H__
#define       HAVE_PAREN_H__

#include "funcemu.h"


class paren
{
protected:
    funcemu<int> *fe_;
    int *x;
    // x[i] is the number of right parentheses between the
    // i-th left parenthesis and the (i+1)-th left parenthesis.
    char *str;

    int n;
    int q;
    int idx;

public:
    paren(int nn);
    ~paren();

    int next()
    {
        if ( 0==q )  return 0;
        else
        {
            q = next_recursion();
            return  ( q ? ++idx : 0 );
        }
    }

    const int *data()  const  { return x; }
    const char *string()  const  { return str; }
    int current()  const  { return idx; }

protected:
    int next_recursion();
};
// -------------------------


#endif  // !defined HAVE_PAREN_H__
