#if !defined  HAVE_PAREN2_H__
#define       HAVE_PAREN2_H__

#include "fxttypes.h"


class paren2
// parentheses by a modified comb_colex procedure
{
public:
    ulong k_;  // number of paren pairs
    ulong n_;  // ==2*k
    ulong *x_; // (negated) positions where a close paren occurs
    char *str_;  // string representation,  e.g. "((())())()"

public:
    paren2(ulong k)
    {
        k_ = (k>1 ? k : 2);  // not zero (empty) or one (trivial: "()")
        n_ = 2 * k_;
        x_ = new ulong[k_ + 1];
        x_[k_] = 999;  // sentinel
        str_ = new char[n_ + 1];
        str_[n_] = 0;
        first();
    }

    ~paren2()
    {
        delete [] x_;
        delete [] str_;
    }


    void first()
    {
        for (ulong i=0; i<k_; ++i)  x_[i] = i;
    }

    void last()
    {
        for (ulong i=0; i<k_; ++i)  x_[i] = 2*i;
    }

    ulong next()  // return zero if previous paren was the last
    {
        ulong j = 0;
        if ( x_[1] == 2 )
        {
            // scan for low end == 010101:
            j = 2;
            while ( (j<=k_) && (x_[j]==2*j) )  ++j;  // can touch sentinel
            // cout << "   ^ " << j ;

            if ( j==k_ )
            {
                first();
                return  0;
            }
        }

        // if ( k_==1 )  return 0;  // uncomment to make algorithm work for k_==1

        // scan block:
        while ( 1 == (x_[j+1] - x_[j]) )  { ++j; }

        ++x_[j];  // move edge element up
        for (ulong i=0; i<j; ++i)  x_[i] = i; // attach block at low end

        return  1;
    }

//    ulong prev()  { TBD; }

    const ulong * data()  { return x_; }

    const char * string()  // generate on demand
    {
        for (ulong j=0; j<n_; ++j)  str_[j] = '(';
        for (ulong j=0; j<k_; ++j)  str_[n_-1-x_[j]] = ')';
        return str_;
    }
};
// -------------------------



#endif  // !defined HAVE_PAREN2_H__
