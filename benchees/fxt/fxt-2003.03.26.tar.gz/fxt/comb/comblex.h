#if !defined HAVE_COMBLEX_H__
#define      HAVE_COMBLEX_H__

#include "fxttypes.h"
#include "fxtio.h"


class comb_lex
{
public:
    ulong n_;
    ulong k_;
    ulong *x_;

public:
    comb_lex(ulong n, ulong k)
    {
        n_ = (n ? n : 1);  // not zero
        k_ = (k ? k : 1);  // not zero
        x_ = new ulong[k_];
        first();
    }

    ~comb_lex()  { delete [] x_; }


    void first()
    {
        for (ulong k=0; k<k_; ++k)  x_[k] = k;
    }

    void last()
    {
        for (ulong i=0; i<k_; ++i)  x_[i] = n_ - k_ + i;
    }

    ulong next()  // return zero if previous comb was the last
    {
        if ( x_[0] == n_ - k_ )  { first();  return 0; }

        ulong j = k_ - 1;
        // trivial if highest element != highest possible value:
        if ( x_[j] < (n_-1) )  { ++x_[j];  return 1; }

        // find highest falling edge:
        while ( 1 == (x_[j] - x_[j-1]) )  { --j; }

        // move lowest element of highest block up:
        ulong z = ++x_[j-1];

        // ... and attach rest of block:
        while ( j < k_ )  { x_[j] = ++z;  ++j; }

        return  1;
    }

    ulong prev()  // return zero if current comb is the first
    {
        if ( x_[k_-1] == k_-1 )  { last();  return 0; }

        // find highest falling edge:
        ulong j = k_ - 1;
        while ( 1 == (x_[j] - x_[j-1]) )  { --j; }

        --x_[j];  // move down edge element

        // ... and move rest of block to high end:
        while ( ++j < k_ )  x_[j] = n_ - k_ + j;

        return  1;
    }

    const ulong * data()  { return x_; }

    friend std::ostream & operator << (std::ostream &os, const comb_lex &x);
};
// -------------------------



#endif  // !defined HAVE_COMBLEX_H__
