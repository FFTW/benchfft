#if !defined  HAVE_MONOTONEGRAY_H__
#define       HAVE_MONOTONEGRAY_H__


#include "fxttypes.h"

// comb/monotonegray.cc:
void delta2gray(const unsigned char *d, ulong ldn, ulong *g);
void monotone_gray_delta(unsigned char *d, ulong ldn);
void monotone_gray(ulong *g, ulong ldn);


#endif  // !defined HAVE_MONOTONEGRAY_H__
