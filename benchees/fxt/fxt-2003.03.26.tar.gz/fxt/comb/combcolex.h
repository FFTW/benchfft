#if !defined HAVE_COMBCOLEX_H__
#define      HAVE_COMBCOLEX_H__

#include "fxttypes.h"
//#include "newop.h"

#include "fxtio.h"


class comb_colex
{
public:
    ulong n_;
    ulong k_;
    ulong *x_;

public:
    comb_colex(ulong n, ulong k)
    {
        n_ = (n ? n : 1);  // not zero
        k_ = (k ? k : 1);  // not zero
        x_ = new ulong[k_];
        first();
    }

    ~comb_colex()  { delete [] x_; }


    void first()
    {
        for (ulong i=0; i<k_; ++i)  x_[i] = i;
    }

    void last()
    {
        for (ulong i=0; i<k_; ++i)  x_[i] = n_ - k_ + i;
    }

    ulong next()  // return zero if previous comb was the last
    {
        if ( x_[0] == n_ - k_ )  { first();  return 0; }

        ulong j = 0;
        // until lowest rising edge ...
        while ( 1 == (x_[j+1] - x_[j]) )
        {
            x_[j] = j;  // attach block at low end
            ++j;
        }

        ++x_[j];  // move edge element up

        return  1;
    }

    ulong prev()  // return zero if current comb is the first
    {
        if ( x_[k_-1] == k_-1 )  { last();  return 0; }

        // find lowest falling edge:
        ulong j = 0;
        while ( j == x_[j] )  ++j;

        --x_[j];  // move edge element down

        // attach rest of low block:
        while ( 0!=j-- )  x_[j] = x_[j+1] - 1;

        return  1;
    }

    const ulong * data()  { return x_; }

    friend std::ostream & operator << (std::ostream &os, const comb_colex &x);
};
// -------------------------


#endif  // !defined HAVE_COMBCOLEX_H__
