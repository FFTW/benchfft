#if !defined HAVE_COMPOSITIONLEX_H__
#define      HAVE_COMPOSITIONLEX_H__


#include "fxttypes.h"


class composition_lex
{
public:
    ulong n_;  // number of elements to choose from
    ulong *x_;  // data

public:
    composition_lex(ulong n)
    {
        n_ = (n ? n : 1);  // not zero
        x_ = new ulong[n_];
        first();
    }

    ~composition_lex()  { delete [] x_; }

    const ulong *data()  const  { return x_; }

    void first()
    {
        x_[0] = n_;
        for (ulong k=1; k<n_; ++k)  x_[k] = 0;
    }

    void last()
    {
        for (ulong k=0; k<n_; ++k)  x_[k] = 0;
        x_[n_-1] = n_;
    }

    ulong next()
    // Nijenhuis, Wilf
    {
        // return zero if current comp. is last:
        if ( n_==x_[n_-1] )  return 0;

        ulong j = 0;
        while ( 0==x_[j] )  ++j;
        ulong v = x_[j];  // first nonzero
        x_[j] = 0;
        x_[0] = v - 1;
        ++x_[j+1];

        return  1;
    }

    ulong prev()
    {
        // return zero if current comp. is first:
        if ( n_==x_[0] )  return 0;

        ulong v0 = x_[0];
        x_[0] = 0;
        ulong j = 1;
        while ( 0==x_[j] )  ++j;
        --x_[j];
        x_[j-1] = 1 + v0;

        return  1;
    }
};
// -------------------------

#endif  // !defined HAVE_COMPOSITIONLEX_H__
