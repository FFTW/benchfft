
#include "fxttypes.h"
#include "fxtio.h"

#include "combminchange.h"


// A recursive version by Glenn C. Rhoads
//
//  word = (1UL << k) - 1;  word <<= (n-k);  // initial comb.
//  Visit(word);  // visit initial bit comb.
//  GEN(n, k);  // visit all following comb.
//
//  void GEN(int n, int k)
//  {
//      if ( (k>0) && (k<n) )
//      {
//          GEN(n-1, k);
//          bit_swap_01(n, k);
//          Visit(word);
//          NEG(n-1, k-1);
//      }
//  }
//
//  void NEG(int n, int k)
//  {
//      if ( (k>0) && (k<n) )
//      {
//          GEN(n-1, k-1);
//          bit_swap_01(n, k);
//          Visit(word);
//          NEG(n-1, k);
//      }
//  }
//// -------------------------


std::ostream & operator << (std::ostream &os, const comb_minchange &x)
{
    cout.width(2);
    os << x.x_[0];
    for (ulong i=1; i<x.k_; ++i)
    {
        os << " ";
        cout.width(2);
        cout << x.x_[i];
    }
    return os;
}
// -------------------------
