#if !defined HAVE_AUX2LAZY_H__
#define      HAVE_AUX2LAZY_H__

//: include file for the lazy: include all headers from aux2/

#include "array2d.h"
#include "copy2d.h"
#include "minmax2d.h"
//#include "misc2d.h"
#include "reverse2d.h"
#include "rotate2d.h"
#include "arith2d.h"
#include "misc2d.h"
#include "scale2d.h"
#include "shift2d.h"
#include "transpose.h"
#include "transpose_ba.h"
#include "transpose2_ba.h"
#include "transpose2.h"


#endif // !defined HAVE_AUX2LAZY_H__
