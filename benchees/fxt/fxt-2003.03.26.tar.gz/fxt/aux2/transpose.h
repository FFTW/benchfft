#if !defined HAVE_TRANSPOSE_H__
#define      HAVE_TRANSPOSE_H__

#include "fxttypes.h"
//#include "bitsperlong.h"
#include "restrict.h"

#include "inline.h" // swap()
#define swap fxtaux::swap // avoid unwanted std::swap


template <typename Type>
void transpose_square(Type **f, ulong nrc)
// in-place transposition of an nr x nc array (nr = nc = nrc)
// that lies at nr rows of length nc
{
    const ulong nr = nrc,  nc = nrc;
    for (ulong r=0; r<nr; ++r)
    {
        for (ulong c=r+1; c<nc; ++c)
        {
            // swap(f[r][c], f[c][r]):
            Type  t = f[r][c];
            f[r][c] = f[c][r];
            f[c][r] = t;
        }
    }
}
// -------------------------

template <typename Type>
void transpose_square(Type *f, ulong nrc)
// in-place transposition of an nr x nc array (nr = nc = nrc)
// that lies in contiguous memory
{
    const ulong nr = nrc,  nc = nrc;
    for (ulong r=0; r<nr; r++)
    {
        for (ulong c=r+1; c<nc; c++)
        {
            // swap(f[r][c], f[c][r]):
            ulong k1 = nc * r + c;
            ulong k2 = nc * c + r;
            Type  t = f[k1];
            f[k1] = f[k2];
            f[k2] = t;
        }
    }
}
// -------------------------

template <typename Type>
void transpose(const Type * restrict f, Type * restrict g, ulong nr, ulong nc)
// copy transpose an nr x nc array into an nc x nr array
// both must lie in contiguous memory
{
    for (ulong r=0; r<nr; r++)
    {
        ulong isrc = r * nc;
        ulong idst = r;
        for (ulong c=0; c<nc; c++)
        {
            g[idst] = f[isrc];
            ++isrc;
            idst += nr;
        }
    }
}
// -------------------------


//#define  SRC(k)  (((k)*nc)%n1)  // note: overflow if k*nc >= 2^BITS_PER_LONG
#define  SRC(k)  (((unsigned long long)(k)*nc)%n1)  // note: overflow if k*nc >= 2^64
//#define  DST(k)  (((k)*nr)%n1)

template <typename Type>
void transpose(Type *f, ulong nr, ulong nc)
// in-place transposition of a  nr X nc  array
// that lies in contiguous memory
{
    if ( 1>=nr )  return;
    if ( 1>=nc )  return;

    if ( nr==nc )
    {
        transpose_square(f, nr);
        return;
    }

    const ulong n1 = nr * nc - 1;
    unsigned ct = 2; // count moves for better detection when finished
    // big improvement if there are only a few cycles

    for (ulong k=1; k<n1; k++)  //  0 and n1 are fixed points
    {
        ulong ks  = SRC(k);
        if ( ks==k )
        {
            ct++;
            continue;  // fixed point
        }

        // scan cycle:
        while ( ks != k )
        {
            if ( ks<k )  goto next; // from previous cycle
            ks = SRC(ks);
        }

        {  // do a cycle:
            ks = SRC(k);
            ulong kd = k;
            Type t = f[kd];
            while ( ks != k )
            {
                ++ct;
                f[kd] = f[ks];
                kd = ks;
                ks = SRC(ks);
            }
            ++ct;
            f[kd] = t;
        }

        if ( ct>=n1 )  return;

    next: ;
    }
}
// -------------------------

#undef SRC
#undef DST

#undef swap // end (avoid unwanted std::swap)

#endif // !defined HAVE_TRANSPOSE_H__
