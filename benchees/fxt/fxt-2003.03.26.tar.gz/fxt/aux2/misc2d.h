#if !defined HAVE_MISC2D_H__
#define      HAVE_MISC2D_H__


#include "fxttypes.h"
#include "misc.h"


template <typename Type>
inline void apply_func(Type **f, ulong nr, ulong nc, Type (*func)(Type))
// apply function func to each element of f[]
{
    while ( nr-- )  apply_func(f[nr], nc, func);
}
// -------------------------



#endif // !defined HAVE_MISC2D_H__
