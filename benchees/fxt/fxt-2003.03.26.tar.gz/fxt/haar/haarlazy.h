#if !defined  HAVE_HAARLAZY_H__
#define       HAVE_HAARLAZY_H__


//: include file for the lazy: include all headers from haar/

#include "haar.h"
#include "haarnn.h"
#include "transposedhaarnn.h"
#include "haarrevnn.h"
#include "transposedhaarrevnn.h"


#endif  // !defined HAVE_HAARLAZY_H__
