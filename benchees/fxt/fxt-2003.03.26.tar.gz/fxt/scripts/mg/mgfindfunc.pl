
# imported by metagen

sub find_func
{
    while ( <STDIN> )
    {
        chomp;
        $line = $_;
        if ( $line =~ /(.*)(\/\/.*)/ ) # strip comments
        {
            $line = $1;
            $comment = $2;
        }

        if ( $line =~ /^($funcname) *\((.*)\) *$/ ) # func found ?
        {
            $funcname = $1;
            $funcsig = $2;
            chomp $funcsig;
            last;
        }

        if ( ($line =~ / *\#/) || ($line =~ /^\/\/\#/ ) )
        {
            print "$line\n";    # . "      // CPP_line \n";
            next;
        }

        if ( $line =~ /^static/ )
        {
            print "$line\n";    # . "      // STATIC_VAR_line \n";
            next;
        }

    }
}

1; # perl stupidity

##########################
