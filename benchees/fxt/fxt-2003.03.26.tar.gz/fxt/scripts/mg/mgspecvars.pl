
# imported by metagen


##########################

sub spec_vars
{
    $tf = $funcsig;
    while ( $tf =~ /\w/ )
    {
        $var = $tf;
        if ( $tf =~ /([^,]+),(.*)/ ) # if more than one parameter, take first
        {
            $var = $1;
            $tf = $2;
        }
        else
        {
            $tf = '';
        }

        if ( $var =~ /^ *([^ ].*[^ ]) *($idpat) *$/ )
        {
            $vartype = $1;
            $varname = $2;
        }
        else
        {
            die "FATAL: cannot match [type identifier]\n  in tf=[$tf]  funcsig=[$funcsig]\n  ";
        }

        print STDERR "vartype=[$vartype]\n";
        print STDERR "varname=[$varname]\n";
#        print STDERR "tf=[$tf]\n";

        $specq = 0;
        foreach $t (@specvarnames)
        {
            if ( $varname eq $t )
            {
                $spectype{$varname} = $vartype;
                $specq = 1;
                print STDERR "special\n";
                last;
            }
        }
        if ( !$specq )
        {
            print STDERR "not special\n";
            $gentype{$varname} = $vartype;
        }
    }

    $gensig = "";
    foreach $t (keys %gentype)
    {
        $v = $gentype{$t};
        print STDERR "gen: $v $t\n";
        $gensig = $gensig . ", " . $v . $t;
        print "$v $t = 0; // gen\n";
    }
    if ( $gensig =~ /^,(.*)$/ )  { $gensig = $1; }
#$gensig = "(" . $gensig. ")";
    print STDERR "gen sig = $gensig\n";

    $specsig = "";
    $specarg = "";
    foreach $t (keys %spectype)
    {
        $v = $spectype{$t};
        print STDERR "spec: $v $t\n";
        $specsig = "$specsig, $v $t";
        $specarg = "$specarg, $t" . "_";
        print "$v $t\_ = 0;  // spec\n";
    }
    if ( $specsig =~ /^, (.*)$/ )  { $specsig = $1; }
    if ( $specarg =~ /^, (.*)$/ )  { $specarg = $1; }
}

1; # perl stupidity

##########################
