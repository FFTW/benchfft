
#include "bitcombcolex.h"
#include "bitcount.h"

#include "fxttypes.h"
#include "printbin.h"

#include "jjassert.h"

#include "fxtio.h"

#include <cstdlib>  // strtoul()

char *vv[] =
{
//    "000001",
//    "000011",
//    "000111",

    "00000001000000000000000000000000",
    "00000011000000000000000000000000",
    "00000111000000000000000000000000",
    "00001100100010000000000000000000",
    "01110000000000000000000000000000",

    "0xf7000000",
    "0xfff10000",
    "0x7f00f000",
    "0xffffffff",
    "0",

    "0x7badcafe"  // magic
};
// -------------------------


int
main()
{
    for (ulong i=0;  ; ++i)
    {
        ulong v = strtoul(vv[i], 0, (vv[i][1]=='x' ? 16 : 2) );
        if ( 0x7badcafe==v )  break;

        cout << endl;
        cout << endl;
        ulong bct = bit_count(v);
        cout << "  " << bct << "  bits set:" << endl;

        for (ulong j=0; j<40; ++j)
        {
            print_bin("", v, 0, ".1");

//            ulong t = next_colex_comb(v);
//            if ( t && (t<v) )  print_bin("", t, 0, ".x");  // never

            v = next_colex_comb(v);

            if ( v )
            {
                if( bct!=bit_count(v) )
                {
                    print_bin("OOPS:", v, 0, ".1");
                    return 1;
                }
            }

            if ( 0==v )
            {
                cout << "last.";
//                cout << " @ j = " << j+1;
                cout << endl;
                goto there;
            }

        }
    there: ;
    }

    return 0;
}
// -------------------------
