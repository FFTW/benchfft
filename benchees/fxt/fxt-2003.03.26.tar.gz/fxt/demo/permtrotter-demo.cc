
#include "permtrotter.h"
//demo-include "permtrotter.cc"

#include "fxttypes.h"
#include "fxtio.h"

#include <cstdlib> // atol()


int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    perm_trotter perm(n);
    const ulong *x = perm.data();
    ulong sw1, sw2;
    do
    {
        cout << " #"; cout.width(3); cout << perm.current() << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";

        perm.get_swap(sw1, sw2);
        cout << "  swap: (" << sw1 << ", " << sw2 << ") ";

        cout << "  p= ";
        for (ulong i=0; i<n; ++i)  cout << perm.p_[i] << " ";

        cout << endl;
    }
    while ( perm.next() );

//    for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
//    cout << endl;

    return 0;
}
// -------------------------


