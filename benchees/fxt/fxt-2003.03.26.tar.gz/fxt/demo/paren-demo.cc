
#include "paren.h"

#include "fxttypes.h"
#include "fxtio.h"

#include <cstdlib> // atol()

int
main(int argc, char **argv)
{
    int n = 5;
    if ( argc>1 )  n = atol(argv[1]);

    paren pa(n);
    const int *x = pa.data();
    const char *str = pa.string();

    do
    {
        cout << " #"; cout.width(3); cout << pa.current() << ":   ";
        for (int i=0; i<n; ++i)  cout << x[i] << " ";

        cout << "  " << str;

        cout << endl;
    }
    while ( pa.next() );

//    cerr << "n= " << n << " total # = " << (1+pa.current()) << endl;

    return 0;
}
// -------------------------


