
#include "bitpolirred.h"
#include "bitpol.h"
#include "printbin.h"

#include <cstdlib>  // atol()

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"


//% irreducible polynomials over Z/2Z

int
main(int argc, char **argv)
{
    ulong ldn = 7;
    if ( argc>1 )  ldn = atol(argv[1]);

    const ulong n = 1UL << ldn;
    const ulong h = 1UL << (ldn-1);

    ulong ct = 0;
    for (ulong k=1; k<n; k+=2)
    {
        ulong z = k | (h<<1);
        if ( bitpol_irreducible_q(z, h) )
        {
            ++ct;
            cout << "  ";
            print_bin_nn("    ", z, ldn+1, ".1");
            cout << "  = " << ldn;
            for (ulong j=ldn-1; (long)j>=0; --j)
            {
                if ( z & (1UL<<j) )  cout << "," << j;
            }
//            cout << "   % k=" << k;
            cout << endl;
        }
    }
    cout << "ldn = " << ldn << "  ct = " << ct << endl;

    cout << endl;
    return 0;
}
// -------------------------


//  ldn =  1  ct = 1
//  ldn =  2  ct = 1
//  ldn =  3  ct = 2
//  ldn =  4  ct = 3
//  ldn =  5  ct = 6
//  ldn =  6  ct = 9
//  ldn =  7  ct = 18
//  ldn =  8  ct = 30
//  ldn =  9  ct = 56
//  ldn = 10  ct = 99
//  ldn = 11  ct = 186
//  ldn = 12  ct = 335
//  ldn = 13  ct = 630
//  ldn = 14  ct = 1161
//  ldn = 15  ct = 2182
//  ldn = 16  ct = 4080
//  ldn = 17  ct = 7710
//  ldn = 18  ct = 14532
//  ldn = 19  ct = 27594
//  ldn = 20  ct = 52377
//  ldn = 21  ct = 99858
//  ldn = 22  ct = 190557
//  ldn = 23  ct = 364722
//  ldn = 24  ct = 698870

