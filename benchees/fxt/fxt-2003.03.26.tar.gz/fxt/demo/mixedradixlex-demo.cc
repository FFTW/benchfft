
#include "mixedradixlex.h"
#include "mixedradix.h"

#include "misc.h" // compare()
#include "copy.h" // fill()

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()

void
print_mr(const ulong *x, ulong n)
{
    for (ulong j=0; j<n; ++j)
    {
        ulong v = x[j];
        cout << " ";
        if ( 0==v )  cout << '.';
        else         cout << v;
    }
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    ulong r[n];
    ulong rr = 3;
    if ( argc>2 )  rr = atol( argv[2] );
    fill(r, n, rr);
    for (ulong k=3;  k<(ulong)argc; ++k)  r[k-2] = atol(argv[k]);

    mixed_radix mr(r, n);
    mixed_radix_lex mrl(r, n);
    ulong ct = 0;
    do
    {
        cout << " " << setw(4) << ct << "  ";
        print_mr( mr.data(), n );

        cout << "    ";
        print_mr( mrl.data(), n );

        // check whether fixed point:
        ulong fp = compare(mr.data(), mrl.data(), n );
        if ( 0==fp )  cout << "  *";;

        mr.prev();
        ++ct;
        cout << endl;
    }
    while ( mrl.next() < n );

    return 0;
}
// -------------------------
