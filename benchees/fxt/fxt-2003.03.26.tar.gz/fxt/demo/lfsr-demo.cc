
#include "lfsr.h"
#include "minweightprimpoly.h"
#include "lowbitprimpoly.h"
#include "randprimpoly.h"

#include "bitpoltrace.h"
#include "graycode.h"

#include "fxttypes.h"
#include "auxbitlazy.h"
#include "jjassert.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()



int
main(int argc, char **argv)
{
    ulong n = 5;
    if ( argc>1 )  n = atol(argv[1]);

    ulong c = 0;  // 0==> default primpoly
    c = lowbit_primpoly[n];
//    c = rand_primpoly[n];
//    c = (1UL<<n)+1+ (1UL<<(1));
//    c = minweight_primpoly[n];

    if ( argc>2 )
    {
        c = 1UL<<n;
        for (ulong j=2; j<(ulong)argc; ++j)
        {
            c |= (1UL << atol(argv[j]));
        }
    }

    lfsr srs(n, c);

    ulong pn  = n;

    print_bin_nn("poly = ", srs.c_, pn+1, ".1");
    cout << " == 0x" << hex << srs.c_ << dec << " == " << srs.c_ ;
    cout << "  (deg = " << (srs.n_) << ")";
    cout << endl;

    ulong end = srs.max_period();
//    cout << "MP=" << srs.max_period() << endl;

//    srs.set_a(1);
//    srs.set_w(1);
    ulong a = srs.get_a(), a1 = a;
    for (ulong k=0; k<end; ++k)
    {
        ulong w = srs.get_w();

        cout << setw(4) << k << "  ";
        print_bin_nn(" = ", k, pn, ".1");

        print_bin_nn("    a= ", a, pn, ".1");

//        ulong t = bitpol_el_trace(a, c, srs.h_);
//        print_bin_nn(" ", t, 1, ".1");
//        ulong p = parity(a&c);
//        print_bin_nn(" ", p, 1, ".1");
//        ulong pa = parity(a);
//        print_bin_nn(" ", pa, 1, ".1");

        print_bin_nn("  w= ", w, pn, ".1");

//        print_bin_nn("   =^=  ", bit_cyclic_min(w, n), pn, ".1");

        cout << " = " << setw(4) << w;
        cout << endl;

        srs.next();
        a = srs.get_a();

        if ( a==a1 )  jjassert( k+1==end );
    }

    return 0;
}
//----------------
