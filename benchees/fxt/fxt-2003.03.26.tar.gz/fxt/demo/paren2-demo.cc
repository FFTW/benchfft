
#include "paren2.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "auxprint.h"

#include <cstdlib> // atol()


int
main(int argc, char **argv)
{
    ulong k = 5;
    if ( argc>1 )  k = atol(argv[1]);

    paren2 par(k);

    ulong n = 2*k;
    ulong ct = 0;
    do
    {
        cout << endl;
        cout << "  " << par.string() << "  ";
        print_set_as_bitset("", par.data(), k, n );
        cout << "  #" << setw(3) << ct;
        ++ct;
    }
    while ( par.next() );
    cout << endl;

    return 0;
}
// -------------------------
