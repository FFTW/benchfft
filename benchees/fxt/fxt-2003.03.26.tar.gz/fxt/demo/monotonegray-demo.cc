
#include "monotonegray.h"
//demo-include "monotonegray.cc"

#include "printbin.h"
#include "bitcount.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()

//% monotone Gray code (Savage/Winkler)


int
main(int argc, char **argv)
{
    ulong ldn = 5;
    if ( argc>1 )  ldn = atol(argv[1]);

    ulong n = 1UL << ldn;
    ulong pd = ldn;
    ulong g[n];
    monotone_gray(g, ldn);

    for (ulong k=0; k<n; ++k)
    {
        cout << setw(4) << k << ":  ";
        print_bin_nn(" ", g[k], pd, ".1");
        cout << setw(3) << bit_count(g[k]);
        if ( 0!=k )  print_bin_nn("    ", g[k]^g[k-1] , pd, ".1");
        cout << endl;
    }

    return 0;
}
// -------------------------
