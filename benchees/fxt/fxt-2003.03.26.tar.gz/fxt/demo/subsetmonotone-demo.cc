
#include "subsetmonotone.h"

#include "printbin.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "fxtiomanip.h"
#include "auxprint.h"

#include <cstdlib> // atol()

int
main(int argc, char **argv)
{
    ulong n = 5;
    if ( argc>1 )  n = atol(argv[1]);

    subset_monotone so(n);
    const ulong *x = so.data();

    ulong idx = 0;
    ulong num;
    do
    {
        num = so.next();
        ++idx;
        cout << setw(2) << idx << ":  ";

        // print as bit set:
        for (ulong k=0; k<n; ++k)  cout << (x[k]?'1':'.'); // << " ";
        cout << "   #=" << num;

        // print as set:
        print_delta_set_as_set("   set=", x, n);

        cout << endl;
    }
    while ( num );

    return 0;
}
// -------------------------
