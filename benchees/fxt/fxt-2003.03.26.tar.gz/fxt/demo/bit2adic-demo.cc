
#include "bit2adic.h"

#include "fxttypes.h"
#include "bitsperlong.h"
#include "printbin.h"

#include "jjassert.h"

#include <cstdlib>  // atol()

#include "fxtio.h"
#include "fxtiomanip.h"


//% 2adic inverse and square root


static void show2adic(ulong x)
{
    const ulong pn = BITS_PER_LONG;

    print_bin_nn("    x   = ", x, pn, ".1");
    cout << "  = " << setw(4) << (long)x;

    if ( x&1 )
    {
        ulong i = inv2adic(x);  // inverse
        cout << endl;
        print_bin_nn("    inv = ", i, pn, ".1");
        jjassert( 1UL == x*i );
    }

    do
    {
        ulong r = sqrt2adic(x);
        if ( r*r != x )   break;

        cout << endl;
        print_bin_nn("   sqrt = ", r, pn, ".1");
//        print_bin_nn("   x = ", x, pn, ".1");
    }
    while ( 0 );

    cout << endl;
    cout << endl;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong ldn = 6;
    if ( argc>1 )  ldn = atol(argv[1]);

    const ulong n = 1UL << ldn;
    for (ulong k=1; k<n; ++k)
    {
        ulong x = k;
        show2adic(x);
        x = -x;
        show2adic(x);
    }

    cout << endl;
    return 0;
}
// -------------------------

