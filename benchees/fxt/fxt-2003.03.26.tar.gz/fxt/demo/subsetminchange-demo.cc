
#include "subsetminchange.h"

#include "printbin.h"
#include "auxprint.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


int
main(int argc, char **argv)
{
    ulong n = 5;
    if ( argc>1 )  n = atol(argv[1]);

    subset_minchange sm(n);
    const ulong *x = sm.data();

    ulong num, idx = 0;
    do
    {
        num = sm.next();  // omit empty set
        ++idx;
        cout << setw(2) << idx << ":  ";

        // print as bit set:
        for (ulong k=0; k<n; ++k)  cout << (x[k]?'1':'.');
        cout << "   chg @ " << sm.get_change();
        cout << "   num=" << num;

        print_delta_set_as_set("   set=", x, n);
        cout << endl;
    }
    while ( num );

    return 0;
}
// -------------------------
