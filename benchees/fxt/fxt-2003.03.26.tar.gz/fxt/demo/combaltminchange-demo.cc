
#include "combaltminchange.h"

#include "revbin.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "printbin.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


void
foo(ulong n, ulong k)
{
    cout << " n = " << n << "  k = " << k << ":" << endl;
    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    ulong ct = 0;
    comb_alt_minchange comb(n, k);

    comb.first();
//    comb.last();
    do
    {
        ulong bits = revbin( ~comb.bits_, n);  // reversed and negated
        cout << "   ";
        for (long k=n-1; k>=0; --k)  cout << ((bits>>k)&1 ? '1' : '.');

        cout << "   [ " << comb << " ]  ";

        cout << "  swap: (" << comb.sw1_ << ", " << comb.sw2_ << ") ";

        cout << "  #" << setw(3) << ct;

        ++ct;
        cout << endl;
    }
    while ( comb.next() );
//    while ( comb.prev() );

    cout << endl;
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
//    ulong n = 7, k = 4;
    ulong n = 5, k = 3;
    if ( argc>1 )  n = atol(argv[1]);
    if ( argc>2 )  k = atol(argv[2]);

    foo(n, k);

    if ( 1==argc )
    {
        foo(7, 3);
        cout << endl;
    }

    return 0;
}
// -------------------------
