
#include "cycles.h"
#include "graypermute.h"
#include "revbinpermute.h"
#include "zip.h"
#include "copy.h"

//#include "permlazy.h"  // all permutation stuff
//#include "newop.h"

#include "fxttypes.h"
#include "fxtio.h"

#include <cstdlib> // atol()


// Print And Doit:
#define  PAD( x )  { cout << "Using: " << #x << endl;  x; }

int
main(int argc, char **argv)
{
    ulong n = 32;
    if ( argc>1 )  n = atol(argv[1]);
    ulong ldn = ld(n);
    if ( (long)n<0 )
    {
        ldn = -(long)n;
        n = 1UL<<ldn;
    }
    cout << "ldn=" << ldn << "  n=" << n << endl;

    ulong a1 = 3;
    if ( argc>2 )  a1 = atol(argv[2]);


    ulong *y = new ulong[n];
    set_seq(y, n);


    cout << " Apply some permutation:" << endl;
    // choose one or more ...:
//    PAD( revbin_permute(y, n) );
//    PAD( reverse(y, n) );
    PAD( gray_permute(y, n) );
//    PAD( zip(y, n) );


    cout << "Study permutation:" << endl;
    cycles cc(n);
    cc.make_cycles(y, n);
    cc.print();
//    cc.print_leaders();


    // ... and print source code:
    cc.print_code("foo_perm", n, 1, 0);
    cc.invert();
    cc.print_code("inverse_foo_perm", n, 1);

    return 0;
}
// -------------------------
