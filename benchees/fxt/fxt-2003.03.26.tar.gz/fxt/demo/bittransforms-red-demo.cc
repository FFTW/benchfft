
#include "bittransforms.h"
#include "graycode.h"
#include "bitlex.h"

#include "bit2pow.h"
#include "bitsperlong.h"
#include "fxttypes.h"
#include "printbin.h"

#include <cstdlib>  // atol()

#include "fxtio.h"
#include "fxtiomanip.h"


//% transforms of binary words that are involutions: red-code and cyan-code


int
main(int argc, char **argv)
{
    ulong ldn = 5;
    if ( argc>1 )  ldn = atol(argv[1]);
    ulong n = 1UL<<ldn;

//    ulong pn = ld(n)+1;
    for (ulong k=0; k<n;  ++k)
    {
        cout << setw(4) << k << ":";

//        ulong l = k;
//        l = blue_code(l);
//        l = i2l(l); l = inverse_gray_code(l); l = i2l(l);  // parity
//        l = gray_code(l); l = l2i(l); l = gray_code(l);  // parity
//        print_bin_nn("   l=", l , BITS_PER_LONG, ".1");
//        cout << " " << setw(2) << bit_count(l);

        ulong r = red_code(k);
        print_bin_nn("   r=", r , BITS_PER_LONG, ".1");
        cout << " " << setw(2) << bit_count(r);

        ulong c = k;
        c = cyan_code(c);
        print_bin_nn("   c=", c , BITS_PER_LONG, ".1");
        cout << " " << setw(2) << bit_count(c);

        cout << endl;
    }

    cout << endl;

    return 0;
}
// -------------------------
