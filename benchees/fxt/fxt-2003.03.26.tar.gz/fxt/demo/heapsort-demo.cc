
#include "heapsort.h"
#include "sort.h"
#include "search.h"

#include "fxttypes.h"
#include "rand.h"  // rnd01()
#include "reverse.h"

#include "jjassert.h"
//#include "newop.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


void
print(const char *bla, const double *f, ulong n)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        double r = f[k];

        cout.width(4);
        cout.flags(ios::right);
        cout << k << ":  ";

        cout.precision(5);
        cout.flags(ios::left);
        cout.width(8);
        cout << r;
        cout << endl;
    }
    cout << endl;
}
// -------------------------


//#define RSEED

int
main(int argc, char **argv)
{
#ifdef  RSEED
    cout << " rseed=" << rseed() << endl;
#endif

    ulong n = 25;
    if ( argc>1 )  n = atol(argv[1]);

    double *f = new double[n];

    rnd01(f, n);
    print("random values:", f, n);

    double v = f[n/2];

    build_heap(f, n);
//    build_heap(f, n-1); heap_insert(f, n-1, n, f[n-1]);
////    print("heapified values:", f, n);
    jjassert( 0==test_heap(f, n) );
////    heap_sort_ascending(f, n);
//    heap_sort_decending(f, n);  reverse(f, n);

//    heap_extract_max(f, n);
//    jjassert( 0==test_heap(f, n-1) );
//    return 0;

    heap_sort(f, n);
    print("sorted values:", f, n);

    jjassert( is_sorted(f, n) );
//    jjassert( 0==test_heap(f, n) );  // not the case in general

    cout << "searching for v=" << v << endl;
    ulong i = bsearch(f, n, v);
    jjassert( i<n );
    cout << "found at index " << i << endl;

    return 0;
}
// -------------------------
