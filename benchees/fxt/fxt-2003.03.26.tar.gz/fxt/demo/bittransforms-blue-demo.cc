
#include "bittransforms.h"
#include "graycode.h"
#include "bitlex.h"

#include "bit2pow.h"
#include "bitsperlong.h"
#include "fxttypes.h"
#include "printbin.h"

#include <cstdlib>  // atol()

#include "fxtio.h"
#include "fxtiomanip.h"


//% transforms of binary words that are involutions: blue-code and yellow-code


int
main(int argc, char **argv)
{
    ulong ldn = 5;
    if ( argc>1 )  ldn = atol(argv[1]);
    ulong n = 1UL<<ldn;

    ulong pn = ld(n)+1;
    for (ulong k=0; k<n;  ++k)
    {
        cout << setw(4) << k << ":";

        ulong g = gray_code(k);
        print_bin_nn("   g=", g , pn, ".1");
        cout << " " << setw(2) << bit_count(g);

        ulong b = blue_code(k);
        print_bin_nn("   b=", b , pn, ".1");
        cout << " " << setw(2) << bit_count(b);


        ulong y = yellow_code(k);
//        y = bit_rotate_right(y, 1);  y = yellow_code(y);  // ==> gray^shift
        print_bin_nn("   y=", y , BITS_PER_LONG, ".1");
        cout << " " << setw(2) << bit_count(y);

        cout << endl;
    }

    cout << endl;

    return 0;
}
// -------------------------
