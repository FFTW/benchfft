
#include "bitcombminchange.h"
#include "greencode.h"

#include "fxttypes.h"
#include "printbin.h"
#include "jjassert.h"

#include "fxtio.h"
#include <cstdlib>  // strtoul()


static const char c01[] = ".1";

void
foo(ulong n, ulong k)
{
    cout << " n = " << n << "  k = " << k << endl;
    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    const ulong pd = n;
    ulong last = igc_last_comb(k, n);
    ulong c, nc = first_sequency(k);
    do
    {
        c = nc;
        nc = igc_next_minchange_comb(c);

        ulong g = gray_code(c);

        print_bin_nn( g, pd, c01);

//        cout << "   ";
//        print_bin_nn(c, pd, c01);

        cout << endl;
    }
    while ( c!=last );

    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    if ( argc>1 )  n = atol(argv[1]);
    if ( argc>2 )  k = atol(argv[2]);

    foo(n, k);

    if ( 1==argc )  foo(7, 3);  // else do only requested n,k

    return 0;
}
// -------------------------
