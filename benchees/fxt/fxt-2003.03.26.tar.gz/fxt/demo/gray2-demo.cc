
#include "graycode.h"
#include "printbin.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()

//% graycode step 2


int
main(int argc, char **argv)
{
    ulong n =5;
    if ( argc>1 )  n = atol(argv[1]);

    ulong nn = 1UL << n;
    ulong pd = n + 2;

    cout << setw(4) << "k" << ":  ";
    cout << setw(pd+4) << "g(k) ";
    cout << setw(pd+4) << "g(g(k))";
    cout << setw(pd+4) << "g(2*k)";
    cout << setw(pd+4) << "g(2*k+1)";
    cout << endl;

    for (ulong k=0; k<nn; ++k)
    {
        cout << setw(4) << k << ":  ";
        print_bin_nn("    ", gray_code(k), pd, ".1");
        print_bin_nn("    ", gray_code( gray_code (k) ) , pd, ".1");
        print_bin_nn("    ", gray_code(2*k), pd, ".1");
        print_bin_nn("    ", gray_code(2*k+1), pd, ".1");
        cout << endl;
    }

    return 0;
}
// -------------------------
