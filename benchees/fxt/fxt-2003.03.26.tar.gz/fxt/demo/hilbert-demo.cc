
#include "hilbert.h"
//demo-include "hilbert.cc"
#include "graycode.h"
#include "bitzip.h"

#include "fxttypes.h"
#include "fxtiomanip.h"
#include "printbin.h"

#include "jjassert.h"

#include <cstdlib>  // atol()


#define PP(x)  cout << "   " << #x << "="; print_bin_nn(x, pd,".1");
int
main(int argc, char **argv)
{
    ulong ldn = 5;
    if ( argc>1 )  ldn = atol(argv[1]);
    ulong  n = (1UL<<ldn);

    ulong pd = ldn + 1;
    cout << "    t ->    binary(x)  binary(y)= ( x,  y)"
         << "   gx=gray(x)  gy=gray(y)"
         << "  z=bitzip(gx,gy) == g"
         << endl;

    for (ulong k=0; k<n; ++k)
    {
        ulong &t = k;
        cout << " #" << setw(3) << t << " -> ";

        ulong x, y;
        hilbert(t, x, y);
        PP(x); PP(y);
        cout << " = (" << setw(2) << x << ", " << setw(2) << y << ")";
        ulong gx = gray_code(x);
        ulong gy = gray_code(y);
        PP( gx );  PP( gy );
        ulong z = bit_zip(gy, gx);
        PP(z);

        ulong g = hilbert_gray_code(t);
        PP(g);

        jjassert( z==g );

        cout << endl;
    }

    return 0;
}
// -------------------------
