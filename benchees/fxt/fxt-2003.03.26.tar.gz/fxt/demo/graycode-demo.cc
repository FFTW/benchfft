
#include "graycode.h"

#include "bitcount.h"

#include "printbin.h"
#include "fxttypes.h"

#include "fxtio.h"

#include <cstdlib> // atol()

static const char c01[] = ".1";

int
main(int argc, char **argv)
{
    ulong n = 64;
    if ( argc>1 )  n = atol(argv[1]);

    cout << "      v             gray_code(v)    bits/sorted   inverse_gray_code(v)/parity(v)"
         << endl;

    for (ulong v=0; v<n; ++v)
    {
        print_bin_nn(v, 8, c01);
        cout << " = ";
        cout.width(3); cout << v;
        cout << "     ";

        ulong g = gray_code(v);
        cout.width(3); cout << g;
        cout << " = ";
        print_bin_nn(g, 8, c01);
        cout << "     ";

        ulong bc = (1UL<<bit_count(g))-1;
        print_bin_nn(bc, 8, c01);
        cout << "     ";

        ulong i = inverse_gray_code(v);
        print_bin_nn(i, 8, c01);
        cout << " = ";
        cout.width(3); cout << i;

        cout << "      P= ";
        cout << parity(v);
        cout << endl;
    }

    return 0;
}
// -------------------------
