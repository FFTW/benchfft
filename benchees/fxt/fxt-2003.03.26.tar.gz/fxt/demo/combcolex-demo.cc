
#include "combcolex.h"

#include "jjassert.h"

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "auxprint.h"

#include <cstdlib> // atol()


//void
//as_bitset(const ulong *x, ulong k, ulong n)
//{
//    ulong w = 0;
//    for (ulong j=0; j<k; ++j)  w |= (1UL<<x[j]);
//    print_bin_nn(w, n, ".1");
//}
//// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 7, k = 4;
    if ( argc>1 )  n = atol(argv[1]);
    if ( argc>2 )  k = atol(argv[2]);
    cout << " n = " << n << "  k = " << k << endl;
    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    ulong ct = 0;
    comb_colex comb(n, k);

    do
    {
        cout << endl;
        cout << "   [ " << comb << " ]  ";
        print_set_as_bitset("", comb.data(), k, n );
        cout << "  #" << setw(3) << ct;
        ++ct;
    }
    while ( comb.next() );
    cout << endl;

    cout << " reversed order: " << endl;
    comb.last();
    do
    {
        --ct;
        cout << "   [ " << comb << " ]  ";
        print_set_as_bitset("", comb.data(), k, n );
        cout << "  #" << setw(3) << ct;
        cout << endl;
    }
    while ( comb.prev() );
    cout << endl;

    return 0;
}
// -------------------------
