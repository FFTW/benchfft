
#include "fxttypes.h"
#include "auxbitlazy.h"
#include "jjassert.h"
#include "fxtiomanip.h"

#include "lfsr.h"

#include <cstdlib> // atol()

//% shift register sequences SRS for all primitive polys of given degree (2<=n<=7)

ulong pp[] =
{
2,1,0,

3,1,0,
3,2,0,

4,1,0,
4,3,0,

5,2,0,
5,3,0,
5,3,2,1,0,
5,4,2,1,0,
5,4,3,1,0,
5,4,3,2,0,

6,1,0,
6,4,3,1,0,
6,5,0,
6,5,2,1,0,
6,5,3,2,0,
6,5,4,1,0,

7,1,0,
7,3,0,
7,3,2,1,0,
7,4,0,
7,4,3,2,0,
7,5,2,1,0,
7,5,3,1,0,
7,5,4,3,0,
7,5,4,3,2,1,0,
7,6,0,
7,6,3,1,0,
7,6,4,1,0,
7,6,4,2,0,
7,6,5,2,0,
7,6,5,3,2,1,0,
7,6,5,4,0,
7,6,5,4,2,1,0,
7,6,5,4,3,2,0,

8,4,3,2,0,
8,5,3,1,0,
8,5,3,2,0,
8,6,3,2,0,
8,6,4,3,2,1,0,
8,6,5,1,0,
8,6,5,2,0,
8,6,5,3,0,
8,6,5,4,0,
8,7,2,1,0,
8,7,3,2,0,
8,7,5,3,0,
8,7,6,1,0,
8,7,6,3,2,1,0,
8,7,6,5,2,1,0,
8,7,6,5,4,2,0,

0
};
//----------------


int
main(int argc, char **argv)
{
    const ulong defn = 6;  // default
    ulong nn = defn;
    if ( argc>1 )  nn = atol(argv[1]);
    if ( (nn<2) || (nn>8) )  nn = defn;
    ulong ct = 0;

    while ( nn!=pp[ct] )  ++ct;  // skip lower degrees

    cout << "degree = " << nn << endl;
    while ( 1 )
    {
        ulong n = pp[ct++];
        if ( nn!=n )  break;  // hit next degree or end
        ulong c = 1UL<<n;
        ulong t;
        do
        {
            t = pp[ct++];
            c |= (1UL<<t);
        }
        while ( t );

        print_bin_nn("c= ", c, n+1, ".1");
//        cout << " = 0x" << hex << c << dec << " = " << c;
        cout << "  srs=";
//        cout << endl;

        lfsr srs(n, c);
        srs.set_w(1);  // to get cyclic min
        ulong end = srs.max_period();
        ulong a = srs.get_a(), a1 = a;
        for (ulong k=1; k<=end; ++k)
        {
//            ulong w = srs.get_w();
//            cout << setw(4) << k << "  ";
//            print_bin_nn("  a= ", a, n, ".1");
//            cout << "    ";
//            print_bin_nn("w= ", w, n, ".1");
//            cout << " = " << w;
//            cout << endl;

            char ch = ((srs.w_ >> (n-1)) ? '1' : '.');
            cout << ch;
            if ( 0==(k%nn) )  cout << ' ';
            srs.next();
            a = srs.get_a();

            if ( a==a1 )  jjassert( k==end );
        }
//        cout << endl;
        cout << endl;
    }

    return 0;
}
//----------------
