
#include "compositionlex.h"

#include "fxttypes.h"
#include "fxtio.h"

#include <cstdlib> // atol()


int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    composition_lex c(n);
    const ulong *x = c.data();
    ulong ct = 0;
    do
    {
        cout << " #"; cout.width(3); cout << ct << ":   ";
        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
        cout << endl;

        ++ct;
    }
    while ( c.next() );

    cout << "  #= " << ct << endl;

//    do
//    {
//        c.prev();
//        cout << " #"; cout.width(3); cout << c.current() << ":   ";
//        for (ulong i=0; i<n; ++i)  cout << x[i] << " ";
//        cout << endl;
//    }
//    while ( c.current() );

    return 0;
}
// -------------------------


//  ? for(n=1,10, print(n, " ", binomial(2*n-1,n-1)))
//  1 1
//  2 3
//  3 10
//  4 35
//  5 126
//  6 462
//  7 1716
//  8 6435
//  9 24310
//  10 92378
