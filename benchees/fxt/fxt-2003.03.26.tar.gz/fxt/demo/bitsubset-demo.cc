
#include "bitsubset.h"

#include "printbin.h"
#include "fxttypes.h"
#include "fxtio.h"

#include <cstdlib>  // strtoul()


char *vv[] =
{
    "00011010",
    "00010000",
    "00001111",
    "10001001",
    "00000000"
};
// -------------------------

static const char c01[] = ".1";
int
main()
{
    for (ulong i=0; i<sizeof(vv)/sizeof(vv[0]); ++i)
    {
        ulong v = strtoul(vv[i], 0, 2);
        cout << "v=" << v << " == " << vv[i] << endl;

        bit_subset s(v);
        do
        {
            print_bin("", s.next(), 8, c01);
        }
        while ( s.current() );

        cout << "----" << endl;
        do
        {
            print_bin("", s.previous(), 8, c01);
        }
        while ( s.current() );

        cout << endl;
    }

    return 0;
}
// -------------------------
