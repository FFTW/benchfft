
#include "partition.h"

#include "fxttypes.h"
#include "copy.h" // set_seq()

#include "jjassert.h"
//#include "newop.h"

#include "fxtio.h"

//#define  CT_UO  // whether to count part. into unequal/odd parts

int
main(int argc, char **argv)
{
//    ulong pv[] = {2, 3, 5, 7, 13, 17, 19, 31, 61, 89, 107, 127, 521, 607, 1279,
//                  2203, 2281, 3217, 4253, 4423, 9689, 9941, 11213, 19937, 21701,
//                  23209, 44497, 86243, 110503, 132049, 216091, 756839, 859433,
//                  1257787, 1398269, 2976221};
//    ulong n = sizeof(pv)/sizeof(ulong);

    ulong n = 50;
    ulong *pv = new ulong[n];
    set_seq(pv, n, 1UL, 1UL);

    for (ulong j=1; j<7; ++j)
    {
        ulong x = pv[j];
        ulong len = j + 1;

        partition pp(pv, len);
        pp.init(x);

        ulong ct = 0;
#ifdef CT_UO
        ulong *pc = pp.pc_;
        ulong cto = 0, ctu = 0;
#endif // CT_UO
        while ( pp.next() < len )
        {
            pp.dump();
            ++ct; // total count

#ifdef CT_UO
            ulong zo = 1;
            for (ulong k=0; k<len; ++k)  if ( pc[k] )  zo &= pv[k];
            cto += zo;  // z==1 for partition into odd parts
            if ( zo )  cout << "part. into odd parts." << endl;

            ulong zu = 1;
            for (ulong k=0; k<len; ++k)  if ( pc[k]>1 )  zu = 0;
            ctu += zu;  // z==1 for partition into unequal parts
            if ( zu )  cout << "part. into unequal parts." << endl;
#endif // CT_UO
        }
        cout << " " << x << ":  ct=" << ct;
#ifdef CT_UO
        cout << "  cto=" << cto << " == ctu=" << ctu;
//        jjassert( ctu == cto );  // for part. n into {1,2,3,...,n}
#endif // CT_UO

        cout << endl;

        cout << endl;
    }
    cout << endl;


    cout << "----------- # of partitions of n into 1,2,3,...,n:" << endl;
    set_seq(pv, n, 1UL, 1UL);
    for (ulong j=1; j<n; ++j)
    {
        ulong x = pv[j];
        ulong len = j + 1;
        partition pp(pv, len);
        ulong ct = pp.count(x);
        cout << " x=" << x << ":  " << ct << endl;
    }

    return 0;
}
// -------------------------
