
#include "debruijn.h"

#include "intarith.h" // ipow()
#include "fxttypes.h"
#include "fxtio.h"

#include <cstdlib> // atol()

void
show_seq(ulong m, ulong n)
{
    debruijn db(m, n);
    ulong ndb = ipow(m, n);
    cout << "\n n = " << n
         << "  len = " << ndb
         << ":" << endl;
    db.init(m, n);
    ulong wct = 0;
    for (ulong j=0; j<ndb; ++j,++wct)
    {
        cout << db.next();
        if ( 0==(j%n) )
        {
            if ( wct>60 )  { wct=0;  cout << "\n "; }
            cout << " ";
            ++wct;
        }
    }
    cout << endl;
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong m = 2;
    if ( argc>1 )  m = atol(argv[1]);
    ulong n = 4;
    if ( argc>2 )
    {
        n = atol(argv[2]);
        cout << " ----- m = " << m << endl;
        show_seq(m, n);
        return 0;
    }


    const ulong maxlen[] = {0, 0, 8, 5, 4, 3, 0};
    //         for:               2  3  4  5

    for (ulong m=2; 0!=maxlen[m]; ++m)
    {
        cout << " ----- m = " << m << endl;
        for (ulong n=1; n<=maxlen[m]; ++n)
        {
            show_seq(m, n);
        }
        cout << endl;
    }

    return 0;
}
// -------------------------
