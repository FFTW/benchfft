
#include "heap.h"
#include "priorityqueue.h"

#include "fxttypes.h"
//#include "search.h"
#include "monotone.h"


#include "arith1.h"
#include "reverse.h"

#include "rand.h"  // rnd01()

#include "jjassert.h"
//#include "newop.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()

#include "copy.h"
//#define copy fxtaux::copy // avoid unwanted std::copy


void
print(const char *bla, const double *f, ulong n)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        double r = f[k];

        cout.width(4);
        cout.flags(ios::right);
        cout << k << ":  ";

        cout.precision(5);
        cout.flags(ios::left);
        cout.width(8);
        cout << r;
        cout << endl;
    }
    cout << endl;
}
// -------------------------


//#define RSEED

int
main(int argc, char **argv)
{
#ifdef  RSEED
    cout << " rseed=" << rseed() << endl;
#endif

    ulong n = 10;
    if ( argc>1 )  n = atol(argv[1]);

//    priority_queue<double, double> pq(n);
    priority_queue<double, double> pq(3, 2); // check grow

    double *t = new double[n];
    double *e = new double[n];
    rnd01(t, n);
//    print("random values:", t, n);
    copy(t, e, n);  negate(e, n); // "events" := -time

    cout << " inserting into piority_queue:..." << endl;
    cout << setw(2) << "# " << ": "
         << setw(12) << " event" << "  @  " << setw(12) << "time" << endl;
    for (ulong k=0; k<n; ++k)
    {
        double ev = e[k];
        double tev = t[k];
        cout << setw(2) << k << ": "
             << setw(12) << ev << "  @  " << setw(12) << tev << endl;
        jjassert( pq.insert(t[k], e[k]) );
    }

    cout << " extracting from piority_queue:..." << endl;
    cout << setw(2) << "# " << ": "
         << setw(12) << " event" << "  @  " << setw(12) << "time" << endl;
    ulong k = n;
    while ( k )
    {
        jjassert( pq.n() );
        double ev;
        double tev = pq.extract_next(ev);
        cout << setw(2) << k << ": "
             << setw(12) << ev << "  @  " << setw(12) << tev << endl;

        --k;
        t[k] = tev;
        e[k] = ev;
    }
    jjassert( 0==pq.n() );

//    print("t-values:", t, n);
    jjassert( is_monotone(t, n) );

//    print("e-values:", e, n);
    jjassert( is_monotone(e, n) );


    return 0;
}
// -------------------------
