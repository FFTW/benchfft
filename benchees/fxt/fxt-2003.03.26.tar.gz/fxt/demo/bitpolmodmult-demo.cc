
#include "bitpolmodmult.h"
#include "minweightprimpoly.h"
#include "lowbitprimpoly.h"
#include "randprimpoly.h"


#include "fxttypes.h"
#include "auxbitlazy.h"
#include "jjassert.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()


int
main(int argc, char **argv)
{
    ulong n = 5;
    if ( argc>1 )  n = atol(argv[1]);

    // multiplier poly:
//    ulong p = 2;  // max period with c primitive
    ulong p = 3;  // period not necessarily maximal
    if ( argc>2 )  p = atol(argv[2]);

    ulong c = 0;
    c = lowbit_primpoly[n];
//    c = rand_primpoly[n];
//    c = (1UL<<n)+1+ (1UL<<(1));
//    c = minweight_primpoly[n];
    if ( argc>3 )
    {
        c = 1UL<<n;
        for (ulong j=3; j<(ulong)argc; ++j)
        {
            c |= (1UL << atol(argv[j]));
        }
    }

    ulong pn  = n;

    ulong h = 1UL << (n-1);
//    c = 3 + (h<<1);
    print_bin_nn("poly = ", c, pn+1, ".1");
    cout << " == 0x" << hex << c << dec;
    cout << "  (deg = " << (n) << ")";
    cout << endl;

    print_bin_nn("mult = ", p, pn+1, ".1");
    cout << " == 0x" << hex << p << dec;
    cout << endl;


    ulong a = 1;
    ulong a1 = a;

    ulong ct = 0;
    do
    {
        cout << setw(6) << ct << "  ";
        print_bin_nn("  a= ", a, pn, ".1");
        cout << "    " << (a&1 ? '1' : '.');  // SRS

//        print_bin_nn("   =^=  ", bit_cyclic_min(a, n), pn, ".1");

//        ulong z = bitpolmod_power(a1, ct+1, c, h);
//        cout << setw(4) << ct << "  ";
//        print_bin_nn("  z= ", z, pn, ".1");
//        cout << endl;
//        jjassert( z == a );

//        a = bitpolmod_times_x(a, c, h);  // =^= p=2
        a = bitpolmod_mult(a, p, c, h);
        ++ct;

//        // inverse mod c (iff c is primitive!):
//        ulong i = bitpolmod_power(a, (h<<1)-2, c, h);
//        print_bin_nn("    i= ", i, pn, ".1");
//        i =  bitpolmod_mult(a, i, c, h);
//        print_bin_nn("    a*i= ", i, pn, ".1");  // ==1

        cout << endl;
    }
    while ( (0==(a>>n)) && (a!=a1) );

    cout << " period = " << ct;
    if ( ct==(1UL<<n)-1 )  cout << "  [maximal]";
    cout << endl;



    return 0;
}
//----------------
