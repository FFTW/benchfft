
#include "bitcomblex.h"
#include "bitrotate.h"


#include "fxttypes.h"
#include "copy.h"
#include "printbin.h"

#include "fxtiomanip.h"

#include <cstdlib>  // strtoul()
#include <cmath>  // floorl()

//% find all SRS of given length 2^n (3<=n<=5)


int
test_debruijn(ulong w, ulong n)
// return 0 if w is a SRS for length-n words
// else return k!=0
// could be optimised, but ...
//   n=5 needs a few seconds
//   n=6 would need too long anyway  ==> leave as is
{
    ulong nn = 1UL<<n;
    int t[nn];
    null(t, nn);

    const ulong mask = first_comb(n);
    for (ulong k=0; k<nn; ++k)
    {
        ulong x = w & mask;
        if ( t[x] )  return  k;  // k!=0
        else         t[x] = 1;
        w = bit_rotate_right(w, 1, nn);
    }

    return 0;
}
// -------------------------


unsigned long long
binomial(ulong n, ulong k)
{
    if ( 2*k > n )  k = n-k;
    if ( (k==0) && (k>=n) )  return  1;

//    long double  b = 1.0;
    double  b = 1.0;
    do
    {
        b *= n;
        b /= k;
        --k;
        --n;
    }
    while ( k!=0 );

//    return  (unsigned long long)floorl(b+0.5);
    return  (unsigned long long)floor(b+0.5);
}
//----------------


double
com(ulong f, ulong n)
// center of mass
{
    double m = 0.0;
    double c = 0.0;
    for (ulong k=0; k<n; ++k)
    {
        ulong e = f & 1;
        m += e;
        c += k*e;
        f >>= 1;
    }
    return  c / m;
}
// -------------------------


int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    const ulong nn = 1UL<<n, nnh = nn/2;
    cout << "n = " << n << "  nn = " << nn << endl;

    ulong N = nn-n-2,  K = nnh-2;
    ulong c = first_rev_comb(K, N);
    cout << "checking binomial("<< N <<", "<< K <<")= "
         << binomial(N,K) << " combinations ..." << endl;
    // n = 3:  binomial(3, 2)   = 3
    // n = 4:  binomial(10, 6)  = 210
    // n = 5:  binomial(25, 14) = 4,457,400
    // n = 6:  binomial(56, 30) = 6,646,448,384,109,072

    ulong ct = 0;     // # of SRS
    const ulong hilo = 1 | (1UL<<(nn-n-1));  // n=4 ==> hilo=....1..........1
    //                               combinations go here: .....**********.
    // the SRS are the cyclic minima, they have the form:  00001**********1

    do
    {
        ulong cc = (c<<1) | hilo;
        int q = test_debruijn(cc, n);
        if ( 0==q )  // found SRS
        {
            ++ct;
//            cout << setw(8) << cc << ":   ";
            print_bin_nn(cc, nn, ".1");
//            cout << "  " << (nn/2 - com(cc, nn));
            cout << endl;
        }
    }
    while ( (c=next_lexrev_comb(c)) );

    cout << "total # of SRS found = " << ct << endl;

    return  0;
}
// -------------------------
