
#include "fcsr.h"

#include "printbin.h"

#include <cstdlib>  // atol()

#include "fxttypes.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include "jjassert.h"


//% Feedback Carry Shift Register


int
main(int argc, char **argv)
{
    ulong c = 37;
    if ( argc>1 )  c = atol(argv[1]);
    ulong ldn = 1 + highest_bit_idx(c);
    ulong pn = ldn; //ld(b+n)+1;
    print_bin_nn("  c = ", c , pn, ".1");
    cout  << "  = " << c << endl;
    cout << "  ldn=" << ldn;
    cout << endl;

    fcsr sr(c);
    ulong a1 = sr.get_a();

    ulong k = 0;
    while ( k<c+ldn )
    {
        ulong a = sr.get_a();
        if ( a1==a )  cout << endl;
        cout << setw(4) << k << " : ";
        print_bin_nn("  a= ", a , pn, ".1");
        cout << " = "<< setw(4) << a << "  ";
        ulong w = sr.get_w();
        print_bin_nn("  w= ", w , pn, ".1");
        cout  << " = " << setw(4) << w;
//        ulong m = sr.get_m();
//        print_bin_nn("  m=", m , pn, ".1");

        sr.next();

//        print_bin_nn("  k=", k , pn, ".1");
//        cout << " " << setw(2) << bit_count(k);

        cout << endl;
        ++k;
    }

    cout << endl;

    return 0;
}
// -------------------------
