
#include "ringbuffer.h"

#include "fxttypes.h"
#include "fxtiomanip.h"

#include "jjassert.h"

#include <cstdlib> // atol()


static void
print_ringbuffer(ringbuffer<ulong> &f)
{
//    cout << endl; for (ulong j=0; j<4; ++j)  cout << "  " << f.x_[j];  cout << endl;

    ulong k = 0;
    ulong z;
    while ( (k = f.read(k, z)) )
    {
        cout << setw(3) << z;
    }
    cout << "   #=" << setw(1) << f.n();
    cout << "   r=" << setw(1) << f.wpos_;
    cout << "   w=" << setw(1) << f.fpos_;
    cout << endl;
}
// -------------------------

static void
vinsert(ringbuffer<ulong> &f, ulong k)
{
    f.insert(k);
    cout << "insert(" << setw(2) << k << ")";
    print_ringbuffer(f);
}
// -------------------------

int
main(int argc, char **argv)
{
    ulong n = 4;
    if ( argc>1 )  n = atol(argv[1]);

    ringbuffer<ulong> f(n);
//    print_ringbuffer(f);

    ulong k = 1;
    for (  ; k<5*n/2; ++k)
    {
        vinsert(f, k);
    }

    return 0;
}
// -------------------------


