
#include "lhca.h"
#include "minweightlhcarule.h"

#include "bitcombcolex.h"  // first_comb() for mask

#include "fxttypes.h"
#include "auxbitlazy.h"
#include "jjassert.h"
#include "fxtiomanip.h"

#include <cstdlib>  // atol()


int
main(int argc, char **argv)
{
    ulong n = 5;
    if ( argc>1 )  n = atol(argv[1]);

//    ulong c = 1;  // rule
    ulong c = minweight_lhca_rule[n];

    ulong pn  = n;

    print_bin_nn("rule = ", c, pn, ".1");
    cout << "  == 0x" << hex << c << dec;// << endl;
    cout << "  length=" << (n) << endl;
    cout << endl;

    ulong end = (1UL<<n)-1;

    ulong x = 1, x1 = x;
    ulong m = first_comb(n);
//    ulong w = 0;
    for (ulong k=1; k<=end; ++k)
    {
        cout << setw(4) << k;
        print_bin_nn("   ", x, pn, ".1");

//        w <<= 1;  w |= (x&1);  w &= m;
//        print_bin_nn("  w= ", w, pn, ".1");

        cout << endl;

        x = lhca_next(x, c, m);
        if ( x==x1 )  jjassert( k==end );
    }

    return 0;
}
//----------------
