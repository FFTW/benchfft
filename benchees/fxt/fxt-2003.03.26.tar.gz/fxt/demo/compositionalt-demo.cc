
#include "compositionalt.h"
#include "bitcombminchange.h"
#include "bit2composition.h"


#include "fxttypes.h"
#include "printbin.h"
#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


int
main(int argc, char **argv)
{
    ulong k = 4;
    if ( argc>1 )  k = atol(argv[1]);

    composition_alt c(k);
    const ulong *x = c.data();


    c.first();
//    c.last();
    ulong ct = 0;
    do
    {
        ulong bits = c.bits_;
        print_bin_nn(bits, 2*k, ".1");
        cout << "  [";
        for (ulong j=0; j<k; ++j)  cout << x[j] << " ";
        cout << "]  ";

        cout << "  #" << setw(3) << ct;

        ++ct;
        cout << endl;
    }
    while ( c.next() );
//    while ( c.prev() );

    cout << endl;

    return 0;
}
// -------------------------
