
#include "subsetlex.h"

#include "printbin.h"
#include "fxttypes.h"

#include "fxtio.h"
#include "fxtiomanip.h"
#include "auxprint.h"

#include <cstdlib>  // atol()


int
main(int argc, char **argv)
{
    ulong n = 5;
    if ( argc>1 )  n = atol(argv[1]);
    subset_lex sl(n);

    ulong idx = 0;
    ulong num = sl.first();
    const ulong *x = sl.data();
    do
    {
        cout << setw(2) << idx;
        ++idx;

        cout << "  #=" << setw(2) << num << ":  ";
        print_set_as_bitset("  ", x, num, n);
        print_set("  ", x, num);
        cout << endl;
    }
    while ( (num = sl.next()) );

    cout << endl;
    num = sl.last();
    do
    {
        cout << setw(2) << idx;
        ++idx;

        cout << "  #=" << setw(2) << num << ":  ";
        print_set_as_bitset("  ", x, num, n);
        print_set("  ", x, num);
        cout << endl;
    }
    while ( (num = sl.prev()) );

    return 0;
}
// -------------------------
