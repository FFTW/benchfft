
#include "bitxtransforms.h"

#include "printbin.h"
#include "revbin.h"
#include "fxtio.h"
#include "fxttypes.h"
#include "bitsperlong.h"

#include <cstdlib>  // atol()

#include "jjassert.h"

//% bases for the symbolix power of the color codes


int
main(int argc, char **argv)
{
    ulong pn = BITS_PER_LONG;
    for (ulong x=0; x<pn; ++x)
    {
        print_bin_nn("x = ", x, 6, ".1");
        cout << " = " << x;
        cout << endl;
        for (ulong z=1,k=0;  k<pn;  ++k,z<<=1)
        {
            ulong a = z;
            a = yellow_xcode(a, x);
//            a = cyan_xcode(a, x);
            a = revbin(a);  // so identity == diagonal
            print_bin(" ", a , pn, ".1");
        }
        cout << endl;
    }
    return 0;
}
// -------------------------
