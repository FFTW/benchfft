#if !defined HAVE_BIT2COMPOSITION_H__
#define      HAVE_BIT2COMPOSITION_H__

#include "fxttypes.h"

static inline void bit2composition(ulong w, ulong *x, ulong n)
// examples:  combinations(7, 4)  --> compositions(4)
//      w         x[0]..x[3]
//  ......1111      4 0 0 0
//  .....1.111      3 1 0 0
//  .....11.11      2 2 0 0
//  .....111.1      1 3 0 0
//  .....1111.      0 4 0 0
//  ....1.111.      0 3 1 0
//  ....1.11.1      1 2 1 0
//  ....1.1.11      2 1 1 0
//  ....1..111      3 0 1 0
//  ....11..11      2 0 2 0
//  ....11.1.1      1 1 2 0
//  ....11.11.      0 2 2 0
//  ....111.1.      0 1 3 0
//  ....111..1      1 0 3 0
//  ....1111..      0 0 4 0
//  ...1.111..      0 0 3 1
//  ...1.11.1.      0 1 2 1
//  ...1.11..1      1 0 2 1
//  ...1.1..11      2 0 1 1
//  ...1.1.1.1      1 1 1 1
//  ...1.1.11.      0 2 1 1
//  ...1..111.      0 3 0 1
//  ...1..11.1      1 2 0 1
//  ...1..1.11      2 1 0 1
//  ...1...111      3 0 0 1
//  ...11...11      2 0 0 2
//  ...11..1.1      1 1 0 2
//  ...11..11.      0 2 0 2
//  ...11.1.1.      0 1 1 2
//  ...11.1..1      1 0 1 2
//  ...11.11..      0 0 2 2
//  ...111.1..      0 0 1 3
//  ...111..1.      0 1 0 3
//  ...111...1      1 0 0 3
//  ...1111...      0 0 0 4
//
{
    for (ulong k=0; k<n; ++k)
    {
        ulong ct = 0;
        ulong b;
        do
        {
            b = w & 1;
            ct += b;
            w >>= 1;
        }
        while ( 0!=b );
        x[k] = ct;
    }
}
// -------------------------


static inline ulong composition2bit(const ulong *x, ulong n)
// 'inverse' of bit2composition()
{
    ulong m = 1,  w = 0;
    for (ulong k=0; k<n; ++k)
    {
        ulong ct = x[k];
        while ( ct-- )
        {
            w |= m;
            m <<= 1;
        }
        m <<= 1;
    }
    return w;
}
// -------------------------


#endif  // !defined HAVE_BIT2COMPOSITION_H__
