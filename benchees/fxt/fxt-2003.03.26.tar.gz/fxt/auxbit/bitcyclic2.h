#if !defined HAVE_BITCYCLIC2_H__
#define      HAVE_BITCYCLIC2_H__


#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitrotate.h"
#include "bitcount.h"



static inline ulong bit_cyclic_period(ulong x)
// return minimal positive bit-rotation
//   that transforms x into itself.
// (same as bit_cyclic_period(x, BITS_PER_LONG) )
//
// Returned value is a divisor of the word length,
//   i.e. 1,2,4,8,...,BITS_PER_LONG.
{
    ulong r = 1;
    do
    {
        ulong y = bit_rotate_right(x, r);
        if ( x==y )  return r;
        r <<= 1;
    }
    while ( r < BITS_PER_LONG );

    return  r;  // == BITS_PER_LONG
}
// -------------------------

static inline ulong bit_cyclic_period(ulong x, ulong ldn)
// return minimal positive bit-rotation
//   that transforms x into itself.
//  (using ldn-bit words)
// Returned value is a divisor of ldn. (possible optimisation)
//
// Examples for ldn=6:
//  ......  1
//  .....1  6
//  ....11  6
//  ...1.1  6
//  ...111  6
//  ..1..1  3
//  ..1.11  6
//  ..11.1  6
//  ..1111  6
//  .1.1.1  2
//  .1.111  6
//  .11.11  3
//  .11111  6
//  111111  1
{
    ulong y = bit_rotate_right(x, 1, ldn);
    return  bit_cyclic_match(x, y, ldn) + 1;
}
// -------------------------


inline ulong bit_cyclic_dist(ulong a, ulong b)
// Return minimal bitcount of (t ^ b)
// where t runs through the cyclic rotations.
{
    ulong d = ~0UL;
    ulong t = a;
    do
    {
        ulong z = t ^ b;
        ulong e = bit_count( z );
        if ( e < d )  d = e;
        t = bit_rotate_right(t, 1);
    }
    while ( t!=a );
    return  d;  // not reached
}
// -------------------------

inline ulong bit_cyclic_dist(ulong a, ulong b, ulong ldn)
// Return minimal bitcount of (t ^ b)
// where t runs through the cyclic rotations.
//  using ldn-bit words
{
    ulong d = ~0UL;
    const ulong m = (~0UL>>(BITS_PER_LONG-ldn));
    b &= m;
    a &= m;
    ulong t = a;
    do
    {
        ulong z = t ^ b;
        ulong e = bit_count( z );
        if ( e < d )  d = e;
        t = bit_rotate_right(t, 1, ldn);
    }
    while ( t!=a );
    return  d;  // not reached
}
// -------------------------


#endif  // !defined HAVE_BITCYCLIC2_H__
