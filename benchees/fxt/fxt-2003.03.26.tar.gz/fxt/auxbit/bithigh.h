#if !defined HAVE_BITHIGH_H__
#define      HAVE_BITHIGH_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitasm.h"


static inline ulong highest_bit_01edge(ulong x)
// return word where a all bits from (including) the
//   highest set bit to bit 0 are set
// returns 0 if no bit is set
//
// feed the result into bit_count() to get
//   the index of the highest bit set
{
#if defined  BITS_USE_ASM

    if ( 0==x )  return 0;
    x = asm_bsr(x);
    return  (2UL<<x) - 1;

#else // BITS_USE_ASM

    x |= x>>1;
    x |= x>>2;
    x |= x>>4;
    x |= x>>8;
    x |= x>>16;
#if  BITS_PER_LONG >= 64
    x |= x>>32;
#endif
    return  x;
#endif // BITS_USE_ASM
}
// -------------------------

static inline ulong highest_bit_10edge(ulong x)
// return word where a all bits from  (including) the
//   highest set bit to most significant bit are set
// returns 0 if no bit is set
{
    if ( 0==x )  return 0;
    x = highest_bit_01edge(x);
    return  ~(x>>1);
}
// -------------------------


static inline ulong highest_bit(ulong x)
// return word where only the highest bit in x is set
// return 0 if no bit is set
{
#if defined  BITS_USE_ASM
    if ( 0==x )  return 0;
    x = asm_bsr(x);
    return  1UL<<x;
#else
    x = highest_bit_01edge(x);
    return  x ^ (x>>1);
#endif // BITS_USE_ASM
}
// -------------------------


static inline ulong highest_zero(ulong x)
// return word where only the highest unset bit in x is set
// return 0 if all bits are set
{
    return  highest_bit( ~x );
}
// -------------------------

static inline ulong set_highest_zero(ulong x)
// return word were the highest unset bit in x is set
// returns ~0 for input == ~0
{
//    if ( ~0UL==x )  return  ~0UL;
    return  x | highest_bit( ~x );
}
// -------------------------


static inline ulong highest_bit_idx(ulong x)
// return index of highest bit set
// return 0 if no bit is set
{
#if defined  BITS_USE_ASM
    return  asm_bsr(x);
#else // BITS_USE_ASM

    if ( 0==x )  return  0;

//    // this version avoids all if() statements:
//    x = ( highest_bit(x) << 1 ) - 1;
//    return  bit_count_01(x) - 1;

    ulong r = 0;
#if  BITS_PER_LONG >= 64
    if ( x & (~0UL<<32) )  { x >>= 32;  r += 32; }
#endif
    if ( x & 0xffff0000 )  { x >>= 16;  r += 16; }
    if ( x & 0x0000ff00 )  { x >>=  8;  r +=  8; }
    if ( x & 0x000000f0 )  { x >>=  4;  r +=  4; }
    if ( x & 0x0000000c )  { x >>=  2;  r +=  2; }
    if ( x & 0x00000002 )  {            r +=  1; }
    return r;
#endif // BITS_USE_ASM
}
// -------------------------


static inline ulong high_zeros(ulong x)
// return word where all the (high end) zeros
// are set
// e.g.  11001000 --> 00000111
// returns 0 if all bits are set
{
    x |= x>>1;
    x |= x>>2;
    x |= x>>4;
    x |= x>>8;
    x |= x>>16;
#if  BITS_PER_LONG >= 64
    x |= x>>32;
#endif
    return  ~x;
}
// -------------------------


static inline ulong high_bits(ulong x)
// return word where all the (high end) ones
// are set
// e.g.  11001011 --> 11000000
// returns 0 if highest bit is zero:
//       01110110 --> 0
{
#if 1
    return  high_zeros( ~x );
#else
    // arithmetic shift is expensive
    long y = (long)x;
    y &= y>>1;
    y &= y>>2;
    y &= y>>4;
    y &= y>>8;
    y &= y>>16;
#if  BITS_PER_LONG >= 64
    y &= y>>32;
#endif
    return  (ulong)y;
#endif
}
// -------------------------

#endif  // !defined HAVE_BITHIGH_H__
