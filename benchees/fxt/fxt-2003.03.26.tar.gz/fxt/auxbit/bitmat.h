#if !defined  HAVE_BITMAT_H__
#define       HAVE_BITMAT_H__

#include "fxttypes.h"
//#include "bitsperlong.h"

#include "graycode.h"  // parity()


// auxbit/bitmat.cc:
void bitmat_print(const char *bla, const ulong *m, ulong n);
ulong bitmat_nullspace(ulong *m, ulong n, ulong *ns);
ulong bitmat_test_nullspace(const ulong *m, ulong n, const ulong *ns, ulong r);


inline ulong bitmat_mult(const ulong *m, ulong n, ulong v)
// Return m*v where
// m is a binary n x n matrix
{
    // ulong mask = ~0UL >> (BITS_PER_LONG-n);
    ulong p = 0;
    for (ulong j=0; j<n; ++j)
    {
        ulong t = m[j] & v;
        // t &= mask;
        t = parity(t);
        p |= (t<<j);
    }
    return p;
}
// -------------------------


#endif  // !defined HAVE_BITMAT_H__
