#if !defined HAVE_PRINTBIN_H__
#define      HAVE_PRINTBIN_H__


// auxbit/printbin.cc:
void print_bin_nn(unsigned long long x, int pd=0, const char *c01=0);
void print_bin_nn(const char *bla, unsigned long long x, int pd/*=0*/, const char *c01/*=0*/);
void print_bin(const char *bla, unsigned long long x, int pd=0, const char *c01=0);


#endif  // !defined HAVE_PRINTBIN_H__
