
#include "fxttypes.h"
#include "bitsperlong.h"

#include "fxtio.h"


void
print_bin_nn(unsigned long long x, int pd/*=0*/, const char *c01/*=0*/)
//
// _nn := No Newline
//
// to print a bit set you may want to use
//   print_bin_nn( revbin(x), pd, ".1")
{
    static const char n01[] = {'0', '1'};

    if ( 0==pd )  pd = BITS_PER_LONG;
    unsigned long long m = 1ULL << (BITS_PER_LONG_LONG-1);
    m >>= (BITS_PER_LONG_LONG-pd);

    const char *d = ( 0==c01 ?  n01 : c01 );

    for(  ; 0!=m; m>>=1)  cout << d[0!=(x & m)];
}
// -------------------------

void
print_bin_nn(const char *bla, unsigned long long x, int pd/*=0*/, const char *c01/*=0*/)
//
// _nn := No Newline
//
// same as print_bin(), but prints no newline
//
{
    cout << bla;
    print_bin_nn(x, pd, c01);
}
// -------------------------

void
print_bin(const char *bla, unsigned long long x, int pd/*=0*/, const char *c01/*=0*/)
//
// print x to radix 2
// pd: how many bits to print
//
{
    cout << bla;
    print_bin_nn(x, pd, c01);
    cout << endl;
}
// -------------------------

