#if !defined  HAVE_BITPOLIRRED_H__
#define       HAVE_BITPOLIRRED_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitpol.h"
#include "bitpolmodmult.h"
#include "bittransforms.h"
//#include "revbin.h"

#include "jjassert.h"


inline ulong bitpol_deriv(ulong x)
// Return  derived polynomial
{
#if  BITS_PER_LONG >= 64
    x &= 0xaaaaaaaaaaaaaaaaUL;
#else
    x &= 0xaaaaaaaaUL;
#endif
    return  (x>>1);
}
// -------------------------

inline ulong bitpol_test_squarefree(ulong x)
// Return  0 if polynomial is square-free
// else return square factor != 0
{
    ulong d = bitpol_deriv(x);
    if ( 0==d )  return  (1==x ? 0 : x);
    ulong g = bitpol_gcd(x, d);
    return  (1==g ? 0 : g);
}
// -------------------------


inline ulong bitpol_irreducible_q(ulong c, ulong h)
// Return zero if C is reducible
// else (i.e. C is irreducible) return value != 0
// C must not be zero.
//
// h needs to be a mask with one bit set:
//  h == highest_bit(c) >> 1  == 1UL << (degree(C)-1)
{
    // if ( 0==(1&c) )  return (c==2 ? 1 : 0); // x is a factor
    // if ( 0==(c & 0xaa..a ) )  return 0; // at least one odd degree term
    // if ( 0==parity(c) )  return 0; // need odd number of nonzero coeff.
    // if ( 0!=bitpol_test_squarefree(c) )  return 0; // must be square free
    ulong d = c;
    ulong u = 2;  // =^= x
    while ( 0 != (d>>=2) )  // floor( degree/2 ) times
    {
        // Square r-times for coefficients of c in GF(2^r).
        // We have r==1
        u = bitpolmod_mult(u, u, c, h);
        ulong upx = u ^ 2;  // =^= u+x
        ulong g = bitpol_gcd(upx, c);
        if ( 1!=g )  return  0;   // reducible
    }
    return  1;  // irreducible
}
// -------------------------


inline ulong bitpol_compose_xp1(ulong c)
// Return C(x+1)
// If C is irreducible/primitive then the returned
//   polynomial is also irreducible/primitive.
{
#if 1
    // log_2(BITS_PER_LONG) - version:
    return  blue_code(c);

#else
    ulong z = 1;
    ulong r = 0;
    while ( c )
    {
        if ( c & 1 )  r ^= z;
        c >>= 1;
        z ^= (z<<1);
    }
    return  r;
#endif
}
// -------------------------


inline ulong bitpol_recip(ulong c)
// Return x^deg(C) * C(1/x)  (the reciprocal polynomial)
// If C is irreducible/primitive then the returned
//   polynomial is also irreducible/primitive.
{
    ulong t = 0;
    while ( c )
    {
        t <<= 1;
        t |= (c & 1);
        c >>= 1;
    }
    return  t;
}
// -------------------------


#endif  // !defined HAVE_BITPOLIRRED_H__
