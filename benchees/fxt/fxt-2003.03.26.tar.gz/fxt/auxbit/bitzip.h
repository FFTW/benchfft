#if !defined HAVE_BITZIP_H__
#define      HAVE_BITZIP_H__

#include "fxttypes.h"
#include "bitsperlong.h"

// functions analogue to butterfly_*()
// can be found at Torsten Sillkes bitmani.h, cf.
// http://www.mathematik.uni-bielefeld.de/~sillke/ALGORITHMS/

static inline ulong butterfly_16(ulong x)
{
#if  BITS_PER_LONG == 64
    ulong t, ml, mr, s;
    ml = 0x0000ffff00000000;
    s = 16;
    mr = ml >> s;
    t = ((x & ml) >> s ) | ((x & mr) << s );
    x = (x & ~(ml | mr)) | t;
#endif
    return  x;
}
// -------------------------



static inline ulong butterfly_8(ulong x)
{
    ulong t, ml, mr, s;
#if  BITS_PER_LONG == 64
    ml = 0x00ff000000ff0000;
#else
    ml = 0x00ff0000;
#endif
    s = 8;
    mr = ml >> s;
    t = ((x & ml) >> s ) | ((x & mr) << s );
    x = (x & ~(ml | mr)) | t;
    return  x;
}
// -------------------------


static inline ulong butterfly_4(ulong x)
{
    ulong t, ml, mr, s;
#if  BITS_PER_LONG == 64
    ml = 0x0f000f000f000f00;
#else
    ml = 0x0f000f00;
#endif
    s = 4;
    mr = ml >> s;
    t = ((x & ml) >> s ) | ((x & mr) << s );
    x = (x & ~(ml | mr)) | t;
    return  x;
}
// -------------------------


static inline ulong butterfly_2(ulong x)
{
    ulong t, ml, mr, s;
#if  BITS_PER_LONG == 64
    ml = 0x3030303030303030;
#else
    ml = 0x30303030;
#endif
    s = 2;
    mr = ml >> s;
    t = ((x & ml) >> s ) | ((x & mr) << s );
    x = (x & ~(ml | mr)) | t;
    return  x;
}
// -------------------------


static inline ulong butterfly_1(ulong x)
{
    ulong t, ml, mr, s;
#if  BITS_PER_LONG == 64
    ml = 0x4444444444444444;
#else
    ml = 0x44444444;
#endif
    s = 1;
    mr = ml >> s;
    t = ((x & ml) >> s ) | ((x & mr) << s );
    x = (x & ~(ml | mr)) | t;
    return  x;
}
// -------------------------


static inline ulong bit_zip(ulong x)
// put lower half bits to even indexes, higher half to odd
{
#if  BITS_PER_LONG == 64
    x = butterfly_16(x);
#endif
    x = butterfly_8(x);
    x = butterfly_4(x);
    x = butterfly_2(x);
    x = butterfly_1(x);
    return  x;
}
// -------------------------


static inline ulong bit_unzip(ulong x)
// put even indexed bits to lower hald, odd indexed to higher half
// inverse of bit_zip()
{
    x = butterfly_1(x);
    x = butterfly_2(x);
    x = butterfly_4(x);
    x = butterfly_8(x);
#if  BITS_PER_LONG == 64
    x = butterfly_16(x);
#endif
    return  x;
}
// -------------------------


#define  BPLH  (BITS_PER_LONG/2)
static inline ulong bit_zip(ulong x, ulong y)
// two-word version:
// only the lower half of x and y are merged
{
    return  bit_zip( (y<<BPLH) + x );
}
// -------------------------

static inline void bit_unzip(ulong t, ulong &x, ulong &y)
// two-word version:
// only the lower half of x and y are filled
{
    t = bit_unzip(t);
    y = t >> BPLH;
    x = t ^ (y<<BPLH);
}
// -------------------------

//ulong
//bit_zip(ulong a, ulong b)
//{
//    ulong x = 0;
//    ulong m = 1, s = 0;
//    for (ulong k=0; k<BPLH; ++k)
//    {
//        x |= (a & m) << s;
//        ++s;
//        x |= (b & m) << s;
//        m <<= 1;
//    }
//    return  x;
//}
////------------------------
//
//
//void
//bit_unzip(ulong x, ulong &a, ulong &b)
//{
//    a = 0;  b = 0;
//    ulong m = 1, s = 0;
//    for (ulong k=0; k<BPLH; ++k)
//    {
//        a |= (x & m) >> s;
//        ++s;
//        m <<= 1;
//        b |= (x & m) >> s;
//        m <<= 1;
//    }
//}
////------------------------
#undef  BPLH


#endif  // !defined HAVE_BITZIP_H__
