#if !defined HAVE_BITSUBSET_H__
#define      HAVE_BITSUBSET_H__

#include "fxttypes.h"


class bit_subset
// generate all all subsets of bits of  a given word
//
// e.g. for the word ('.' printed for unset bits)
//   ...11.1.
// these words are produced by subsequent next()-calls:
//   ......1.
//   ....1...
//   ....1.1.
//   ...1....
//   ...1..1.
//   ...11...
//   ...11.1.
//   ........
//
{
public:
    ulong u_, v_;

public:
    bit_subset(ulong vv) : u_(0), v_(vv) { ; }
    ~bit_subset() { ; }
    ulong current()  const { return u_; }
    ulong next()      { u_ = (u_ - v_) & v_;  return u_; }
    ulong previous()  { u_ = (u_ - 1 ) & v_;  return u_; }
};
// -------------------------


#endif  // !defined HAVE_BITSUBSET_H__
