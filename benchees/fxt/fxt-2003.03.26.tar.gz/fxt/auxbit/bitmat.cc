

#include "fxttypes.h"
#include "printbin.h"
#include "bitmat.h"
#include "fxtiomanip.h"


void
bitmat_print(const char *bla, const ulong *m, ulong n)
{
    if ( bla )  cout << bla << endl;
    for (ulong k=0; k<n; ++k)
    {
        print_bin_nn("  ", m[k], n, ".1");
        cout << "  " << setw(2) << k << endl;
    }
    cout << endl;
}
// -------------------------

ulong
bitmat_nullspace(ulong *m, ulong n, ulong *ns)
// Write basis of nullspace of m to ns.
// m is a binary n x n matrix (over GF(2)).
// Return r, the number of vectors of nullspace.
// 0<=r<=n  (r==n only for m==0)
// rank(m) = n-r
// Contents of m are modified.
//.
// Implementation following Knuth.
{
    ulong cc[n];
    for (ulong k=0; k<n; ++k)  cc[k] = ~0UL;
    ulong c = ~0UL;  // bit(j)==0  iff  cc[j]!=~0

    ulong r = 0;  // size of nullspace
    ulong bk = 1;  // bk == 1<<k
    for (ulong k=0;  k<n;  ++k, bk<<=1)
    {
        ulong bj = 1;  // bj == 1<<j
        ulong j = 0;
        for (  ;  j<n;  ++j, bj<<=1)  // scan column
        {
            if ( 0== (bj & c) )  continue;

            ulong mj = m[j];
            if ( mj & bk )
            {
                for (ulong i=0; i<n; ++i)
                {
                    if ( i==j )  continue;
                    if ( m[i] & bk )  m[i] ^= mj;
                }

                c ^= bj;
                cc[j] = k;
                goto endscan;
            }
        }
    endscan: ;

        if ( j==n )  // output vector
        {
            ulong v = 0;
            for (ulong s=0; s<n; ++s)
            {
                ulong i = cc[s];
                if ( i > n )  continue;
                if ( 0==( m[s] & (1UL<<k) ) )  continue;
                v |= (1UL<<i);
            }
            v |= (1UL<<k);
            ns[r] = v;
            ++r;
        }
    }

    return  r;
}
// -------------------------


ulong
bitmat_test_nullspace(const ulong *m, ulong n, const ulong *ns, ulong r)
// (print and) check nullspace as returned by bitmat_nullspace()
// Return k<r if vector k is not in nullspace.
{
    for (ulong k=0; k<r; ++k)
    {
        ulong v = ns[k];
        cout << setw(2) << k;
        print_bin_nn("   v = ", v, n, ".1");
        ulong z = bitmat_mult(m, n, v);
        if ( 0!=z )  print_bin_nn("  0 =!= m*v = ", z, n, ".1");
        cout << endl;

        if ( 0!=z )  return k;
    }
    return  r;
}
// -------------------------
