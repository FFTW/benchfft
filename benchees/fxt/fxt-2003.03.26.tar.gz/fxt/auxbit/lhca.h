#if !defined  HAVE_LHCA_H__
#define       HAVE_LHCA_H__

#include "fxttypes.h"


inline ulong lhca_next(ulong x, ulong r, ulong m)
// LHCA := (1-dim) Linear Hybrid Cellular Automaton
// return next state (after x) of the
// lhcr with rule defined by r, length defined by m:
// Rule 150 is applied for cells where r is one, rule 90 else.
// Rule 150 :=  next(x) = x + leftbit(x) + rightbit(x)
// Rule 90  :=  next(x) = leftbit(x) + rightbit(x)
// m has to be a burst of the n lowest bits (n: length of automaton)
{
    r &= x;
    ulong t = (x>>1) ^ (x<<1);
    t ^= r;
    t &= m;
    return  t;
}
// -------------------------


#endif  // !defined HAVE_LHCA_H__
