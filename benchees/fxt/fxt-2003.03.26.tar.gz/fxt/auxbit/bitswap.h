#if !defined HAVE_BITSWAP_H__
#define      HAVE_BITSWAP_H__


#include "fxttypes.h"
#include "bitsperlong.h"


static inline void bit_swap(ulong &x, ulong k1, ulong k2)
//
// swap bits k1 and k2
// ok even if  k1 == k2
{
    ulong b1 = x & (1UL<<k1);
    ulong b2 = x & (1UL<<k2);
    x ^= (b1 ^ b2);
    x ^= (b1>>k1)<<k2;
    x ^= (b2>>k2)<<k1;
}
// -------------------------


static inline ulong bit_swap_1(ulong x)
// return x with neighbour bits swapped
{
#if  BITS_PER_LONG == 32
    ulong m = 0x55555555;
#else
#if  BITS_PER_LONG == 64
    ulong m = 0x5555555555555555;
#endif
#endif
    return  ((x & m) << 1) | ((x & (~m)) >> 1);
}
// -------------------------

static inline ulong bit_swap_2(ulong x)
// return x with groups of 2 bits swapped
{
#if  BITS_PER_LONG == 32
    ulong m = 0x33333333;
#else
#if  BITS_PER_LONG == 64
    ulong m = 0x3333333333333333;
#endif
#endif
    return  ((x & m) << 2) | ((x & (~m)) >> 2);
}
// -------------------------

static inline ulong bit_swap_4(ulong x)
// return x with groups of 4 bits swapped
{
#if  BITS_PER_LONG == 32
    ulong m = 0x0f0f0f0f;
#else
#if  BITS_PER_LONG == 64
    ulong m = 0x0f0f0f0f0f0f0f0f;
#endif
#endif
    return  ((x & m) << 4) | ((x & (~m)) >> 4);
}
// -------------------------

static inline ulong bit_swap_8(ulong x)
// return x with groups of 8 bits swapped
{
#if  BITS_PER_LONG == 32
    ulong m = 0x00ff00ff;
#else
#if  BITS_PER_LONG == 64
    ulong m = 0x00ff00ff00ff00ff;
#endif
#endif
    return  ((x & m) << 8) | ((x & (~m)) >> 8);
}
// -------------------------


static inline ulong bit_swap_16(ulong x)
// return x with groups of 16 bits swapped
//
// for 32 bit words this is identical to
//   rotate_left(x,16) or rotate_right(x,16)
{
#if  BITS_PER_LONG == 32
    ulong m = 0x0000ffff;
    // following line is optimized to 'roll $16,%eax'
    // by gcc 2.95.2:
    return  ((x & m) << 16) | ((x & (m<<16)) >> 16);
#else
#if  BITS_PER_LONG == 64
    ulong m = 0x0000ffff0000ffff;
    return  ((x & m) << 16) | ((x & (~m)) >> 16);
#endif
#endif
}
// -------------------------


#if  BITS_PER_LONG == 64
static inline ulong bit_swap_32(ulong x)
// return x with groups of 32 bits swapped
{
    ulong m = 0x00000000ffffffff;
    return  ((x & m) << 32) | ((x & (m<<32)) >> 32);

//    return  ((x & m) << 32) | ((x & (~m)) >> 32);
}
// -------------------------
#endif


#endif  // !defined HAVE_BITSWAP_H__
