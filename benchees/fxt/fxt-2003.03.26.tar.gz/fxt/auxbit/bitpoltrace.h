#if !defined  HAVE_BITPOLTRACE_H__
#define       HAVE_BITPOLTRACE_H__


#include "fxttypes.h"
#include "bitpolmodmult.h"


static inline ulong bitpol_el_trace(ulong a, ulong c, ulong h)
// Return  trace of a an element of GF(2**k)
// where C must be a primitive polynomial
//
// h needs to be a mask with one bit set:
//  h == highest_bit(c) >> 1  == 1UL << (degree(C)-1)
//
// the value returned is zero or one
{
    ulong t = a;
    ulong d = c;
    d >>= 1;
    while ( (d>>=1) )
    {
        t = bitpolmod_square(t, c, h);
        t ^= a;
    }
    return  t;
}
// -------------------------

static inline ulong bitpol_trace(ulong c, ulong h)
// Return  trace of a polynomial over GF(2)
// (this is simply the coefficient of the "degree-1" -term
//
// h needs to be a mask with one bit set:
//  h == highest_bit(c) >> 1  == 1UL << (degree(C)-1)
//
// the value returned is zero or one
{
    return  (c & h ? 1 : 0);
}
// -------------------------


#endif  // !defined HAVE_BITPOLTRACE_H__
