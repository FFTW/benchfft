#if !defined  HAVE_BITPOL_H__
#define       HAVE_BITPOL_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bithigh.h"  // highest_bit()

//<<
// Arithmetic with polynomials over Z/2Z
// The polynomial W represented by the word w is
//  W = pol(w) =: \sum_k{ [bit_k(w)] * x^k}
//>>


inline ulong bitpol_mult(ulong a, ulong b)
// Return  A * B
//
// b=2 corresponds to multiplication with 'x'
//
// Note that the result silently overflows
//  if deg(A)+deg(B) > BITS_PER_LONG
{
    ulong t = 0;
    while ( b )
    {
        if ( b & 1 )  t ^= a;
        b >>= 1;
        a <<= 1;
    }
    return  t;
}
// -------------------------

inline ulong bitpol_square(ulong a)
{
    return bitpol_mult(a, a);
}
// -------------------------


inline ulong bitpol_power(ulong a, ulong x)
// Return A ** x
//
// Overflow will occur even for moderate exponents
{
    if ( 0==x )  return 1;

    ulong s = a;
    while ( 0==(x&1) )
    {
        s = bitpol_square(s);
        x >>= 1;
    }

    a = s;
    while ( 0!=(x>>=1) )
    {
        s = bitpol_square(s);
        if ( x & 1 )  a = bitpol_mult(a, s);
    }
    return  a;
}
// -------------------------


inline ulong bitpol_rem(ulong a, ulong b)
// Return  R = A % B = A - (A/B)*B
{
#if 1
    while ( b <= a )
    {
        ulong t = b;
        while ( (a^t) > t )  t <<= 1;
        // =^= while ( highest_bit(a) > highest_bit(t) )  t <<= 1;
        a ^= t;
    }
#else
    // version for longer polynomials
    if ( b <= a )
    {
        ulong t = b;
        while ( (a^t) > t )  t <<= 1;
        ulong h = highest_bit(t);
        do
        {
            a ^= t;
            do
            {
                t >>= 1;
                h >>= 1;
            }
            while ( h > a );
        }
        while ( t>=b );
    }
#endif
    return  a;
}
// -------------------------

inline ulong bitpol_div(ulong a, ulong b)
// Return  R = A / B
{
    if ( b <= a )
    {
        ulong t = b;
        ulong qb = 1;
        while ( (a^t) > t )  { t <<= 1;  qb <<= 1; }
        ulong h = highest_bit(t);
        ulong q = 0;
        do
        {
            a ^= t;
            q ^= qb;
            do
            {
                t >>= 1;
                h >>= 1;
                qb >>= 1;
            }
            while ( h > a );
        }
        while ( t>=b );

        return  q;
    }
    else  return  0;
}
// -------------------------


inline ulong bitpol_gcd(ulong a, ulong b)
// Return  polynomial gcd(A, B)
{
    if ( 0==a )  return 0;
    if ( 0==b )  return 0;
    while ( 0!=b )
    {
        ulong c = bitpol_rem(a, b);
        a = b;
        b = c;
    }
    // a *= inverse( leading_coeff(a) )
    return  a;
}
// -------------------------



#endif  // !defined HAVE_BITPOL_H__
