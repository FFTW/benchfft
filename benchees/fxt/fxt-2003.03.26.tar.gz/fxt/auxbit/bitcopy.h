#if !defined  HAVE_BITCOPY_H__
#define       HAVE_BITCOPY_H__

#include "fxttypes.h"
//#include "bitsperlong.h"


//: result undefined if indices >= BITS_PER_LONG

inline ulong test_bit(ulong a, ulong i)
// Return whether bit[i] is set
{
    ulong b = 1UL << i;
    return  (a & b);
}
// -------------------------

inline ulong set_bit(ulong a, ulong i)
// Return a with bit[i] set
{
    return  (a | (1UL << i));
}
// -------------------------

inline ulong delete_bit(ulong a, ulong i)
// Return a with bit[i] set to zero
{
    return  (a & ~(1UL << i));
}
// -------------------------

inline ulong change_bit(ulong a, ulong i)
// Return a with bit[i] changed
{
    return  (a ^ (1UL << i));
}
// -------------------------


inline ulong copy_bit(ulong a, ulong isrc, ulong idst)
// copy bit at [isrc] to position [idst]
{
    ulong v = a & (1UL << isrc);
    ulong b = 1UL << idst;
    if ( 0==v )  a &= ~b;
    else         a |=  b;
    return  a;
}
// -------------------------

inline ulong bit_swap_01(ulong a, ulong i, ulong j)
// Swap bits i and j of a
// Bits must have different values (!)
// (i.e. one is zero, the other one)
// i==j is allowed (a is unchanged then)
{
    return  a ^ ( (1UL<<i) ^ (1UL<<j) );
}
// -------------------------


inline ulong bit_swap(ulong a, ulong i, ulong j)
// Swap bits i and j of a
// i==j is allowed (a is unchanged then)
{
#if 1  // optimized:
    ulong x = (a >> i) ^ (a >> j);
    // something to do if bit[i]!=bit[j]:
    if ( 0!=(x&1) )  a = bit_swap_01(a, i, j);
    return  a;

#else  // non-optimized version:
    ulong bi = 1UL << i;
    ulong bj = 1UL << j;
    ulong m = ~0UL;
    m ^= bi;
    m ^= bj;  // use xor to make it work for i==j
    ulong t = a & m;  // delete bits from a
    if ( a & bi )  t |= bj;
    if ( a & bj )  t |= bi;
    return  t;
#endif
}
// -------------------------


#endif  // !defined HAVE_BITCOPY_H__
