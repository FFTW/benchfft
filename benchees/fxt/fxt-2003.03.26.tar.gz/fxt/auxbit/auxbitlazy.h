#if !defined HAVE_AUXBITLAZY_H__
#define      HAVE_AUXBITLAZY_H__

//: include file for the lazy: include all headers from auxbit/

#include "bitsperlong.h"

#include "bitcount.h"
#include "bitswap.h"
#include "bitrotate.h"
#include "bitcyclic.h"
#include "bitcyclic2.h"
#include "bitlow.h"
#include "bithigh.h"
#include "bit2pow.h"
#include "bitsubset.h"
#include "revbin.h"
#include "graycode.h"
#include "tinyfactors.h"

#include "bitasm.h"

#include "bitpol.h"
#include "bitmat.h"
#include "bitpolirred.h"
#include "bitpoltrace.h"
#include "bitpolmodmult.h"
#include "bitpolmodmultrev.h"
#include "minweightprimpoly.h"
#include "lowbitprimpoly.h"
#include "randprimpoly.h"
#include "lfsr.h"
#include "lfsr64.h"

#include "lhca.h"
#include "minweightlhcarule.h"

#include "fcsr.h"

#include "bit2adic.h"

#include "bitcombcolex.h"
#include "bitcomblex.h"
#include "bitcombminchange.h"
#include "bit2composition.h"
#include "bitlex.h"
#include "zerobyte.h"
#include "branchless.h"

#include "bitmrotate.h"

#include "bitsequency.h"
#include "bitcopy.h"
#include "bitmisc.h"
#include "bitzip.h"
#include "bitgather.h"
#include "greencode.h"
#include "graypower.h"
#include "bittransforms.h"
#include "bitxtransforms.h"
#include "hilbert.h"

#include "colormix.h"
#include "colormixp.h"
#include "fl_colormix.h"

#include "printbin.h"


#endif // !defined HAVE_AUXBITLAZY_H__
