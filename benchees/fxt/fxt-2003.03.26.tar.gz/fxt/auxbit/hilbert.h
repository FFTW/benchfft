#if !defined HAVE_HILBERT_H__
#define      HAVE_HILBERT_H__

#include "fxttypes.h"


// auxbit/hilbert.cc:
void hilbert(ulong t, ulong &x, ulong &y);
ulong hilbert_gray_code(ulong t);


#endif  // !defined HAVE_HILBERT_H__
