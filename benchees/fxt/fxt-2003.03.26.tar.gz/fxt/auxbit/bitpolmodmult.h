#if !defined  HAVE_BITPOLMODMULT_H__
#define       HAVE_BITPOLMODMULT_H__

#include "fxttypes.h"


static inline ulong bitpolmod_times_x(ulong a, ulong c, ulong h)
// Return  (A * x) mod C
// where A and C represent polynomials over Z/2Z:
//  W = pol(w) =: \sum_k{ [bit_k(w)] * x^k}
//
// h needs to be a mask with one bit set:
//  h == highest_bit(c) >> 1  == 1UL << (degree(C)-1)
//
// If C is a primitive polynomial of degree n
// successive calls will cycle through all 2**n-1
// n-bit words and the sequence of bits
// (any fixed position) of a constitutes
// a shift register sequence (SRS).
// Start with a=2 to get a SRS that starts with
// n-1 consecutive zeroes (use bit 0 of a)
{
    ulong s = a & h;
    a <<= 1;
    if ( s )  a ^= c;
    return  a;
}
// -------------------------


inline ulong bitpolmod_mult(ulong a, ulong b, ulong c, ulong h)
// Return  (A * B) mod C
// where A, B and C represent polynomials over Z/2Z:
//  W = pol(w) =: \sum_k{ [bit_k(w)] * x^k}
//
// h needs to be a mask with one bit set:
//  h == highest_bit(c) >> 1  == 1UL << (degree(C)-1)
//
// With b=2 (== 'x') the result is identical to
//   bitpolmod_times_x(a, c)
{
    ulong t = 0;
    while ( b )
    {
        if ( b & 1 )  t ^= a;
        b >>= 1;

        ulong s = a & h;
        a <<= 1;
        if ( s )  a ^= c;
    }
    return  t;
}
// -------------------------

inline ulong bitpolmod_square(ulong a, ulong c, ulong h)
{
    return bitpolmod_mult(a, a, c, h);
}
// -------------------------


inline ulong bitpolmod_power(ulong a, ulong x, ulong c, ulong h)
// Return (A ** x)  mod C
// where A and C represent polynomials over Z/2Z:
//   W = pol(w) =: \sum_k{ [bit_k(w)] * x^k}
//
// h needs to be a mask with one bit set:
//  h == highest_bit(c) >> 1  == 1UL << (degree(C)-1)
//
// With primitive C the inverse of A can be obtained via
// i = bitpolmod_power(a, c, r1, h)
//  where r1 = (h<<1)-2 = max_order - 1 = 2^degree(C) - 2
// Then  1 == bitpolmod_mult(a, c, i, h)
{
    if ( 0==x )  return 1;

    ulong s = a;
    while ( 0==(x&1) )
    {
        s = bitpolmod_square(s, c, h);
        x >>= 1;
    }

    a = s;
    while ( 0!=(x>>=1) )
    {
        s = bitpolmod_square(s, c, h);
        if ( x & 1 )  a = bitpolmod_mult(a, s, c, h);
    }
    return  a;
}
// -------------------------


#endif  // !defined HAVE_BITPOLMODMULT_H__
