#if !defined HAVE_BITLEX_H__
#define      HAVE_BITLEX_H__

#include "fxttypes.h"
#include "bitcount.h"
#include "bithigh.h"


static inline ulong next_lexrev(ulong x)
// Return next word in (reversed) lex order.
// Start with a one-bit word at position n-1 to
// generate 2**n bit-subsets of length n:
// e.g. for n==4:
//  1...
//  11..
//  111.
//  1111
//  11.1
//  1.1.
//  1.11
//  1..1
//  .1..
//  .11.
//  .111
//  .1.1
//  ..1.
//  ..11
//  ...1
//
{
    ulong x0 = x & -x;
    if ( 1==x0 )
    {
        x ^= x0;
        x0 = x & -x;
        x0 ^= (x0>>1);
    }
    else  x0 >>= 1;

    x ^= x0;
    return  x;
}
// -------------------------


static inline ulong prev_lexrev(ulong x)
// Return previous word in (reversed) lex order.
// Start with zero and use 2**n calls
// generate 2**n bit-subsets of length n:
// e.g. for n==4:
//  ....  =  0
//  ...1  =  1
//  ..11  =  3
//  ..1.  =  2
//  .1.1  =  5
//  .111  =  7
//  .11.  =  6
//  .1..  =  4
//  1..1  =  9
//  1.11  = 11
//  1.1.  = 10
//  11.1  = 13
//  1111  = 15
//  111.  = 14
//  11..  = 12
//  1...  =  8
//
{
    ulong x0 = x & -x;
    if ( x & (x0<<1) )  x ^= x0;
    else
    {
        x0 ^= (x0<<1);
        x ^= x0;
        x |= 1;
    }
    return x;
}
// -------------------------


inline ulong negidx2lexrev(ulong k)
//
//   k:  idx2revlex(k)
//   0:  .....
//   1:  ....1
//   2:  ...11
//   3:  ...1.
//   4:  ..1.1
//   5:  ..111
//   6:  ..11.
//   7:  ..1..
//   8:  .1..1
//   9:  .1.11
//  10:  .1.1.
//  11:  .11.1
//  12:  .1111
//  13:  .111.
//  14:  .11..
//  15:  .1...
//  16:  1...1
//
{
    ulong z = 0;
    ulong h = highest_bit(k);
    while ( k )
    {
        while ( 0==(h&k) )  h >>= 1;
        z ^= h;
        ++k;
        k &= h - 1;
    }

    return  z;
}
// -------------------------

inline ulong lexrev2negidx(ulong x)
// inverse of negidx2lexrev()
// todo: optimize
{
    ulong r = 0;
    while ( x )
    {
        ulong h = highest_bit(x);
        r ^= h;
        x = next_lexrev(x);
        h = highest_bit(x);
        x ^= h;
    }
    return  r;
}
// -------------------------



static inline bool is_lexrev_fixed_point(ulong x)
// Return whether x is a fixed point in the prev_lexrev() - sequence
{
    if ( x & 1 )
    {
        if ( 1==x )  return  true;
        else         return  false;
    }
    else
    {
        ulong w = bit_count(x);
        if ( w != (w & -w) )  return  false;
        if ( 0==x )  return  true;
        return  0 != ( (x & -x) & w );
    }
}
// -------------------------



#endif  // !defined HAVE_BITLEX_H__
