#if !defined HAVE_BITCOMBLEX_H__
#define      HAVE_BITCOMBLEX_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitcombcolex.h"
#include "revbin.h"


static inline ulong next_lex_comb(ulong x)
//
// Return next bit-reversed lex-order combination.
//
// Let the zeros move to the lower end in the same manner
// as the ones go to the higher end in next_colex_comb()
//
// lex order:  (5, 3):  (for a 5 bit word !)
//  0  1  2   ..111
//  0  1  3   .1.11
//  0  1  4   1..11
//  0  2  3   .11.1
//  0  2  4   1.1.1
//  0  3  4   11..1
//  1  2  3   .111.
//  1  2  4   1.11.
//  1  3  4   11.1.
//  2  3  4   111..
//
// start and end combo are the same as for next_colex_comb()
//
{
    x = revbin( ~x );
    x = next_colex_comb( x );
    if ( 0!=x )  x = revbin( ~x );
    return  x;
}
// -------------------------


static inline ulong prev_lex_comb(ulong x)
// Return previous lex-order combination.
// inverse of next_lex_comb()
//
{
    x = revbin( x );
    x = next_colex_comb( x );
    x = revbin( x );
    return  x;
}
// -------------------------


static inline ulong first_rev_comb(ulong k, ulong n=BITS_PER_LONG)
{
    return  last_comb(k, n);
}
// -------------------------

static inline ulong last_rev_comb(ulong k)
{
    return  first_comb(k);
}
// -------------------------

static inline ulong next_lexrev_comb(ulong x)
// Return next bit-reversed lex-order combination.
{
    return  prev_colex_comb(x);
}
// -------------------------

static inline ulong prev_lexrev_comb(ulong x)
// Return previous bit-reversed lex-order combination.
{
    return  next_colex_comb( x );
}
// -------------------------



#endif //  !defined HAVE_BITCOMBLEX_H__
