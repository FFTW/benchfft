#if !defined HAVE_BITLOW_H__
#define      HAVE_BITLOW_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitasm.h"


static inline ulong lowest_bit_01edge(ulong x)
// return word where a all bits from  (including) the
//   lowest set bit to bit 0 are set
// return 0 if no bit is set
{
    if ( 0==x )  return 0;
    return  x^(x-1);
}
// -------------------------

static inline ulong lowest_bit_10edge(ulong x)
// return word where a all bits from (including) the
//   lowest set bit to most significant bit are set
// return 0 if no bit is set
{
    if ( 0==x )  return 0;
    x ^= (x-1);
    // here  x == lowest_bit_01edge(x);
    return  ~(x>>1);
}
// -------------------------


static inline ulong lowest_bit_idx(ulong x)
// return index of lowest bit set
// return 0 if no bit is set
{
#if defined  BITS_USE_ASM
    return  asm_bsf(x);
#else // BITS_USE_ASM

//    if ( 1>=x )  return  x-1; // 0 if 1, ~0 if 0
//    if ( 0==x )  return  0;

    ulong r = 0;
    x &= -x;
#if  BITS_PER_LONG >= 64
    if ( x & 0xffffffff00000000 )  r += 32;
    if ( x & 0xffff0000ffff0000 )  r += 16;
    if ( x & 0xff00ff00ff00ff00 )  r += 8;
    if ( x & 0xf0f0f0f0f0f0f0f0 )  r += 4;
    if ( x & 0xcccccccccccccccc )  r += 2;
    if ( x & 0xaaaaaaaaaaaaaaaa )  r += 1;
#else // BITS_PER_LONG >= 64
    if ( x & 0xffff0000 )  r += 16;
    if ( x & 0xff00ff00 )  r += 8;
    if ( x & 0xf0f0f0f0 )  r += 4;
    if ( x & 0xcccccccc )  r += 2;
    if ( x & 0xaaaaaaaa )  r += 1;
#endif // BITS_PER_LONG >= 64

    return r;
#endif // BITS_USE_ASM
}
// -------------------------


static inline ulong lowest_bit(ulong x)
// return word where only the lowest set bit in x is set
// return 0 if no bit is set
{
//    if ( 0==x )  return 0;
//    return  ((x^(x-1)) >> 1) + 1;

//    return  (x & (x-1)) ^ x;

    return  x & -x;  // use: -x == ~x + 1
}
// -------------------------

static inline ulong lowest_zero(ulong x)
// return word where only the lowest unset bit in x is set
// return 0 if all bits are set
{
//    return  (x ^ (x+1)) & ~x;
    x = ~x;
    return  x & -x;
}
// -------------------------

static inline ulong lowest_block(ulong x)
//
// x   = *****011100
// l   = 00000000100
// y   = *****100000
// x^y = 00000111100
// ret = 00000011100
//
{
    ulong l = x & -x;  // lowest bit
    ulong y = x + l;
    x ^= y;
    return  x & (x>>1);
}
// -------------------------

static inline ulong delete_lowest_bit(ulong x)
// return word were the lowest bit set in x is unset
// returns 0 for input == 0
{
    return  x & (x-1);
}
// -------------------------

static inline ulong set_lowest_zero(ulong x)
// return word were the lowest unset bit in x is set
// returns ~0 for input == ~0
{
    return  x | (x+1);
}
// -------------------------


static inline ulong low_zeros(ulong x)
// return word where all the (low end) zeros
// are set
// e.g.  01011000 --> 00000111
// returns 0 if all bits are set
{
    if ( 0==x )  return ~0UL;

    return (((x-1)^x) >> 1);
}
// -------------------------

static inline ulong low_bits(ulong x)
// return word where all the (low end) ones
// are set
// e.g.  01011011 --> 00000011
// returns 0 if lowest bit is zero:
//       10110110 --> 0
{
    if ( ~0UL==x )  return ~0UL;

    return (((x+1)^x) >> 1);
}
// -------------------------


#endif  // !defined HAVE_BITLOW_H__
