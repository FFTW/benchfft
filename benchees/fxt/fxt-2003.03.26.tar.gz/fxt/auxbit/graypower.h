#if !defined  HAVE_GRAYPOWER_H__
#define       HAVE_GRAYPOWER_H__


#include "fxttypes.h"
#include "bitsperlong.h"


inline ulong gray_pow(ulong x, ulong e)
// Return (gray_code**e)(x)
// gray_pow(x, 1) == gray_code(x)
// gray_pow(x, BITS_PER_LONG-1) == inverse_gray_code(x)
{
    e &= (BITS_PER_LONG-1);  // modulo BITS_PER_LONG
    ulong s = 1;
    while ( e )
    {
        if ( e & 1 )  x ^= x >> s;  // gray ** s
        s <<= 1;
        e >>= 1;
    }
    return  x;
}
// -------------------------

inline ulong inverse_gray_pow(ulong x, ulong e)
// Return (inverse_gray_code**(e))(x)
//   == (gray_code**(-e))(x)
// inverse_gray_pow(x, 1) == inverse_gray_code(x)
// gray_pow(x, BITS_PER_LONG-1) == gray_code(x)
{
    return  gray_pow(x, -e);
}
// -------------------------



inline ulong green_pow(ulong x, ulong e)
// Return (green_code**e)(x)
// green_pow(x, 1) == green_code(x)
// green_pow(x, BITS_PER_LONG-1) == inverse_green_code(x)
{
    e &= (BITS_PER_LONG-1);  // modulo BITS_PER_LONG
    ulong s = 1;
    while ( e )
    {
        if ( e & 1 )  x ^= x << s;  // green ** s
        s <<= 1;
        e >>= 1;
    }
    return  x;
}
// -------------------------


inline ulong inverse_green_pow(ulong x, ulong e)
// Return (inverse_green_code**(e))(x)
//   == (green_code**(-e))(x)
// inverse_green_pow(x, 1) == inverse_green_code(x)
// green_pow(x, BITS_PER_LONG-1) == green_code(x)
{
    return  green_pow(x, -e);
}
// -------------------------


#endif  // !defined HAVE_GRAYPOWER_H__
