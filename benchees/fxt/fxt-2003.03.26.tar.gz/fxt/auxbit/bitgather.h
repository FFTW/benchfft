#if !defined  HAVE_BITGATHER_H__
#define       HAVE_BITGATHER_H__

#include "fxttypes.h"
#include "bitsperlong.h"


inline ulong bit_gather(ulong w, ulong m)
// Return  word with bits of w collected as indicated by m:
// Example:
//  w = ABCDEFGH
//  m = 00101100
//  ==> 00000CEF
{
    ulong z = 0;
    ulong b = 1;
    while ( m )
    {
        ulong i = m & -m;  // lowest bit
        m ^= i;
        z += (i&w ? b : 0);
        b <<= 1;
    }
    return  z;
}
// -------------------------

inline ulong bit_scatter(ulong w, ulong m)
// Return  word with bits of w distributed as indicated by m:
// Example:
//  w = 00000CEF
//  m = 00101100
//  ==> ABCDEFGH
// This is the 'inverse' of bit_gather()
{
    ulong z = 0;
    ulong b = 1;
    while ( m )
    {
        ulong i = m & -m;  // lowest bit
        m ^= i;
        z += (b&w ? i : 0);
        b <<= 1;
    }
    return  z;
}
// -------------------------



#endif  // !defined HAVE_BITGATHER_H__
