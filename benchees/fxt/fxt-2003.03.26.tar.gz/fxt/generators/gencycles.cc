
#include "fxt.h"
#include "fxtauxlazy.h"

#include "jjassert.h"

#include "fxtio.h"
#include "fxtiomanip.h"

#include <cstdlib> // atol()


static char *tt = 0;
#define  TT(x)  { tt = "// " #x "  where n="; cerr << tt << n << endl;  x; }
#define  PP()   { cerr << tt << n << endl; }


int
main(int argc, char **argv)
{
    ulong n = 32;
    if ( argc>1 )  n = atol(argv[1]);
    ulong ldn = ld(n);
    if ( (long)n<0 )
    {
        ldn = -(long)n;
        n = 1UL<<ldn;
    }
    cout << "ldn=" << ldn << "  n=" << n << endl;

    ulong nc = 0,  nr = 2;
    if ( argc>2 )
    {
        nr = atol(argv[2]);
        nc = n / nr;
        jjassert( nr*nc == n );
    }

    ulong *x = new ulong[n];  // aux
    ulong *f = new ulong[n];  // permuted indices
    set_seq(f, n);
    copy(f, x, n);

    // ++++++++++ apply some permutation: ++++++++++

//    TT( gray_rev_permute(f, n); );
//    TT( inverse_green_rev_permute(f, n); );
//    TT( gray_rev_permute(f, n); );
    TT( gray_permute(f, n); );
//    TT( xor_permute(f, n, 1); );
//    TT( inverse_green_permute(f, n); );
//    TT( revbin_permute(f, n); );


    // ++++++++++ study permutation: ++++++++++

    for (ulong k=0; k<n; ++k )
    {
//        if ( k==f[k] )
        {
            cout << setw(5) << k << ": ";
            print_bin_nn(" ", k, ldn, ".1");
            cout << "  " << setw(5) << f[k];
            print_bin_nn(" =", f[k], ldn, ".1");
        }
        if ( k==f[k] ) cout << " * ";
//        if ( lowest_zero(k-1)==lowest_bit(k) )  cout << " # ";
        cout << endl;
    }

    jjassert( is_valid_permutation(f, n) );

    cycles cc(n);
    cc.make_cycles(f, n);
    cc.print();
//    cc.print( 1 );  // only info
//    cc.print_leaders();
//    cout << cc.test_equivalent(f, n) << endl;
    jjassert( cc.is_equivalent(f, n) );


//    //        01234567
//    char strf[] = "ABadCafe";
//    char strg[10];
//    ulong x[] = {7, 6, 3, 2, 5, 1, 0, 4};
//    jjassert( is_valid_permutation(x, 8) );
//    apply(x, strf, strg, 8);
//    strg[8] = 0;
//    cout << strf << endl;
//    cout << strg << endl;
//    ulong nf = print_cycles(x, 8);
//    cout << " nf = " << nf << endl;

//    cout << endl;
//    for (ulong k=0; k<n; ++k )  cout << f[k] << ", ";  cout << endl;
//    ulong nf = print_cycles(f, n);
//    cout << " nf = " << nf << endl;
//
//    make_inverse(f, n);
//    cout << endl;
//    for (ulong k=0; k<n; ++k )  cout << f[k] << ", ";  cout << endl;
//    print_cycles(f, n);


//    cc.print_leaders();
//
//    {
//        ulong k=0, len=0, ct = 0;
//        while ( (len=cc.next_cycle(k)) )
//        {
//            cout << "#" << setw(3) << k << ":  ";
//            ulong mi = cc.get(k);
//            cout << "   [" << setw(5) << mi << "]  ";
//            print_bin_nn(mi, ldn, ".1");
//            cout << endl;
//
//            k += len-1;
//            ++ct;
//        }
//    }

    // ++++++++++ print code: ++++++++++
    cc.print_code("permute", n, 1);
    cc.invert();
    cc.print_code("inverse_zulp", n, 1);


    return 0;
}
// -------------------------
