
#include "fxttypes.h"
#include "jjassert.h"
#include "fxtiomanip.h"

//using namespace std;


ulong wct = 1;  // weight (bit count)

inline void eat_comma()
{
    char c;
    cin >> c;
    ++wct;
    jjassert( c==',' );
}
// -------------------------

bool eat_comment_line(bool printq)
{
    char c;
    c = cin.peek();
    if ( c=='#' )
    {
        char str[4096];
        cin.getline(str, 4096);

        if ( printq )
        {
            cout << "// ";
            cout << (str+1);
            cout << endl;
        }

        return true;
    }

    return false;
}
// -------------------------


int main(int argc, char **argv)
{
//    cerr << "argc=" << argc << endl;
//    for (int i=0; i<argc; ++i)  cerr << "arg[" << i << "] =" << argv[i] << endl;

    jjassert( argc-1==2 );
    const char *hn0 = argv[1];  // ARGV[1] := capitalized haeder name
    const char *hn = "PRIMPOLY";
    cout << "#if !defined  HAVE_" << hn0 << hn << "_H__" << endl;
    cout << "#define       HAVE_" << hn0 << hn << "_H__" << endl;
    cout << endl;
    cout << "// GENERATED FILE" << endl;
    cout << endl;

    cout << "#include \"fxttypes.h\"" << endl;
    cout << "#include \"bitsperlong.h\"" << endl;
    cout << endl;

    cout << "extern ";
    cout << "const ulong " << argv[2]   // ARGV[2] := array name
         << "_primpoly[]=\n";
    while ( eat_comment_line(true) )  {;}  // swallow comments, echo into output
    cout << "{\n";
    cout << "//  hex_val,  // ==dec_val  (deg)  [weight]" << endl;
    cout << " 0x1,         // 1  (0)  [1]" << endl;
    cout << " 0x3,         // 3  (1)  [2]" << endl;

    for (ulong k=2;  ;++k)
    {
        while ( eat_comment_line(false) )  {;}  // swallow comments silently

        wct = 1;

        if ( k==32 )  cout << "#if  ( BITS_PER_LONG > 32 )" << endl;
        if ( k==64 )  cout << "#if 0" << endl;
        ulong deg;
        cin >> deg;
        if ( 0==deg )  break;
        eat_comma();

        unsigned long long w = 1ULL << deg;
//        cout << "0UL";
        while ( 1 )
        {
            ulong x;
            cin >> x;
//            cout << " | (1UL<<" << x <<")";
            w |= (1ULL << x );
            if ( 0==x )  break;
            eat_comma();
        }
        cout << " 0x" << hex << w << dec << "UL";
        cout << ", ";
        cout << "  // ==" << w;
        cout << "  (" << deg << ")";
        cout << "  [" << wct << "]";
        cout << endl;

//        if ( (k%32)==31 )  cout << endl;

        // for minweight primpoly up to here a single (1UL<<deg) is missing
//        if ( k==90 )  break;
        if ( k==64 )  break;
    }

    cout << "#endif // 0" << endl;
    cout << "#endif  // ( BITS_PER_LONG > 32 )" << endl;
    cout << "};" << endl;
    cout << "// -------------------------" << endl;

    cout << endl;
    cout << "#endif //  !defined  HAVE_" << hn0 << hn << "_H__" << endl;
}
// -------------------------
