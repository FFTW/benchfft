#!/usr/bin/perl -w

$debug = 0 ;

print '#if !defined  HAVE_MINWEIGHTLHCARULE_H__'."\n";
print '#define       HAVE_MINWEIGHTLHCARULE_H__'."\n";
print "\n";
print '// generated file'."\n";
print "\n";
print "#include \"fxttypes.h\"\n";
print "#include \"bitsperlong.h\"\n";
print "\n";
print '#define R1(n,s1)     (1UL<<s1)'."\n";
print '#define R2(n,s1,s2)  (1UL<<s1) | (1UL<<s2)'."\n";

print 'extern const ulong minweight_lhca_rule[]='."\n";
print '// LHCA rules of minimum weight that lead to maximal period.'."\n";
print '{'."\n";
print "      0,  // (empty)\n";
while ( <STDIN> )
{
    /^\#/  &&  next;  ## skip comments

    chomp;
    $line = $_;

    $s2=-999;

    if ( $line =~ /^( *[0-9]+): ([0-9]+) ([0-9]+)$/)
    {
        $n=$1;
        $s1=$2;
        $s2=$3;
    }
    else
    {
        unless ( $line =~ /^( *[0-9]+): ([0-9]+)$/)
        {
            print ' ***** '," [[$_]]\n";
            die 'barf!';
        }

        $n=$1;
        $s1=$2;
    }

    if ( $n==32+1 )  { print "#if  ( BITS_PER_LONG > 32 )"."\n"; }
    if ( $n==64+1 )  { print "#if 0"."\n"; }

    $debug  &&  print "  n=[$n]  s1=[$s1]  s2=[$s2] \n";

    $s1 = $s1 - 1;
    $s2 = $s2 - 1;
    if ( $s2>0 )  { print " R2($n,  $s1, $s2),"; }
    else          { print " R1($n,  $s1),"; }
    print "\n";

#    if ( ($n == 17) ) { die 'DEBUG'; }
}
print "#endif // 0"."\n";
print "#endif  // ( BITS_PER_LONG > 32 )"."\n";
print "      0  // (end)\n";
print '};'."\n";
print '// -------------------------'."\n";

print '#undef R1'."\n";
print '#undef R2'."\n";

print "\n";

print '#endif //  !defined  HAVE_MINWEIGHTLHCARULE_H__'."\n";


exit 0;
##############################
