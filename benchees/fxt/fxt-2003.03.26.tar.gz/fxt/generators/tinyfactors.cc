

#include "fxttypes.h"
#include "bitsperlong.h"
#include "fxtio.h"
#include "fxtiomanip.h"
#include "fxtauxlazy.h"


int
main()
{
    cout << "const unsigned long tiny_factors_tab[] =" <<endl;
    cout << "{" << endl;

    cout.setf(ios::showbase);

    unsigned long long f;
    unsigned int x, d, m = 64;
    for (x=0; x<m; ++x)
    {
        if ( x==32 )  cout << "#if  ( BITS_PER_LONG > 32 ) " << endl;
        f = 0;
        for (d=1; d<=x; ++d)  if ( (x/d)*d == x )  f |= (1ULL << d);

        cout << "    "<< hex << setw(18) << f << dec;
        if ( x!=m-1 )  cout << ",";

        cout << "  // x = " << x << ": ";

        for (d=1; d<=x; ++d)  if ( (x/d)*d == x )  cout << " " << d;
        if ( x<8 )
        {
            cout << "   ( bits: ";
            print_bin_nn(f, 8);
            cout << ")";
        }

        cout << endl;
    }

    cout << "#endif // ( BITS_PER_LONG > 32 ) " << endl;
    cout << "};" << endl;
    cout << endl;
    return 0;
}
