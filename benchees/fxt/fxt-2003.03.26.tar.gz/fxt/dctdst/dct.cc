
#include "fxt.h"

#include "jjassert.h"

#include <cmath>  // sqrt()

#error 'to be implemented  ;-) '

void
dct(double *f, ulong ldn, double *tmp/*=0*/)
// basis: cos((k+0.5)*(i+0.5)*M_PI/n)
// ldn := base-2 logarithm of the array length
// tmp := (optional) pointer to scratch space
{
    jjassert(0);
}
// -------------------------

void
dct_basefunc(double *f, ulong n, ulong k)
{
    double vv = 1.0;
    for (ulong i=0; i<n; ++i)  f[i] = vv * cos( M_PI * (k+0.5) * (i+0.5) / n );
}
// -------------------------
