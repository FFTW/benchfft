

#include "fxttypes.h"
#include "sincos.h"

#include <cmath> // M_PI, M_SQRT1_2


void
cos_rot(const double *x, double *y, ulong n)
// auxiliary routine for dcth() and dct4()
// x and y may be identical
// self-inverse
{
    ulong nh = (n>>1);
    y[0]  = x[0];
    y[nh] = x[nh];
    double phi0 = M_PI/(2*n);
    double phi = 0.0;
    for (ulong k=1,j=n-1;  k<j;  ++k,--j)
    {
        phi += phi0;
        double c, s;
        SinCos(phi, &s, &c);
        // cos(x) +- sin(x) == sqrt(2) * cos( Pi/4 -+ x )
        double p = (c+s) * M_SQRT1_2;
        double m = (c-s) * M_SQRT1_2;
        double xk = x[k],  xj = x[j];
        y[k] = m * xk + p * xj;
        y[j] = p * xk - m * xj;
    }
}
// -------------------------
