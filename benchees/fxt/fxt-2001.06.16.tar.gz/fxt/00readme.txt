
fxt.lsm       short description

00legal.txt   legal notice

doc/*         automatically generated docs

fxt.h         function declarations


======== DESCRIPTION: ========
  fxt is a library package (coming as C++ source code)
  containing code for:

  1) --- FAST FOURIER TRANSFORMS (FFTs): ---
  Hartley transform based fft.
  Decimation in time/frequency, radix 2 & 4.
  Split radix FFT (DIT and DIF).
  Matrix (aka four-step) FFT.
  Special versions for zero padded data.
  Various versions of realfft (and inverse).
  Arbitrary length FFT based on chirp filter.
  2...5 dimensional FFT
  Fractional FT (based on chirp filter).
  Weighted FFT

  2) --- FAST HARTLEY TRANSFORM (FHTs): ---
  Split radix FHT (DIF and DIT)
  2-dimensional hartley transform

  3) --- NUMBER THEORETIC TRANSFORMS (NTTs): ---
  Radix 2/4, decimation in freq./time.
  Exact integer (modular-)convolution.

  4) --- FAST WALSH TRANSFORM ---
  Radix 2 decimation in freq./time:
  Walsh-Kronecker (wak), Walsh-Paley (pal) and
  Walsh-Kaczmarz (wal, sequency ordered).
  Dyadic convolution via walsh transform.

  5) --- CONVOLUTION, CORRELATION, POWER SPECTRUM: ---
  Cyclic and linear convolution and auto convolution
  for real and complex data.
  Correlation (and auto-corr.) for real and complex data.
  Power spectrum.
  Weighted convolution; negacyclic and right angle convolution.

  6) --- FAST HAAR TRANSFORM: ---
  Haar transform and its inverse inverse haar transform.
  Inplace version of Haar transform.
  Integer-to-integer version of Haar transform

  7) --- FAST WAVELET TRANSFORM: ---
  Fast transforms and inverses: Haar, Daubechies

  8) --- MASS STORAGE CONVOLUTION: ---
  Convolutions with size limited only by disk space.

  9) --- FAST MULTIPLICATION ROUTINES: ---
  fft-multiplication and mass storage multiplication
  for high precision ('bignum') libraries

  10) --- SINE AND COSINE TRANSFORM ---

  11) --- FAST Z-TRANSFORM ---
  based on chirp-filter

  12) --- MISC UTILS: ---
  Auxiliary routines for 1dim arrays in auxil/
  Auxiliary routines for 2dim arrays in auxil2d/
  Bit manipulation inlines in auxbit/

Keywords:
  fourier transform, fft, real fft, weighted fft
  hartley transform, fht, 2dim transform, ndim transform
  numbertheoretic transform, ntt, integer convolution
  walsh transform, haar transform, wavelets, wavelet transform
  convolution, negacyclic convolution, right angle convolution
  correlation, spectrum, mass storage fft, multiplication
