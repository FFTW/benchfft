
#include "fxt.h"

// tuning parameter:
#define  FHT_AUTO_CONVOLUTION_VERSION  0  // 0 (default) or 1
//
#if  ( FHT_AUTO_CONVOLUTION_VERSION==0 )
#warning 'FYI fht_auto_convolution(double *, ulong) using revbin_permuted_core'
#else
#warning 'FYI fht_auto_convolution(double *, ulong) using normal core'
#endif


static inline  void
fht_sqr(double &xi, double &xj,
        double v) // jjkeep
// xi <-- v*( 2*xi*xj + xi*xi - xj*xj )
// xj <-- v*( 2*xi*xj - xi*xi + xj*xj )
// auxiliary routine for fht_auto_convolution_core()
{
    double a = xi,  b = xj,  s1 = (a + b) * (a - b);
    a *= b;
    a += a;
    xi = (a+s1) * v;
    xj = (a-s1) * v;
}
// ================


void
fht_auto_convolution(double *f, ulong ldn)
// (cyclic, real) self convolution:  f[] :=  f[] (*) f[]
// ldn := base-2 logarithm of the array length
{
#if  ( FHT_AUTO_CONVOLUTION_VERSION==0 )
    dif_fht_core(f, ldn);
    fht_auto_convolution_revbin_permuted_core(f, ldn);
    dit_fht_core(f, ldn);
#else
    fht(f,ldn);
    fht_auto_convolution_core(f,ldn);
    fht(f,ldn);
#endif
}
// ================ end ==============


void
fht_auto_convolution0(double *f, ulong ldn)
// (linear, real) self convolution:  f[] :=  f[] (*0) f[]
// ldn := base-2 logarithm of the array length
// version for zero padded data:
//   f[k] == 0 for k=n/2 ... n-1
// n = 2**ldn  must be >=2
{
//    if ( ldn<=1 )
//    {
//        fr[0] *= fr[0];
//        return;
//    }

    fht0(f,ldn);
    fht_auto_convolution_core(f,ldn);
    fht(f,ldn);
}
// ================ end ==============


void
fht_auto_convolution_core(double *f, ulong ldn,
                          double v/*=0.0*/)  // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
{
    const ulong  n  = (1<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    f[0] *= (v * f[0]);

    if ( n>=2 )
    {
        const ulong  nh = n/2;
        f[nh] *= (v * f[nh]);

        v *= 0.5;
        for (ulong i=1,j=n-1; i<nh; i++,j--)
        {
            fht_sqr(f[i], f[j], v);
        }
    }
}
// ================ end ==============


void
fht_auto_convolution_revbin_permuted_core(double *f, ulong ldn,
                                    double v/*=0.0*/)  // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
//
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
//
// as fht_auto_convolution_core() but with data access in revbin order
// i.e. this version avoids two calls to revbin_permute()
{
    const ulong n = (1<<ldn);

    if ( v==0.0 )  v = 1.0/n;
    f[0] *= (v * f[0]);  // == [0]
    if ( n>=2 )  f[1] *= (v * f[1]); // == [nh]

    if ( n<4 )  return;

    v *= 0.5;
    const ulong nh = (n>>1);

    ulong r=nh, rm=n-1;
    fht_sqr(f[r], f[rm], v);

    ulong k=2, km=n-2;
    while ( k<nh  )
    {
        // k even:
        rm -= nh;
        ulong tr = r;
        r^=nh;  for (ulong m=(nh>>1); !((r^=m)&m); m>>=1)  {;}
        fht_sqr(f[r], f[rm], v);
        --km;
        ++k;

        // k odd:
        rm += (tr-r);
        r += nh;
        fht_sqr(f[r], f[rm], v);
        --km;
        ++k;
    }
}
//============== end =================


//void
//fht_auto_convolution0_2proc(double *f, ulong ldn)
//{
//    const ulong n = (1<<ldn);
//    const ulong nh = (n>>1);
//    ulong ldnh = ldn-1;
//
//    double *g = f+nh;
//    copy(f,g,nh);
//
//    // ----- processor 1:  cyclic convolution
//    fht_auto_convolution(f,ldnh);
//
//    // ----- processor 2:  negacyclic convolution
//    fht_negacyclic_auto_convolution(g,ldnh);
//
//    sumdiff05(f,g,nh);
//}
////============= end ============

