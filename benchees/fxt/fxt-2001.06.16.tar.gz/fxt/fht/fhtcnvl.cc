
#include "fxt.h"


// tuning parameter:
#define  FHT_CONVOLUTION_VERSION  0  // 0 (default) or 1
//
#if  ( FHT_CONVOLUTION_VERSION==0 )
#warning 'FYI fht_convolution(double *, ulong) using revbin_permuted_core'
#else
#warning 'FYI fht_convolution(double *, ulong) using normal core'
#endif

//#define PARANOIA 1
#ifdef PARANOIA
#include "jjassert.h"
#warning 'FYI: we have PARANOIA'
#endif


static inline  void
fht_mul(double xi, double xj,
        double &yi, double &yj,
        double v) // jjkeep
// auxiliary routine for fht_convolution_core()
{
    double h1p = xi,  h1m = xj;
    double s1 = h1p + h1m,  d1 = h1p - h1m;
    double h2p = yi,  h2m = yj;
    yi = (h2p * s1 + h2m * d1) * v;
    yj = (h2m * s1 - h2p * d1) * v;
}
//==================


void
fht_convolution(double *f, double *g, ulong ldn)
// (cyclic, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
// f and g must not overlap
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

#if  ( FHT_CONVOLUTION_VERSION==0 )
    dif_fht_core(f, ldn);
    dif_fht_core(g, ldn);
    fht_convolution_revbin_permuted_core(f, g, ldn);
    dit_fht_core(g, ldn);
#else
    fht(f, ldn);
    fht(g, ldn);
    fht_convolution_core(f, g, ldn);
    fht(g, ldn);
#endif
}
//================== end =================


void
fht_convolution0(double *f, double *g, ulong ldn)
// (linear, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
// f and g must not overlap
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n = 2**ldn  must be >=2
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    fht0(f, ldn);
    fht0(g, ldn);
    fht_convolution_core(f, g, ldn);
    fht(g, ldn);
}
//================== end =================


void
fht_convolution_core(double *f, double *g, ulong ldn,
                     double v/*=0.0*/) // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
// n = 2**ldn  must be >=2
{
    const ulong n = (1<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    g[0]  *=  (v * f[0]);
    const ulong  nh = n/2;

//    if ( nh>0 )
    {
        g[nh] *= (v * f[nh]);
        v *= 0.5;
        for (ulong i=1,j=n-1; i<j; i++,j--)
        {
            fht_mul(f[i], f[j], g[i], g[j], v);
        }
    }
}
//================== end =================


void
fht_convolution_revbin_permuted_core(double *f, double *g, ulong ldn,
                               double v/*=0.0*/)  // jjkeep
// auxiliary routine for the computation of convolutions
//   via Fast Hartley Transforms
//
// ldn := base-2 logarithm of the array length
// v!=0.0 chooses alternative normalization
//
// as fht_convolution_core() but with data access in revbin order
// i.e. this version avoids two calls to revbin_permute()
//
{
    const ulong n = (1<<ldn);

    if ( v==0.0 )  v = 1.0/n;
    f[0] *= (v * f[0]);  // == [0]
    if ( n>=2 )  f[1] *= (v * f[1]); // 1 == revbin(nh)

    if ( n<4 )  return;

    v *= 0.5;
    const ulong nh = (n>>1);

    ulong r=nh, rm=n-1;
    fht_mul(f[r], f[rm], g[r], g[rm], v);

    ulong k=2, km=n-2;
    while ( k<nh  )
    {
        // k even:
        rm -= nh;
        ulong tr = r;
        r^=nh;  for (ulong m=(nh>>1); !((r^=m)&m); m>>=1)  {;}
        fht_mul(f[r], f[rm], g[r], g[rm], v);
        --km;
        ++k;

        // k odd:
        rm += (tr-r);
        r += nh;
        fht_mul(f[r], f[rm], g[r], g[rm], v);
        --km;
        ++k;
    }
}
//============== end =================
