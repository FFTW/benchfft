
#include "fxt.h"
#include "misc.h"
#include "cmult.h"
#include "sumdiff.h"

//#define PARANOIA 1
#ifdef PARANOIA
#include "jjassert.h"
#warning 'FYI: we have PARANOIA'
#endif


void
fht_correlation0(double *f, double *g, ulong ldn)
// compute (real, linear) correlation of f[], g[]
// result is in g[]
// ldn := base-2 logarithm of the array length
// version for zero padded data:
//   f[k],g[k] == 0 for k=n/2 ... n-1
// n = 2**ldn  must be >=2
// f and g must not overlap
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    fht0(f, ldn);
    fht0(g, ldn);

    g[0]  *= f[0] * 4.0;
    const ulong n  = (1<<ldn);
    const ulong nh = (n>>1);
//    if ( nh>0 )
    {
        g[nh] *= f[nh] * 4.0;
        for (ulong i=1,j=n-1;  i<j;  ++i,--j)
        {
            double t1, t2;
            sumdiff(f[i], f[j], t1, t2);
            double x1, x2;
            sumdiff(g[i], g[j], x1, x2);
            cmult(t1, -t2, x1, x2);
            sumdiff(x1, x2, g[i], g[j]);
        }
    }

    fht(g, ldn);
    multiply(g, n, 0.25/n);
}
//=============== end ===============


void
fht_auto_correlation0(double *f, ulong ldn)
// compute (real, linear) self correlation of f[]
// ldn := base-2 logarithm of the array length
// version for zero padded data:
//   f[k] == 0 for k=n/2 ... n-1
// n = 2**ldn  must be >=2
{
    fht0(f, ldn);

    f[0]  *= f[0] * 4.0;
    const ulong  n  = (1<<ldn);
    const ulong  nh = (n>>1);
//    if ( nh>0 )
    {
        f[nh] *= f[nh] * 4.0;
        for (ulong i=1,j=n-1;  i<j;  ++i,--j)
        {
            double t1, t2;
            sumdiff(f[i], f[j], t1, t2);
            t1 = t1 * t1 + t2 * t2;
            f[i] = f[j] = t1;
        }
    }

    fht(f, ldn);
    multiply(f, n, 0.25/n);
}
//============ end ==============

