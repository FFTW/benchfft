
#include "bits2pow.h" // ld()
#include "fxt.h"


#define FHT(f,ldn)  fht(f,ldn)


void
row_column_fht(double *f, ulong nr, ulong nc)
// fht over rows and columns
// this is _not_ a two dimensional fht
// nr := number of rows
// nc := number of columns
{
    ulong n = nr*nc;

    // fht over rows:
    ulong ldc = ld(nc);
    for (ulong k=0; k<n; k+=nc)  FHT(f+k, ldc);

    double *w = new double[nr];

    // fht over columns:
    for (ulong k=0; k<nc; k++)  skip_fht(f+k, nr, nc, w);
    
    delete [] w;
}
// =============== end ===========


void
y_transform(double *f, ulong nr, ulong nc)
// transforms row-column-fht to 2dim fht
// self-inverse
// nr := number of rows
// nc := number of columns
{
    ulong rh = nr/2;
    if ( nr&1 )  rh++;
    
    ulong ch = nc/2;
    if ( nc&1 )  ch++;

    ulong n = nr*nc;
    for (ulong tr=1, ctr=nc; tr<rh; tr++,ctr+=nc) // ctr=nc*tr
    {
        // jjnote: use array style code for inner loop
        double *pa = f + ctr;
        double *pb = pa + nc;
        double *pc = f + n - ctr;
        double *pd = pc + nc;
        for (ulong tc=1; tc<ch; tc++)
        {
            pa++;
            pb--;
            pc++;
            pd--;
            double e = (*pa + *pd - *pb - *pc) * 0.5;
            *pa -= e;
            *pb += e;
            *pc += e;
            *pd -= e;
        }
    }
}
//===========================================


void
twodim_fht(double *f, ulong nr, ulong nc)
// two dimensional fast hartley transform
// nr := number of rows
// nc := number of columns
{
    row_column_fht(f, nr, nc);
    y_transform(f, nr, nc);
}
// =============== end ===========
