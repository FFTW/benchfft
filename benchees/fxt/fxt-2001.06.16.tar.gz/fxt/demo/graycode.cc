
#include "graycode.h"

#include "printbin.h"
#include "fxttypes.h"

#include <iostream.h>


int
main()
{
    cout << "       v            gray_code(v)     inverse_gray_code(v) " << endl;
    for (ulong v=0; v<128; ++v)
    {
        print_bin_nn(v, 8);
        cout << " = ";
        cout.width(3); cout << v;
        cout << "     ";

        ulong g = gray_code(v);
        cout.width(3); cout << g;
        cout << " = ";
        print_bin_nn(g, 8);
        cout << "     ";

        ulong i = inverse_gray_code(v);
        print_bin_nn(i, 8);
        cout << " = ";
        cout.width(3); cout << i;

        cout << "   P= ";
        cout << parity(v);
        cout << endl;
    }
}
// --------------------------
