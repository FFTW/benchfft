
#include "bitarray.h"

#include <iostream.h>

#define  PRINT_DO(x) \
 ba.##x; \
 cout << "\n" << #x << " ==>" << endl; \
 ba.dump_bits();

#define  PRINT_VAL(x) \
 { ulong t = ba.##x; \
  cout << "\n" << #x << " ==> " << t << endl; }

#define  PRINT_DO_VAL(x) \
 { ulong t = ba.##x; \
  cout << "\n" << #x << " ==> " << t << endl; \
  ba.dump_bits(); }

int
main()
{
    bitarray ba(43);
    ba.dump();

    PRINT_DO( set(12) );
    PRINT_DO( set(13) );

    PRINT_DO( set(33) );

    PRINT_VAL( next_set_idx(13) );
    PRINT_VAL( next_set_idx(14) );
    PRINT_VAL( next_set_idx(999) );

    PRINT_VAL( test(13) );
    PRINT_VAL( test(14) );
    PRINT_VAL( test(999) );

    PRINT_DO_VAL( test_set(24) );
    PRINT_DO_VAL( test_clear(24) );
    PRINT_DO_VAL( test_change(24) );

    return 0;
}
// --------------------------
