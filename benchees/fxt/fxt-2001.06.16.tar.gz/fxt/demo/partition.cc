
#include "partition.h"
#include "copy.h" // fill_seq()
#include "jjassert.h"
#include "fxttypes.h"

#include <iostream.h>


int
main(int argc, char **argv)
{
//    ulong pv[] = {2, 3, 5, 7, 13, 17, 19, 31, 61, 89, 107, 127, 521, 607, 1279,
//    2203, 2281, 3217, 4253, 4423, 9689, 9941, 11213, 19937, 21701, 23209, 
//    44497, 86243, 110503, 132049, 216091, 756839, 859433, 1257787, 1398269,
//    2976221};
//    ulong n = sizeof(pv)/sizeof(ulong);

    ulong n = 70;
    ulong *pv = new ulong[n];
    fill_seq(pv, n, (ulong)1, (ulong)1);

    ulong *pc = new ulong[n];
    for (ulong j=1; j<7; ++j)
    {
        ulong x = pv[j];
        ulong len = j+1;
        cout << "----------- len=" << len << "  x=" << x << endl;

        partition pp(pv, len);

        pp.count(x);
        ulong ctp = pp.ct_;

        pp.init(x);
        ulong ii;
        ulong ct = 0, cto = 0, ctu = 0;
        while ( (ii = pp.next(pc))<len )
        {
            pp.dump(ii, pc);
            
            ++ct; // total count

            ulong zo = 1;
            for (ulong k=0; k<len; ++k)
            {
                if ( pc[k] )  zo &= pv[k];
            }
            cto += zo;  // z==1 for partition into odd parts
            if ( zo )  cout << "part. into odd parts." << endl;

            ulong zu = 1;
            for (ulong k=0; k<len; ++k)
            {
                if ( pc[k]>1 )  zu = 0;
            }
            ctu += zu;  // z==1 for partition into unequal parts
            if ( zu )  cout << "part. into unequal parts." << endl;
        }
        cout << " " << x << ":  ct=" << ct;
        cout << "  cto=" << cto << " == ctu=" << ctu;
        cout << endl;

        jjassert( ct == ctp );
//        jjassert( ctu == cto );  // for part. n into {1,2,3,...,n}

        cout << endl;
    }

    cout << endl;
    cout << "----------- # of partitions of n into 1,2,3,...,n:" << endl;
    for (ulong j=1; j<50; ++j)
    {
        ulong x = pv[j];
        ulong len = j+1;
        partition pp(pv, len);
        ulong ct = pp.count(x);
        cout << " x=" << x << ":  " << ct << endl;
    }

    return 0;
}
// -------------------------
