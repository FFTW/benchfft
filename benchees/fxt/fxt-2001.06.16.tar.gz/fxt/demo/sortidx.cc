
#include "fxttypes.h"
#include "sortidx.h"
#include "searchidx.h"
#include "copy.h" // fill_seq()
//#include "search.h"
#include "auxdouble.h"  // rnd01()
//#include "auxprint.h"
#include "jjassert.h"

#include <iostream.h>
#include <iomanip.h>
#include <stdlib.h> // atol()


void
idx_print(const char *bla, const double *f, ulong n, ulong *x)
{
    cout << endl;
    if ( bla )  cout << bla << endl;

    for (ulong k=0; k<n; ++k)
    {
        double r = f[x[k]];

        cout.width(4);
        cout.flags(ios::right);
        cout << k << ":  ";

        cout.precision(5);
        cout.flags(ios::left);
        cout.width(8);
        cout << r;

        cout << "  x[k]=" << x[k];
        cout << endl;
    }
    cout << endl;
}
//-----------------------


int
main(int argc, char **argv)
{
    ulong n = 25;
    if ( argc>1 )  n = atol(argv[1]);

    double *f = new double[n];

    ulong  *x = new ulong[n];
    fill_seq(x, n);

    for (ulong i=0; i<n; ++i)  f[i] = rnd01();
    idx_print("random values:", f, n, x);

    double v = f[n/2];


//    cout << "idx_min=" << idx_min(f, n, x) << endl;
//    cout << "idx_max=" << idx_max(f, n, x) << endl;

//    ulong p = idx_partition(f, n, x);
//    idx_print("partitioned values:", f, n, x);
//    cout << "p-idx=" << p << endl;
//    cout << "p-max=" << idx_max(f, p, x) << endl;
//    cout << "p-min=" << idx_min(f, n-p, x+p) << endl;
//    jjassert( is_idx_partitioned(f, n, x, p) );


//    idx_selection_sort(f, n, x);
    idx_quick_sort(f, n, x);
    idx_print("sorted values:", f, n, x);

    jjassert( is_idx_sorted(f, n, x) );

    cout << "searching for v=" << v << endl;
    ulong i = idx_bsearch(f, n, x, v);
    cout << "found at index " << x[i] << " == x[" << i << "]" << endl;

    return 0;
}
//-----------------------
