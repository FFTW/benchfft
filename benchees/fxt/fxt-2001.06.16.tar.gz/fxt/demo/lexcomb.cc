
#include "lexcomb.h"
#include "jjassert.h"

#include <iostream.h>
#include <iomanip.h>


int
main()
{
    ulong n = 7, k = 4;
    cout << " n = " << n << "  k = " << k << endl;
    jjassert( n>0 );
    jjassert( k>0 );
    jjassert( n>=k );

    ulong ct = 0;
    lexcomb comb(n, k);
    comb.first();

    do
    {
        cout << endl;

        ulong bits = comb.bits_;
        cout << setw(3) << bits;
        cout << "   ";

        for (long k=n-1; k>=0; --k)  cout << ((bits>>k)&1 ? '1' : '.');

        cout << "   [ " << comb.current() << " ]  ";

        cout << "  #" << setw(3) << ct;

        ++ct;
    }
    while ( comb.next() );

    cout << endl;
}
//---------------------


