
#include "fxtauxlazy.h"
#include "permutelazy.h"

#include <iostream.h>
#include <stdlib.h> // atol()


// Print And Doit:
#define  PAD( x )  { cout << "Using: " << #x << endl;  x; }

int
main(int argc, char **argv)
{
    ulong n = 32;
    if ( argc>1 )  n = atol(argv[1]);
    ulong ldn = ld(n);
    if ( (long)n<0 )
    {
        ldn = -(long)n;
        n = 1<<ldn;
    }
    cout << "ldn=" << ldn << "  n=" << n << endl;

    ulong a1 = 3;
    if ( argc>2 )  a1 = atol(argv[2]);


    ulong *y = new ulong[n];
    fill_seq(y, n);


    cout << " Apply some permutation:" << endl;
    // choose one or more ...:
//    PAD( revbin_permute(y, n) );
//    PAD( reverse(y, n) );
    PAD( gray_permute(y, n) );
//    PAD( zip(y, n) );


    cout << "Study permutation:" << endl;
    cycles cc(n);
    cc.make_cycles(y, n);
    cc.print();
//    cc.print_leaders();


    // ... and print source code:
    cc.print_code("zulp", n, 1, 0);
    cc.invert();
    cc.print_code("inverse_zulp", n, 1);

    return 0;
}
//===========================================
