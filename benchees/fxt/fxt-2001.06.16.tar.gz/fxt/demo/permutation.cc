
#include "enumerate.h"

#include <iostream.h>

int
main()
{
    int n = 4;

    enumerate_per perm(n);
    const int *x = perm.data();
    do
    {
        cout << " #"; cout.width(2); cout << perm.current() << ":   ";
        for (int i=0; i<n; ++i)  cout << x[i] << " ";
        cout << endl;
    }
    while ( perm.next() );

//    for (int i=0; i<n; ++i)  cout << x[i] << " ";
//    cout << endl;
}
//---------------------


