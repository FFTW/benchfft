
#include "bitslazy.h"
#include "inline.h"
#include "printbin.h"

#include "fxttypes.h"
#include "jjassert.h"

#include <iostream.h>
#include <stdlib.h>  // strtoul()

char *vv[] =
{
    "0000001000000",
    "0000101",
//    "00111111",
//    "00111100",
    "001111000011110111",
    "111101100011100100",
    "00000001",
    "10101010",
    "00000000" // last must be zero
};
// -------

#define  SHWBIN( func ) \
{ t=func(v); print_bin_nn(t); cout << " = " << #func << endl; }

#define  SHWDEC( func ) \
{ t=func(v); cout.width(BITS_PER_LONG); cout << t << " = " << #func << endl; }


void print_sep()
{
    cout << "----------------------------------------------------------" << endl;
}
// --------------------------

void
do_the_show(ulong v)
{
    ulong t;

    print_sep();
    cout << "word =" << endl;
    print_bin_nn(v);
    cout << "  == " << v;
    cout << endl;

//    SHWBIN( func );
//    SHWDEC( func );
//    return; // XXXXXXXXXXXXXXX

    SHWBIN( revbin );

    SHWBIN( highest_bit );
    SHWBIN( highest_bit_01edge );
    SHWBIN( highest_bit_10edge );
    SHWDEC( highest_bit_idx );

    SHWDEC( ld );

    SHWBIN( low_unset_bits );
    SHWBIN( low_set_bits );

    SHWBIN( lowest_bit );
    SHWBIN( lowest_bit_01edge );
    SHWBIN( lowest_bit_10edge );
    SHWDEC( lowest_bit_idx );


    SHWBIN( delete_lowest_bit );

    SHWBIN( lowest_unset_bit );
    SHWBIN( set_lowest_unset_bit );

    SHWBIN( highest_unset_bit );
    SHWBIN( set_highest_unset_bit );

    SHWBIN( single_bits );
    SHWBIN( single_zeroes );
    SHWBIN( single_values );

    SHWBIN( border_bits );
    SHWBIN( high_border_bits );
    SHWBIN( low_border_bits );


    SHWBIN( block_border_bits );
    SHWBIN( low_block_border_bits );
    SHWBIN( high_block_border_bits );

    SHWBIN( block_bits );
    SHWBIN( interior_bits );

    SHWDEC( bit_count );
    SHWDEC( bit_count_sparse );
    SHWDEC( bit_block_count );
    SHWDEC( bit_block_ge2_count );

    SHWDEC( 0!=contains_zero_byte );
    SHWBIN( contains_zero_byte );

    cout << endl;
}
// --------------------------


int
main()
{
    for (ulong i=0;  ; ++i)
    {
        ulong v = strtoul(vv[i], 0, 2);

        do_the_show(v);

        v = ~v;
        do_the_show(v);

        v = revbin(~v, BITS_PER_LONG);
        if ( 0==v )  break;
        do_the_show(v);

        v = ~v;
        do_the_show(v);

        print_sep();
        cout << endl;
        cout << endl;
    }
}
// --------------------------
