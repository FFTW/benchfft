
#include "bitcombination.h"
#include "bitcount.h"
#include "printbin.h"
#include "fxttypes.h"
#include "jjassert.h"

#include <iostream.h>
#include <stdlib.h>  // strtoul()


char *vv[] =
{
    "00000001",
    "00000011",
    "00000111",
    "00001111",
    "0xfff10000",
    "0xfffffff3",
    "0xffffffff",
    "00000000",

    "0x7badcafe"  // magic
};
// -------


int
main()
{
    for (ulong i=0;  ; ++i)
    {
        ulong v = strtoul(vv[i], 0, (vv[i][1]=='x' ? 16 : 2) );
        if ( 0x7badcafe==v )  break;

        cout << endl;
        print_bin("v == ",v);  cout << endl;
        ulong ct = bit_count(v);

        for (ulong j=0; j<20; ++j)
        {
//            cout.width(10); cout << v << " = ";
            print_bin("", v);
            v = next_combination(v);
            if ( v )  { jjassert( ct==bit_count(v) ); }
            else
            {
                cout << "last." << endl;
                goto there;
            }
        }
    there: ;
    }

    return 0;
}
// --------------------------
