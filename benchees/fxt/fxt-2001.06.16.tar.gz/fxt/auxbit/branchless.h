#if !defined HAVE_BRANCHLESS_H__
#define      HAVE_BRANCHLESS_H__

#include "fxttypes.h"

//<<
// Some functions that avoid if-statements.
// The upos_*() functions only work for a limited range
// in order to have the hight-bit emulate the carry flag.
// The trick is to use signed shift right to get a mask
// which == 0xfff... if a carry ocurred or zero else.
//
// With newer CPUs (e.g. AMD Athlon) that have
// conditional-move instructions the compiler
// should produce branch-free assembler.
// GCC does that (in many situations; check to be sure).
//>>


static inline ulong upos_max(ulong a, ulong b)
// return maximum(a, b)
// Both a and b must not have the most significant bit set
{
    long d = b - a;
    d &= (d>>(BITS_PER_LONG-1));
    // here: d ==
    // 0    if  b > a
    // b-a  if  a > b  (negative as signed type)
    return  b - d;
}
// --------------------------


static inline ulong upos_min(ulong a, ulong b)
// return minimum(a, b)
// Both a and b must not have the most significant bit set
{
    long d = b - a;
    d &= (d>>(BITS_PER_LONG-1));
    return  a + d;
}
// --------------------------


static inline ulong upos_abs_diff(ulong a, ulong b)
// return abs(a-b)
// Both a and b must not have the most significant bit set
{
    long d1 = b - a;
    long d2 = (d1 & (d1>>(BITS_PER_LONG-1)))<<1;
    return  d1 - d2; // == (b - d) - (a + d);
}
// --------------------------


static inline void upos_sort2(ulong &a, ulong &b)
// Set {a, b} := {minimum(a, b), maximum(a,b)}
// Both a and b must not have the most significant bit set
{
    long d = b - a;
    d &= (d>>(BITS_PER_LONG-1));
    a += d;
    b -= d;
}
// --------------------------


static inline long add_sat(ulong a, ulong b)
// Return a + b
// if result overflows, return 0xfff...
// Both a and b must not have the most significant bit set
{
    ulong x = a + b;   // bit 31 set iff overflow
    ulong y = (ulong)( ((long)x) >> (BITS_PER_LONG-1) );
    // y == 0xfff.. if overflow, else 0
    return  (x | y);
}
// --------------------------

static inline long sub_sat(ulong a, ulong b)
// Return a - b
// if result underflows, return zero
// Both a and b must not have the most significant bit set
{
    ulong x = a - b;   // bit 31 set iff underflow
    ulong y = (ulong)( ((long)x) >> (BITS_PER_LONG-1) );
    // y == 0xfff.. if underflow, else 0
    return  (x & ~y);
}
// --------------------------


static inline short add_sat16(ushort a, ushort b)
// Add two 16-bit numbers
// if result overflows, return 0xffff
{
    ulong x = a + b;   // bit 16 set iff overflow
    ulong y = x << 15; // bit 31 set iff overflow
    y = (ulong)( ((long)y) >> (BITS_PER_LONG-1) );
    // y == 0xfff.. if overflow, else 0
    return (ushort)(x | y);
}
// --------------------------

static inline short sub_sat16(ushort a, ushort b)
// Add two 16-bit numbers
// if result underflows, return zero
{
    ulong x = a - b;   // bits 16..31 set iff underflow
    ulong y = (ulong)( ((long)x) >> (BITS_PER_LONG-1) );
    // y == 0xfff.. if underflow, else 0
    return (ushort)(x & ~y);
}
// --------------------------


//static inline long abs(long x)
//// return abs(x)
//// no restriction on input range
//{
//    return  x & (long)(~0UL >> 1);
//}
//// --------------------------


static inline long max0(long x)
// return max(0, x)
// no restriction on input range
{
    return  x & (x >> (BITS_PER_LONG-1));
}
// --------------------------

static inline long min0(long x)
// return min(0, x)
// no restriction on input range
{
//    return  x & (-x>>(BITS_PER_LONG-1));
    return  x & ~(x >> (BITS_PER_LONG-1));
}
// --------------------------


static inline ulong average(ulong x, ulong y)
// return (x+y)/2
// result is correct even if (x+y) wouldn't fit into a ulong
{
    return  (x & y) + ((x ^ y) >> 1);
    // return  y + ((x-y)>>1);  // works if x>=y
}
// --------------------------


static inline long clip_range0(long x, long m)
// code equivalent (for m>0) to:
// if ( x<0 )  x = 0;
// else if ( x>m )  x = m;
// return  x;
{
    if ( (ulong)x>(ulong)m )  x = m & ~(x >> (BITS_PER_LONG-1));
    return  x;
}
// --------------------------

// in order to toggle a value x between two values a, b:
// for integers:
//  precalculate:  t  = a ^ b;
//  toggle:        x ^= t;
// for floats:
//  precalculate:  t = a + b;
//  toggle:        x = t - x;


#endif // !defined HAVE_BRANCHLESS_H__
