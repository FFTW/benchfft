#if !defined HAVE_BITSPERLONG_H__
#define      HAVE_BITSPERLONG_H__


#if !defined BITS_PER_LONG
#include <limits.h>
#if  ( 4294967295UL==ULONG_MAX )  // long is 32bit
#define  BITS_PER_LONG  32
#else
#if  ( 18446744073709551615UL==ULONG_MAX )  // long is 64 bit
#define  BITS_PER_LONG  64
#else
#define  BITS_PER_LONG  128  // ... assume long is 128 bit
#error 'several functions are not implemented for 128bit words'
#endif
#endif
#endif // BITS_PER_LONG


#endif  // !defined HAVE_BITSPERLONG_H__
