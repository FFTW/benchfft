#if !defined HAVE_BITLOW_H__
#define      HAVE_BITLOW_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitcount01.h"
#include "bitsasm.h"


static inline ulong lowest_bit_01edge(ulong x)
// return word where a all bits from  (including) the
//   lowest set bit to bit 0 are set
// return 0 if no bit is set
//
// feed the result into bit_count() to get
//   the index of the lowest bit set
{
    if ( 0==x )  return 0;
    return  x^(x-1);
}
//------------------------

static inline ulong lowest_bit_10edge(ulong x)
// return word where a all bits from (including) the
//   lowest set bit to most significant bit are set
// return 0 if no bit is set
{
    if ( 0==x )  return 0;
    x ^= (x-1);
    // x == lowest_bit_01edge(x);
    return  ~(x>>1);
}
//------------------------

#define   LOWEST_BIT_IDX_VER  1  // default is 1

static inline ulong lowest_bit_idx(ulong x)
// return index of lowest bit set
// return ~0 if no bit is set
{
#if defined  BITS_USE_ASM
    if ( 0==x )  return  ~0UL;
    return  asm_bsf(x);
#else // BITS_USE_ASM


    if ( 1>=x )  return  x-1; // 0 if 1, ~0 if 0

#if  ( LOWEST_BIT_IDX_VER == 1 )

    x = lowest_bit_01edge(x);
    return  bit_count_01( x );

#else // LOWEST_BIT_IDX_VER

    ulong r = 1;
#if  BITS_PER_LONG >= 64
    if ( !(x & (~0UL>>32)) )  { r += 32;  x >>= 32; }
#endif
    if ( !(x & 0x0000ffff) )  { r += 16;  x >>= 16; }

    if ( !(x & 0x000000ff) )  { r +=  8;  x >>= 8; }

    if ( !(x & 0x0000000f) )  { r +=  4;  x >>= 4; }

    if ( !(x & 0x00000003) )  { r +=  2;  x >>= 2; }

    if ( !(x & 0x00000001) )  r += 1;

    return r;
#endif // LOWEST_BIT_IDX_VER
#endif // BITS_USE_ASM
}
//------------------------


static inline ulong lowest_bit(ulong x)
// return word where only the lowest set bit in x is set
// return 0 if no bit is set
{
//    if ( 0==x )  return 0;
//    return  ((x^(x-1)) >> 1) + 1;

//    return  (x & (x-1)) ^ x;

    return  x & -x;  // use: -x == ~x + 1
}
//------------------------

static inline ulong lowest_unset_bit(ulong x)
// return word where only the lowest unset bit in x is set
// return 0 if all bits are set
{
//    return  (x ^ (x+1)) & ~x;
    x = ~x;
    return  x & -x;
}
//------------------------

static inline ulong delete_lowest_bit(ulong x)
// return word were the lowest bit set in x is unset
// returns 0 for input == 0
{
    return  x & (x-1);
}
//------------------------

static inline ulong set_lowest_unset_bit(ulong x)
// return word were the lowest unset bit in x is set
// returns ~0 for input == ~0
{
    return  x | (x+1);
}
//------------------------


static inline ulong low_unset_bits(ulong x)
// return word where all the (low end) zeroes
// are set
// e.g.  01011000 --> 00000111
// returns 0 if all bits are set
{
    if ( 0==x )  return ~0UL;

    return (((x-1)^x) >> 1);
}
//------------------------

static inline ulong low_set_bits(ulong x)
// return word where all the (low end) ones
// are set
// e.g.  01011011 --> 00000011
// returns 0 if no bit is set
{
    if ( ~0UL==x )  return ~0UL;

    return (((x+1)^x) >> 1);
}
//------------------------


#endif  // !defined HAVE_BITLOW_H__
