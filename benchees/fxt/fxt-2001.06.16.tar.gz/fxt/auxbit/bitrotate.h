#if !defined HAVE_BITROTATE_H__
#define      HAVE_BITROTATE_H__


#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitsasm.h"


static inline ulong rotate_left(ulong x, ulong r)
// return word rotated r bits
// to the left (i.e. toward the most significant bit)
//
// gcc 2.95.2 optimizes the function to asm 'roll %cl,%ebx'
{
#if defined  BITS_USE_ASM    // use x86 asm code
    return asm_rol(x, r);
#else
//    r &= (BITS_PER_LONG-1);  // modulo wordlength
    return  (x<<r) | (x>>(BITS_PER_LONG-r));
#endif
}
//------------------------


static inline ulong rotate_right(ulong x, ulong r)
// return word rotated r bits
// to the right (i.e. toward the least significant bit)
//
// gcc 2.95.2 optimizes the function to asm 'rorl %cl,%ebx'
{
#if defined  BITS_USE_ASM    // use x86 asm code
    return asm_ror(x, r);
#else
//    r &= (BITS_PER_LONG-1);  // modulo wordlength
    return  (x>>r) | (x<<(BITS_PER_LONG-r));
#endif
}
//------------------------


static inline ulong rotate_left(ulong x, ulong r, ulong ldn)
// return ldn-bit word rotated r bits
// to the left (i.e. toward the most significant bit)
// r must be <= ldn
{
    x  = (x<<r) | (x>>(ldn-r));
    if ( 0!=(ldn % BITS_PER_LONG) )  x &= ((1UL<<(ldn))-1);
    return  x;
}
//------------------------


static inline ulong rotate_right(ulong x, ulong r, ulong ldn)
// return ldn-bit word rotated r bits
// to the right (i.e. toward the least significant bit)
// r must be <= ldn
{
    x  =  (x>>r) | (x<<(ldn-r));
    if ( 0!=(ldn % BITS_PER_LONG) )  x &= ((1UL<<(ldn))-1);
    return  x;
}
//------------------------


static inline ulong cyclic_match(ulong x, ulong y)
// return  r if x==rotate_right(y, r)
// else return ~0UL
// in other words: returns, how often
//   the right arg must be rotated right (to match the left)
// or, equivalently: how often
//   the left arg must be rotated left (to match the right)
{
    ulong r = 0;
    do
    {
        if ( x==y )  return r;
        y = rotate_right(y, 1);
        ++r;
    }
    while ( r<BITS_PER_LONG );

    return ~0UL;
}
//------------------------


static inline ulong cyclic_match(ulong x, ulong y, ulong ldn)
// return  r if x==rotate_right(y, r, ldn)
// else return ~0UL
{
    ulong r = 0;
    do
    {
        if ( x==y )  return r;
        y = rotate_right(y, 1, ldn);
        ++r;
    }
    while ( r<ldn );

    return ~0UL;
}
//------------------------


#endif  // !defined HAVE_BITROTATE_H__
