#if !defined HAVE_BITSASM_H__
#define      HAVE_BITSASM_H__

#include "fxttypes.h"

#if defined  __i386__  // ------- if x86 cpu
#if defined  __GNUC__  // if GNU-C

// comment out the following line to disable asm usage:
#define  BITS_USE_ASM    // use x86 asm code

#endif // __GNUC__
#endif // __i386__



#if defined  BITS_USE_ASM    // use x86 asm code

static inline ulong asm_bsf(ulong x)
// Bit Scan Forward
{
    __asm__ ("bsfl %0, %0" : "=r" (x) : "0" (x));
    return x;
}
//------------------------


static inline ulong asm_bsr(ulong x)
// Bit Scan Reverse
{
    __asm__ ("bsrl %0, %0" : "=r" (x) : "0" (x));
    return x;
}
//------------------------


static inline ulong asm_bswap(ulong x)
// byte swap
{
    __asm__ ("bswap %0" : "=r" (x) : "0" (x));

//  if ( cpu <= i386 )
//    __asm__ ("xchgb %b0, %h0 \n\t"
//             "rorl  $16, %0  \n\t"
//             "xchgb %b0, %h0"
//             :"=r" (x)
//             : "0" (x));

    return x;
}
//------------------------


static inline ulong asm_rol(ulong x, ulong r)
// Rotate Left
{
    __asm__ ("roll   %%cl, %0" : "=r" (x) : "0" (x), "c" (r));
    return x;
}
//------------------------


static inline ulong asm_ror(ulong x, ulong r)
// Rotate Right
{
    __asm__ ("rorl   %%cl, %0" : "=r" (x) : "0" (x), "c" (r));
    return x;
}
//------------------------


static inline ulong asm_parity(ulong x)
// Return the parity of x (which is the
// _complement_ of x86's parity flag).
// As parity is for the low byte only,
// therefore we need to prepend 
// x ^= (x>>16);  x ^= (x>>8);
// in the code
{
    x ^= (x>>16);
    x ^= (x>>8);
    __asm__ ("addl  $0, %0  \n\t"
             "setnp %%al   \n\t"
             "movzx %%al, %0"
             : "=r" (x) : "0" (x) : "eax");

    return x;
}
//------------------------


static inline ulong asm_bt(const ulong *f, ulong i)
// Bit Test
{
    ulong ret;
    __asm__ ( "btl  %2, %1 \n" // carry = 0 or 1
              "sbbl %0, %0"    // ret = 0 or -1
              : "=r" (ret)
              : "m" (*f), "r" (i) );
    return ret;
}
//------------------------

static inline ulong asm_bts(ulong *f, ulong i)
// Bit Test and Set
{
    ulong ret;
    __asm__ ( "btsl %2, %1 \n"
              "sbbl %0, %0"
              : "=r" (ret)
              : "m" (*f), "r" (i) );
    return ret;
}
//------------------------

static inline void asm_b_s(ulong *f, ulong i)
// Bit Set
{
    __asm__ ( "btsl  %1, %0 \n"
              : /* void */
              : "m" (*f), "r" (i) );
}
//------------------------

static inline ulong asm_btr(ulong *f, ulong i)
// Bit Test and Reset
{
    ulong ret;
    __asm__ ( "btrl  %2, %1 \n"
              "sbbl %0, %0"
              : "=r" (ret)
              : "m" (*f), "r" (i) );
    return ret;
}
//------------------------

static inline void asm_b_r(ulong *f, ulong i)
// Bit Reset
{
    __asm__ ( "btrl  %1, %0 \n"
              : /* void */
              : "m" (*f), "r" (i) );
}
//------------------------

static inline ulong asm_btc(ulong *f, ulong i)
// Bit Test and Complement
{
    ulong ret;
    __asm__ ( "btcl  %2, %1 \n"
              "sbbl %0, %0"
              : "=r" (ret)
              : "m" (*f), "r" (i) );
    return ret;
}
//------------------------

static inline void asm_b_c(ulong *f, ulong i)
// Bit Complement
{
    __asm__ ( "btcl  %1, %0 \n"
              : /* void */
              : "m" (*f), "r" (i) );
}
//------------------------


#endif // BITS_USE_ASM


#endif  // !defined HAVE_BITSASM_H__
