
#include "fxttypes.h"
#include "bitsperlong.h"

#include <iostream.h>


void
print_bin_nn(ulong x, int pd/*=BITS_PER_LONG*/)
//
// same as print_bin(), but prints no newline
//
{
    x <<= (BITS_PER_LONG-pd);

    for(int i=0; i<pd; ++i)
    {
        int y = ((long)x<0 ? 1 : 0);
        x <<= 1;
        cout << (y?'1':'.');
    }
}
// --------------------------


void
print_bin(char *bla, ulong x, int pd/*=BITS_PER_LONG*/)
//
// print x to radix 2
// pd: how many bits to print
//
{
    cout << bla << "  ";

    print_bin_nn(x, pd);

    cout << endl;
}
// --------------------------
