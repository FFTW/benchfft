#if !defined HAVE_ZEROBYTE_H__
#define      HAVE_ZEROBYTE_H__


#include "fxttypes.h"
#include "bitsperlong.h"


static inline ulong contains_zero_byte(ulong x)
// Determine if any sub-byte of x is zero.
// Returns zero when x contains no zero byte and nonzero when it does.
// The idea is to subtract 1 from each of the bytes and then look for bytes
//   where the borrow propagated all the way to the most significant bit.
// To scan for other values than zero (e.g. 0xa5) use:
//  contains_zero_byte( x ^ 0xa5a5a5a5 )
//.
// found on the net
{
#if  BITS_PER_LONG == 32
    return ((x-0x01010101)^x) & (~x) & (0x80808080);
#endif

#if  BITS_PER_LONG == 64
    return ((x-0x0101010101010101)^x) & (~x) & (0x8080808080808080);
#endif
}
//------------------------


#endif  // !defined HAVE_ZEROBYTE_H__
