#if !defined HAVE_BITCOMBINATION_H__
#define      HAVE_BITCOMBINATION_H__

#include "fxttypes.h"
#include "bitsperlong.h"


static inline ulong first_combination(ulong k)
// return the first combination of (i.e. smallest word with) k bits,
// i.e.  00..001111..1 (k low bits set)
// must be:  1 <= k <= BITS_PER_LONG
{
    ulong x = ~0UL;
    if ( BITS_PER_LONG != k )  x = ~(x<<k);
    return  x;
}
//------------------------------------------------


static inline ulong last_combination(ulong k)
// return the lasst combination of (i.e. biggest word with) k bits,
// i.e.  1111..100..00 (k high bits set)
// must be:  1 <= k <= BITS_PER_LONG
{
//    if ( 0==k )  return 0;  // if we want zero allowed

    return  ~0UL << (BITS_PER_LONG - k);
}
//------------------------------------------------


static inline ulong next_combination(ulong x)
// return smallest integer greater than x with the same number of bits set.
//
//  Examples:
//    000001 -> 000010 -> 000100 -> 001000 -> 010000 -> 100000
//    000011 -> 000101 -> 000110 -> 001001 -> 001010 -> 001100 -> 010001 -> ...
//    000111 -> 001011 -> 001101 -> 001110 -> 010011 -> 010101 -> 010110 -> ...
//
//  Special cases:
//    0 -> 0
//    all bits on the high side (i.e. last combination) -> 0
//
//  Example: (the bits marked by '.' remain fixed)
//    x         = ....01111100000000
//    z         = 000000000100000000   (the lowest set bit)
//    v=x+z     = ....10000000000000   (first zero beyond burst of ones)
//    v^x       = 000011111100000000
//    v^x/z     = 000000000000111111
//    v^x/z>>2  = 000000000000001111
//    next      = ....10000000001111
//
//  based on code taken from Torsten Sillke's bitmani.h:
//  http://www.mathematik.uni-bielefeld.de/~sillke/ALGORITHMS/
//  The algorithm can be found in hakmem, shortcut by me.
{
    // begin shortcut
    if ( x & 1 )  // avoid division for trivial update
    {
        ulong z = (x ^ (x+1)) & ~x; // lowest unset bit
        if ( 0==z )  return  0;   // x was == 0xffffffff
        x += (z>>1);  // same as:  x ^= z;  x ^= (z>>1);
        return  x;
    }
    else
    // end shortcut
    {
        if ( x==0 )  return 0;
    }

    ulong z = (((x-1)^x) >> 1) + 1; // lowest set bit
    ulong v = x + z;   // zero beyond burst

    if ( v )  v += ((v^x)/z >> 2);

    return  v;  // ==0 if input was the biggest combo with that number of bits
}
//------------------------------------------------


#endif  // !defined HAVE_BITCOMBINATION_H__
