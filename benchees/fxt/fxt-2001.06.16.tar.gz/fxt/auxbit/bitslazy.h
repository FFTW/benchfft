#if !defined HAVE_BITSLAZY_H__
#define      HAVE_BITSLAZY_H__

// include file for the lazy

#include "bitsperlong.h"

#include "bitarray.h"
#include "bitcount.h"
#include "bitswap.h"
#include "bitrotate.h"
#include "bitlow.h"
#include "bithigh.h"
#include "bits2pow.h"
#include "bitsubset.h"
#include "revbin.h"
#include "graycode.h"

#include "bitsasm.h"

#include "printbin.h"


// slightly esoteric stuff:
#include "bitcount01.h"
#include "bitcombination.h"
#include "zerobyte.h"
#include "branchless.h"

// clearly esoteric stuff:
#include "bitsequency.h"
#include "bitmisc.h"


#endif // !defined HAVE_BITSLAZY_H__
