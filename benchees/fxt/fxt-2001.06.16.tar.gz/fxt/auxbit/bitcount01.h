#if !defined HAVE_BITCOUNT01_H__
#define      HAVE_BITCOUNT01_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bitsasm.h"


#define BIT_COUNT_01_use_BIT_COUNT  // default = defined

#if defined BIT_COUNT_01_use_BIT_COUNT
#include "bitcount.h"
#endif


static inline ulong bit_count_01(ulong x)
// return number of bits in a word
// for words of the special form 00...0001...11
{
#if defined  BITS_USE_ASM

    if ( 1>=x )  return x;
    x = asm_bsr(x);
    return  x + 1;

#else // BITS_USE_ASM

#if defined BIT_COUNT_01_use_BIT_COUNT
    return  bit_count(x);
#else

    ulong ct = 0;
    ulong a;

#if  BITS_PER_LONG == 64
    a = (x & (1<<32)) >> (32-5);  // test bit 32
    x >>= a;  ct += a;
#endif
    a = (x & (1<<16)) >> (16-4);  // test bit 16
    x >>= a;  ct += a;

    a = (x & (1<<8)) >> (8-3);  // test bit 8
    x >>= a;  ct += a;

    a = (x & (1<<4)) >> (4-2);  // test bit 4
    x >>= a;  ct += a;

    a = (x & (1<<2)) >> (2-1);  // test bit 2
    x >>= a;  ct += a;

    a = (x & (1<<1)) >> (1-0); // test bit 1
    x >>= a;  ct += a;

    ct += x & 1; // test bit 0

    return ct;

#endif // BIT_COUNT_01_use_BIT_COUNT
#endif // BITS_USE_ASM
}
//------------------------



#endif  // !defined HAVE_BITCOUNT01_H__
