
#include "bitarray.h"

#include <iostream.h>


bitarray::bitarray(ulong nbits)
{
    // avoid trouble for zero length:
    nb_ = ( 0==nbits ? 1 : nbits );

    nw_ = nb_ / BITS_PER_LONG;
    nfw_ = nw_;
    nbl_ = nb_ - nw_*BITS_PER_LONG;
    if ( nbl_ )  ++nw_;

    if ( nw_==nfw_ )  ml_ = ~0UL;
    else              ml_ = (2UL << nbl_) - 1;

    f_ = new ulong[nw_];
    clear_all();
}
//-----------------------


void
bitarray::clear_all()
{
    for (ulong k=0; k<nw_; ++k)  f_[k] = 0;
}
//-----------------------


void
bitarray::set_all()
{
    ulong k=0;
    for (  ; k<nw_; ++k)  f_[k] = ~0UL;
    f_[k-1] &= ml_;  // nop iff there is no partially used word
}
//-----------------------


int
bitarray::all_set()  const
{
    ulong k = 0;
    for (  ; k<nfw_; ++k)  if ( ~f_[k] )  return 0;

    if ( nbl_ && (f_[k]^ml_) )  return 0;

    return  1;
}
//-----------------------


int
bitarray::all_clear()  const
{
    ulong k = 0;
    for (  ; k<nfw_; ++k)  if ( f_[k] )  return 0;

    if ( nbl_ && (f_[k]&ml_) )  return 0;

    return  1;
}
//-----------------------


#define  PRINTVAR(x)  cout << "  "#x" = " << x << endl
#define  PRINTVAR2(s,x)  cout << s << "  "#x" = " << x << endl
void
bitarray::dump()  const
{
    cout << __PRETTY_FUNCTION__ << ": " << endl;
//    cout << "  nb_=" << nb_ << endl;
    PRINTVAR2("number of bits:", nb_);
    PRINTVAR2("number of words:", nw_);
    PRINTVAR2("fully used words:", nfw_);
    PRINTVAR2("bits in partially used word:", nbl_);
    PRINTVAR2("mask for last word:", ml_);
    dump_bits();
}
//-----------------------

void
bitarray::dump_bits()  const
{
    for (ulong k=0; k<nb_; ++k)
    {
        if ( (0==(k%8)) && (0!=k) )
        {
            if ( 0==(k%64) )  cout << endl;
            else
            {
                if ( 0==(k%32) )  cout << " ";
                cout << " ";
            }
        }
        cout << ( test(k) ? '1' : '.' );
    }
    cout << endl;
}
//-----------------------
