#if !defined HAVE_BITARRAY_H__
#define      HAVE_BITARRAY_H__


#include "fxttypes.h"
#include "bitsasm.h"
#include "bitsperlong.h"


#define  DIVMOD_BPL(n, d, bm) \
ulong d = n / BITS_PER_LONG; \
ulong bm = 1UL << (n % BITS_PER_LONG);

#define  DIVMOD_BPL_TEST(n, d, bm) \
ulong d = n / BITS_PER_LONG; \
ulong bm = 1UL << (n % BITS_PER_LONG); \
ulong t = bm & f_[d];


class bitarray
//
// simply bitarray class mostly for use as
// memory saving array of boolean values
// valid index is 0...nb_-1 (as usual in C arrays)
//
{
public:

    bitarray(ulong nbits);
    ~bitarray()  { delete [] f_; }


    void clear_all();
    void set_all();

    ulong test(ulong n)  const
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_bt(f_, n);
#else
        DIVMOD_BPL_TEST(n, d, bm);
        return  t;
#endif
    }

    void set(ulong n)
    {
        if ( n>=nb_ )  return;
#if defined  BITS_USE_ASM
        asm_b_s(f_, n);
#else
        DIVMOD_BPL(n, d, bm);
        f_[d] |= bm;
#endif
    }

    void clear(ulong n)
    {
        if ( n>=nb_ )  return;
#if defined  BITS_USE_ASM
        asm_b_r(f_, n);
#else
        DIVMOD_BPL(n, d, bm);
        f_[d] &= ~bm;
#endif
    }

    void change(ulong n)
    {
        if ( n>=nb_ )  return;
#if defined  BITS_USE_ASM
        asm_b_c(f_, n);
#else
        DIVMOD_BPL(n, d, bm);
        f_[d] ^= bm;
#endif
    }

    ulong test_set(ulong n)
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_bts(f_, n);
#else
        DIVMOD_BPL_TEST(n, d, bm);
        f_[d] |= bm;
        return  t;
#endif
    }

    ulong test_clear(ulong n)
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_btr(f_, n);
#else
        DIVMOD_BPL_TEST(n, d, bm);
        f_[d] &= ~bm;
        return  t;
#endif
    }

    ulong test_change(ulong n)
    {
        if ( n>=nb_ )  return 0;
#if defined  BITS_USE_ASM
        return asm_btc(f_, n);
#else
        DIVMOD_BPL_TEST(n, d, bm);
        f_[d] ^= bm;
        return  t;
#endif
    }

    int all_set()  const;
    int all_clear()  const;

    ulong next_set_idx(ulong n)  // return next set or one beyond end
    {
        if ( n>=nb_ )  return nb_;
        while ( (n<nb_) && (!test(n)) )  ++n;  // jjnote: inefficient
        return n;
    }

    void dump()  const;
    void dump_bits()  const;


//private:
    ulong nb_, nw_;  // number of bits/words
    ulong nfw_;  // number of words where all bits are used, may be zero
    ulong nbl_;  // number of bits used in last (partially used) word, 0 if mw==mfw
    ulong ml_;   // mask for last (partially used) word, ~0 if mw==mfw
    ulong *f_;   // data
    
};
//---------------------------------------------


#endif // !defined HAVE_BITARRAY_H__
