#if !defined HAVE_BITS2POW_H__
#define      HAVE_BITS2POW_H__

#include "fxttypes.h"
#include "bitsperlong.h"
#include "bithigh.h"
#include "bitcount01.h"


static inline ulong ld(ulong x)
// returns k so that 2^k <= x < 2^(k+1)
// if x==0 then 0 is returned (!)
{
//    ulong k = 0;
//    while ( x>>=1 )  ++k;
//    return k;

    if ( 0==x )  return 0;
    x = highest_bit(x) - 1;
    return  bit_count_01(x);
}
//------------------------


static inline unsigned long long ld(unsigned long long x)
// returns k so that 2^k <= x < 2^(k+1)
// if x==0 then 0 is returned (!)
{
#if  BITS_PER_LONG == 64
    return  highest_bit_idx(x);
#else
    ulong  r = highest_bit_idx( x>>32 );
    if ( r )  return  r + 32;
    else      return  highest_bit_idx( x );
#endif
}
//------------------------


static inline ulong ldq(ulong x)
// return k if x=2**k
// else return ~0
{
    ulong k = ld(x);
    if ( x==(1UL<<k) )  return  k;
    else                return  (ulong)~0;
}
//------------------------

static inline int is_pow_of_2(ulong x)
// return 1 if x == 0(!) or x == 2**k
{
    return  (x & -x) == x;
}
//------------------------

static inline int one_bit_q(ulong x)
// return 1 iff x \in {1,2,4,8,16,...}
{
    ulong m = x-1;
    return  (x^m)>>1 == m;
}
//------------------------



static inline ulong next_pow_of_2(ulong x)
// return x if x=2**k
// else return 2**ceil(log_2(x))
{
    ulong n = (ulong)1<<ld(x);  // n<=x
    if ( n==x )  return x;
    else         return n<<1;
}
//------------------------

static inline ulong next_exp_of_2(ulong x)
// return k if x=2**k
// else return k+1
{
    ulong ldx = ld(x);
    ulong n = (ulong)1<<ldx;  // n<=x
    if ( n==x )  return ldx;
    else         return ldx+1;
}
//------------------------



#endif  // !defined HAVE_BITS2POW_H__
