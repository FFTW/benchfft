#if !defined HAVE_BITSUBSET_H__
#define      HAVE_BITSUBSET_H__

#include "fxttypes.h"


class bit_subset
// returns all subsets of bits of vv
{
public:
    bit_subset(ulong vv) : u(0), v(vv) { ; }
    ~bit_subset() { ; }
    ulong current()  const { return u; }
    ulong next()      { u = (u-v) & v;  return u; }
    ulong previous()  { u = (u-1) & v;  return u; }

private:
    ulong u, v;
};
// --------------------------


#endif  // !defined HAVE_BITSUBSET_H__
