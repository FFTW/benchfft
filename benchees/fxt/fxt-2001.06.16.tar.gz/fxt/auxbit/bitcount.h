#if !defined HAVE_BITCOUNT_H__
#define      HAVE_BITCOUNT_H__

#include "fxttypes.h"
#include "bitsperlong.h"


static inline ulong bit_count(ulong x)
// return number of bits set
{
#if  BITS_PER_LONG == 32
    // VERSION 1:
//    x = (0x55555555 & x) + (0x55555555 & (x>> 1));  // 0-2 in 2 bits
//    x = (0x33333333 & x) + (0x33333333 & (x>> 2));  // 0-4 in 4 bits
//    x = (0x0f0f0f0f & x) + (0x0f0f0f0f & (x>> 4));  // 0-8 in 8 bits
//    x = (0x00ff00ff & x) + (0x00ff00ff & (x>> 8));  // 0-16 in 16 bits
//    x = (0x0000ffff & x) + (0x0000ffff & (x>>16));  // 0-31 in 32 bits
//    return x;

    // VERSION 2:
    x  = ((x>>1) & 0x55555555) + (x & 0x55555555);  // 0-2 in 2 bits
    x  = ((x>>2) & 0x33333333) + (x & 0x33333333);  // 0-4 in 4 bits
    x  = ((x>>4) + x) & 0x0f0f0f0f;                 // 0-8 in 4 bits
    x +=  x>> 8;                                    // 0-16 in 8 bits
    x +=  x>>16;                                    // 0-32 in 8 bits
    return  x & 0xff;

    // VERSION 3:
//    x -=  (x>>1) & 0x55555555;
//    x  = ((x>>2) & 0x33333333) + (x & 0x33333333);
//    x  = ((x>>4) + x) & 0x0f0f0f0f;
//    x *= 0x01010101;
//    return  x>>24;

#endif

#if  BITS_PER_LONG == 64
//    x = (0x5555555555555555 & x) + (0x5555555555555555 & (x>> 1));
//    x = (0x3333333333333333 & x) + (0x3333333333333333 & (x>> 2));
//    x = (0x0f0f0f0f0f0f0f0f & x) + (0x0f0f0f0f0f0f0f0f & (x>> 4));
//    x = (0x00ff00ff00ff00ff & x) + (0x00ff00ff00ff00ff & (x>> 8));
//    x = (0x0000ffff0000ffff & x) + (0x0000ffff0000ffff & (x>>16));
//    x = (0x00000000ffffffff & x) + (0x00000000ffffffff & (x>>32));
//    return x;

    x = ((x>>1) & 0x5555555555555555) + (x & 0x5555555555555555);  // 0-2 in 2 bits
    x = ((x>>2) & 0x3333333333333333) + (x & 0x3333333333333333);  // 0-4 in 4 bits
    x = ((x>>4) + x) & 0x0f0f0f0f0f0f0f0f;                         // 0-8 in 4 bits
    x +=  x>> 8;                                                   // 0-16 in 8 bits
    x +=  x>>16;                                                   // 0-32 in 8 bits
    x +=  x>>32;                                                   // 0-64 in 8 bits
    return  x & 0xff;
#endif
}
//------------------------


static inline ulong bit_count_sparse(ulong x)
// return number of bits set
// the loop will execute once for each bit of x set
{
    if ( 0==x )  return 0;

    ulong n = 0;
    do
    {
        ++n;
    }
    while ( x &= (x-1) );

    return  n;
}
//------------------------


static inline ulong bit_block_count(ulong x)
// return number of bit blocks
// e.g.:
// ..1..11111...111.  -> 3
// ...1..11111...111  -> 3
// ......1.....1.1..  -> 3
// .........111.1111  -> 2
{
//    return  bit_count(gray_code(x))/2 + (x & 1);
    return  bit_count( (x^(x>>1)) ) / 2 + (x & 1);
}
//------------------------


static inline ulong bit_block_ge2_count(ulong x)
// return number of bit blocks with at least 2 bits
// e.g.:
// ..1..11111...111.  -> 2
// ...1..11111...111  -> 2
// ......1.....1.1..  -> 0
// .........111.1111  -> 2
{
    // return bit_block_count( interior_bits(x) );
    return  bit_block_count( x & ( (x<<1) & (x>>1) ) );
}
//------------------------


#endif  // !defined HAVE_BITCOUNT_H__
