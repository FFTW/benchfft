#if !defined HAVE_PRINTBIN_H__
#define      HAVE_PRINTBIN_H__

#include "bitsperlong.h"

// auxbit/printbin.cc:
void print_bin_nn(ulong x, int pd=BITS_PER_LONG);

void print_bin(char *bla, ulong x, int pd=BITS_PER_LONG);


#endif  // !defined HAVE_PRINTBIN_H__
