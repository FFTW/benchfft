
#include "fxt.h"
#include "copy.h"
#include "auxdouble.h"
#include "auxprint.h"
#include "misc.h"
#include "permutelazy.h"

#include <math.h>
#include <iostream.h>
#include <stdlib.h>  // atol()

// jjnote: todo: generated (short) versions
// jjnote: todo: ntt


#include "paranoia.h"


int
main(int argc, char **argv)
{
  cout << "Running tests for complex FFTs ... " << endl;

  ulong minldn = 0, maxldn = 11;
  if ( argc>1 )  minldn = atol(argv[1]);
  if ( argc>2 )  maxldn = atol(argv[2]);

  int rep = 1;
  if ( argc>3 )  rep = atol(argv[3]);


  ulong n = 1<<maxldn;
  Complex ac[n], fc[n], gc[n];
//  double *ar=(double *)ac;
  double *fr=(double *)fc, *gr=(double *)gc;
  for (int r=1; r<=rep; ++r)
  {
    cout << "+++++++++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") +++++++++++++++++++++++++" << endl;

    for (ulong ldn=minldn; ldn<=maxldn; ++ldn)
    {
      n = 1<<ldn;
      cout << "====================  LDN = " << ldn
           << "   N = " << n << " :" << endl;

      ulong nh = n/2;
      double *fi=fr+n,  *gi=gr+n; // ,  *ai=ar+n;
      null(ac, n);
      //   ar[1] = ai[1] = 1;
      for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), white_noise());
      //   for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), 0.0 );
      //   fill_seq(ar, 2*n, 1.0/n, 1.0/n);
      //   fill(ar, 2*n, 1.0);


      for (int is=+1; is>=-1; is-=2)
      {
        cout << "========= ISIGN = " << is << endl;

        cout << "\n----- COMPLEX FFT: -----" << endl;
        ECHO( fht_fft(fc, ldn, is); );

        CHECK( split_radix_fft(gc, ldn, is); );
        CHECK( matrix_fft(gc, ldn, is); );
        CHECK( fht_fft(gc, ldn, is); );
        CHECK( split_radix_fft(gc, ldn, is); );
        CHECK( matrix_fft(gc, ldn, is); );
        CHECK( dif4_fft(gc, ldn, is); );
        CHECK( dit4_fft(gc, ldn, is); );
        CHECK( dif4l_fft(gc, ldn, is); );
        CHECK( dit4l_fft(gc, ldn, is); );
        CHECK( dif2_fft(gc, ldn, is); );
        CHECK( dit2_fft(gc, ldn, is); );

        if ( ldn<=SMALL_LDN )
        {
          CHECK( slow_ft(gc, n, is); );
          CHECK( slow_rotated_ft(gc, n, is, 1); );
          CHECK( slow_fract_ft(gc, n, is); );
          //     double phi = 2.0*M_PI*is;
          //     CHECK( slow_zt(gc, n, Complex(cos(phi),sin(phi))); );

          CHECK( recursive_dif2_fft(gc, ldn, is); );
          CHECK( recursive_dit2_fft(gc, ldn, is); );
          CHECK( dit2_fft_localized(gc, ldn, is); );
          CHECK( dif2_fft_localized(gc, ldn, is); );
        }


        cout << "----- COMPLEX (RE/IM) FFT: -----" << endl;
        ECHO( fht_fft(fr, fi, ldn, is); );
        CHECK( dif4_fft(gr, gi, ldn, is); );
        CHECK( dit4_fft(gr, gi, ldn, is); );
        CHECK( dif2_fft(gr, gi, ldn, is); );
        CHECK( dit2_fft(gr, gi, ldn, is); );

        if ( ldn<=SMALL_LDN )
        {
          CHECK( slow_ft(gr, gi, n, is); );
          CHECK( slow_rotated_ft(gr, gi, n, is, 1); );
          CHECK( slow_fract_ft(gr, gi, n, is); );
        }

        copy(ac, fc, n);
        CHECK( fht_fft(gr, gi, ldn, is);/**/ separator(gr, gi, n, is); multiply(gr, 2*n, 1.0/n); fht_complex_real_fft(gr, ldn); fht_complex_real_fft(gi, ldn); );

        cout << "\n----- REAL FFT: -----" << endl;
        ECHO( fht_real_complex_fft(fr, ldn, is); );

        CHECK( wrap_real_complex_fft(gr, ldn, is); unzip(gr, n); );

        CHECK( easy_ordering_real_complex_fft(gr, ldn, is); if (n>=4) reverse(gr+nh+1, nh-1); );

        if ( is<0 )  CHECK( split_radix_real_complex_fft(gr, ldn); );


        cout << "\n----- IDENTITY (FFT/invFFT): -----" << endl;
        ECHO( copy(ac, fc, n); );

        CHECK( fht_real_complex_fft(gr, ldn, is);/**/ fht_complex_real_fft(gr, ldn, is); multiply(gr, n, 1.0/n); );

        CHECK( wrap_real_complex_fft(gr, ldn, is);/**/ wrap_complex_real_fft(gr, ldn, is); multiply(gr, n, 1.0/n); );

        CHECK( dif4_fft_core(gc, ldn); /* is = +1 */ dit4_fft_core(gc, ldn); /* is = -1 */ multiply(gr, 2*n, 1.0/n); );

        CHECK( split_radix_dif_fft_core(gc, ldn); /* is = +1 */ split_radix_dit_fft_core(gc, ldn); /* is = -1 */ multiply(gr, 2*n, 1.0/n); );

      } // ---------- end isign loop

    } // === ldn ===

    cout << "+++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") ++++++ FINISHED +++++++++++++" << endl;

  } // === r ===


  cout << "\nOK, all passed." << endl;
  return 0;
}
//===========================================
/*
Local variables:
mode: C++
c-basic-offset: 2 
End:
*/
