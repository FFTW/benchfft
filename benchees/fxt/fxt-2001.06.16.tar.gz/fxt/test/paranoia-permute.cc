
#include "permutelazy.h"
#include "copy.h"
#include "auxprint.h"
#include "auxdouble.h"

#include <math.h>
#include <iostream.h>
#include <stdlib.h>  // atol()


#include "paranoia.h"

//void print_fxt_version();

int
main(int argc, char **argv)
{
  cout << "Running tests for permutations ... " << endl;
//  print_fxt_version();

  ulong minldn = 0, maxldn = 11;
  if ( argc>1 )  minldn = atol(argv[1]);
  if ( argc>2 )  maxldn = atol(argv[2]);

  int rep = 1;
  if ( argc>3 )  rep = atol(argv[3]);


  ulong n = 1<<maxldn;
  double ar[n], fr[n], gr[n];


  for (int r=1; r<=rep; ++r)
  {
    cout << "+++++++++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") +++++++++++++++++++++++++" << endl;

    for (ulong ldn=minldn; ldn<=maxldn; ++ldn)
    {
      n = 1<<ldn;
      cout << "====================  LDN = " << ldn
           << "   N = " << n << " :" << endl;

      null(ar, n);
//      for (ulong i=0; i<n; ++i)  ar[i] = white_noise();
      fill_seq(ar, n, 0.0, 1.0);


      cout << "\n----- GRAY: -----" << endl;
      EQUIV_REAL( gray_permute(ar, fr, n);/**/ copy(ar, gr, n); gray_permute(gr, n); );

      EQUIV_REAL( copy(ar, fr, n);/**/ copy(ar, gr, n); gray_permute(ar, gr, n); inverse_gray_permute(gr, n); );

      EQUIV_REAL( inverse_gray_permute(ar, fr, n);/**/ copy(ar, gr, n); inverse_gray_permute(gr, n); );


      cout << "\n----- EVENODD: -----" << endl;
      EQUIV_REAL( copy(ar, fr, n); zip(fr, n);/**/ copy(ar, gr, n); zip(gr, n); );

      EQUIV_REAL( copy(ar, fr, n);/**/ copy(ar, gr, n); zip(gr, n); unzip(gr, n); );

      EQUIV_REAL( zip(ar, fr, n);/**/ copy(ar, gr, n); zip(gr, n); );

      EQUIV_REAL( unzip(ar, fr, n);/**/ copy(ar, gr, n); unzip(gr, n); );


      cout << "\n----- EVENODDREV: -----" << endl;
      EQUIV_REAL( copy(ar, fr, n); ziprev(fr, n);/**/ copy(ar, gr, n); ziprev(gr, n); );

      EQUIV_REAL( copy(ar, fr, n);/**/ copy(ar, gr, n); ziprev(gr, n); unziprev(gr, n); );

      EQUIV_REAL( ziprev(ar, fr, n);/**/ copy(ar, gr, n); ziprev(gr, n); );

      EQUIV_REAL( unziprev(ar, fr, n);/**/ copy(ar, gr, n); unziprev(gr, n); );


// test makefile behavior with failure:
//      EQUIV_REAL( unziprev(ar, fr, n);/**/ if (ldn<5) copy(ar, gr, n); unziprev(gr, n); );
    }

    cout << "+++++++++++++++++++ PASS # " << r
         << " (of " << rep << ") ++++++ FINISHED +++++++++++++" << endl;
  }

  cout << "\nOK, all passed." << endl;
  return 0;
}
//===========================================
/*
Local variables:
mode: C++
c-basic-offset: 2
End:
*/
