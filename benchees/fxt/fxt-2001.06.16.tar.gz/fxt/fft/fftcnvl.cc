
#include "fxt.h"
#include "cmult.h"
#include "sumdiff.h"


//#define PARANOIA 1
#ifdef PARANOIA
#include "jjassert.h"
#warning 'FYI: we have PARANOIA'
#endif


void
fht_fft_convolution(double *f, double *g, ulong ldn)
// (cyclic, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
// f and g must not overlap
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    fht_real_complex_fft(f, ldn);
    fht_real_complex_fft(g, ldn);

    fft_convolution_core1(f, g, ldn);

    fht_complex_real_fft(g, ldn);
}
//============ end ===============


void
split_radix_fft_convolution(double *f, double *g, ulong ldn)
// (cyclic, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
// f and g must not overlap
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    split_radix_real_complex_fft(f, ldn);
    split_radix_real_complex_fft(g, ldn);

    fft_convolution_core1(f, g, ldn);

    split_radix_complex_real_fft(g, ldn);
}
//=========================== end =================


void
fht_fft_convolution0(double *f, double *g, ulong ldn)
// (linear, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
// f and g must not overlap
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n = 2**ldn  must be >=2
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    fht_real_complex_fft0(f, ldn);
    fht_real_complex_fft0(g, ldn);

    fft_convolution_core1(f, g, ldn);

    fht_complex_real_fft(g, ldn);
}
//============ end ===============


void
split_radix_fft_convolution0(double *f, double *g, ulong ldn)
// (linear, real) convolution:  g[] :=  f[] (*) g[]
// ldn := base-2 logarithm of the array length
// f and g must not overlap
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n = 2**ldn  must be >=2
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    split_radix_real_complex_fft0(f, ldn);
    split_radix_real_complex_fft0(g, ldn);

    fft_convolution_core1(f, g, ldn);

    split_radix_complex_real_fft(g, ldn);
}
//=========================== end =================



void
fft_convolution_core1(double *f, double *g, ulong ldn, double v/*=0.0*/)
// auxiliary routine for FFT based convolutions
// supply a value for v for a normalization factor != 1/n
// f and g must not overlap
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    const ulong n  = (1<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    g[0]  *= f[0] * v;
    const ulong nh = n/2;
    g[nh] *= f[nh] * v;

    for (ulong i=1,j=n-1; i<j; ++i,--j)
    {
        cmult_n(f[i], f[j], g[i], g[j], v);
    }
}
//================== end =============


void
fft_convolution_core2(double *f, double *g, ulong ldn, double v/*=0.0*/)
// auxiliary routine for FFT based convolutions
// supply a value for v for a normalization factor != 1/n
// f and g must not overlap
{
#ifdef PARANOIA
    jjassert( f!=g );
#endif

    const ulong n  = (1<<ldn);

    if ( v==0.0 )  v = 1.0/n;

    g[0]  *= f[0] * v;
    const ulong nh = n/2;
    g[nh] *= f[nh] * v;
    for (ulong i=1,j=nh+1; i<nh; ++i,++j)
    {
        cmult_n(f[i], f[j], g[i], g[j], v);
    }
}
//================== end =============
