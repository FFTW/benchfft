
#include "jjassert.h"

#include "fxt.h"
#include "zip.h"


void
complex_to_real_imag(Complex *c, long n)
//
// this routine transforms
// complex data into two seperate fields
// with real and imag data (inplace)
//
// n := array length
{
    unzip((double *)c, 2*n);
}
//============= end  ============


void
real_imag_to_complex(double *fr, double *fi, long n)
//
// this routine transforms
// two seperate fields with real and imag
// data into complex data (inplace)
// (the data must lie in contiguous memory)
//
// n := array length
{
    jjassert( fi==fr+n ); // assert contiguous memory
    zip(fr, 2*n);
}
//============= end ============


void
complex_fft(Complex *c, ulong ldn, int is)
//
// FFT wrapper to use the routines that use the data
// in the real/imag form for type complex data
//
// ldn := base-2 logarithm of the array length
// is := sign of the transform (+1 or -1)
{
    const ulong n = (1<<ldn);

    double *fr = (double *)c;
    double *fi = fr + n;

    complex_to_real_imag(c,n);

    fht_fft(fr,fi,ldn,is);

    real_imag_to_complex(fr,fi,n);
}
//=========================== end ==========================


void
real_imag_fft(double *fr, double *fi, ulong ldn, int is)
//
// FFT wrapper to use the routines that use the data
// in the complex form for data in real/imag form
//
// ldn := base-2 logarithm of the array length
// is := sign of the transform (+1 or -1)
{
    const ulong n  = (1<<ldn);
    jjassert( fi==fr+n ); // assert contiguous memory

    Complex *c = (Complex *)fr;

    real_imag_to_complex(fr,fi,n);

    //  here goes *YOUR* type Complex FFT:
    fht_fft(c,ldn,is);

    complex_to_real_imag(c,n);
}
//=========================== end ==========================

