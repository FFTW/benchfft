
#include <stdlib.h>  // strtol()

#include <iostream.h>

#include "bitslazy.h"
#include "auxlazy.h"

#include "jjassert.h"


char *vv[] =
{
    "00000001",
    "00000011",
    "01010011",
    "01011001",
    "01111111",
    "11111111",
    "00010111",
    "00000000" // ZERO
};
// -------

void
print_val(ulong x)
{
    cout << " = ";
    cout.width(5);
    cout << x;
}
// --------------------------

void
print_bin_nn(ulong x, int pd, int pv)
{
    print_bin_nn(x, pd);
    if ( pv )  print_val(x);
}
// --------------------------


int pd = 8;
ulong m = (1UL<<pd) - 1;

void
www(ulong x, ulong y)
{
    print_bin_nn(x, pd, 1);  cout << "    ";
    print_bin_nn(y, pd, 1);  cout << "    ";

    ulong g  = gcd(x, y);
    ulong gx = gcd(x, m);
    ulong gy = gcd(y, m);
    print_val(g);
    print_val(gx);
    print_val(gy);

    cout << "    ";
    print_bin_nn(x/g, pd, 1);  cout << "    ";
    print_bin_nn(y/g, pd, 1);  cout << "    ";
//    cout << endl;
}
// --------------------------


int
main(int argc, char **argv)
{
    ulong v = 0;
//    if ( argc>1 )  v = strtoul(argv[1], 0, 2); // bit pattern from arg
//    cout << "v=" << v << endl;
//    print_bin("V",v, pd);
    cout << endl;

    for (ulong i=1; i<18; ++i)
    {
        v = strtoul(vv[i], 0, 2);
        if ( 0==v )  break;
        ulong x = v;

        print_bin_nn(x, pd);  cout << "::" << endl;
        for (ulong s=0; s<pd; ++s)
        {
            cout << "  s= "; cout.width(2); cout << s << ":  ";
            ulong y = rotate_left(x, s, pd);
            www(x, y);

//            cout << "   " << cyclic_match(x, y, pd);
            cout << endl;
        }
        cout << endl;
    }

    return 0;
}
// --------------------------
