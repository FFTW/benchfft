
#include "fxt.h"
#include "fxtauxlazy.h"

#include <math.h>
#include <limits.h>

// dummy to test predefines ...
