
#include <math.h>
#include <iostream.h>
#include <iomanip.h>

#include "mod.h"
#include "modm.h"
#include "bits2pow.h"

umod_t
strtol64(const char *str)
{
    umod_t z = 0;
    int k = 0;
    umod_t rx = 10;

    while ( str[k]==' ' )  k++;

    if ( str[0]=='0' && str[1]=='x' )
    {
        rx = 16;
        k += 2;
    }

    while ( str[k] )
    {
        z *= rx;
        unsigned char c = str[k];
        if ( c>='0' && c<='9' )  c -= '0';
        else
        {
            if ( rx==10 )  jjassert2( 0, "error in (dec) strtol64()" );

            if ( c>='a' && c<='f' )  c -= 'a';
            else
            {
                if ( c>='A' && c<='F' )   c -= 'A';
                else  jjassert2( 0, "error in (hex) strtol64()" );
            }

            c += 10;
        }

        z += c;
        k++;
    }

    return z;
}
//-------------------------------------------

