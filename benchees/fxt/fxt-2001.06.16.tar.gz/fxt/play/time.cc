
#include <iostream.h>
#include <stdlib.h>
//#include <builtin.h>
#include "jjassert.h"

#include "fxt.h"
#include "fxtauxlazy.h"
#include "matrix/ldn2rc.h"
#include "permutelazy.h"
#include "graypermute.h"


#define  invclock  (1.0/(366*1024*1024))

#define rdtsc(lo, hi) \
asm("rdtsc" : "=a" (lo), "=d" (hi))


#define  get_time(z) \
{ rdtsc(tlo, thi);  z = invclock*(thi*(4.0*1024*1024*1024)+tlo); }

#define  STR(s)  #s

#define TT(CODE) \
{ \
  null( f, n ); \
  cout.width(25);  cout << STR(CODE); cout.flush(); \
  get_time(t); \
  for (ulong ct=0; ct<m; ++ct)  {CODE}; \
  get_time(dt); \
  dt -= t; \
  dt /= m; \
  cout << "    dt="; cout.width(8); cout << dt; \
  if ( dt1==0 )  dt1 = dt; \
  cout << "   rel="; cout.width(8); cout << dt/dt1; \
  cout << endl; \
}


int
main(int argc, char **argv)
{
    double t, dt, dt1=0;
    ulong tlo, thi;

    ulong ldn = 22;
    if ( argc>1 )  ldn = atol(argv[1]);
    ulong  n = (1<<ldn);
    ulong ldn2 = ldn + 1,  n2 = 2*n;  // for real ops

    ulong m = 2;
    if ( argc>2 )  m = atol(argv[2]);


    Complex *f;
    double *fr, *fi;
    f = new Complex[n];
    fr = (double *)f;
    fi = fr + n;

    cout << "ldn=" << ldn << "  n=" << n << endl;
    cout << "repetitions: m=" << m << endl;

    int ms = n*sizeof(Complex)/1024;
    cout << "memsize=" << ms << " kiloByte" << endl;
    cout << endl;

    fill_seq(fr, n2);  // touch memory
    
    ulong y = n;
    gray_permute(fr, y);
    inverse_gray_permute(fr, y);
    jjassert( is_seq(fr, y) );

    TT( reverse(fr,n2); );

    TT( revbin_permute(fr,n2); );
//    TT( test(fr,n2); );

    TT( revbin_permute0(fr,n2); );
    TT( reverse(fr,n2); );

    TT( gray_permute(fr,n2); );
    TT( reverse(fr,n2); );

    TT( inverse_gray_permute(fr,n2); );

//    TT( fht_auto_convolution0(fr,ldn); );
//    TT( matrix_auto_convolution0(fr,ldn); );
//    TT( fht(fr,ldn); );
//
//    TT( dif2_walsh_wak(fr,ldn); );
//    TT( dit2_walsh_wak(fr,ldn); );
//    TT( dif2_walsh_wak_slow(fr,ldn); );
//    TT( dit2_walsh_wak_slow(fr,ldn); );
//
//    TT( null(f,n); );
//    TT( fht(fr,ldn2); );
//    TT( fht(f,ldn); );
//
//    TT( fht_fft(fr,fi,ldn,+1); );
//    TT( matrix_fft(fr,fi,ldn,+1); );
//
//    ulong r, c;  ldn2rc(ldn, r, c);  TT( matrix_transpose2(f,r,c); );
//    TT( revbin_permute0(f,n); );
//    TT( revbin_permute(f,n); );
//
//    TT( matrix_auto_convolution0(f,ldn); );
//    TT( matrix_complex_auto_convolution0(fr,fi,ldn); );
//
//    TT( matrix_auto_convolution0(fr,ldn2); );
//    TT( fht_auto_convolution0(fr,ldn2); );
//    TT( split_radix_fft_auto_convolution0(fr,ldn2); );
//
//    TT( dit2_fft(f,ldn,+1); );
//    TT( dit2_fft_localized(f,ldn,+1); );

    return 0;
}
//===========================================

