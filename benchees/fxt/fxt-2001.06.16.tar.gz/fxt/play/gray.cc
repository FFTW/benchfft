
#include "fxtauxlazy.h"
#include "graypermute.h"
#include "jjassert.h"

#include <iostream>
#include <iomanip>

void
base2print(ulong x, ulong ldn)
{
    ulong m = 1<<ldn;
    ulong u = x;
    for (ulong j=0;  j<=ldn;  ++j, m>>=1)  cout << ((u&m)? '1' : '.');
}
// =========================


template <typename Type>
void
igp(Type *f, ulong n)
{
    ulong z = 1; // mask for cycle maxima
    ulong v = 0; // ~v
    ulong cl = 1;  // cycle length
    for (ulong ldm=1, m=2;  m<n;  ++ldm, m<<=1)
    {
        cout << " -------- ldm=" << ldm << "  cl=" << cl << endl;

        z <<= 1;
        v <<= 1;
        if ( is_pow_of_2(ldm) )
        {
            ++z;
            cl <<= 1;
        }
        else  ++v;
        cout << "z=";  base2print(z, 24); cout << endl;

        ulong tv = v, tu = 0;  // cf. bitsubset.h
        cout << "v=";  base2print(tv, 24); cout << endl;
        do
        {
            tu = (tu-tv) & tv;
            ulong s = z | tu;  // start of cycle

            // do cycle:
            ulong g = gray_code(s);
            Type tt, t = f[s];
            for (ulong k=0; k<cl-1; ++k)
            {
                tt = f[g];
                f[g] = t;
                t = tt;
                g = gray_code(g);
            }
            f[g] = t;


            /*
            // do inverse cycle:
            ulong g = gray_code(s);
            Type t = f[s];
            for (ulong k=0; k<cl-1; ++k)
            {
//                cout << "g=";  base2print(g, ldm+2); cout << " = " << g << endl;
                f[s] = f[g];
                s = g;
                g = gray_code(s);
            }
            f[s] = t;
            */

        }
        while ( tu );
    }
}
// =========================

int
main()
{
//    ulong ip; // invariant pattern

    for (ulong ldn=0; ldn<=20; ++ldn)
    {
        ulong n = 1UL<<ldn;
        if ( one_bit_q(ldn) )  cout << "=========================" << endl;
        cout << " ldn=" << ldn
             << hex << " [" << n << ".." << n+n-1 << "]:" << dec
             << " (cycle length=" << (2UL<<ld(ldn)) << ")"
             << endl;

//        ulong mm = 0; // max of cycle max

        ulong mask = n+n-1; // all bits set
        ulong c = mask; // record changes in max
        for (ulong i=0; i<n; ++i)
        {
            ulong s = n+i;
//            cout << " -- s=" << s << ":" << endl;
            
            ulong g=0, j=s;
            ulong m=s;  // cyclemax
            do
            {
                g = gray_code(j);
//                cout << "j=" << j << "  g=" << g << endl;

                m = max(m, g);
                j = g;
            }
            while ( s != g );

            c &= m; // unset all bits that are zero in max
//            cout << "c=";  base2print(c, 16);  cout << endl;
//            base2print(m, 16);  cout << endl;
        }

        cout << "inv: ";  base2print(c, 24);  cout << endl;
        cout << "var: ";  base2print(mask^c, 24);  cout << endl;
        cout << endl;
    }

    ulong n = 1UL<<13;
    int f[n];
    int g[n];
    fill_seq(f, n);
//    gray_permute(f, n);
    gray_permute(f, g, n);
    gray_permute(f, n);
    for (ulong k=0; k<n; ++k)
    {
//        cout << k << ": " << f[k]
//             << "  g(k)=" << gray_code(k)
//             << "  i(k)=" << inverse_gray_code(k)
//             << endl;

        jjassert( f[k] == g[k] );
    }

    return 0;
}
// =========================


/*
 ldn=0 [1..1]: (cycle length=2)
inv: ........................1
var: .........................

=========================
 ldn=1 [2..3]: (cycle length=2)
inv: .......................11
var: .........................

=========================
 ldn=2 [4..7]: (cycle length=4)
inv: ......................111
var: .........................

 ldn=3 [8..f]: (cycle length=4)
inv: .....................111.
var: ........................1

=========================
 ldn=4 [10..1f]: (cycle length=8)
inv: ....................111.1
var: .......................1.

 ldn=5 [20..3f]: (cycle length=8)
inv: ...................111.1.
var: ......................1.1

 ldn=6 [40..7f]: (cycle length=8)
inv: ..................111.1..
var: .....................1.11

 ldn=7 [80..ff]: (cycle length=8)
inv: .................111.1...
var: ....................1.111

=========================
 ldn=8 [100..1ff]: (cycle length=16)
inv: ................111.1...1
var: ...................1.111.

 ldn=9 [200..3ff]: (cycle length=16)
inv: ...............111.1...1.
var: ..................1.111.1

 ldn=10 [400..7ff]: (cycle length=16)
inv: ..............111.1...1..
var: .................1.111.11

 ldn=11 [800..fff]: (cycle length=16)
inv: .............111.1...1...
var: ................1.111.111

 ldn=12 [1000..1fff]: (cycle length=16)
inv: ............111.1...1....
var: ...............1.111.1111


 ldn=13 [2000..3fff]: (cycle length=16)
inv: ...........111.1...1.....
var: ..............1.111.11111

 ldn=14 [4000..7fff]: (cycle length=16)
inv: ..........111.1...1......
var: .............1.111.111111

 ldn=15 [8000..ffff]: (cycle length=16)
inv: .........111.1...1.......
var: ............1.111.1111111

=========================
 ldn=16 [10000..1ffff]: (cycle length=32)
inv: ........111.1...1.......1
var: ...........1.111.1111111.

 ldn=17 [20000..3ffff]: (cycle length=32)
inv: .......111.1...1.......1.
var: ..........1.111.1111111.1

 ldn=18 [40000..7ffff]: (cycle length=32)
inv: ......111.1...1.......1..
var: .........1.111.1111111.11

 ldn=19 [80000..fffff]: (cycle length=32)
inv: .....111.1...1.......1...
var: ........1.111.1111111.111

 ldn=20 [100000..1fffff]: (cycle length=32)
inv: ....111.1...1.......1....
var: .......1.111.1111111.1111

*/
