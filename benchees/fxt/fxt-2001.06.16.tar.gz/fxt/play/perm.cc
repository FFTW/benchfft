
#include "fxttypes.h"
#include "bitlow.h"
#include "copy.h"
#include "rotate.h"
#include "jjassert.h"
#include "revbin.h" // revbin()

#include <iostream.h>
#include <iomanip.h>

void
dump(ulong *f, ulong n)
{
    for (ulong i=0; i<n; ++i)
    {
        cout.width(2);
        cout << f[i];
    }
    cout << endl;
}
//-----------------

inline ulong
asm_bt(ulong *f, ulong i)
{
    ulong ret;
    asm ( "btl  %2, %1 \n"
          "sbbl %0, %0"
          : "=r" (ret)
          : "m" (*f), "r" (i) );
    return ret;
}
//-----------------

ulong test(ulong *f, ulong n)
{
    ulong d = n / BITS_PER_LONG;
    ulong bm = 1UL << (n % BITS_PER_LONG); 
    ulong t = bm & f[d];
    ulong tt = (asm_bt(f, n) ? bm : 0);
    cout << hex << "word="; cout.width(8); cout << f[d]
         << "  bm="; cout.width(8); cout << bm
         << "  idx="; cout.width(8); cout << n
         << "  t="; cout.width(8); cout  << t
         << "  tt="; cout.width(8); cout << tt
         << dec
         << (t ? "  ***" : "")
         << endl;

    jjassert( tt == t );
    return  t;
}
//-----------------

int
main()
{
    ulong f[] = {0, 0x50a0, 0x040abcd};
    ulong n = sizeof(f)*8;
    cout << hex << "word@"; cout.width(8); cout << f << endl;
    for (ulong k=0; k<n; ++k)
    {
        test(f, k);
    }


//    cout << hex;
//    ulong ldn = 6;
//    ulong n = 1UL<<ldn;
//    for (ulong k=0; k<n; k+=2)
//    {
//        ulong r = revbin(k,ldn);
//        long d = (r-k);
//        cout.width(3);
//        cout << k << " <--> ";
//        cout.width(3);
//        cout << r << "   ";
//        cout.width(3);
//        cout << ( d>0 ? d : 0) << endl;
//    }

    return 0;
}
//-----------------
