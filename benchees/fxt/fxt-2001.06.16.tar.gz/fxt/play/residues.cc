
#include "modm.h"
#include "mod.h"
#include "inline.h"

#include <iostream.h>

int
main()
{
    umod_t x = 727237;
//    for (umod_t m=x; m<x+162; m+=2)
//    {

    for (umod_t ldm=2; ldm<62; ++ldm)
    {
        umod_t m = ((umod_t)1<<ldm)-1;
        cout << "  ldm=" << ldm;


        cout << "  m=" << m;
        factorization mf(m);
        int pq = mf.is_prime();

        if ( pq ) cout << " PRIME ";
        else      cout << "   " << mf;
        cout << endl;


        umod_t s = 0;
        umod_t am = min((umod_t)250, m);
        for (umod_t a=1; a<am; a+=1)
        {
            int ap = is_quadratic_residue(a, mf);
            int am = is_quadratic_residue(m-a, mf);
//            if ( ap || am )  cout << ".";
//            else             cout << " ";
            
            int kp = kronecker(a, m);
            int km = kronecker(m-a, m);
//            if ( ap || am )
            if ( kp && km )
            {
//                cout << ":";
            }
            else
            {
//                cout << " ";
                if ( 0==s )  s = a;
            }
        }
//        cout << endl;
        if ( s )  cout << "s = " << s << endl;
        cout << endl;
    }

    return 0;
}
// -------------------
