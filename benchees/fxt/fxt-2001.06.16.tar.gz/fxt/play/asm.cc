
#include "cmult.h"

#include "fxttypes.h"
#include "revbin.h"
#include "bitslazy.h"


void
asm_prefetch(void *x)
{ asm("
movl  4 (%esp), %eax
prefetch  (%eax)
");
}
//------------------------

#include "sumdiff.h"

// JJBEGIN


ulong bswap(ulong x)
// compiled to:
// movl %eax,%edx
// rolw $8,%dx
// shrl $16,%eax
// rorw $8,%ax
// sall $16,%edx
// andl $65535,%eax
// orl %eax,%edx
{
    unsigned short z1 = (unsigned short)(x);
    z1 = (z1<<8) | (z1>>8);

    unsigned short z2 = (unsigned short)(x>>16);
    z2 = (z2<<8) | (z2>>8);

    return  ulong(z1)<<16  |  ulong(z2);
}
// --------------------------

ulong bswab(ulong x)
{
    return
        ((x & 0x000000ffUL) << 24) |
        ((x & 0x0000ff00UL) <<  8) |
        ((x & 0x00ff0000UL) >>  8) |
        ((x & 0xff000000UL) >> 24);
}
// --------------------------

double f[] = {12340001,12340002,12340003,12340004};


inline void
fht_dif_core_4(double *f)
{
   double f0, f1;
   double f2, f3;
   sumdiff(f[0], f[2], f0, f1);
   sumdiff(f[1], f[3], f2, f3);
   sumdiff(f0, f2, f[0], f[1]);
   sumdiff(f1, f3, f[2], f[3]);
}
// ==============

//#define __restrict

void
CORE1(double * __restrict f, double * __restrict g, ulong ldn)
{
    const ulong n  = (1<<ldn);
    g[0]  *= f[0];
    const ulong nh = n/2;
    g[nh] *= f[nh];

    for (ulong i=1,j=n-1; i<j; ++i,--j)
    {
        cmult(f[i], f[j], g[i], g[j]);
    }
}
// ==============



//void
//somefunc()
//{
//    fht_dif_core_4(f);
//}
////------------------------

void jjend() { /*JJEND*/;}
