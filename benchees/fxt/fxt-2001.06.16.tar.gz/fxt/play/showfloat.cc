
#include <iostream.h>
#include <math.h>

// cf.
// /usr/include/ieee754.h
// /usr/include/endian.h


void
bitwise_print(double d)
{
    unsigned long long *u = (unsigned long long *)&d;
    unsigned long long m = 1ULL<<63;

    int i = 63;
    for (  ; i>=0; --i)
    {
        cout << ( *u&m ? '1' : '0' );
        if ( i && !(i&15) )  cout << ' ';
        *u <<= 1;
    }
}
//------------------------------


int
main()
{
    double t, d;
//    unsigned long long *u = (unsigned long long *)&t;
//    unsigned long long m = 1ULL<<63;

    cout.precision(23);

    d = 65536+3;
    double z = 3; //ldexp(1,52);
    cout << "  z= " << z << endl;

    for (int e=-2; e<=2; ++e)
    {
        t = d + z;
        cout << d << " + z" << " = " << t << " ==" << endl;

        bitwise_print(t);
        cout << endl;
        cout << "sEEEEEEEEEEEmmmm mmmmmmmmmmmmmmmm mmmmmmmmmmmmmmmm mmmmmmmmmmmmmmmm";
        cout << endl;

        d *= -1;
        cout << endl;
    }

    return 0;
}
//------------------------------
