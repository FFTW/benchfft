#include <math.h>
#include "jjassert.h"
#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#include <time.h>  // time()
#include <stdlib.h> // atol()

#include "fxt.h"
#include "fxtauxlazy.h"
#include "matrix/ldn2rc.h"

#include "testaux.cc"  // yuck

#define CHOP(x,eps)  (fabs(x)<(eps) ? 0 : (x))

void
prseq(double *f, ulong n)
{
    for (ulong k=0; k<n; ++k)
    {
        double fk = f[k];
        if ( fabs(fk)<1.0e-7 )  fk = 0.0;

//        if ( k && 0==k%8 )  cout << ", ";
        cout << endl;

        cout << setw(2) << k << ":  ";
        cout << setw(12) << fk;
    }
    cout << endl;
}
// ================= end ==================


void
dif_fht_core__(double *f, ulong ldn)
{
    if ( ldn<=2 )
    {
        if ( ldn==1 )  // two point fht
        {
        }
        else if ( ldn==2 )  // four point fht
        {
        }
        return;
    }

    const ulong n = (1<<ldn);
    const double *fn = f + n;
    ulong ldk = ldn - 2;

    for (  ; ldk>2;  ldk-=2)
    {
        ulong k   = 1 << ldk;
        ulong kh  = k >> 1;
        ulong k2  = k << 1;
        ulong k3  = k2 + k;
        ulong k4  = k2 << 1;
        cout << "==== ldk = " << ldk << "  kh=" << kh << endl;

        for (double *fi=f, *gi=f+kh;  fi<fn;  fi+=k4, gi+=k4)
        {
        }

        double tt = M_PI_4/kh;
        for (ulong i=1; i<kh; i++)
        {
//            cout << "---- i = " << i << endl;
            double s1, c1;
            sincos(tt*i, &s1, &c1);
            cout << " ph = Pi/4 * " << i << "/" << kh; 
            cout << "    c1=" << setw(9) << c1;
            cout << "  s1=" << setw(9) << s1;

            double c2, s2;
            csqr(c1, s1, c2, s2);
            cout << "   c2=" << setw(9) << c2;
            cout << "  s2=" << setw(9) << s2;

            cout << endl;

            for (double *fi=f+i, *gi=f+k-i;  fi<fn;  fi+=k4, gi+=k4)
            {
            }
        }
    }

}
// =====================


int
main(int argc, char **argv)
{
    ulong ldn = 4;
    if ( argc>1 )  ldn = atol(argv[1]);
    ulong  n = (1<<ldn);
//    ulong  nh = n/2, n4 = n/4;

    ulong delta = 1;
    if ( argc>2 )  delta = atol(argv[2]);
    if ( delta>=n )  delta = n-1;
    cout << "ldn=" << ldn << "  n=" << n << "  delta=" << delta << endl;


//    dif_fht_core__(0, ldn);
//    return 0;


    Complex *ac = new Complex[n];   null( ac, n );
    Complex *fc = new Complex[n];   null( fc, n );
    Complex *gc = new Complex[n];   null( gc, n );
    double *ar, *ai, *fr, *fi, *gr, *gi;
    ar = (double *)ac;  ai = ar + n;
    fr = (double *)fc;  fi = fr + n;
    gr = (double *)gc;  gi = gr + n;

    null(ac, n);
    //   ar[1] = ai[1] = 1;
//    for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), white_noise());
    //   for (ulong i=0; i<n; ++i)  ac[i] = Complex(white_noise(), 0.0 );
   fill_seq(ar, 2*n, 1.0, 1.0);
//    fill(ar, 2*n, 1.0);

   for (ulong i=0; i<n; ++i)  ar[i] = cos(3*i*M_PI/n) * cos(5*i*M_PI/n);
//   for (ulong i=0; i<n; i+=2)  ar[i] = 0.0;

    copy(ac, fc, n);
    copy(ac, gc, n);

    for (ulong k=0; k<n; ++k)
    {
        null(fr, n);
        fr[k] = 1;
//        for (ulong r=0; r<delta; ++r)  walsh_seq(fr, ldn);

//        hartley_shift_05(fr, n);
        fht(fr, ldn);

//        for (ulong i=0, j=n-1;  i<j;  ++i, --j)  sumdiff(fr[i], fr[j]); 
        dst(fr, ldn);
//        for (ulong i=0, j=n-1;  i<j;  ++i, --j)  sumdiff(fr[i], fr[j]); 

        multiply(fr, n, 1.0/n);

//        double v = fabs(fr[first_ne_idx(fr, n, 0.0)]);
//        multiply(fr, n, 1.0/v);

        cout << setw(2) << k << ":  [";
        for (ulong j=0; j<n; ++j)
        {
//            cout << setw(3) << (fr[j]>0 ? " X " : " . ");
            cout.precision(4);
            cout << setw(9) << CHOP(fr[j],1e-6) <<  "";
        }
        cout << "] ";
//        cout << setw(2) << sequency(fr, n) << endl;
        cout << endl;
    }

//    cout << "     ";
//    for (ulong j=0; j<n; ++j)  cout << "  ^";
//    cout << endl;
//    cout << "     ";
//    for (ulong j=0; j<n; ++j)  cout << setw(3) << j;
    cout << endl;

    return 0;
}
//===========================================


// xv tmp.pgm -geometry 512x512 -raw &
// killall -QUIT xv
