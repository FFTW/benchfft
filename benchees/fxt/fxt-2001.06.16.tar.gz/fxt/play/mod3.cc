
#include "fxt.h"
#include "fxtauxlazy.h"

#include "jjassert.h"
#include <iostream.h>
#include <iomanip.h>

ulong
mod3(ulong x)
// return x % 3
{
    cout << "  X=" << x << "  ==" << x%3 << " %3"
         << "  ==" << x%255 << " %255" << endl;

    ulong b = 0x00ff00ff;
    x = (x & b) + ((x>>8) & b);       // 0..512-2 in 9 bits
    cout << "  X=" << x << endl;
    x +=  x>>16;                      // 0..1024-4 in 10 bits
    cout << "  X=" << x << endl;
    x &= 0xffff;
    cout << "  X=" << x << "  ==" << x%3 << " %3"
         << "  ==" << x%255 << " %255" << endl;

    // here: x%255 == arg%255

    ulong m = 0x3333;
    x = (x & m) + ((x>>2) & m);    // 0-6 in 4 bits
    cout << "  .x=" << x << endl;
    x = ((x>> 4) + x) & 0x0f0f;    // 0-12 in 8 bits
    cout << "  .x=" << x << endl;
    x = ((x>> 8) + x) & 0x00ff;    // 0-24 in 8 bits
    cout << "  .x=" << x << endl;

//    cout << "  X=" << x << endl;
    while ( x>=3 )  { cout << "M";  x-=3; }

    cout << "  X=" << x << "  ==" << x%3 << " %3" << endl;
    cout << endl;
    return x;
}

int
main()
{
    cout << setbase(16);
    for (ulong i=0; i<1000; ++i)
    {
        ulong s = (ulong)random();
        ulong m = mod3(s);
        jjassert( (m%3) == (s%3) );
    }
    return 0;
}
