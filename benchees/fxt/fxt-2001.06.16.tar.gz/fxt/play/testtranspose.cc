
//  gcc -Ifxt -Ifxt/include transpose.cc -o transpose -lstdc++

#include "fxt.h"
#include "jjassert.h"
#include "auxil2d/transpose.h"

#include <iostream.h>


template <typename Type>
void
print(const Type *f, ulong nr, ulong nc)
{
    for (ulong k=0; k<nr; ++k)
    {
        cout.width(2);
        cout << k << ":  ";
        for (ulong j=0; j<nc; ++j)
        {
            cout.width(8);
            cout << f[j+k*nc];
        }
        cout << endl;
    }
}
//-----------------------


ulong nrnc[] =
{
    3, 5,
    3, 3,
    4, 4,
    2, 5,
    5, 2,
    7, 6,
    7, 8,
    0, 0,
};
//-----------------------

int
main()
{
    ulong f[1000];

    ulong nr, nc, n;
    int ct = 0;

    while ( (nr=nrnc[ct]) )
    {
        nc = nrnc[ct+1];
        ct +=2;
        n = nr*nc;

        for (ulong i=0; i<n; ++i)  f[i] = i;

        print(f, nr, nc);  cout << endl;
        transpose(f, nr, nc);
        print(f, nc, nr);  cout << endl;
        transpose(f, nc, nr);

        for (ulong i=0; i<n; ++i)
        {
            if ( f[i] != i )
            {
                print(f, nr, nc);  cout << endl;
                jjassert(0);
            }
        }
        cout << endl;
        cout << endl;
    }
}
//-----------------------
