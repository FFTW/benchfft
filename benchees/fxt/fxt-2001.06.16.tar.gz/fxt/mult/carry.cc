
#include "fxtmult.h"

#include <math.h>
#include "jjassert.h"


inline void
d_divmod(double &a, double &cy, double drx, double d1rx)
{
    a = floor( drx * modf( (a+cy+0.5)*(d1rx), &cy) );
}
// -------------------


// a few jjasserts outside loops that trap many errors:
#define  CARRYCHECK  1  // 0 or 1 (default)

ulong
carry(double *a, ulong n, uint rx)
//
//  carry operation for fft-multiplication (and sqr)
//
//  returns:
//  if(no overflow)  0;
//  else: the new most significant digit
//
{
#if  ( CARRYCHECK==1 )
    double ns = (double)rx-1;  ns *= ns;
    jjassert( ns >= floor(0.5+a[0]) );
    jjassert( ns >= floor(0.5+a[n-2]) );
    jjassert( 0  == floor(0.5+a[n-1]) );
#endif // CARRYCHECK==1

    double cy = 0.0;
    carry_thru(a, n, rx, cy);

    if ( cy==0 )  return 0;
    else
    {
        cy = floor(0.5+cy);
#if  ( CARRYCHECK==1 )
        jjassert( cy >= 0 );
        jjassert( cy < rx );
#endif  // CARRYCHECK==1
        return (ulong)cy;
    }
}
//========================== end =================================



void
carry_thru(double *a, ulong n, uint rx, double &cy)
// carry through region a[n-1,...,0]
{
    const double drx  = (double)rx;
    const double d1rx = 1.0/drx;
    n--;
    do
    {
//        jjassert( fabs(a[n]-floor(0.5+a[n])) < 0.25 );

        d_divmod(a[n], cy, drx, d1rx);

//        jjassert( a[n]>=0 );
//        jjassert( cy>=0 );
    }
    while ( n-- );
}
//===================== end =======================
