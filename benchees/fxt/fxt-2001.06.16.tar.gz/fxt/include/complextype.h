#if !defined HAVE_COMPLEXTYPE_H__
#define      HAVE_COMPLEXTYPE_H__

//#include <math.h>
#include <complex.h>
#define  Complex  complex<double>
//typedef  complex<double>  Complex;


#endif // !defined HAVE_COMPLEXTYPE_H__
