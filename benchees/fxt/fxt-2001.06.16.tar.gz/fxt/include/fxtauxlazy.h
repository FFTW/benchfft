#if !defined HAVE_FXTAUXLAZY_H__
#define      HAVE_FXTAUXLAZY_H__


// include file for the lazy:
// include the whole planet here

#include "fxttypes.h"
#include "complextype.h"

#include "cmult.h"
#include "sumdiff.h"

#include "constants.h"
//#include "fxt.h"
#include "jjassert.h"


#include "auxlazy.h"
#include "aux2dlazy.h"
#include "bitslazy.h"
#include "permutelazy.h"


#endif // !defined HAVE_FXTAUXLAZY_H__
