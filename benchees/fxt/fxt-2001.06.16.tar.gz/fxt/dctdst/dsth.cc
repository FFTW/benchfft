
#include "fxt.h"
#include "inline.h"


void
dsth(double *x, ulong ldn, double *tmp/*=0*/)
// basis: sin((k+1)*(i+0.5)*M_PI/n) * sqrt(2)
// ldn := base-2 logarithm of the array length
// tmp := (optional) pointer to scratch space
{
    ulong n = (1<<ldn);
    for (ulong k=1; k<n; k+=2)  x[k] = -x[k];
    
    dcth(x, ldn, tmp);
    
    for (ulong k=0,j=n-1;  k<j;  ++k,--j)  swap(x[k], x[j]);
}
// =============== end ===========


void
idsth(double *x, ulong ldn, double *tmp/*=0*/)
// inverse of dsth()
// ldn := base-2 logarithm of the array length
// tmp := (optional) pointer to scratch space
{
    ulong n = (1<<ldn);
    for (ulong k=0,j=n-1;  k<j;  ++k,--j)  swap(x[k], x[j]);

    idcth(x, ldn, tmp);

    for (ulong k=1; k<n; k+=2)  x[k] = -x[k];
}
// =============== end ===========
