
#include "fxt.h"

#include "jjassert.h"

#error 'to be implemented  ;-) '

void
dct(double *f, ulong ldn, double *tmp/*=0*/)
// basis: cos((k+0.5)*(i+0.5)*M_PI/n)
// jjnote: dct() to be implemented ...
// ldn := base-2 logarithm of the array length
// tmp := (optional) pointer to scratch space
{
    f = 0;
    ldn = 0;
    tmp = 0;

    jjassert(0);
}
// ============= end ===============
