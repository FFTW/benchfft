
#include "copy.h"
#include "fxt.h"


void
slow_row_column_ht(double *f, ulong r, ulong c)
{
    ulong n = r*c;

    // ht over rows:
    for (ulong k=0; k<n; k+=c)  slow_ht(f+k,c);

    double *w = new double[r];

    // ht over columns:
    for (ulong k=0; k<c; k++)
    {
        skip_copy(f+k,w,r,c);
        slow_ht(w,r);
        skip_copy_back(w,f+k,r,c);
    }

    delete [] w;
}
// =============== end ===========
