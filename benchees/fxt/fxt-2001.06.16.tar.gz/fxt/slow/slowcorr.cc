
#include "jjassert.h"

#include "copy.h"


void
slow_correlation(const double *f, double *g, ulong n)
// compute (real, cyclic) correlation of f[], g[]
// result is in g[]
// n := array length
//
// (use zero padded data for usual co.)
//
// slow_correlation(f, g, n)  =^=
// reverse(g, n); slow_convolution(f, g, n); reverse(g, n);
{
    double *r=new double[n];

    long ns=(long)n;
    for (long tau=0;  tau<ns;  ++tau)
    {
        double s=0.0;
        for (long k=0; k<ns; ++k)
        {
             long k2 = k + tau;
             if ( k2>=ns )  k2-=ns;

             s += (g[k]*f[k2]);
        }

        r[tau] = s;
    }

    copy(r, g, n);

    delete [] r;
}
// ============== end ================


void
slow_correlation0(const double *f, double *g, ulong n)
// compute (real, linear) correlation of f[], g[]
// result is in g[]
// n := array length
//
// version for zero padded data:
//   f[k],g[k] == 0 for k=n/2 ... n-1
//
// n must be >=2
{

//    if ( n<=1 )
//    {
//        if ( n==1 )  g[0] *= f[0];
//        return;
//    }

    double *r=new double[n];

    long ns=(long)n, nh=ns/2;
    long tau;
    for (tau=0; tau<nh; ++tau)
    {
        double s = 0.0;
        // k2 == tau + k
        for (long k=0, k2=tau;  k2<nh;  ++k,++k2)  s += (f[k]*g[k2]);
        r[tau] = s;
    }

    for (  ; tau<ns; ++tau)
    {
        double s = 0.0;
        // k2 == tau + k
        for (long k=ns-tau, k2=0;  k<nh  ; ++k,++k2)  s += (f[k]*g[k2]);
        r[tau] = s;
    }

    copy(r, g, n);

    delete [] r;
}
// ============== end ================



void
slow_auto_correlation(double *f, ulong n)
// compute (real, cyclic) self correlation of f[]
// n := array length
{
    slow_correlation(f, f, n);
}
// ============== end ================


void
slow_auto_correlation0(double *f, ulong n)
// compute (real, linear) self correlation of f[]
// n := array length
//
// version for zero padded data:
//   f[k] == 0 for k=n/2 ... n-1
//
{
    slow_correlation0(f, f, n);
}
// ============== end ================
