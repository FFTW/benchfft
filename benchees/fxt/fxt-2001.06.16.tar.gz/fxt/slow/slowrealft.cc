
#include "copy.h"
#include "complextype.h"

// under construction

void
slow_real_complex_ft(double *f, ulong n, int is, int ord/*=1*/)
//
// (slow) real to complex fourier transform
//
{
    double *g = new double[n];
    null(g, n);
    slow_ft(f, g, n, is);
    nh = n/2;
    copy(g+1, f+nh, nh-1);
    if ( ord!=1 )  reverse(f+nh, nh);
    delete [] g;
}
// ================== end ====================


void
slow_real_complex_ft(double *f, ulong n, int is, int ord/*=1*/)
//
// (slow) complex to real fourier transform
//
{
//    double *g = new double[n];
//    null(g, n);
//    nh = n/2;
//    if ( ord!=1 )  reverse(f+nh, nh);
//    copy(f+nh, g+1, nh-1);
//    slow_ft(f, g, n, -is);
//
//    delete [] g;
}
// ================== end ====================
