
#include "fxttypes.h"
#include "copy.h"


void
slow_convolution(const double *f, const double *g, double *h, ulong n)
// (cyclic, real) convolution:  h[] :=  f[] (*) g[]
// n := array length
{
    long ns = (long)n;
    for (long tau=0;  tau<ns;  ++tau)
    {
        double s = 0.0;

//        for (long k=0; k<ns; ++k)
//        {
//            long k2 = tau-k;
//            if ( k2<0 )  k2 += ns;
//            s += (f[k]*g[k2]);
//        }

        // =^=

        long k = 0, k2 = tau;
        for (  ; k<=tau; ++k,--k2)  s += (f[k]*g[k2]);
        k2 = ns - 1;
        for (  ;  k<ns;   ++k,--k2)  s += (f[k]*g[k2]);


        h[tau] = s;
    }
}
// ============== end ================


void
slow_convolution0(const double *f, const double *g, double *h, ulong n)
// (linear, real) convolution:  h[] :=  f[] (*0) g[]
// n := array length
//
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n  must be >=2
{

//    if ( n<=1 ) // jjnote: ugly
//    {
//        if ( n==1 )  h[0] = f[0] * g[0];
//        return;
//    }

    long ns = (long)n;
    long nh = ns/2;

    long tau;
    for (tau=0; tau<nh; ++tau)
    {
        double s = 0.0;
        // k2 == tau - k
        for (long k=0, k2=tau;  k2>=0;  ++k,--k2)  s += (f[k]*g[k2]);
        h[tau] = s;
    }

    for (  ; tau<ns; ++tau)
    {
        double s = 0.0;
        // k2 == tau - k
        for (long k=tau-nh, k2=nh;  k<nh  ; ++k,--k2)  s += (f[k]*g[k2]);
        h[tau] = s;
    }
}
// ============== end ================


void
slow_auto_convolution(const double *f, double *g, ulong n)
// (cyclic, real) convolution:  g[] :=  f[] (*) g[]
// n := array length
{
    slow_convolution(f, f, g, n);
}
// ============== end ================

void
slow_auto_convolution0(const double *f, double *g, ulong n)
// (linear, real) self convolution:  g[] :=  f[] (*0) g[]
// n := array length
//
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n  must be >=2
{
    slow_convolution0(f, f, g, n);
}
// ============== end ================


void
slow_convolution(const double *f, double *g, ulong n)
// (cyclic, real) convolution:  g[] :=  f[] (*) g[]
// n := array length
{
    double *h = new double[n];
    slow_convolution(f, g, h, n);
    copy(h, g, n);

    delete [] h;
}
// ============== end ================

void
slow_convolution0(const double *f, double *g, ulong n)
// (linear, real) convolution:  g[] :=  f[] (*0) g[]
// n := array length
//
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0 and g[n/2] .. g[n-1] == 0
// n  must be >=2
{
    double *h = new double[n];
    slow_convolution0(f, g, h, n);
    copy(h, g, n);

    delete [] h;
}
// ============== end ================


void
slow_auto_convolution(double *f, ulong n)
// (cyclic, real) self convolution:  f[] :=  f[] (*) f[]
// n := array length
{
    double *h = new double[n];
    slow_convolution(f, f, h, n);
    copy(h, f, n);

    delete [] h;
}
// ============== end ================

void
slow_auto_convolution0(double *f, ulong n)
// (linear, real) self convolution:  g[] :=  f[] (*0) g[]
// n := array length
//
// input data must be zero padded:
//   f[n/2] .. f[n-1] == 0
// n  must be >=2
{
    double *h = new double[n];
    slow_convolution0(f, f, h, n);
    copy(h, f, n);

    delete [] h;
}
// ============== end ================

