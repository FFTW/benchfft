
#include "copy.h"


//#define PARANOIA 1
#ifdef PARANOIA
#include "jjassert.h"
#warning 'FYI: we have PARANOIA'
#endif


void
slow_twodim_convolution(const double *f, const double *g, double *h,
                        ulong nr, ulong nc)
//
// (cyclic, real) two-dimensional convolution:  h[][] :=  f[][] (*) g[][]
// nr := number of rows
// nc := number of columns
//
// (use zero padded data for linear convolution)
//
// h must not overlap with neither f nor g
// f may overlap with g
//
{
#ifdef PARANOIA
    jjassert( f!=h );
    jjassert( g!=h );
#endif

    long nrs = (long)nr;
    long ncs = (long)nc;
    for (long rtau=0; rtau<nrs; ++rtau)
    {
        for (long ctau=0; ctau<ncs; ++ctau)
        {
            double s=0.0;
            for (long r=0; r<nrs; ++r)
            {
                long r2 = rtau - r;
                if ( r2<0 )  r2 += nrs;

                for (long c=0; c<ncs; ++c)
                {
                    long c2 = ctau - c;
                    if ( c2<0 )  c2 += ncs;

                    s += ( f[r*ncs+c] * g[r2*ncs+c2] );
                }
            }
            h[rtau*ncs+ctau] = s;
        }
    }
}
// ============== end ================


void
slow_twodim_convolution(const double *f, double *g, ulong nr, ulong nc)
//
// (cyclic, real) two-dimensional convolution:  g[][] :=  f[][] (*) g[][]
// nr := number of rows
// nc := number of columns
//
// (use zero padded data for linear convolution)
//
// f may overlap with g
//
{
    double *h = new double[nr*nc];

    slow_twodim_convolution(f, g, h, nr, nc);

    copy(h, g, nr*nc);

    delete [] h;
}
// ============== end ================

