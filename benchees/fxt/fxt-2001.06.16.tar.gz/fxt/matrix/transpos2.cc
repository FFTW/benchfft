
#include "jjassert.h"

#include "fxttypes.h"
#include "inline.h"


void
matrix_transpose2(double *x, ulong nr, ulong nc, double *tmp/*=0*/)
//
//  matrix transpose
//  only for n*n or n*2n or 2n*n matrix !
//
// scratchspace, if given, must have size max(nr,nc)
{
    ulong i,j;
    ulong i1,i2;
    double *y, *z;

    jjassert( (nr==nc) || (nr==2*nc) || (2*nr==nc) );

    if ( nr==nc )
    {
        for (i=1; i<nr; ++i)
        {
            y = x+i*nc;
            z = x+i;
            for (j=0; j<i; ++j)
            {
                swap(*y, *z);
                y++;
                z += nc;
            }
        }
    }
    else  // nr!=nc
    {
        ulong mrc = (nr>nc ? nr : nc);  // max(nr,nc)
        double *wd;
        if ( tmp )  wd = tmp;
        else        wd = (double *)operator new (mrc*sizeof(double));

        if ( nc>nr )
        {
            ulong nch = nc/2;

            for (i=0; i<nr; ++i)
            {
                i1 = i*nc;
                i2 = i1+1;
                for (j=0; j<nch; j++)
                {
//                    i1 = i*nc + 2*j;
//                    i2 = i*nc + 2*j + 1;
                    wd[j] =   x[i1];
                    wd[nch+j] = x[i2];

                    i1 += 2;
                    i2 += 2;
                }

                i1 = i*nc;
                for (j=0; j<nc; j++)
                {
//                    x[i*nc+j] = wd[j];
                    x[i1] = wd[j];
                    i1++;
                }
            }

            for (i=0; i<nr; ++i)
            {
                i1 = i*nc;
                i2 = i;
                for (j=0; j<i; ++j)
                {
//                    i1 = i*nc + j;
//                    i2 = j*nc + i;
                    swap(x[i1], x[i2]);
                    i1++;
                    i2 += nc;
                }
            }

            for (i=0; i<nr; ++i)
            {
                i1 = i*nc+nch;
                i2 = i+nch;
                for (j=0; j<i; ++j)
                {
//                    i1 = i*nc + nch + j;
//                    i2 = j*nc + nch + i;
                    swap(x[i1], x[i2]);
                    i1++;
                    i2 += nc;
                }
            }
        }
        else  // nr>nc
        {
            ulong nrh = nr/2;
            for (i=0; i<nrh; ++i)
            {
                i1 = i*nrh;
                i2 = i;
                for (j=0; j<i; ++j)
                {
//                    i1 = i*nrh + j;
//                    i2 = j*nrh + i;
                    swap(x[i1], x[i2]);
                    i1++;
                    i2 += nrh;
                }
            }

            for (i=0; i<nrh; ++i)
            {
                i1 = nrh*(nrh+i);
                i2 = nrh*nrh+i;
                for (j=0; j<i; ++j)
                {
//                    i1 = nrh*nrh + i*nrh + j;
//                    i2 = nrh*nrh + i + j*nrh;
                    swap(x[i1], x[i2]);
                    i1++;
                    i2 += nrh;
                }
            }

            for (j=0; j<nc; ++j)
            {

                ulong i3 = 0;
                i1 = j;
                i2 = j+nrh*nrh;
                for (i=0; i<nrh; ++i)
                {
//                    i1 = j + i*nc;
//                    i2 = j + nrh*nrh + i*nc;
//                    wd[2*i] =   x[i1];
//                    wd[2*i+1] = x[i2];
                    wd[i3] =   x[i1];
                    wd[++i3] = x[i2];
                    i3++;
                    i1 += nc;
                    i2 += nc;

                }

                i1 = j;
                for (i=0; i<nr; ++i)
                {
//                    i1 = j + i*nc;
                    x[i1] = wd[i];
                    i1 += nc;
                }
            }
        }

        if ( !tmp )  operator delete(wd);
    }
}
//==================================================================
