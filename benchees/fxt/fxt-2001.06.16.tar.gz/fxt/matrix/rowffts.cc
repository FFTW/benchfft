
#include "fxt.h"
#include "bits2pow.h" // ld()

#define  FFT(fr,fi,ldn,is)  fht_fft(fr,fi,ldn,is)
#define  FFTC(f,ldn,is)  fht_fft(f,ldn,is)


void
row_ffts(double *fr, double *fi, ulong nr, ulong nc, int is)
//
// nr x nc matrix (nr rows of length nc)
//
{
    ulong ldc = ld(nc);
    double *pr = fr,  *pi = fi;
    for (ulong k=0; k<nr; ++k)
    {
        FFT(pr, pi, ldc, is);  // jjnote: cache problem !

        pr += nc;
        pi += nc;
    }
}
// ==========================================


void
row_weighted_ffts(double *fr, double *fi, ulong nr, ulong nc, int is)
//
// nr x nc matrix (nr rows of length nc)
//
{
    ulong ldc = ld(nc);
    double *pr = fr,  *pi = fi;
    for (ulong k=0; k<nr; ++k)
    {
        fourier_shift(pr, pi, nc, 1.0*is*k/nr);  // jjnote: cache problem !
        FFT(pr, pi, ldc, is);  // jjnote: cache problem !

        pr += nc;
        pi += nc;
    }
}
// ==========================================


void
row_ffts(Complex *f, ulong nr, ulong nc, int is)
//
// nr x nc matrix (nr rows of length nc)
//
{
    ulong ldc = ld(nc);
    Complex *p = f;
    for (ulong k=0; k<nr; ++k)
    {
        FFTC(p, ldc, is);
        p += nc;
    }
}
// ==========================================


void
row_weighted_ffts(Complex *f, ulong nr, ulong nc, int is)
//
// nr x nc matrix (nr rows of length nc)
//
{
    ulong ldc = ld(nc);
    Complex *p = f;
    for (ulong k=0; k<nr; ++k)
    {
        fourier_shift(p, nc, 1.0*is*k/nr);
        FFTC(p, ldc, is);
        p += nc;
    }
}
// ==========================================

