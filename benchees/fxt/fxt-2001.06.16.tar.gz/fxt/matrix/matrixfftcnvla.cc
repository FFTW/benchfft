
#include "fxt.h"
#include "bits2pow.h" // ld()
#include "copy.h"
#include "ldn2rc.h"

#define  FFT(fr,fi,ldn,is)  fht_fft(fr,fi,ldn,is)

// tuning parameter:
#define  CP_ROWS  1  // 0 or 1 (use scratch space, default)
#if  ( CP_ROWS==1 )
#warning 'FYI: matrix_fft_auto_convolution() does row FFTs in scratch space'
#else
#warning 'FYI: matrix_fft_auto_convolution() does row FFTs inplace'
#endif


void
matrix_fft_auto_convolution(double *f, ulong ldn)
// (cyclic, real) self convolution:  f[] :=  f[] (*) f[]
// ldn := base-2 logarithm of the array length
{
    if ( ldn<=1 )  // jjnote: slightly ugly
    {
        if ( ldn==1 )
        {
            double t0 = f[0] * f[0] + f[1] * f[1];
            double t1 = f[0] * f[1];  t1 += t1;
            f[0] = t0;
            f[1] = t1;
        }
        else  f[0] *= f[0];

        return;
    }

    ulong nr, nc;
    ldn2rc(ldn, nr, nc);
    matrix_fft_auto_convolution(f, nr, nc, 0);
}
// ============================


void
matrix_fft_auto_convolution0(double *f, ulong ldn)
// (linear, real) self convolution:  f[] :=  f[] (*0) f[]
// ldn := base-2 logarithm of the array length
// version for zero padded data:
//   f[k] == 0 for k=n/2 ... n-1
// n = 2**ldn  must be >=2
{
    if ( ldn<=1 )  // jjnote: slightly ugly
    {
        if ( ldn==1 )
        {
            double t0 = f[0] * f[0] + f[1] * f[1];
            double t1 = f[0] * f[1];  t1 += t1;
            f[0] = t0;
            f[1] = t1;
        }
        else  f[0] *= f[0];

        return;
    }

    ulong nr, nc;
    ldn2rc(ldn, nr, nc);
    matrix_fft_auto_convolution(f, nr, nc, 1);
}
// ============================


void
matrix_fft_auto_convolution(double *f, ulong nr, ulong nc, int zp/*=0*/)
// auxiliary routine for real self convolutions via matrix FFT
//
// call with zp==1 if high half of data is zero (for linear convolution)
{
    ulong n = nr * nc;
    ulong nh = n / 2;
    ulong ldc = ld(nc);

#if  ( CP_ROWS==1 )
    ulong mrc = 2 * (nr>nc ? nr : nc);
    double *tr = (double *)operator new( 2*mrc * sizeof(double) ); // jjnote: mem allocation
    double *ti = tr + mrc;
#else
    double *tr = (double *)operator new( nr * sizeof(double) ); // jjnote: mem allocation
#endif

    column_real_complex_ffts(f, nr, nc, zp, tr);

    double v = 1.0/n;
    // row #0:
    fht(f, ldc);
    fht_auto_convolution_core(f, ldc, v);
    fht(f, ldc);

    if ( (nr>1) && !(nr&1) )  // nr>1 and nr even
    {
        fht_negacyclic_auto_convolution(f+nh, ldc, v);  // row #n/2
    }


    double *pr = f,  *pi = f + n;
    for (ulong k=1; k<nr/2; k++)
    {
        pr += nc;
        pi -= nc; // jjnote: dependent of order of imag part
        double w = (double)k/nr;

#if  ( CP_ROWS==1 )
        copy(pr, tr , nc);
        copy(pi, ti , nc);
        weighted_complex_auto_convolution(tr, ti, ldc, w, v);
        copy(tr, pr , nc);
        copy(ti, pi , nc);
#else // CP_ROWS
        weighted_complex_auto_convolution(pr, pi, ldc, w, v);  // jjnote: cache problem !
#endif // CP_ROWS
    }

    column_complex_real_ffts(f, nr, nc, tr);
    operator delete(tr);
}
// ============================

