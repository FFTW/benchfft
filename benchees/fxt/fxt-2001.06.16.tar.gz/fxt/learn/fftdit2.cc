
#include "complextype.h"
#include "sincos.h"
#include "revbinpermute.h"

#include <math.h> // M_PI


void
dit2_fft_localized(Complex *f, ulong ldn, int is)
// decimation in time radix 2 fft
// depth-first version
// compared to usual fft this one
// - does more trig computations
// - is (far) better memory local
{
    const ulong n = 1<<ldn;
    const double pi = is*M_PI;

    revbin_permute(f,n);

    for (ulong ldm=1; ldm<=ldn; ++ldm)
    {
        const ulong m = (1<<ldm);  // m = 2^ldm
        const ulong mh = (m>>1);   // mh = m/2

        const double phi = pi/(double)(mh);

        for (ulong r=0; r<n; r+=m)
        {
            for (ulong j=0; j<mh; ++j)
            {
                ulong i0 = r + j;
                ulong i1 = i0 + mh;

                Complex u = f[i0];
                double c, s;
                sincos(phi*(double)j, &s, &c);
                Complex v = f[i1] * Complex(c,s);

                f[i0] = u + v;
                f[i1] = u - v;
            }
        }
    }
}
// ================ end ====================


void
dit2_fft(Complex *f, ulong ldn, int is)
// decimation in time radix 2 fft
{
    const ulong n = 1<<ldn;
    const double pi = is*M_PI;

    revbin_permute(f,n);

    for (ulong ldm=1; ldm<=ldn; ++ldm)
    {
        const ulong m = (1<<ldm);  // m = 2^ldm
        const ulong mh = (m>>1);   // mh = m/2

        const double phi = pi/(double)(mh);

        for (ulong j=0; j<mh; ++j)
        {
            double c,s;
            sincos(phi*(double)j, &s, &c);

            for (ulong r=0; r<n; r+=m)
            {
                ulong i0 = r + j;
                ulong i1 = i0 + mh;
                Complex u = f[i0];
                Complex v = f[i1] * Complex(c,s);
                f[i0] = u + v;
                f[i1] = u - v;
            }
        }
    }
}
// ================ end ====================


void
dit2_fft(double *fr, double *fi, ulong ldn, int is)
// decimation in time radix 2 fft
{
    const ulong n = 1<<ldn;

    const double pi = is*M_PI;

    revbin_permute(fr,n);
    revbin_permute(fi,n);

    for (ulong ldm=1; ldm<=ldn; ++ldm)
    {
        const ulong m = (1<<ldm);  // m = 2^ldm
        const ulong mh = (m>>1);   // mh = m/2

        const double phi = pi/(double)(mh);

        for (ulong j=0; j<mh; ++j)
        {
            double c,s;
            sincos(phi*(double)j, &s, &c);

            for (ulong r=0; r<n; r+=m)
            {
                ulong i0 = r + j;
                ulong i1 = i0 + mh;

                double vr = fr[i1] * c - fi[i1] * s;
                double vi = fr[i1] * s + fi[i1] * c;

                double ur = fr[i0];
                fr[i0] = ur + vr;
                fr[i1] = ur - vr;

                double ui = fi[i0];
                fi[i0] = ui + vi;
                fi[i1] = ui - vi;
            }
        }
    }
}
// ================ end ====================
