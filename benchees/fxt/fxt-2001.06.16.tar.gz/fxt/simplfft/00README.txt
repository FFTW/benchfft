
   DOCUMENTATION for the simple-fft package by Joerg Arndt
  =========================================================


 This is a straight&simple-no-Cplusplus extract
 from my fxt-library.
 
 Only real_fft() and fft() are here.
 Data length must be a power of 2, the parameter ldn 
 must be set to the base 2 log of the data length.
 
 For the order of the data at the output of real_fft()
 see the comment at the definition of the function. 


  Hope you can handle it !
