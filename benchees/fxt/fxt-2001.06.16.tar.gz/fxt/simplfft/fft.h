#if !defined HAVE_FFT_H__
#define      HAVE_FFT_H__

/*
 * NOTE: ldn is the base 2 logarithm of the length
 * of the complex data array
 * i.e. ldn=10 means that there are 2^10 = 1024 elements
 *
 */

void fft(double *fr, double *fi, int ldn, int is);

void real_fft(double *fr, int ldn);


#endif // !defined HAVE_FFT_H__
