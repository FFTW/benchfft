#if !defined HAVE_INLINE_H__
#define      HAVE_INLINE_H__


#include "fxttypes.h"


template <typename Type>
static inline void  swap(Type &x, Type &y)
// swap values
{ Type t(x);  x = y;  y = t; }

template <typename Type>
static inline void  swap0(Type &x, Type &y)
// swap() for y known to be zero
{ y = x;  x = 0; }


template <typename Type>
static inline Type  min(const Type &x, const Type &y)
// Return minimum of the input values
{ return  x<y ? x : y; }

template <typename Type>
static inline Type  max(const Type &x, const Type &y)
// Return maximum of the input values
{ return  x>y ? x : y; }


template <typename Type>
static inline Type  min3(const Type &x, const Type &y, const Type &z)
// Return minimum of the input values
{ return  min( min(x,y), z ); }

template <typename Type>
static inline Type  max3(const Type &x, const Type &y, const Type &z)
// Return maximum of the input values
{ return  max( max(x,y), z ); }

template <typename Type>
static inline Type  median3(const Type &x, const Type &y, const Type &z)
// Return median of the input values
{ return  x<y ? (y<z ? y : (x<z ? z : x)) : (y>z? y : (x>z ? z : x)); }


template <typename Type>
static inline int   sign(const Type &x)
// Return sign(x)
{ return  x<0 ? -1 : (x==0?0:1); }

template <typename Type>
static inline int   sign1(const Type &x)
// Return 1 iff x==0, else sign(x)
{ return  x<0 ? -1 : 1; }

template <typename Type>
static inline Type  abs(const Type &x)
// Return abs(x)
{ return  x>=0 ? x : -x; }


template <typename Type>
static inline void sort2(Type &x1, Type &x2)
// sort x1, x2
{ if (x1>x2) {Type t=x1; x1=x2; x2=t;} }

template <typename Type>
static inline void sort3(Type &x1, Type &x2, Type &x3)
// sort x1, x2, x3
{ sort2(x1,x2); sort2(x2,x3); sort2(x1,x2); }


template <typename Type>
static inline int in_range_q(Type x, Type xmin, Type xmax)
// Return whether xmin<= x <=xmax
{ return ( (x>=xmin) && (x<=xmax) ); }

template <typename Type>
static inline int off_range_q(Type x, Type xmin, Type xmax)
// Return whether x<xmin or x>xmax
{ return ( (x<xmin) || (x>xmax) ); }

template <typename Type>
static inline void clip_range(Type &x, Type xmin, Type xmax)
// force x into [xmin, xmax]
{
    if      ( x<xmin )  { x = xmin; }
    else if ( x>xmax )  { x = xmax; }
    return; 
}


#endif // !defined HAVE_INLINE_H__
