
#include  "sincos.h"


#if defined __GNUC__  // if GNUC
#warning "FYI: sincos:  GNU-C"
#endif // __GNUC__

#if defined __i386__  // if x86 cpu
#warning  "FYI: sincos: x86 CPU"
#endif // __i386__

//<<
// SINCOS_* #defined in sincos.h

#if !defined SINCOS_AUTOMATIC
#warning 'FYI: automatic sincos-code selection was DISABLED in sincos.h'
#else
#warning 'FYI: automatic sincos-code selection'
#endif  // SINCOS_AUTOMATIC


#if defined SINCOS_USE_ASM_TEMPLATE
#warning "FYI: sincos: x86 asm template sincos"
//#warning "FYI: If you get strange results (e.g. nan) with asm template"
//#warning "FYI:  then use one of the ASM/mathinline/plain-C version"
#endif // SINCOS_USE_ASM_TEMPLATE


#if defined SINCOS_USE_ASM
#warning "FYI: sincos: x86 asm sincos"
void
sincos(double a, double *s, double *c)
{ asm("
fldl 4 (%esp)
fsincos
movl 16 (%esp), %eax
fstpl (%eax)
movl 12 (%esp), %eax
fstpl (%eax)
ret ");
}
#endif // SINCOS_USE_ASM


#if defined SINCOS_USE_MATHINLINE
#warning 'FYI: sincos: inline-math sincos'
#endif // SINCOS_USE_MATHINLINE

#if defined  SINCOS_USE_C
#warning 'FYI: sincos: C sincos'
#endif // SINCOS_USE_C
//>>
