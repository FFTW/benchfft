#if !defined HAVE_AUXLAZY_H__
#define      HAVE_AUXLAZY_H__

// include file for the lazy

#include "array.h"
#include "gcd.h"
#include "auxdouble.h"
#include "auxprint.h"
#include "copy.h"
#include "inline.h"
#include "minmax.h"
#include "misc.h"
#include "scale.h"
#include "scan.h"
#include "scanbox.h"
#include "search.h"
#include "searchidx.h"
#include "shift.h"
#include "sincos.h"
#include "sort.h"
#include "sortidx.h"
#include "workspace.h"
#include "quantise.h"
#include "unique.h"

#endif // !defined HAVE_AUXLAZY_H__
