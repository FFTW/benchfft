
//#include <sys/types.h>
//#include <signal.h>
//#include <unistd.h> // getpid()

#include <stdlib.h>  // abort()

#include <iostream.h>


void
jjassert_fail(
              const char *func,
              const char *pretty_func,
              const char *file,
              const int   line,
              const char *expr,
              const char *bla
              )
{
    cout.flush();

    cerr << "\n";

    cerr << "FAILED ASSERTION: ( " << expr << " )";
    cerr << "\n";

    cerr << " FUNCTION: \"" << func <<"()\"";
    cerr << "\n";

    cerr << " FILE: " << file
         << " (line " << line << ")";
    cerr << "\n";

    cerr << " PRETTY_FUNCTION: \"" << pretty_func <<"\"";
    cerr << "\n";

    if ( bla )  cerr << " REASON: " << bla << "\n";

    cerr << "\n";

//     kill(getpid(), SIGSTOP);
//    pause();

    abort();
}
// ============ end ===========

