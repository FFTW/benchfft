#if !defined HAVE_SORTIDX_H__
#define      HAVE_SORTIDX_H__

#include "fxttypes.h"
#include "inline.h"
#include "minmax.h"

//#include "jjassert.h"


template <typename Type>
void
idx_selection_sort(const Type *f, ulong n, ulong *x)
{
    for (ulong i=0; i<n; ++i)
    {
        Type v = f[x[i]];
        ulong m = i; // position-ptr of minimum
        ulong j = n;
        while ( --j > i )  // search (index of) minimum
        {
            if ( f[x[j]]<v )
            {
                m = j;
                v = f[x[m]];
            }
        }

        swap(x[i], x[m]);
    }
}
//-----------------------


template  <typename Type>
int
is_idx_sorted(const Type *f, ulong n, const ulong *x)
{
    if ( 0==n )  return 1;

    while ( --n )  // n-1 ... 1
    {
        if ( f[x[n]] < f[x[n-1]] )  break;
    }

    return  !n;
}
//-----------------------

template <typename Type>
Type
idx_min(const Type *f, ulong n, const ulong *x)
// returns minimum (value) of array elements
//   {f[x[0]], f[x[1]], .. , f[x[n-1]]}
{
    Type v = f[x[0]];
    while ( n-- )
    {
        if ( f[x[n]]<v )
        {
            v = f[x[n]];
        }
    }
    return  v;
}
//-----------------------

template <typename Type>
Type
idx_max(const Type *f, ulong n, const ulong *x)
// returns maximum (value) of array elements
//   {f[x[0]], f[x[1]], .. , f[x[n-1]]}
{
    Type v = f[x[0]];
    while ( n-- )
    {
        if ( f[x[n]]>v )
        {
            v = f[x[n]];
        }
    }
    return v;
}
//-----------------------

template  <typename Type>
int
is_idx_partitioned(const Type *f, ulong n, const ulong *x, ulong k)
{
    ++k;
    Type lmax = idx_max(f,   k,   x);
    Type rmin = idx_min(f,   n-k, x+k);

    return  ( lmax<=rmin );
}
//-----------------------


template <typename Type>
ulong
idx_partition(const Type *f, ulong n, ulong *x)
// rearrange index array, so that for some index p
// max(f[x[0]] ... f[x[p]]) <= min(f[x[p+1]] ... f[x[n-1]])
{
    swap( x[0], x[n/2]);
    const Type v = f[x[0]];

    ulong i = 0UL - 1;
    ulong j = n;
    while ( 1 )
    {
        do  ++i;
        while ( f[x[i]]<v );

        do  --j;
        while ( f[x[j]]>v );

        if ( i<j )  swap(x[i], x[j]);
        else        return j;
    }
}
//-----------------------


template <typename Type>
void
idx_quick_sort(const Type *f, ulong n, ulong *x)
{
 start:
    if ( n<8 ) // parameter: threshold for nonrecursive algorithm
    {
        idx_selection_sort(f, n, x);
        return;
    }

    ulong p = idx_partition(f, n, x);
//    jjassert( is_idx_partitioned(f, n, x, p) );

    ulong ln = p + 1;
    ulong rn = n - ln;

//    idx_quick_sort(f,    ln, x);  // f[0]  ... f[ln-1]  left
//    idx_quick_sort(f+ln, rn, x);  // f[ln] ... f[n-1]   right

    if ( ln>rn )  // recursion for shorter subarray
    {
        idx_quick_sort(f, rn, x+ln);  // f[x[ln]] ... f[x[n-1]]  right
        n = ln;
    }
    else
    {
        idx_quick_sort(f, ln, x);  // f[x[0]]  ... f[x[ln-1]]  left

        n = rn;
        x += ln;
    }

    goto start;
}
//-----------------------


#endif // !defined HAVE_SORTIDX_H__
