#if !defined HAVE_SEARCHIDX_H__
#define      HAVE_SEARCHIDX_H__


#include "fxttypes.h"

template <typename Type>
ulong
idx_bsearch(Type *f, ulong n, ulong *x, Type v)
//
// return index-ptr i of first element in f[] that is == v
// i.e. f[x[i]] == v, with i minimal
// return ~0 if there is no such element
// f[x[]] must be (index-)sorted in ascending order:
// f[x[i]] <= f[x[i+i]]
//
{
    ulong nlo=0, nhi=n-1;
    while ( 1 )
    {
        ulong t = (nhi+nlo)/2;

        if ( nlo==nhi )
        {
            if ( f[x[nhi]]==v )  return nhi;
            else                 return ~0UL; 
        }

        if ( f[x[t]] < v )  nlo = t + 1;
        else             nhi = t;
    }
}
//-----------------------

template <typename Type>
ulong
idx_bsearch_ge(Type *f, ulong n, Type v)
//
// return index-ptr of first element in f[] that is >= v
// i.e. f[x[i]] >= v, with i minimal
// return ~0 if there is no such element
// f[x[]] must be (index-)sorted in ascending order:
// f[x[i]] <= f[x[i+i]]
//
{
    ulong nlo=0, nhi=n-1;
    while ( 1 )
    {
        ulong t = (nhi+nlo)/2;

        if ( nlo==nhi )
        {
            if ( f[x[nhi]]>=v )  return nhi;
            else                 return ~0UL; 
        }

        if ( f[x[t]] < v )  nlo = t + 1;
        else             nhi = t;
    }
}
//-----------------------

#endif // !defined HAVE_SEARCHIDX_H__
