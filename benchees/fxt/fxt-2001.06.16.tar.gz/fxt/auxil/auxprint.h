#if !defined HAVE_AUXPRINT_H__
#define      HAVE_AUXPRINT_H__

#include "fxttypes.h"
#include "complextype.h"

// auxil/auxprint.cc:

void print(const char *bla, const double *f, ulong n, double eps=0.0);
void print_twodim(const char *bla, const double *f, ulong r, ulong c, double eps=0.0);

void c_print(const char *what, const Complex *c, long n, double eps=0.0);
void ri_print(const char *bla, const double *fr, const double *fi, long n, double eps=0.0);


void approx_eq(const double *f, const double *g, uint n,
               const char *bla, double eps=1e-12);

void approx_eq(const Complex *f, const Complex *g, uint n,
               const char *bla, double eps=1e-12);


#endif  // !defined HAVE_AUXPRINT_H__
