#if !defined  HAVE_SINCOS_H__
#define       HAVE_SINCOS_H__


#define  SINCOS_AUTOMATIC  // undefine to select sincos by hand
//
// uncomment the above to manually choose one of:
//
#if !defined  SINCOS_AUTOMATIC
//#define  SINCOS_USE_ASM_TEMPLATE       // x86 asm template sincos
//#define  SINCOS_USE_ASM         // x86 asm sincos
//#define  SINCOS_USE_MATHINLINE  // inline-math sincos
//#define  SINCOS_USE_C           // plain call of sin() and cos()
#endif


#if defined SINCOS_AUTOMATIC

#if defined  __i386__  // ------- if x86 cpu

#if defined  __GNUC__  // if GNU-C
// choose (uncomment) one of the next two lines:
#define  SINCOS_USE_ASM_TEMPLATE  // use x86 asm template
//#define  SINCOS_USE_ASM    // use x86 ASM asm code in sincos.cc
#endif // __GNUC__

#else // __i386__

// if __sincos_code is defined in /usr/include/bits/mathinline.h
#if defined  __sincos_code
#define  SINCOS_USE_MATHINLINE
#else  // __sincos_code
#define  SINCOS_USE_C  // use C-version
#endif // __sincos_code

#endif // __i386__ // ------- if x86 cpu

#else // -------------- SINCOS_AUTOMATIC

// ... algorithm selected by hand

#endif // -------------- SINCOS_AUTOMATIC



#if defined  SINCOS_USE_ASM_TEMPLATE
static inline void sincos(double a, double *s, double *c)
{
    __asm__ ("fsincos" : "=t" (*c), "=u" (*s) : "0" (a));
}
// used (special i386) constraints:
//    `t'  First (top of stack) floating point register
//    `u'  Second floating point register
#endif // SINCOS_USE_ASM_TEMPLATE


#if defined  SINCOS_USE_ASM
// auxil/sincos.cc:
void sincos(double a, double *c, double *s);
#endif // SINCOS_USE_ASM


#if defined  SINCOS_USE_MATHINLINE
#define  sincos(a,s,c)  __sincos(a,s,c)
#endif // SINCOS_USE_MATHINLINE


#if defined  SINCOS_USE_C

#include <math.h>

inline void sincos(double a, double *s, double *c)
{
    *s = sin(a);
    *c = cos(a);
}
#endif // SINCOS_USE_C



#endif  // HAVE_SINCOS_H__
