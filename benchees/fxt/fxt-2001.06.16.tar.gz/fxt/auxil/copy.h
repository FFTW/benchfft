#if !defined HAVE_COPY_H__
#define      HAVE_COPY_H__


#include "fxttypes.h"
#include "inline.h"  // min()

#include <string.h>  // memcpy()


template <typename Type>
inline void
swap(Type *f, Type *g, ulong n)
// swap arrays
{
    while ( n-- )
    {
        Type t(f[n]);  f[n]=g[n];  g[n]=t;
    }
}
//-----------------------


template <typename Type>
inline void
swap_reverse(Type *f, Type *g, ulong n)
// swap arrays reversed:
// f[] <-- reverse(g[])
// g[] <-- reverse(f[])
{
    ulong j = 0;
    while ( n-- )
    {
        Type t(f[j]);  f[j]=g[n];  g[n]=t;
        ++j;
    }
}
//-----------------------


template <typename Type>
inline void
copy_mem(const Type *src, Type *dst, ulong n)
// copy array using memcpy()
{
    memcpy(dst, src, n*sizeof(Type));
//  void * memcpy (void *TO, const void *FROM, size_t SIZE)
//  undefined if the two arrays TO and FROM overlap;
}
//-----------------------


template <typename Type1, typename Type2>
inline void
copy(const Type1 *src, Type2 *dst, ulong n)
// copy array
{
    while ( n-- )  dst[n] = (Type2)src[n];
}
//-----------------------


template <typename Type1, typename Type2>
inline void
copy_reverse(const Type1 *src, Type2 *dst, ulong n)
// copy array reversed:
// dst[] <-- reverse(f[])
{
    ulong j = 0;
    while ( n-- )
    {
        dst[j] = (Type2)src[n];
        ++j;
    }
}
//-----------------------


template <typename Type1, typename Type2>
inline void
copy(const Type1 *src, ulong ns,
     Type2 *dst, ulong nd)
// copy as much as makes sense, fill rest with zeroes
// from src[] (length ns) to dst[] (length nd):
{
    ulong k, n;
    n = min(nd, ns);
    for (k=0; k<n; ++k)  dst[k] = (Type2)src[k];
    for (  ; k<nd; ++k)  dst[k] = 0;
}
//-----------------------


//template <typename Type1, typename Type2>
//inline void
//offset_copy(const Type1 *src, ulong ns,
//            Type2 *dst, ulong nd,
//            ulong off)
//// copy with offset
//// from src[] (length ns) to dst[] (length nd):
//{
//    if ( off>=ns )  return;  // no elements to copy from
//    if ( off>=nd )  return;  // no elements to copy to
//
//    ulong len = min(ns-off, nd-off);
//    copy(src+off, dst+off, len);
//}
////-----------------------


template <typename Type1, typename Type2>
inline void
skip_copy(const Type1 *src, Type2 *dst, ulong n, ulong d)
// copy n elements from src[] at positions
// [0],[d],[2d],[3d],...,[(n-1)*d]
// to dst[0, 1, ... ,n-1]
{
    for (ulong k=0,j=0; j<n; k+=d,j++)  dst[j] = src[k];
}
//-----------------------


template <typename Type1, typename Type2>
inline void
skip_copy_back(const Type1 *src, Type2 *dst, ulong n, ulong d)
// copy n elements from src[0, 1, ... ,n-1]
// to dst[] at positions
// [0],[d],[2d],[3d],...,[(n-1)*d]
{
    for (ulong k=0,j=0; j<n; k+=d,j++)  dst[k] = src[j];
}
//-----------------------


template <typename Type>
inline void
null(Type *f, ulong n)
// set array to zero:
{
    const Type v(0);
    while ( n-- )  f[n] = v;
}
//-----------------------


template <typename Type>
inline void
fill(Type *dst, ulong n, Type v)
// fill array with value v
{
    while (  n--  )  dst[n] = v;
}
//-----------------------


template <typename Type>
inline void
fill_seq(Type *dst, ulong n, Type start=0, Type step=1)
// fill array with sequence
// start, start+step, start+2*step, ...
// used for testing
{
    for (ulong k=0; k<n; ++k)
    {
        dst[k] = start;
        start += step;
    }
}
//-----------------------

template <typename Type>
int
is_seq(const Type *dst, ulong n, Type start=0, Type step=1)
// check whether array with the sequence
// start, start+step, start+2*step, ...
// (as filled in by fill_seq(dst, n, start, step)
// used for testing
{
    for (ulong k=0; k<n; ++k)
    {
        if ( dst[k] != start )  return 0;
        start += step;
    }

    return 1;
}
//-----------------------


#endif // !defined HAVE_COPY_H__
