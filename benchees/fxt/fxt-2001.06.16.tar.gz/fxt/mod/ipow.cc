
#include "mtypes.h"


umod_t
ipow(umod_t a, umod_t ex)
{
    if ( 0==ex )
    {
        return 1;
    }
    else
    {
        umod_t z = a;
        umod_t y = 1;

        while ( 1 )
        {
            if ( ex&1 )  y *= z;
            
            ex /= 2;

            if ( 0==ex )  break;

            z *= z;
        }

        return y;
    }
}
// ============= end ===========
