

#include "mod.h"
#include "bits2pow.h" // ld()


void
slow_ntt(mod *f, ulong n, int is)
{
    mod g[n];

    const mod rn = mod::root2pow( is>0 ? ld(n) : -ld(n) );

    for (ulong k=0; k<n; ++k)
    {
        mod t = mod::zero;
        mod w = mod::one;
        mod dw = pow(rn,k);

        for (ulong x=0; x<n; ++x)
        {
            t += (w*f[x]);
            w *= dw;
        }

        g[k] = t;
    }

    for (ulong x=0; x<n; ++x)  f[x] = g[x];

}
// ================ end ===================
