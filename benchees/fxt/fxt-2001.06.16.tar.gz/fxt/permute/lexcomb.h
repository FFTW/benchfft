#if !defined HAVE_LEXCOMB_H__
#define      HAVE_LEXCOMB_H__

#include "bitcombination.h"
#include "fxttypes.h"


class ostream;


class lexcomb
{
public:
    lexcomb(ulong n, ulong k);
    ~lexcomb();

    ulong first()
    {
        bits_ = first_combination(k_);
        sync_x();
        return bits_;
    }

    ulong next()  // return zero if previous comb was the last
    {
        bits_ = next_combination(bits_);
        sync_x();
        return ( (bits_ & mask_) ? 0 : bits_ );
    }

    const ulong * data()  { return x_; }
    const lexcomb &  current()  const  { return *this; }

    friend ostream & operator << (ostream &os, const lexcomb &x);

//private:
    void sync_x();

//private:
    ulong n_;
    ulong k_;
    ulong bits_;
    ulong mask_;  // 111...111000..00 (n zeros)
    ulong *x_;
};
//---------------------



#endif  // !defined HAVE_LEXCOMB_H__
