#if !defined HAVE_PERMUTELAZY_H__
#define      HAVE_PERMUTELAZY_H__


#include "cycles.h"
#include "enumerate.h"
#include "zip.h"
#include "ziprev.h"
#include "graypermute.h"
#include "partition.h"
#include "permutation.h"
#include "lexcomb.h"
#include "numcomb.h"
#include "radixpermute.h"
#include "revbinpermute.h"
#include "revbinpermute0.h"
#include "reverse.h"
#include "rotate.h"
#include "shortgraypermute.h"
#include "shortrevbinpermute.h"
#include "shortrevbinpermute0.h"


#endif  // !defined HAVE_PERMUTELAZY_H__
