#if !defined HAVE_NUMCOMB_H__
#define      HAVE_NUMCOMB_H__

#include "bitcombination.h"
#include "fxttypes.h"


class ostream;


class numcomb
{
public:
    numcomb(ulong n, ulong k);
    ~numcomb();

    ulong first()
    {
        xbits_ = first_combination(n_-k_);
        sync_x();
        return bits_;
    }

    ulong next()  // return zero if previous comb was the last
    {
        xbits_ = next_combination(xbits_);
        sync_x();
        return ( (xbits_ & mask_) ? 0 : xbits_ );
    }

    const ulong * data()  { return x_; }
    const numcomb &  current()  const  { return *this; }

    friend ostream & operator << (ostream &os, const numcomb &x);

//private:
    void sync_x();

//private:
    ulong n_;
    ulong k_;
    ulong bits_;
    ulong xbits_;
    ulong mask_;  // 111...111000..00 (n zeros)
    ulong nmask_;  // ~mask_
    ulong *x_;
};
//---------------------



#endif  // !defined HAVE_NUMCOMB_H__
