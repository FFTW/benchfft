#if !defined HAVE_PERMUTATION_H__
#define      HAVE_PERMUTATION_H__


#include "bitarray.h"
#include "fxttypes.h"

// permute/permutation.cc:
int is_trivial_permutation(const ulong *f, ulong n);
int has_fixed_points(const ulong *f, ulong n);
int is_valid_permutation(const ulong *f, ulong n, bitarray *bp=0);
int is_involution(const ulong *f, ulong n);

int is_inverse(const ulong *f, const ulong *g, ulong n);
void  make_inverse(const ulong *f, ulong *g, ulong n);

ulong count_fixed_points(const ulong *f, ulong n);

ulong permutation_index(const ulong *f, ulong n);


#endif  // !defined HAVE_PERMUTATION_H__
