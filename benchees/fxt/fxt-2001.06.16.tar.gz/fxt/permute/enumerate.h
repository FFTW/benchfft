#if !defined HAVE_ENUMERATE_H__
#define      HAVE_ENUMERATE_H__


class enumerate_per
{
public:
    enumerate_per(int nn);
    ~enumerate_per();
    void init();

    int next()  { make_next();  return idx; }
    int current()  const  { return idx; }
    const int *data()  const  { return x;}

private:
    void make_next();
    int n;
    int sig;
    int idx;
    int *p;
    int *d;
    int *x;
};
//---------------------


#endif  // !defined HAVE_ENUMERATE_H__
