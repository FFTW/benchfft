
#include "enumerate.h"
#include "inline.h"


enumerate_per::enumerate_per(int nn)
{
    n = ( nn<1 ? 1 : nn );
    p = new int[n];
    d = new int[n];
    x = new int[n];
    init();
}
//---------------------

enumerate_per::~enumerate_per()
{
    delete [] p;
    delete [] d;
    delete [] x;
}
//---------------------

void
enumerate_per::init()
{
    sig = 0;
    idx = 0;
    for (int i=0; i<n; i++)
    {
        p[i] = 0;
        d[i] = 1;
        x[i] = i;
    }
}
//---------------------

void
enumerate_per::make_next()
// Trotter's algorithm
// based on code by Helmut Herold
// jjnote: todo: get sign of permutation
{
    ++idx;
//    if ( idx>maxidx )
//    {
//        idx = 0;
//        if ( n>1 )  swap(x[n-1], x[n-2]);
//        sig   = 1;
//        return;
//    }

    int k = 0;
    int m = 0;
    sig = p[m] + d[m];
    p[m] = sig;

    while ( sig==n-m || sig==0 )
    {
        if ( sig==0 )
        {
            d[m] = 1;
            k++;
        }
        else  d[m] = -1;

        if ( m==n-2 )
        {
            swap(x[n-1], x[n-2]);
            sig   = 1;
            idx = 0;
            return;
        }
        else
        {
            m++;
            sig = p[m] + d[m];
            p[m] = sig;
        }
    }

    int t1 = sig + k;
    int t2 = t1 - 1;
//    cout << "sig=" << sig << "  k=" << k
//         << "  swap " << t2 << " " << t1
//         << "    ";
//        cout << endl;
//    jjassert( t1<n );
//    jjassert( t2<n );

    swap(x[t1], x[t2]);
}
//---------------------

