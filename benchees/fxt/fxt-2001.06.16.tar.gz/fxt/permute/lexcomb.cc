
#include "bitcombination.h"
#include "lexcomb.h"
#include "fxttypes.h"

#include <iostream.h>


lexcomb::lexcomb(ulong n, ulong k)
{
    n_ = (n ? n : 1);  // not zero
    k_ = (k ? k : 1);  // not zero
    mask_ = ~first_combination(n);
    x_ = new ulong[k];
    first();
}
//-------------------


lexcomb::~lexcomb()
{
    delete [] x_;
}
//-------------------


void
lexcomb::sync_x()
{
    ulong tbits = bits_;
    ulong xi = 0, bi = 0;
    while ( bi < n_ )
    {
        if ( tbits&1 )  x_[xi++] = bi;
        ++bi;
        tbits >>= 1;
    }
}
//-------------------


ostream & operator << (ostream &os, const lexcomb &x)
{
    cout.width(2);
    os << x.x_[0];
    for (ulong i=1; i<x.k_; ++i)
    {
        os << " ";
        cout.width(2);
        cout << x.x_[i];
    }
    return os;
}
//-------------------
