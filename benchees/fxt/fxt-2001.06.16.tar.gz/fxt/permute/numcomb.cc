
#include "bitcombination.h"
#include "numcomb.h"
#include "revbin.h"
#include "fxttypes.h"

#include <iostream.h>


numcomb::numcomb(ulong n, ulong k)
{
    n_ = (n ? n : 1);  // not zero
    k_ = (k ? k : 1);  // not zero
    mask_ = ~first_combination(n);
    nmask_ = ~mask_;
    x_ = new ulong[k];
    first();
}
//-------------------


numcomb::~numcomb()
{
    delete [] x_;
}
//-------------------


void
numcomb::sync_x()
{
    bits_ = nmask_ & ~revbin(xbits_, n_);
    ulong tbits = bits_;
    ulong xi = 0, bi = 0;
    while ( bi < n_ )
    {
        if ( tbits&1 )  x_[xi++] = bi;
        ++bi;
        tbits >>= 1;
    }
}
//-------------------


ostream & operator << (ostream &os, const numcomb &x)
{
    cout.width(2);
    os << x.x_[0];
    for (ulong i=1; i<x.k_; ++i)
    {
        os << " ";
        cout.width(2);
        cout << x.x_[i];
    }
    return os;
}
//-------------------
