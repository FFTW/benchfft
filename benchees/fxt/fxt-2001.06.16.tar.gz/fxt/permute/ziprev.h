#if !defined HAVE_ZIPREV_H__
#define      HAVE_ZIPREV_H__


#include "fxttypes.h"
#include "reverse.h"
#include "revbinpermute.h"


template <typename Type>
void
ziprev(const Type *x, Type *y, ulong n)
// reordering needed for fht based inverse dct
{
    const ulong nh = n/2;
//    for (ulong k=0, k2=0;  k<nh;  k++, k2+=2)
//    {
//        y[k2] = x[k];
//        y[n-1-k2] = x[nh+k];
//    }
    // =^=
    for (ulong k=0, k2=0;     k<nh;  k++, k2+=2)  y[k2] = x[k];
    for (ulong k=nh, k2=n-1;  k<n;   k++, k2-=2)  y[k2] = x[k];
}
// =============== end ===========


template <typename Type>
void
ziprev(Type *x, ulong n)
// reordering needed for fht based inverse dct
// inplace version
//
// n must be a power of two
{
    const ulong nh = n/2;
    reverse(x+nh, nh);
    revbin_permute(x, nh); revbin_permute(x+nh, nh);
    revbin_permute(x, n);
}
// =============== end ===========


template <typename Type>
void
unziprev(const Type *x, Type *y, ulong n)
// reordering needed for fht based dct
{
    const ulong nh = n/2;
//    for (ulong k=0, k2=0;  k<nh;  k++, k2+=2)
//    {
//        y[k] = x[k2];
//        y[nh+k] = x[n-1-k2];
//    }
    // =^=
    for (ulong k=0, k2=0;     k<nh;  k++, k2+=2)  y[k] = x[k2];
    for (ulong k=nh, k2=n-1;  k<n;   k++, k2-=2)  y[k] = x[k2];
}
// =============== end ===========

template <typename Type>
void
unziprev(Type *x, ulong n)
// reordering needed for fht based dct
// inplace version
//
// n must be a power of two
{
    const ulong nh = n/2;
    revbin_permute(x, n);
    revbin_permute(x, nh); revbin_permute(x+nh, nh);
    reverse(x+nh, nh);
}
// =============== end ===========



#endif // !defined HAVE_ZIPREV_H__
