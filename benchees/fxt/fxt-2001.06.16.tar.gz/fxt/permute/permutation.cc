
#include "permutation.h"
#include "bitarray.h"
#include "copy.h"


int
is_trivial_permutation(const ulong *f, ulong n)
//
// check whether f[k]==k for all k= 0...n-1
//
{
    for (ulong k=0; k<n; ++k)  if ( f[k] != k )  return 0;
    return 1;
}
//---------------------

int
has_fixed_points(const ulong *f, ulong n)
//
// check whether f[k]==k for any k= 0...n-1
//
{
    for (ulong k=0; k<n; ++k)  if ( f[k] == k )  return 1;
    return 0;
}
//---------------------

int
is_valid_permutation(const ulong *f, ulong n, bitarray *bp/*=0*/)
//
// check whether all values 0...n-1
// appear exactly once
//
{
    // check whether any element is out of range:
    for (ulong k=0; k<n; ++k)  if ( f[k]>=n )  return 0;

    // check whether values are unique:
    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags
    tp->clear_all();

    for (ulong k=0; k<n; ++k)  if ( tp->test_set(f[k]) )  return 0;

    if ( 0==bp )  delete tp;

    return 1;
}
//---------------------


int
is_involution(const ulong *f, ulong n)
//
// check whether max cycle length is <= 2
//
{
    for (ulong k=0; k<n; ++k)  if ( f[f[k]] != k )  return 0;

    return 1;
}
//---------------------

int
is_inverse(const ulong *f, const ulong *g, ulong n)
//
// check whether f[] is inverse of g[]
//
{
    for (ulong k=0; k<n; ++k)  if ( f[g[k]] != k )  return 0;

    return 1;
}
//---------------------

void
make_inverse(const ulong *f, ulong *g, ulong n)
//
// set f[] to the inverse of f[]
//
{
    for (ulong k=0; k<n; ++k)  g[f[k]] = k;
}
//---------------------


ulong
count_fixed_points(const ulong *f, ulong n)
//
// return number of fixed points in f[]
//
{
    ulong ct = 0;
    for (ulong k=0; k<n; ++k)  if ( f[k] == k )  ++ct;
    return ct;
}
//---------------------


ulong
permutation_index(const ulong *f, ulong n)
//
// Determine the permutation index for a given permutation list.
//
// The following function computes the ordinal of the given permutation,
// which is index of the permutation in sorting order:
//  1, 2, ..., n-1, n   is index 0
//  1, 2, ..., n, n-1   is index 1
//  ...
//  n, n-1, ..., 2, 1   is index n! -1
//
// The actual values of the elements are immaterial, only the relative
// ordering of the values is used.
//
// f[] is the array of elements of length n.
// The return value is the permutation index.
//.
// Original code by Thad Smith III, Boulder, CO  8/31/91
{
    ulong idx = 0;
    for (ulong i=1; i<n; i++)
    {
        ulong x = f[i-1];
        for (ulong j=i; j<n; j++)  if ( x>f[j] )  ++idx;
        idx *= n - i;
    }

    return idx;
}
//---------------------
