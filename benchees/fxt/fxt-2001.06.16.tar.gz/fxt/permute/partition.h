#if !defined HAVE_PARTITION_H__
#define      HAVE_PARTITION_H__


#include "fxttypes.h"

class partition
{
public:
    partition(const ulong *pv, ulong n)
        : n_(n==0?1:n)
    {
        pv_ = new long[n_+1];
        for (ulong j=0; j<n_; ++j)  pv_[j] = pv[j];
        pc_ = new ulong[n_+1];
        r_  = new long[n_+1];
    }

    ~partition()
    {
        delete [] pv_;
        delete [] pc_;
        delete [] r_;
    }

    void init(ulong x);

    ulong next(ulong *pc);

    ulong next_func(ulong i);  // aux

    ulong count(ulong x);
    ulong count_func(ulong i);  // aux

    void adjust(ulong i);  // aux
    void dump(ulong i)  const  { dump(i, pc_); }
    void dump(ulong i, ulong *pv)  const;
    int  check(ulong i)  const;

//private:
    ulong ct_;  // # of partitions found so far
    ulong n_;   // # of values
    ulong i_;   // level in iterative search

    long *pv_;  // values into which to partition
    ulong *pc_; // multipliers for values
    long *r_;   // rest
    long x_;    // value to partition
};
// -------------------------


#endif  // !defined HAVE_PARTITION_H__
