
#include "cycles.h"
#include "bitarray.h"
#include "shift.h"
#include "reverse.h"
#include "minmax.h"
#include "reverse.h"
#include "fxttypes.h"

#include "jjassert.h"

#include <iostream.h>
#include <iomanip.h>  // setw()


cycles::cycles(ulong n)
    : n_(n), f_(0),
      nn_(n),
      nc_(0), nce_(),
      nf_(0),
      ma_(0), mi_(0)
{
    f_ = new ulong[n_];
    ta_ = new bitarray(n);
}
//---------------------


cycles::~cycles()
{
    delete ta_;
    delete [] f_;
}
//---------------------


int
cycles::make_cycles(const ulong *f, ulong n, bitarray *bp/*=0*/)
{
    jjassert( n<=n_ );

    bitarray *tp = bp;
    if ( 0==bp )  tp = new bitarray(n);  // tags

    nc_ = 0;  // # of cycles
    nce_ = 0;
    nf_ = 0;  // # of fixed points
    ma_ = 1;  // max length of cycles
    mi_ = n;  // min length of cycles
    ulong k;  // index in f[]
    ulong j = 0;  // index in f_[]
    for (k=0; k<n; ++k)
    {
        if ( tp->test_set(k) )  continue; // already processed

        ulong i = f[k];  // next in cycle

        if ( i==k )  // skip fixed points
        {
            ++nf_;
            f_[n_-nf_] = k;  // record fixed point backwards from end
            continue;
        }

        ulong cl = 0; // length of current cycle
        ++nc_;
        f_[j++] = k;
        ++nce_;
        ++cl;
        tp->set(i); // cannot be already set, because minlen==2
        do
        {
            f_[j++] = i;
            ++nce_;
            ++cl;
            i = f[i];
        }
        while ( !tp->test_set(i) ); // until we meet cycle leader again

        tag_idx(j-1); // tagged as last

        if ( ma_<cl )  ma_ = cl;
        if ( mi_>cl )  mi_ = cl;

        jjassert( i==k );
    }

    nn_ =  nce_ + nf_;
    jjassert( nn_ <= n_ );

    // want fixed points inorder of appearence:
    if ( nf_>1 )  reverse(f_+n_-nf_, nf_);

    // want fixed points after cycles:
    if ( nf_ > 0 )
    {
        shift_left(f_+nce_, n_-nce_, n_-nce_-nf_);
    }

    if ( 0==bp )  delete tp;

    jjassert( n==nn_ );
    return  nn_;
}
//---------------------

void
cycles::invert()
{
    // we could just reverse() the cycles part:
    // reverse(f_, nce_);
    // but then the tags must be moved too, so
    // we invert the cycles one by one ...

    ulong k=0, len=0;
    while ( (len=next_cycle(k)) )
    {
        if ( len>2 )  reverse(f_+k, len);
        k += len-1;
    }
}
//---------------------

ulong
cycles::next_cycle(ulong &k)  const
// set k to the leader of the next cycle
// returns the length of the cycle
// zero is returned if there is no more cycle
//
// assumes that input index k points to the last (i.e. tagged)
// element of a cycle or one higher (i.e. leader of next cycle)
//
// usage:  while( clen = next_cycle(idx) )  { ... }
{
    if ( k>=nce_ )  return 0;

    if ( has_tag(k) )  ++k;  // advance if at cycle end
//    else  k = ta_->next_set_idx(k) + 1;

    if ( k>=nce_ )  return 0;

    ulong len = ta_->next_set_idx(k) - k + 1;

    jjassert( k+len <= nce_ );

    return  len;
}
//---------------------

int
cycles::make_permutation(ulong *f, ulong n)  const
// 'inverse' of make_cycles()
{
    // ---- fixed points:
    for (ulong k = nce_; k<nn_; ++k)
    {
        ulong x = f_[k];
        f[x] = x;
    }

    // ---- cycles:
    if ( 0==nc_ )  return 1;  // nothing to do

    ulong i = 0;
    ulong clen = cycle_length(0);
    do
    {
        ulong si = f_[i];  // cycle leader
        ulong di = f_[i+clen-1];  // last elem
        f[di] = si;

        for (ulong k=0; k<clen-1; ++k)
        {
            di = f_[i+k];
            si = f_[i+k+1];
            f[di] = si;
        }

        i += clen;
        clen = next_cycle(i);
    }
    while ( 0!=clen );

    return 1;
}
//---------------------


int
cycles::is_equivalent(const ulong *f, ulong n)  const
{
    // ---- check fixed points:
    for (ulong k = nce_; k<nn_; ++k)
    {
        ulong x = f_[k];
//        cout << "FP el = " << x << "  @ " << k << endl;
        if ( f[x]!=x )  return  0;
    }


    // ---- check cycles:
    if ( 0==nc_ )  return 1;  // nothing to do

    ulong i = 0;
    ulong clen = cycle_length(0);
    do
    {
        ulong si = f_[i];  // cycle leader
        ulong di = f_[i+clen-1];  // last elem
//        cout << "TEST si=" << si << "  di=" << di << endl;
//        cout << "     f[si]=" << f[si] << "  f[di]=" << f[di] << endl;
        if ( f[di] != si )  return 0;

        for (ulong k=0; k<clen-1; ++k)
        {
            di = f_[i+k];
            si = f_[i+k+1];
//            cout << "test si=" << si << "  di=" << di << endl;
//            cout << "     f[si]=" << f[si] << "  f[di]=" << f[di] << endl;
            if ( f[di] != si )  return 0;
        }

        i += clen;
        clen = next_cycle(i);
    }
    while ( 0!=clen );

    return 1;
}
//---------------------


static void
scream(const char *what)
{
    cout << "+++++++++++++++++  "
         << "--- " << what << "  ---"
         << endl;
}
//---------------------

void
cycles::print(int info_only/*=0*/)  const
{
    if ( 0==nce_ )
    {
        scream("IDENTITY (only fixed points).");
        return;
    }
    else  print_cycles(info_only);

    if ( 0==nf_ )
    {
        cout << "No fixed points." << endl;
    }
    else  print_fixed_points(info_only);
}
//---------------------


void
cycles::print_fixed_points(int info_only/*=0*/)  const
{
    cout << nf_ << " fixed points: " << endl;

    if ( info_only )  return;

    cout << "[";
    for (ulong k=0;  k<nf_-1; ++k)
    {
        cout << f_[nce_+k] << ". ";
    }
    cout << f_[nce_+nf_-1] << "]" << endl;
}
//---------------------

void
cycles::print_cycles(int info_only/*=0*/)  const
{

    if ( !info_only )
    {
        ulong ct = 0;
        ulong k=0, len=0;
        while ( (len=next_cycle(k)) )
        {
            ulong x = get(k);
            cout << setw(3) << ct << ":";

            cout << "  (";
            cout << setw(3) << x << ",";
            ulong i;
            for (i=1; i<len-1; ++i)
            {
                cout << setw(3) << get(k+i) << ",";
                if ( 0==(i%16) )  cout << "\n  ";
            }
            cout << setw(3) << get(k+i) << ")";
            cout << " #=" << len;
            cout << endl;

            ++ct;
            k += len-1;
        }
    }

    cout << setw(4) << nce_ << " elements";
    cout << " in " << setw(3) << nc_ << " nontrivial cycles." << endl;

    if ( mi_==ma_ )
    {
        scream("ONE CYCLE LENGTH.");
        cout << "   which is == " << ma_ << endl;
        if ( 2==ma_ )  scream("INVOLUTION (self inverse).");
    }
    else
    {
        cout << " cycle lengths: "
             << setw(3) << mi_ << " ... " << setw(3) << ma_
             << endl;
    }
}
//---------------------

void
cycles::print_leaders()  const
{
    ulong k=0, len=0, ct = 0;
    while ( (len=next_cycle(k)) )
    {
        cout << "#" << setw(3) << ct << ":  ";
        ulong mi, ma;
        mi = ma = get(k+len-1);
        cout << "  len = " << setw(3) << len;
        update_min_max(f_+k, len-1, &mi, &ma);
        cout << "   [" << setw(3) << mi << " .. " << setw(3) << ma << "]";
        cout << endl;

        k += len-1;
        ++ct;
    }

    jjassert( ct == nc_ );
}
//---------------------


static void
print_cycle_code(const ulong *f, ulong len, ostream &out)
{
    ulong ct = 0;
    ulong z = f[0];
    out << "  { Type t=f[" << z << "]; ";
    out << "f[" << z << "]";

    for (ulong k=1; k<len; ++k)
    {
        z = f[k];
        out  << "=f[" << z << "];";
        ++ct;
        if ( !(ct&3) )  out << endl;
        out << " f[" << z << "]";
    }

    out << "=t; }" << endl;
}
//---------------------


void
cycles::print_code(const char *funcname, ulong n,
                   int use_swap/*=0*/, int use_stderr/*=0*/)  const
{
    ostream &out = (use_stderr ? cerr : cout);

    cout << " ===== start printing CODE "
         << (use_stderr?"(to stderr)":"")
         << " ====="<< endl;
    out << "template <typename Type>" << endl;
    out << "inline void" << endl;
    out << funcname << "_" << n << "(Type *f)" << endl;
    out << "// unrolled version for length " << n << endl;
    out << "{" << endl;

    ulong k=0, len=0, ct = 0;
    while ( (len=next_cycle(k)) )
    {
        if ( (len==2) && use_swap )
        {
            out << "  swap(f[" << f_[k] << "], f[" << f_[k+1] << "]);" << endl;
        }
        else  print_cycle_code(f_+k, len, out);

        k += len-1;
        ++ct;
    }

    out << "}" << endl;
    cout << " ===== end (printing CODE "
         << (use_stderr?"to stderr":"")
         << " ====="<< endl;

    jjassert( ct == nc_ );
}
//---------------------



