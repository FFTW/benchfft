
#include "partition.h"
#include "fxttypes.h"

#include <iostream.h>
#include <iomanip.h>


int
partition::check(ulong i)  const
{
    long xx = 0;
    for (ulong k=i;  k<n_; ++k)  xx += pc_[k]*pv_[k];
    return  (xx==x_);
}
// -------------------------


void
partition::dump(ulong i, ulong *pc)  const
{
    cout << "{" << i << "} ";

    for (ulong k=0; k<n_; ++k)
    {
        cout << "  + ";
        cout.width(2);
        cout << pc[k];
        cout << "*";
        cout.width(2);
        cout << pv_[k];

//        cout << " [";
//        cout.width(2);
//        cout << r_[k] << "]";
    }

//    cout << "  [[";
//    cout.width(2);
//    cout << r_[n_] << "]]";

    cout << "  ==";
    cout.width(4);
    cout << x_;

    cout << endl;
}
// -------------------------


void
partition::adjust(ulong i)
{
    for (ulong j=0; j<i; ++j)  pc_[j] = 0;
    for (ulong j=0; j<i; ++j)  r_[j] = 0;
}
// -------------------------


ulong
partition::count(ulong x)
{
    init(x);
    count_func(n_-1);
    return ct_;
}
// -------------------------

ulong
partition::count_func(ulong i)
{
    if ( 0!=i )
    {
        while ( r_[i]>0 )
        {
            pc_[i-1] = 0;
            r_[i-1] = r_[i];
            count_func(i-1);  // recursion
            r_[i] -= pv_[i];
            ++pc_[i];
        }
    }
    else  // recursion end
    {
        if ( 0!=r_[i] )
        {
            long d = r_[i] / pv_[i];
            r_[i] -= d * pv_[i];
            pc_[i] = d;
        }
    }

    if ( 0==r_[i] )  // valid partition found
    {
        ++ct_;
        return 1;
    }
    else  return 0;
}
// -------------------------


void
partition::init(ulong x)
// to be called before next() and count()
{
    x_ = x;
    ct_ = 0;
    for (ulong k=0; k<n_; ++k)  pc_[k] = 0;
    for (ulong k=0; k<n_; ++k)  r_[k] = 0;
    r_[n_-1] = x;
    r_[n_] = x;
    i_ = n_ - 1;
}
// -------------------------

ulong
partition::next(ulong *pc)
{
    if ( i_>=n_ )
    {
        return  n_;
    }
    i_ = next_func(i_);

    ulong j;
    for (j=0; j<i_; ++j)  pc[j] = 0;
    for (   ; j<n_; ++j)  pc[j] = pc_[j];

    ++i_;
    r_[i_] -= pv_[i_];
    ++pc_[i_];

    return  i_ - 1;  // >=0
}
// -------------------------


ulong
partition::next_func(ulong i)
{
 start:
    if ( 0!=i )
    {
        while ( r_[i]>0 )
        {
            pc_[i-1] = 0;
            r_[i-1] = r_[i];
            --i;  goto start;   // iteration
        }
    }
    else  // iteration end
    {
        if ( 0!=r_[i] )
        {
            long d = r_[i] / pv_[i];
            r_[i] -= d * pv_[i];
            pc_[i] = d;
        }
    }

    if ( 0==r_[i] )  // valid partition found
    {
        ++ct_;
        return i;
    }

    ++i;
    if ( i>=n_ )  return n_;  // search finished

    r_[i] -= pv_[i];
    ++pc_[i];

    goto start;  // iteration
}
// -------------------------
