#if !defined HAVE_AUXGEN_H__
#define      HAVE_AUXGEN_H__


extern ulong mct, act;
extern double *st;

#define idxf(pt,i)  "f[" << st[((pt)-(f)+(i))] << "]"

void prsincos(char *varc, char *vars, long num, ulong den);
#define  PRSINCOS(c,s,n,d)  prsincos(#c,#s,n,d)

void prelude(ulong n, const char *fname, int scrt);
void finale(ulong n, int scrt);


#endif // !defined HAVE_AUXGEN_H__
