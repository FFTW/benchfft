
#include "fxt.h"
#include "fxtauxlazy.h"
#include "permutelazy.h"
#include "jjassert.h"

#include <iostream.h>
#include <iomanip.h>
#include <stdlib.h> // atol()

static char *tt = 0;
#define  TT(x)  { tt = "// " #x " for n="; cerr << tt << n << endl;  x; }
#define  PP()   { cerr << tt << n << endl; }


template <typename Type>
void
rb_permute(Type *f, ulong n)
// put data in revbin order
// self-inverse
{
    if ( n<=2 )  return;

    const ulong nh = (n>>1);
    Type * const f1 = f + n - 1;
    swap(f[1], f[nh]);

    ulong k=2, r=nh;
    while ( k<nh  )
    {
        // k even:
        r ^= nh;
        for (ulong m=(nh>>1); !((r^=m)&m); m>>=1)  {;}
        if ( r>k )
        {
//            swap(f[k], f[r]);     // k<nh, r<nh
//            swap(f1[-k], f1[-r]); // n-k>nh, n-r>nh
        }
        ++k;

        // k odd:
        r += nh;
        swap(f[k], f[r]);  // k<nh, r>nh
        ++k;
    }
}
//============== end =================


template <typename Type>
void
gray_permute_hi(Type *f, ulong n)
{
    ulong z = 1; // mask for cycle maxima
    ulong v = 0; // ~z
    ulong cl = 1;  // cycle length

    f -= n;

    ulong ldm, m;
    for (ldm=1, m=2;  m<n;  ++ldm, m<<=1)
    {
        z <<= 1;
        v <<= 1;
        if ( is_pow_of_2(ldm) )
        {
            ++z;
            cl <<= 1;
        }
        else  ++v;
    }

    for ( ;  m<2*n;  ++ldm, m<<=1)
    {
        z <<= 1;
        v <<= 1;
        if ( is_pow_of_2(ldm) )
        {
            ++z;
            cl <<= 1;
        }
        else  ++v;

        ulong tv = v, tu = 0;  // cf. bitsubset.h
        do
        {
            tu = (tu-tv) & tv;
            ulong s = z | tu;  // start of cycle

            // --- do cycle: ---
            ulong g = gray_code(s);
            Type t = f[s];
            for (ulong k=cl-1; k!=0; --k)
            {
                Type tt = f[g];
                f[g] = t;
                t = tt;
                g = gray_code(g);
            }
            f[g] = t;
            // --- end (do cycle) ---
        }
        while ( tu );
    }
}
// =========================


void
tower(long *f, ulong ldx)
{
    const ulong n = 1<<ldx;

    for (ulong ldm=ldx; ldm>=1; ldm--) // dif (gray, inverse_evenodd)
//    for (ulong ldm=1; ldm<=ldx; ldm++) // dit (inverse_gray, evenodd)
    {
        ulong m = 1<<ldm;
        for (ulong r=0; r<n; r+=m)
        {
            unzip(f+r, m);
        }
    }
}
// =========================



int
main(int argc, char **argv)
{
    ulong n = 16;
    if ( argc>1 )  n = atol(argv[1]);
    ulong ldn = ld(n);
    if ( (long)n<0 )
    {
        ldn = -(long)n;
        n = 1<<ldn;
    }
    cout << "ldn=" << ldn << "  n=" << n << endl;

    ulong a1 = 3;
    if ( argc>2 )  a1 = atol(argv[2]);


    ulong *y = new ulong[n];  // permuted indices
    fill_seq(y, n);


    // ++++++++++ apply some permutation: ++++++++++
//    TT( revbin_permute(y, n) );
//    TT( reverse(y, n) );

//    TT( gray_permute(y, n) );
//    TT( gray_permute_hi(y, n) );
//    TT( rb_permute(y, n); rb_permute(y, n/2); rb_permute(y+n/2, n/2); );
//    TT( rb_permute(y, n); );
//    TT( rb_permute(y, n/2); rb_permute(y+n/2, n/2);
//    TT( revbin_permute(y, n/2); revbin_permute(y+n/2, n/2); );
    TT( zip(y, n); );
//    TT( radix_permute(y, n, 4); revbin_permute(y, n); );
//    TT( revbin_permute(y, n); gray_permute(y, n) );
//    TT( radix_permute(y, n, 3) );
//    TT( radix_permute(y, n, 2); revbin_permute(y, n) );

//    TT( tower(y, ldn); );

//    TT( tower(y, ldn-1);  tower(y+n/2, ldn-1); );

//    prseq(y,0,n);  exit(99);



    // ++++++++++ study permutation: ++++++++++
    cycles cc(n);
    cc.make_cycles((ulong *)y, n);
    cc.print();
    jjassert( cc.is_equivalent((ulong *)y, n) );

//    ulong v[n];
//    cc.make_permutation(v, n);
//    jjassert( cc.is_equivalent(v, n) );
//    jjassert( 0==compare((ulong *)y, v, n) );

//    cc.print_leaders();

    // ++++++++++ print code: ++++++++++
//    cc.print_code("zulp", n, 1);
//    cc.invert();
//    cc.print_code("inverse_zulp", n, 1);


    return 0;
}
//===========================================
