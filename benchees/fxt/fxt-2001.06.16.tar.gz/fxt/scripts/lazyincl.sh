#!/bin/bash

#
# check which headers are included by *lazy.h
#

#exit 99;

HDRS=$*
if [ "$HDRS" = "" ]; then
    HDRS=$(find . -name \*lazy.h)
fi

TMPI=/tmp/incl-tmpi
TMPA=/tmp/incl-tmpa
TMPT=/tmp/incl-tmpt

for f in $HDRS; do
#    echo
    echo "--- HDR = [$f]";
    d=$(dirname $f);
#    echo "--- dirname = [$d]";
    b=$(basename $f .h);
#    echo "--- basename = [$b]";

    grep "$b" $f  &&  echo " *** OOPS, $f is including itself (?)";

    a=$(ls -1 $d/*.h);  ## all headers
#    echo "all hdrs=[$a]";

    i=$(grep -E '^#include +"' $f | cut -d'"' -f2);  ## headers actually included
#    echo " included: [$i]"

    echo -n > $TMPI;
    for t in $i; do
        echo $d/$t >> $TMPI;
        if [ ! -f $d/$t ]; then
            echo " *** inluded file $t is not in directory $d";
        fi
    done;
    sort $TMPI | grep -v 'lazy' > $TMPT ;  mv $TMPT $TMPI;

    ud=$(uniq -d $TMPI);
    if [ -n "$ud" ]; then
        echo "*** OOPS, multiple inclusion of [$ud] (?)";
        exit 1;  ## fail
    fi

    echo -n > $TMPA;
    for t in $a; do  echo $t >> $TMPA;  done;
    sort $TMPA | grep -v 'lazy' > $TMPT;  mv $TMPT $TMPA;

    if [ $(diff -d -bB $TMPA $TMPI | wc -l) -gt 0 ]; then
        echo "*** OOPS, missing header file(s) in $f:"
        diff -d -bB $TMPA $TMPI;
        exit 1; ## fail
    fi

done

#rm -f $TMPA $TMPI $TMPT

echo 'OK.'
exit 0

############################
