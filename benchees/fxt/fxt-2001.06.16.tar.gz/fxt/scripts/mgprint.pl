
# imported by metagen


##########################

sub meta_out
{
    my $x = shift;
    print "cout << \"$x\" << endl;\n";
}

sub meta_out_nn
{
    my $x = shift;
    print "cout << \"$x\";\n";
}

sub meta_out_val
{
    my $x = shift;
    print "cout << $x << endl;\n";
}

sub meta_err
{
    my $x = shift;
    print "cerr << \"$x\" << endl;\n";
}

1; # perl stupidity

##########################

