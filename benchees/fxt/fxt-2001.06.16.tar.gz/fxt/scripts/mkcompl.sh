#! /bin/sh

# quick hack by Joerg Arndt (arndt@jjj.de)
# version: 2001-February-02 (21h18)

/usr/bin/test -n "$NAME" || exit 1;
/usr/bin/test -n "$CNAME" || exit 1;

echo " ***** creating $CNAME from $NAME"

if [ -f $CNAME ]; then
#    echo "file $CNAME already exists, copying it into /tmp ";
    cp $CNAME /tmp;
fi

#exit 0;

FROM=`basename $NAME`;

echo > $CNAME
echo "// MACHINE GENERATED FILE, DO NOT EDIT !" >> $CNAME
echo "// this file was generated from $FROM" >> $CNAME
echo '#include "complextype.h"' >> $CNAME
perl -we 'while(<STDIN>) {/jjkeep/ || s/double/Complex/g; print;}' < $NAME >> $CNAME

touch --reference=$NAME $CNAME

if [ -f /tmp/$CNAME ]; then
    diff $CNAME /tmp/$CNAME &>/dev/null ||  echo "CHANGE wrt. last version."
fi

#echo " ***** done."

exit 0;
####################################
