#!/bin/bash

#
# check that header files have canonical #ifdefs against multiple inclusion:
# foo.h should have
# #if !defined HAVE_FOO_H__
# etc.

#exit 99;

HDRS=$*
if [ "$HDRS" = "" ]; then
    HDRS=$(find . -name \*.h)
fi

for f in $HDRS; do
#    echo
    echo "--- HDR = [$f]";
    export b=$(basename $f .h | tr 'a-z\-' 'A-Z_' );

    CAN="HAVE_${b}_H__";
    CT=$(grep -E "\b$CAN\$" $f | wc -l);
    if [ $CT -lt 3 ];  then
        echo " *** OOPS, $f doesn't seem to have the canonical #ifdefs:"
        echo " *** should be: "
        echo "LINE  1:  #if !defined  $CAN"
        echo "LINE  2:  #define       $CAN"
        echo "LINE -1:  #endif  // !defined $CAN"
        echo "first two lines look like:"
        head -2 $f;
        echo "last line is:"
        tail -1 $f;

        replace "^(#.+) [A-Z0-9_]+_H\$" "\$1 HAVE_${b}_H__" $f;
        replace "^(#.+) HAVE_.+_H__\$" "\$1 HAVE_${b}_H__" $f;
#        exit 1;  ## fail

    fi
done

echo 'OK.'
exit 0

############################
#
#    replace "^(#.+) [A-Z0-9_]+_H\$" "\$1 HAVE_${b}_H__" $f;
#
#    echo "b=[$b]";
#    echo "\$1 HAVE_${b}_H__"
#    replace '^(#.*defin.+) __[A-Z0-9_]+$' "\$1 HAVE_${b}_H__" $f;
#
#XX=$(for f in $(find . -name \*.h); do \
#    if [ "3" != $(grep -E 'HAVE_[A-Z0-9_]+_H__' $f | wc -l) ]; then echo $f; fi; \
#done)
#echo "$XX"
#
#for f in $XX; do
#  echo "-------- $f: --------";
#  grep -E -C3 'HAVE_[A-Z0-9_]+_H__' $f;
#done
#
#ee $XX
#
