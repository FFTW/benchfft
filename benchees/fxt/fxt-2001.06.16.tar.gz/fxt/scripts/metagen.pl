#! /usr/bin/perl -w

# meta hack by Joerg Arndt (arndt@jjj.de)
# version: 2000-September-15 (00h30)

## under constant development ;-)


$dir = 'scripts';
require "$dir/mgprint.pl";
require "$dir/mghead.pl";
require "$dir/mgfindfunc.pl";
require "$dir/mgspecvars.pl";
require "$dir/mgprintmain.pl";
require "$dir/mgscanfunc.pl";

$idpat = '\b[a-zA-Z_][a-zA-Z0-9_]*\b';  # regex for C-identifier
#$floattype = '';

if ( ! $ARGV[0] )  { die "FATAL: need function name to make generator\n"; }
$funcname = $ARGV[0];
#$funcname='split_radix_dif_fht_core'; # TODO: as 1. arg

if ( ! $ARGV[1] )  { die  "FATAL: need at least one varname to specialize\n"; }
@specvarnames = reverse @ARGV;
pop @specvarnames;
@specvarnames = reverse @specvarnames;
#@specvarnames = ('ldn'); # TODO: as arg 2,3,...
print STDERR "specvarnames=[@specvarnames]\n";


$funcsig=''; # signature or the function
$class = ''; # debug: classification of lines
$debug = 1;  # whether to debug
$comment = ''; # C++ comment

&print_head;

&find_func;
print STDERR "funcname=[$funcname]\n";
print STDERR "funcsig=[$funcsig]\n";


&spec_vars;
print STDERR "special sig = $specsig\n";
print STDERR "special arg = $specarg\n";


$mgfuncname = "metagen";
print "\n\nvoid $mgfuncname($specsig);\n\n";

&print_main;

&scan_func;

exit 0;

########################
########################

