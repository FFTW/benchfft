
# imported by metagen


##########################

sub print_main
{
#    print "#include \"auxgen.h\"\n";
    print "int\n";
    print "main()\n";
    print "{\n";

    foreach $t (keys %spectype)
    {
        $v = $spectype{$t};
#        print "cerr << \"enter (type= $v ) $t: \";\n";
        &meta_err("enter $v  $t: ");
        print "cin >> $t\_;\n";
    }
#    print "void $funcname$funcsig\n";


    &meta_out("#include \\\"fxttypes.h\\\"");
    &meta_out("#include \\\"sincos.h\\\"");
    &meta_out("#include \\\"cmult.h\\\"");
    &meta_out("#include \\\"sumdiff.h\\\"");
#    &meta_out("#include \\\".h\\\"");


    $specfuncname = "$funcname";
    &meta_out("void");
    &meta_out("$specfuncname($gensig)");
    &meta_out("// $funcname($funcsig)");
    &meta_out_nn("// where");
    foreach $t ( @specvarnames )
    {
        &meta_out_nn("  $t=");
        &meta_out_val("$t\_");
    }

    print "$mgfuncname($specarg);\n";

    print "return 0;\n";
    print "}\n\n";
}

1; # perl stupidity

##########################
