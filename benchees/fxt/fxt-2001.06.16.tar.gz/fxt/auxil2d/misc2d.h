#if !defined HAVE_MISC2D_H__
#define      HAVE_MISC2D_H__


#include "fxttypes.h"
#include "misc.h"


template <typename Type>
void
apply_func(Type **f, ulong nr, ulong nc, Type (*func)(Type))
// apply func() on each element
{
    for (ulong r=0; r<nr; ++r)
    {
        apply_func(f[r],nc,func);
    }
}
//-----------------------


#endif // !defined HAVE_MISC2D_H__
