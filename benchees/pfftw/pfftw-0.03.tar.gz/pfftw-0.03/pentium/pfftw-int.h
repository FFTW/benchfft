/* -*- C -*- */

/* pfftw-int.h -- internal definitions */
/* $Id: pfftw-int.h 1.1 Tue, 02 Nov 1999 17:15:02 +0100 athena $ */

#include <pfftw.h>

#define CONCAT_AUX(a, b) a ## b
#define CONCAT(a, b) CONCAT_AUX(a,b)

#ifdef SINGLE_PRECISION
#define fftw_real float
#define fftw_complex fftw_complex_s
#define PFFTW(name)  CONCAT(pfftw_s_, name)
#define PFFTWI(name)  CONCAT(pfftwi_s_, name)
#else
#ifdef DOUBLE_PRECISION
#define fftw_real double
#define fftw_complex fftw_complex_d
#define PFFTW(name)  CONCAT(pfftw_d_, name)
#define PFFTWI(name)  CONCAT(pfftwi_d_, name)
#else
#error "Either SINGLE_PRECISION or DOUBLE_PRECISION must be defined"
#endif
#endif

#define FFTW_KONST(x) ((fftw_real) x)

void PFFTW(twiddle_2)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTW(twiddle_4)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTWI(twiddle_2)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTWI(twiddle_4)(fftw_complex *A, const fftw_complex *W, int iostride);
