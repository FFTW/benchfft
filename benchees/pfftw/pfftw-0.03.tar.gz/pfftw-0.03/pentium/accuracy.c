#include <pfftw-int.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

fftw_complex x[1024];
fftw_complex y[1024];
fftw_complex z[1024];

/*
 * Naive O(n^2) algorithm, used for testing purposes
 */
void fftw_naive(int n, fftw_complex * in, fftw_complex * out)
{
     int i, j;
     fftw_complex sum;
     fftw_complex w;
     fftw_real pi = 3.1415926535897932384626434;

     for (j = 0; j < n; ++j) {
	  c_re(sum) = c_im(sum) = 0.0;
	  for (i = 0; i < n; ++i) {
	       c_re(w) = cos((2.0 * pi * (i * j % n)) / n);
	       c_im(w) = -sin((2.0 * pi * (i * j % n)) / n);
	       c_re(sum) += c_re(in[i]) * c_re(w) - c_im(in[i]) * c_im(w);
	       c_im(sum) += c_im(in[i]) * c_re(w) + c_re(in[i]) * c_im(w);
	  }
	  out[j] = sum;
     }
     return;
}

void fftwi_naive(int n, fftw_complex * in, fftw_complex * out)
{
     int i, j;
     fftw_complex sum;
     fftw_complex w;
     fftw_real pi = 3.1415926535897932384626434;

     for (j = 0; j < n; ++j) {
	  c_re(sum) = c_im(sum) = 0.0;
	  for (i = 0; i < n; ++i) {
	       c_re(w) = cos((2.0 * pi * (i * j % n)) / n);
	       c_im(w) = sin((2.0 * pi * (i * j % n)) / n);
	       c_re(sum) += c_re(in[i]) * c_re(w) - c_im(in[i]) * c_im(w);
	       c_im(sum) += c_im(in[i]) * c_re(w) + c_re(in[i]) * c_im(w);
	  }
	  out[j] = sum;
     }
     return;
}

void test(int n, register void (*fft) (), register int (*order) ())
{
     int i;
     double err;

     for (i = 0; i < n; ++i) {
	  x[i].re = drand48();
	  x[i].im = drand48();
     }

     fftw_naive(n, x, y);

     fft(x);

     err = 0.0;
     for (i = 0; i < n; ++i) {
	  int i1 = order(i);
	  err += (x[i1].re - y[i].re) * (x[i1].re - y[i].re) +
	      (x[i1].im - y[i].im) * (x[i1].im - y[i].im);
     }

     printf("%6d %d+ %g\n", n, sizeof(fftw_real), err);
}

void testi(int n, register void (*ifft) (), register int (*order) ())
{
     int i;
     double err;

     for (i = 0; i < n; ++i) {
	  int i1 = order(i);
	  z[i].re = x[i1].re = drand48();
	  z[i].im = x[i1].im = drand48();
     }

     fftwi_naive(n, z, y);

     ifft(x);

     err = 0.0;
     for (i = 0; i < n; ++i) {
	  err += (x[i].re - y[i].re) * (x[i].re - y[i].re) +
	      (x[i].im - y[i].im) * (x[i].im - y[i].im);
     }

     printf("%6d %d- %g\n", n, sizeof(fftw_real), err);
}

int main()
{
     int j;

     for (j = 0; j < 1024; ++j)
	  x[j].re = x[j].im = 0;

     test(2, PFFTW(2), PFFTW(permutation_2));
     testi(2, PFFTWI(2), PFFTW(permutation_2));
     test(4, PFFTW(4), PFFTW(permutation_4));
     testi(4, PFFTWI(4), PFFTW(permutation_4));
     test(8, PFFTW(8), PFFTW(permutation_8));
     testi(8, PFFTWI(8), PFFTW(permutation_8));
     test(16, PFFTW(16), PFFTW(permutation_16));
     testi(16, PFFTWI(16), PFFTW(permutation_16));
     test(32, PFFTW(32), PFFTW(permutation_32));
     testi(32, PFFTWI(32), PFFTW(permutation_32));
     test(64, PFFTW(64), PFFTW(permutation_64));
     testi(64, PFFTWI(64), PFFTW(permutation_64));
     test(128, PFFTW(128), PFFTW(permutation_128));
     testi(128, PFFTWI(128), PFFTW(permutation_128));
     test(256, PFFTW(256), PFFTW(permutation_256));
     testi(256, PFFTWI(256), PFFTW(permutation_256));
     test(512, PFFTW(512), PFFTW(permutation_512));
     testi(512, PFFTWI(512), PFFTW(permutation_512));
     test(1024, PFFTW(1024), PFFTW(permutation_1024));
     testi(1024, PFFTWI(1024), PFFTW(permutation_1024));

     return 0;
}
