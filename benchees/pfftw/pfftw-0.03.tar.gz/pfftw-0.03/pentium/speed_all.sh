#!/bin/sh
for i in 0 2 4 8 16 32 64 128 256 512 1024
do
    ./speed_s_$i
    ./speed_d_$i
done
