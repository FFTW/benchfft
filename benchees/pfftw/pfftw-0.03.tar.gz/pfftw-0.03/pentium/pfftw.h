/* -*- C -*- */

/* pfftw.h -- system-wide definitions */
/* $Id: pfftw.h 1.1 Tue, 02 Nov 1999 17:15:02 +0100 athena $ */

typedef struct {
     float re, im;
} fftw_complex_s;

typedef struct {
     double re, im;
} fftw_complex_d;

#define c_re(c)  ((c).re)
#define c_im(c)  ((c).im)

#define DEFINE_PFFTW(size)			\
 void pfftw_s_##size(fftw_complex_s *input);	\
 void pfftw_d_##size(fftw_complex_d *input);	\
 void pfftwi_s_##size(fftw_complex_s *input);	\
 void pfftwi_d_##size(fftw_complex_d *input);	\
 int pfftw_s_permutation_##size(int i);		\
 int pfftw_d_permutation_##size(int i);

DEFINE_PFFTW(2)
DEFINE_PFFTW(4)
DEFINE_PFFTW(8)
DEFINE_PFFTW(16)
DEFINE_PFFTW(32)
DEFINE_PFFTW(64)
DEFINE_PFFTW(128)
DEFINE_PFFTW(256)
DEFINE_PFFTW(512)
DEFINE_PFFTW(1024)

