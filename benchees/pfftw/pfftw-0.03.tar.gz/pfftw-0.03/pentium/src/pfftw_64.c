#include <pfftw-int.h>

void PFFTW(64)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_64)[];
     PFFTW(twiddle_4)(input, PFFTW(W_64), 16);
     PFFTW(16)(input + 16 * 0);
     PFFTW(16)(input + 16 * 1);
     PFFTW(16)(input + 16 * 2);
     PFFTW(16)(input + 16 * 3);
}

int PFFTW(permutation_64)(int i)
{
    int i1 = i % 4;
    int i2 = i / 4;
    if (i1 <= (4 / 2))
       return (i1 * 16 + PFFTW(permutation_16)(i2));
    else
       return (i1 * 16 + PFFTW(permutation_16)((i2 + 1) % 16));
}

