#include <pfftw-int.h>

void PFFTWI(1024)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_1024)[];
     PFFTWI(256)(input + 256 * 0);
     PFFTWI(256)(input + 256 * 1);
     PFFTWI(256)(input + 256 * 2);
     PFFTWI(256)(input + 256 * 3);
     PFFTWI(twiddle_4)(input, PFFTW(W_1024), 256);
}
