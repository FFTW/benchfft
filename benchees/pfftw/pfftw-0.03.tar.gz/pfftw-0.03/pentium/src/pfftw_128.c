#include <pfftw-int.h>

void PFFTW(128)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_128)[];
     PFFTW(twiddle_4)(input, PFFTW(W_128), 32);
     PFFTW(32)(input + 32 * 0);
     PFFTW(32)(input + 32 * 1);
     PFFTW(32)(input + 32 * 2);
     PFFTW(32)(input + 32 * 3);
}

int PFFTW(permutation_128)(int i)
{
    int i1 = i % 4;
    int i2 = i / 4;
    if (i1 <= (4 / 2))
       return (i1 * 32 + PFFTW(permutation_32)(i2));
    else
       return (i1 * 32 + PFFTW(permutation_32)((i2 + 1) % 32));
}

