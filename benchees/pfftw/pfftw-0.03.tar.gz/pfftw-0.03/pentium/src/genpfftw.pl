#!/usr/bin/perl -w

unless (@ARGV > 1) { die "usage: genpfftw [-fw | -bw | -rt]<n> <radix>"; }

$mode = shift(@ARGV);
$n = shift(@ARGV);
$radix = shift(@ARGV);
$m = $n / $radix;

print "#include <pfftw-int.h>\n\n";

if ($mode eq "-rt") {
    $n1 = ($m-1)*($radix/2);
    print "fftw_complex PFFTW(W_${n})[$n1] = {\n";

    $twopiOverN = (6.2831853071795864769252867665590057683943388 / $n);
    for ($i = 1; $i < $m; ++$i) {
	for ($j = 1; $j <= $radix/2; ++$j) {
	    $c = cos($i*$j*$twopiOverN);
	    $s = sin($i*$j*$twopiOverN);
	    print "{ $c, $s },\n";
	}
    }

    print "};\n";

} elsif ($mode eq "-fw") {

    print <<EOF ;
void PFFTW($n)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_${n})[];
     PFFTW(twiddle_$radix)(input, PFFTW(W_$n), $m);
EOF

    for ($i = 0; $i < $radix; ++$i) {
	print "     PFFTW($m)(input + $m * $i);\n";
    }
print <<EOF ;
}

int PFFTW(permutation_$n)(int i)
{
    int i1 = i % $radix;
    int i2 = i / $radix;
    if (i1 <= ($radix / 2))
       return (i1 * $m + PFFTW(permutation_$m)(i2));
    else
       return (i1 * $m + PFFTW(permutation_$m)((i2 + 1) % $m));
}

EOF

} elsif ($mode eq "-bw") {

    print <<EOF ;
void PFFTWI($n)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_${n})[];
EOF

    for ($i = 0; $i < $radix; ++$i) {
	print "     PFFTWI($m)(input + $m * $i);\n";
    }

print <<EOF ;
     PFFTWI(twiddle_$radix)(input, PFFTW(W_${n}), $m);
}
EOF
}
