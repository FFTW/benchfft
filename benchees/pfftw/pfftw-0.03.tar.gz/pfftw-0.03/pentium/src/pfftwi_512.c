#include <pfftw-int.h>

void PFFTWI(512)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_512)[];
     PFFTWI(128)(input + 128 * 0);
     PFFTWI(128)(input + 128 * 1);
     PFFTWI(128)(input + 128 * 2);
     PFFTWI(128)(input + 128 * 3);
     PFFTWI(twiddle_4)(input, PFFTW(W_512), 128);
}
