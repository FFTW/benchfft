#include <pfftw-int.h>

void PFFTWI(128)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_128)[];
     PFFTWI(32)(input + 32 * 0);
     PFFTWI(32)(input + 32 * 1);
     PFFTWI(32)(input + 32 * 2);
     PFFTWI(32)(input + 32 * 3);
     PFFTWI(twiddle_4)(input, PFFTW(W_128), 32);
}
