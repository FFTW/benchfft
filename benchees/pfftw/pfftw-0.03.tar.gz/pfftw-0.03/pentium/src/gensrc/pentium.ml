open Schedule
open Expr
open Variable
open Asched
module Pentium = struct
  let fresh = Variable.make_temporary
  let nreg() = !Magic.nreg

  let rec aschedule_to_alist = function
      ADone -> []
    | AInstr a -> [a]
    | ASeq (a, b) ->
	(annotated_to_alist a) @ (annotated_to_alist b)
  and annotated_to_alist (Annotate (_, _, _, _, a)) =
    aschedule_to_alist a

  let rec to_asched = function
    | [] -> ADone
    | [a] -> AInstr a
    | l -> 
	let n2 = (List.length l) / 2 in
	let rec loop n a b =
	  if n = 0 then
	    (List.rev b, a)
	  else
	    match a with
	      [] -> failwith "loop"
	    | x :: y -> loop (n - 1) y (x :: b)
	in let (a, b) = loop n2 l []
	in ASeq (Annotate([], [], [],  0, to_asched a),
		 Annotate ([], [], [], 0, to_asched b))

  let rec myassoc x = function
    [] -> None
  | (a,b)::l -> if a = x then Some b else myassoc x l

  let rec substitute_var sublist = function
    | Var x as y -> (match myassoc x sublist with
	None -> y
      |	Some v -> v)
    | Plus l -> Plus (List.map (substitute_var sublist) l)
    | Uminus x -> Uminus (substitute_var sublist x)
    | Times (a, b) -> Times (substitute_var sublist a,
			     substitute_var sublist b)
    | x -> x

  let rec inline_loads s = function
      [] -> []
    | (Assign (v, x)) :: b ->
	match x with
	  Var t when is_input t && not (is_output v)
	  -> inline_loads ((v, x) :: s) b
	| _ -> 
	    Assign (v, substitute_var s x) :: inline_loads s b

  let rec canonicalize_stores = function
      [] -> []
    | (Assign (_, Var _)) as a :: b ->
	a :: canonicalize_stores b
    | (Assign (v, x)) :: b when is_output v ->
	let t = fresh () in
	Assign (t, x) ::
	Assign (v, Var t) ::
	canonicalize_stores b
    | a :: b ->
	a :: canonicalize_stores b

  let rec canonicalize = function
      [] -> []
    | (Assign (v, x)) :: r -> match x with
	Plus [Var a; Var b] when is_input a && is_input b ->
	  let t = fresh () in
	  Assign (t, Var a) ::
	  Assign (v, Plus [Var t; Var b]) ::
	  canonicalize r
      | Plus [Var a; Uminus (Var b)] when is_input a && is_input b ->
	  let t = fresh () in
	  Assign (t, Var a) ::
	  Assign (v, Plus [Var t; Uminus (Var b)]) ::
	  canonicalize r
      |	Times (Var a, Var b) when not (is_temporary a) 
	    && not (is_temporary b) ->
	  let t = fresh () in
	  if (is_twiddle a) then
	    Assign (t, Var b) ::
	    Assign (v, Times (Var t, Var a)) ::
	    canonicalize r
	  else
	    Assign (t, Var a) ::
	    Assign (v, Times (Var t, Var b)) ::
	    canonicalize r
      |	_ ->
	  (Assign (v, x)) :: 
	  canonicalize r

  type register = V of variable | FR of int
  type memory = M of variable | C of Number.number
  type datum = REG of register | MEM of memory
  type pentium_instr = 
    | FLD of register * datum
    | FADD of register * register * datum
    | FSUB of register * register * datum
    | FSUBR of register * register * datum
    | FMUL of register * register * datum
    | FST of  memory * register

  let rec var_to_datum x =
    if (is_temporary x) then
      REG (V x)
    else
      MEM (M x)

  let rec pentiumize = function
      [] -> []
    | (Assign (v, x)) :: r -> 
	(match x with
	  Var a when is_temporary v && not (is_temporary a) ->
	    FLD (V v, MEM (M a))
	| Var a when is_output v && is_temporary a ->
	    FST (M v, V a) 
	| Times (Var a, Num b) when is_temporary v && is_temporary a ->
	    FMUL (V v, V a, MEM (C b))
	| Times (Num b, Var a) when is_temporary v && is_temporary a ->
	    FMUL (V v, V a, MEM (C b))
	| Times (Var a, Var b) when is_temporary a && is_temporary b ->
	    FMUL (V v, V a, REG (V b))
	| Times (Var a, Var b) when is_temporary a && 
	    not (is_temporary b) ->
	    FMUL (V v, V a, MEM (M b))
	| Times (Var b, Var a) when is_temporary a &&
	    not (is_temporary b) ->
	    FMUL (V v, V a, MEM (M b))
        | Plus [Var a; Uminus (Var b)] when is_temporary a ->
	    FSUB (V v, V a, var_to_datum b) 
	| Plus [Var a; Var b] when is_temporary a ->
	    FADD (V v, V a, var_to_datum b)
        | Plus [Var a; Uminus (Var b)] when is_temporary b ->
	    FSUBR (V v, V b, var_to_datum a) 
	| Plus [Var a; Var b] when is_temporary b ->
	    FADD (V v, V b, var_to_datum a)
	| Plus _  -> failwith "plus"
	| Uminus _ -> failwith "uminus"
	| Times _ -> failwith "times"
	| _ -> failwith "pentiumize"
	) :: pentiumize r


  let unparser = make_unparser ("input", None)  ("input", None) ("twiddle", None)
  let register_file = Array.init (32) (fun i -> make_named_temporary "st")
  let fixed_reg i = register_file.(i)

  let reg_to_string = function
    | V v -> (unparser v)
    | FR i -> "st" ^ (string_of_int i) 
  let mem_to_string = function
    | M v -> (unparser v)
    | C n -> Number.unparse n
  let datum_to_string = function
      REG r -> reg_to_string r
    | MEM m -> mem_to_string m

  let gets = " = "
  let pentium_to_string = function
      FLD (a, b) -> (reg_to_string a) ^ gets ^ (datum_to_string b)
    | FST (a, b) -> (mem_to_string a) ^ gets ^ (reg_to_string b)
    | FADD (a, b, c) -> (reg_to_string a) ^ gets ^ (reg_to_string b)
	^ " + " ^ (datum_to_string c)
    | FSUB (a, b, c) -> (reg_to_string a) ^ gets ^ (reg_to_string b)
	^ " - " ^ (datum_to_string c)
    | FSUBR (a, b, c) -> (reg_to_string a) ^ gets ^ (datum_to_string c)
	^ " - " ^ (reg_to_string b)
    | FMUL (a, b, c) -> (reg_to_string a) ^ gets ^ (reg_to_string b)
	^ " * " ^ (datum_to_string c)
	
  let dump_pentium =
    List.iter (fun x ->
      print_string (pentium_to_string x);
      print_string ";\n")

  let uses_var =
    let same_reg v = function
	V a -> same a v
      |	_ -> false
    in let same_datum v = function
	REG a -> same_reg v a
      |	_ -> false
    in fun v instr -> match instr with
      FST (_, b) -> same_reg v b
    | FADD (_, b, c) -> same_reg v b || same_datum v c
    | FSUB (_, b, c) -> same_reg v b || same_datum v c
    | FSUBR (_, b, c) -> same_reg v b || same_datum v c
    | FMUL (_, b, c) -> same_reg v b || same_datum v c
    | _ -> false

  let substitute_instr sublist = 
    let substitute_reg sublist = function
	V a as y -> (match myassoc a sublist with
	  None -> y
	| Some v -> v)
      |	x -> x in
    let substitute_datum sublist = function
	REG a -> REG (substitute_reg sublist a)
      | x -> x in
    function
      FADD (a, b, c) ->
	FADD (a, substitute_reg sublist b, substitute_datum sublist c)
    | FSUB (a, b, c) ->
	FSUB (a, substitute_reg sublist b, substitute_datum sublist c)
    | FSUBR (a, b, c) ->
	FSUBR (a, substitute_reg sublist b, substitute_datum sublist c)
    | FMUL (a, b, c) ->
	FMUL (a, substitute_reg sublist b, substitute_datum sublist c)
    | FST (a, b) ->
	FST (a, substitute_reg sublist b)
    | FLD (a, b) -> 
	FLD (a, substitute_datum sublist b)
      
  let rec introduce_duplicates sublist =
    let doit sublist instr (V b) r =
      if List.exists (uses_var b) r then
	let t = fresh () in
	FLD (V t, REG (V b)) ::
	instr ::
	introduce_duplicates ((b, V t) :: sublist) r
      else
	instr :: introduce_duplicates sublist r
    in function
	[] -> []
      |	t :: r ->
	  match (substitute_instr sublist t) with
	    FADD (a, b, c) as i ->
	      doit sublist i b r
	  | FSUB (a, b, c) as i ->
	      doit sublist i b r
	  | FSUBR (a, b, c) as i ->
	      doit sublist i b r
	  | FMUL (a, b, c) as i ->
	      doit sublist i b r
	  | x ->
	      x :: introduce_duplicates sublist r

  let preschedule ilist =
    let latency = function
      |	FADD _ -> !Magic.latency
      |	FSUB _ -> !Magic.latency
      |	FSUBR _ -> !Magic.latency
      |	FMUL _ -> !Magic.latency
      |	_ -> 1
    in let execution_time = function
      |	FST _ -> 2
      |	_ -> 1
    in let ready_reg t ready_times = function
      |	V v -> 
	  (match myassoc v ready_times with
	    Some t' -> t >= t'
	  | None -> false)
      |	_ -> true
    in let ready_datum t ready_times = function
      |	MEM _ -> true
      |	REG r -> ready_reg t ready_times r
    in let ready_instr t ready_times mb = function
      |	FLD (_, a) -> ready_datum t ready_times a
      |	FST (_, a) -> ready_reg (t - 1) ready_times a
      |	FADD (_, b, c) -> 
	  ready_reg t ready_times b && ready_datum t ready_times c
      |	FSUB (_, b, c) -> 
	  ready_reg t ready_times b && ready_datum t ready_times c
      |	FSUBR (_, b, c) -> 
	  ready_reg t ready_times b && ready_datum t ready_times c
      |	FMUL (_, b, c) -> 
	  not mb &&
	  ready_reg t ready_times b && ready_datum t ready_times c
    in let infinity = 100000 
    in let has_all_inputs r = ready_instr infinity r false
    in let is_mult = function
      |	FMUL _ -> true
      |	_ -> false
    in let urgency = function
      |	FST _ -> 4
      |	FMUL _ -> 3
      |	FLD (_, MEM _) -> 1
      |	_ -> 2
    in let clobbers_memory v = function
      |	M x -> Variable.clobbers v x
      |	_ -> false
    (* true if assignment of v clobbers instruction inputs *)
    in let clobbers_instr v = function
      |	FLD (_, MEM a) -> clobbers_memory v a
      |	FADD (_, _, MEM a) -> clobbers_memory v a
      |	FSUB (_, _, MEM a) -> clobbers_memory v a
      |	FSUBR (_, _, MEM a) -> clobbers_memory v a
      |	FMUL (_, _, MEM a) -> clobbers_memory v a
      |	_ -> false
    in let dangerous_store past = function
	FST ((M v), _) -> List.exists (clobbers_instr v) past
      |	_ -> false
    in let dangerous_op past =
      let duplicates v past = 
	List.exists 
	  (function
	      FLD (_, REG (V b)) -> b == v
	    | _ -> false) past 
      in function
      |	FADD (_, V b, _) -> duplicates b past
      |	FSUB (_, V b, _) -> duplicates b past
      |	FSUBR (_, V b, _) -> duplicates b past
      |	FMUL (_, V b, _) -> duplicates b past
      |	_ -> false

    in let grade_instructions t rt multiplier_busy instructions =
      let rec loop ready_times past = function
	| [] -> []
	| i :: b ->
	    let is_ready = ready_instr t ready_times multiplier_busy i in
	    let dangerous =
	      not (has_all_inputs ready_times i) or
	      dangerous_op past i or
	      dangerous_store past i in
	    let grade = 
	      if dangerous then (-1000) else
	      if not is_ready then 0 else  urgency i in
	    (grade, i) :: (loop  ready_times (i :: past) b)
      in loop rt [] instructions
    in let find_best t rt mb instructions =
      let grades = grade_instructions t rt mb instructions in
      let rec loop (best_grade, best_instr) = function
	  [] -> best_instr
	| (grade, instr) :: rest ->
	    if (grade > best_grade) then loop (grade, instr) rest
	    else loop (best_grade, best_instr) rest
      in let ((fg, fi) :: rest) = grades in
      let best = loop (fg, fi) rest in
      (best, Util.filter (fun x -> x != best) instructions)
    in let update_ready_times t rt = function
      |	FLD (V a, _) -> (a, t) :: rt
      |	FADD (V a, _, _) -> (a, t) :: rt
      |	FSUB (V a, _, _) -> (a, t) :: rt
      |	FSUBR (V a, _, _) -> (a, t) :: rt
      |	FMUL (V a, _, _) -> (a, t) :: rt
      |	_ -> rt
    in let rec reorder t ready_times mb = function
	[] -> []
      | l -> 
	  let (first, rest) = find_best t ready_times mb l in
	  let lat = latency first in
	  first :: (reorder (t + execution_time first)
		      (update_ready_times (t+lat) ready_times first) 
		      (is_mult first)
		      rest)
    in reorder 0 [] false ilist

  let reg_to_var = function
      V x -> x
    | FR i -> (fixed_reg i)

  let reg_to_expr x = Var (reg_to_var x)

  let datum_to_expr = function
      REG x -> reg_to_expr x
    | MEM (M x) -> Var x
    | MEM (C x) -> Num x
 
  let rec pentium_to_alist = function
      [] -> []
    | a :: b -> 
	(match a with
	| FLD (a, b) -> Assign (reg_to_var a, datum_to_expr b)
	| FADD (a, b, c) -> Assign (reg_to_var a,
				    Plus [reg_to_expr b; datum_to_expr c])
	| FSUB (a, b, c) -> Assign (reg_to_var a,
				    Plus [reg_to_expr b; 
					   Uminus (datum_to_expr c)])
	| FSUBR (a, b, c) -> Assign (reg_to_var a,
				     Plus [datum_to_expr c;
					    Uminus (reg_to_expr b)])
	| FMUL (a, b, c) -> Assign (reg_to_var a,
				    Times (reg_to_expr b, datum_to_expr c))
	| FST (M v, a) -> Assign (v, reg_to_expr a)
	) :: pentium_to_alist b

  let rec iota n =
    if (n == 0) then [0]
    else (n - 1) :: iota (n - 1)

  let rec next_access v t = function
      [] -> None
    | i :: b ->
	if (uses_var v i) then Some t
	else next_access v (t+1) b
      
  let find_unused_reg allocation =
    let unused = 
      Util.filter 
	(fun n ->
	  List.for_all (fun (a, b) ->
	    match b with
	      FR n' -> n <> n'
	    | _ -> true)
	    allocation)
	(iota (nreg())) in
    match unused with
      [] -> None
    | a :: b -> Some (FR a)
	    
  let find_dead_reg allocation rest =
    let dead = Util.filter 
	(fun (v, r) -> not (List.exists (uses_var v) rest))
	allocation in
    match dead with
      [] -> None
    | (v, r) :: _ -> Some r

  let maximize f =
    let rec loop best best_val = function
	[] -> best
      | a :: b -> 
	  let this_val = f a in
	  if (this_val > best_val) then
	    loop a this_val b
	  else
	    loop best best_val b
    in function
	[] -> failwith "maximize"
      |	a :: b ->
	  loop a (f a) b

  let find_farthest allocation rest =
    let access_times = 
      List.map (fun (v, r) -> (r, next_access v 0 rest)) allocation in
    let (r, t) = maximize (fun (r, t) -> t) access_times in
    r

  let rec variable_in_register r = function
      [] -> failwith "variable_in_register"
    | (v, s) :: b ->
	if (r == s) then v
	else variable_in_register r b

  let choose_reg allocation spill_locations preferred rest =
    let pref_regs = 
      List.map (function (REG x) -> x | _ -> failwith "pref_regs")
	(Util.filter 
	   (function
	     | (REG (FR _)) -> true
	     | _ -> false)
	preferred) in
    let revalloc = List.map (fun (v,x) -> (x,v)) allocation in
    let dying = Util.filter
	(function r -> match myassoc r revalloc with
	  None -> false
	| Some v -> not (List.exists (uses_var v) rest))
	pref_regs
    in
    match dying with
      d :: _ -> (d, spill_locations, [])
    | [] -> match find_unused_reg allocation with
      Some r -> (r, spill_locations, [])
    | None ->
	match find_dead_reg allocation rest with
	  Some r -> (r, spill_locations, [])
	| None -> 
	    let spilled = find_farthest allocation rest in
	    let sl = fresh () in
	    let var = variable_in_register spilled allocation in
	    (spilled, (var, V sl) :: spill_locations, [FST (M sl, spilled)])

  let allocate var reg allocation =
    (Util.filter (fun (v, r) -> r <> reg) allocation) @ [(var, reg)]
  let rec choose_registers allocation spilled = 
    let continue f dest ops rest =
      let (reg_for_dest, spilled', spillcode)
	  = choose_reg allocation spilled ops rest in
      spillcode @
      (f reg_for_dest) ::
      choose_registers (allocate dest reg_for_dest allocation) spilled' rest
    in function
	[] -> []
      | i :: rest -> 
	  let i' = substitute_instr allocation i in
	  let i' = substitute_instr spilled i' in
	  match i' with
	  | FLD (V a, b) -> 
	      continue (fun r -> FLD (r, b)) a [b] rest
	  | FADD (V a, b, c) -> 
	      continue (fun r -> FADD (r, b, c)) a [REG b; c] rest
	  | FSUB (V a, b, c) -> 
	      continue (fun r -> FSUB (r, b, c)) a [REG b; c] rest
	  | FSUBR (V a, b, c) -> 
	      continue (fun r -> FSUBR (r, b, c)) a [REG b; c] rest
	  | FMUL (V a, b, c) -> 
	      continue (fun r -> FMUL (r, b, c)) a [REG b; c] rest
	  | x ->
	      x :: choose_registers allocation spilled rest

  let addelem a set = if not (List.mem a set) then a :: set else set
  let rec all_variables l = function
      [] -> l
    | (Assign (v, _)) :: b -> all_variables (addelem v l) b

  let store_conflicts a (FST (_, r)) =
    let dest = match a with
      FLD (v, _) -> v
    | FADD (v, _, _) -> v
    | FSUB (v, _, _) -> v
    | FSUBR (v, _, _) -> v
    | FMUL (v, _, _) -> v
    | _ -> failwith "dest" in
    r == dest

  let rec delay_stores delayed = function
      [] -> List.rev delayed
    | a :: rest ->
	match a with
	  FST _ -> delay_stores (a :: delayed) rest
	| _ ->
	    (Util.filter (store_conflicts a) delayed) @ 
	    (a ::
	     (delay_stores 
		(Util.filter (fun s -> not (store_conflicts a s)) delayed)
		rest))

  let doit x =
    let asched = annotate_aux x in
    let alist = (annotated_to_alist asched) in
    let alist = inline_loads [] alist in
    let alist = canonicalize_stores alist in
    let alist = canonicalize alist in
    let p = pentiumize alist in
(*    let p = introduce_duplicates [] p in  *)
    let p = preschedule p in
    let p = choose_registers [] [] p in 
    let p = if !Magic.delay_stores then delay_stores [] p else p in
(*    let _ = dump_pentium p in 
    let _ = flush stdout in *)
    let a = pentium_to_alist p in
    Annotate ([], [], all_variables [] a, 0, to_asched a)
end

let annotate =  Pentium.doit
