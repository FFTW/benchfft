(cd gensrc; make)
GENERATOR=./gensrc/genfft
GOPTS="-magic-pfftw -magic-inline-loads -magic-no-inline-single -magic-twiddle-positive  -magic-variables 4 -magic-loopi"
INDENT=indent

for size in 2 4 8 16 32; do
for nreg in 6 7 8; do
for latency in 1 2 3 4; do
for dif in "-magic-pfftw" "-magic-dif"; do
for delay in "-magic-pfftw" "-magic-delay-stores"; do
$GENERATOR $GOPTS -notwiddle $size -magic-nreg $nreg -magic-latency $latency $dif $delay | $INDENT >pfftw.$size.$nreg.$latency.$dif.$delay.c
$GENERATOR $GOPTS -notwiddleinv $size -magic-nreg $nreg -magic-latency $latency $dif $delay | $INDENT >pfftwi.$size.$nreg.$latency.$dif.$delay.c
done
done
done
done
done

for size in 2 4; do
for nreg in 6 7 8; do
for latency in 1 2 3 4; do
for dif in "-magic-pfftw" "-magic-dif"; do
for delay in "-magic-pfftw" "-magic-delay-stores"; do
$GENERATOR $GOPTS -twiddle $size -magic-nreg $nreg -magic-latency $latency $dif $delay | $INDENT >pfftww.$size.$nreg.$latency.$dif.$delay.c
$GENERATOR $GOPTS -twiddleinv $size -magic-nreg $nreg -magic-latency $latency $dif $delay | $INDENT >pfftwwi.$size.$nreg.$latency.$dif.$delay.c
done
done
done
done
done

