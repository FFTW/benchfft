#include <pfftw-int.h>

void PFFTW(512)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_512)[];
     PFFTW(twiddle_4)(input, PFFTW(W_512), 128);
     PFFTW(128)(input + 128 * 0);
     PFFTW(128)(input + 128 * 1);
     PFFTW(128)(input + 128 * 2);
     PFFTW(128)(input + 128 * 3);
}

int PFFTW(permutation_512)(int i)
{
    int i1 = i % 4;
    int i2 = i / 4;
    if (i1 <= (4 / 2))
       return (i1 * 128 + PFFTW(permutation_128)(i2));
    else
       return (i1 * 128 + PFFTW(permutation_128)((i2 + 1) % 128));
}

