#include <pfftw-int.h>

void PFFTW(256)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_256)[];
     PFFTW(twiddle_4)(input, PFFTW(W_256), 64);
     PFFTW(64)(input + 64 * 0);
     PFFTW(64)(input + 64 * 1);
     PFFTW(64)(input + 64 * 2);
     PFFTW(64)(input + 64 * 3);
}

int PFFTW(permutation_256)(int i)
{
    int i1 = i % 4;
    int i2 = i / 4;
    if (i1 <= (4 / 2))
       return (i1 * 64 + PFFTW(permutation_64)(i2));
    else
       return (i1 * 64 + PFFTW(permutation_64)((i2 + 1) % 64));
}

