type reg = ST of int
type memory = M of string
type mode = FLOAT | DOUBLE
type instr =
    FADD of reg * reg 
  | FADDP of reg * reg 
  | FADDS of memory * reg * mode
  | FSUB of reg * reg 
  | FSUBP of reg * reg 
  | FSUBS of memory * reg * mode
  | FSUBR of reg * reg 
  | FSUBRP of reg * reg 
  | FSUBRS of memory * reg * mode
  | FMUL of reg * reg 
  | FMULP of reg * reg 
  | FMULS of memory * reg * mode
  | FLD of reg * reg
  | FLDS of memory * reg * mode
  | FSTPS of reg * memory * mode
  | FSTS of reg * memory * mode
  | FXCH of reg * reg
  | OTHER of string
  | LABEL of string

let tos = ST 0

let string_of_char c =
  String.make 1 c

let st_number = parser 
    [< ''('; ''0'..'7' as c; '')' >] -> ST (int_of_char c - int_of_char '0')
  | [< >] -> tos

let st = parser
    [< ''%'; ''s'; ''t'; n=st_number >] -> n

let space = parser
    [< '' '|'\t' >] -> ()

let comma = parser
    [< '',' >] -> ()

let rec rest_of_line = parser
  | [< '_ as x; y = rest_of_line >] -> (string_of_char x) ^ y
  | [< ''\n' >] -> ""
  | [< >] -> ""

let fadd = parser
    [< ''f'; ''a'; ''d'; ''d' >] -> ()
let fsub = parser
    [< >] -> ()

let faddinstr = parser
  | [< ''p'; _ = space; x = st; _ = comma; y = st >] -> FADDP (x, y)
  | [< ''s'; _ = space; y = rest_of_line >] -> FADDS (M y, tos, FLOAT)
  | [< ''l'; _ = space; y = rest_of_line >] -> FADDS (M y, tos, DOUBLE)
  | [< _ = space; x = st; _ = comma; y = st >] -> FADD (x, y)

let fsubrinstr = parser
  | [< ''p'; _ = space; x = st; _ = comma; y = st >] -> FSUBRP (x, y)
  | [< ''s'; _ = space; y = rest_of_line >] -> FSUBRS (M y, tos, FLOAT)
  | [< ''l'; _ = space; y = rest_of_line >] -> FSUBRS (M y, tos, DOUBLE)
  | [< _ = space; x = st; _ = comma; y = st >] -> 
      match x with
	ST 0 -> FSUB (x, y)
      |	_ -> FSUBR (x, y)

let fsubinstr = parser
  | [< ''r'; x = fsubrinstr >] -> x
  | [< ''p'; _ = space; x = st; _ = comma; y = st >] -> FSUBP (x, y)
  | [< ''s'; _ = space; y = rest_of_line >] -> FSUBS (M y, tos, FLOAT)
  | [< ''l'; _ = space; y = rest_of_line >] -> FSUBS (M y, tos, DOUBLE)
  | [< _ = space; x = st; _ = comma; y = st >] -> FSUB (x, y)

let fmulinstr = parser
  | [< ''p'; _ = space; x = st; _ = comma; y = st >] -> FMULP (x, y)
  | [< ''s'; _ = space; y = rest_of_line >] -> FMULS (M y, tos, FLOAT)
  | [< ''l'; _ = space; y = rest_of_line >] -> FMULS (M y, tos, DOUBLE)
  | [< _ = space; x = st; _ = comma; y = st >] -> FMUL (x, y)

let fldinstr = parser
  | [< ''s'; _ = space; y = rest_of_line >] -> FLDS (M y, tos, FLOAT)
  | [< ''l'; _ = space; y = rest_of_line >] -> FLDS (M y, tos, DOUBLE)
  | [< _ = space; y = st >] -> FLD (y, tos)

let fxchinstr = parser
  | [< _ = space; y = st >] -> FXCH (y, tos)

let fstpinstr = parser
  | [< ''s'; _ = space; y = rest_of_line >] -> FSTPS (tos, M y, FLOAT)
  | [< ''l'; _ = space; y = rest_of_line >] -> FSTPS (tos, M y, DOUBLE)

let fstinstr = parser
  | [< ''p'; x = fstpinstr >] -> x
  | [< ''s'; _ = space; y = rest_of_line >] -> FSTS (tos, M y, FLOAT)
  | [< ''l'; _ = space; y = rest_of_line >] -> FSTS (tos, M y, DOUBLE)

let fsinstr = parser 
  | [< ''u'; ''b'; x = fsubinstr >] -> x
  | [< ''t'; x = fstinstr >] -> x

let finstr = parser
  | [< ''a'; ''d'; ''d'; x = faddinstr >] -> x
  | [< ''s'; x = fsinstr >] -> x
  | [< ''m'; ''u'; ''l'; x = fmulinstr >] -> x
  | [< ''l'; ''d'; x = fldinstr >] -> x
  | [< ''x'; ''c'; ''h'; x = fxchinstr >] -> x

let instr = parser
  | [< ''f'; x = finstr >] -> x
  | [< y = rest_of_line >] -> OTHER y

let tabinstr = parser
    [< ''\t'; x = instr >] -> x
  | [< y = rest_of_line >] -> LABEL y

let rec read_input () =
  try
    let s = read_line () in
    s :: read_input ()
  with End_of_file -> []

let parse_input = List.map 
    (fun x -> tabinstr (Stream.of_string x))

let unparse_st (ST i) = match i with
  0 -> "%st"
| _ -> "%st(" ^ (string_of_int i) ^ ")"

let unparse_st0 (ST i) = "%st(" ^ (string_of_int i) ^ ")"

let unparse_stt (ST i) = match i with
  0 -> ""
| _ -> ",%st(" ^ (string_of_int i) ^ ")"

let unparse_mem (M m) = m

let two_sts x y =
  unparse_st x ^ "," ^ unparse_st y

let unparse_instr = function
  | FADD (x, y) -> "fadd " ^ two_sts x y
  | FADDP (x, y) -> "faddp " ^ two_sts x y
  | FADDS (m, x, FLOAT) -> "fadds " ^ unparse_mem m ^ unparse_stt x
  | FADDS (m, x, DOUBLE) -> "faddl " ^ unparse_mem m ^ unparse_stt x
  | FMUL (x, y) -> "fmul " ^ two_sts x y
  | FMULP (x, y) -> "fmulp " ^ two_sts x y
  | FMULS (m, x, FLOAT) -> "fmuls " ^ unparse_mem m ^ unparse_stt x
  | FMULS (m, x, DOUBLE) -> "fmull " ^ unparse_mem m ^ unparse_stt x
  | FSUB (x, y) -> "fsub " ^ two_sts x y
  | FSUBP (x, y) -> "fsubp " ^ two_sts x y
  | FSUBS (m, x, FLOAT) -> "fsubs " ^ unparse_mem m ^ unparse_stt x
  | FSUBS (m, x, DOUBLE) -> "fsubl " ^ unparse_mem m ^ unparse_stt x
  | FSUBR (x, y) -> "fsubr " ^ two_sts x y
  | FSUBRP (x, y) -> "fsubrp " ^ two_sts x y
  | FSUBRS (m, x, FLOAT) -> "fsubrs " ^ unparse_mem m ^ unparse_stt x
  | FSUBRS (m, x, DOUBLE) -> "fsubrl " ^ unparse_mem m ^ unparse_stt x
  | FLD (y, x) -> "fld " ^ unparse_st0 y ^ unparse_stt x
  | FLDS (m, x, FLOAT) -> "flds " ^ unparse_mem m ^ unparse_stt x
  | FLDS (m, x, DOUBLE) -> "fldl " ^ unparse_mem m ^ unparse_stt x
  | FXCH (y, x) -> "fxch " ^ unparse_st y ^ unparse_stt x
  | FSTS (x, m, FLOAT) -> "fsts " ^ unparse_mem m ^ unparse_stt x
  | FSTS (x, m, DOUBLE) -> "fstl " ^ unparse_mem m ^ unparse_stt x
  | FSTPS (x, m, FLOAT) -> "fstps " ^ unparse_mem m ^ unparse_stt x
  | FSTPS (x, m, DOUBLE) -> "fstpl " ^ unparse_mem m ^ unparse_stt x
  | OTHER x -> x
  | LABEL s -> failwith "label"

let unparse_tabinstr = function
    LABEL s -> s
  | x -> "\t" ^ unparse_instr x

let unparse_input = List.map unparse_tabinstr

let write_output =  List.iter (fun x -> print_string (x ^ "\n"))

let pops = function
    FADDP _ -> true
  | FSUBP _ -> true
  | FSUBRP _ -> true
  | FMULP _ -> true
  | FSTPS _ -> true
  | _ -> false

let fadd_type = function
    FADD _ -> true
  | FSUB _ -> true
  | FSUBR _ -> true
  | FMUL _ -> true
  | _ -> false

let fadds_type = function
    FADDS _ -> true
  | FSUBS _ -> true
  | FSUBRS _ -> true
  | FMULS _ -> true
  | _ -> false

let source_op = function
    FADDP (x, _) -> x
  | FSUBP (x, _) -> x
  | FSUBRP (x, _) -> x
  | FMULP (x, _) -> x
  | FSTPS (x, _, _) -> x
  | _ -> failwith "source_op"

let dest_op = function
  | FADDS (_, x, _) -> x
  | FSUBS (_, x, _) -> x
  | FSUBRS (_, x, _) -> x
  | FMULS (_, x, _) -> x
  | FADD (_, x) -> x
  | FSUB (_, x) -> x
  | FSUBR (_, x) -> x
  | FMUL (_, x) -> x
  | FLD (_, x) -> x
  | FLDS (_, x, _) -> x
  | _ -> failwith "dest_op"

let pushes = function
  | FLD _ -> true
  | FLDS _ -> true
  | _ -> false

let map_instr map = function
  | FADD (x, y) -> FADD (map x, map y) 
  | FADDP (x, y) -> FADDP (map x, map y)
  | FADDS (m, y, mode) -> FADDS (m, map y, mode) 
  | FSUB (x, y) -> FSUB (map x, map y) 
  | FSUBP (x, y) -> FSUBP (map x, map y)
  | FSUBS (m, y, mode) -> FSUBS (m, map y, mode) 
  | FSUBR (x, y) -> FSUBR (map x, map y) 
  | FSUBRP (x, y) -> FSUBRP (map x, map y)
  | FSUBRS (m, y, mode) -> FSUBRS (m, map y, mode) 
  | FMUL (x, y) -> FMUL (map x, map y) 
  | FMULP (x, y) -> FMULP (map x, map y)
  | FMULS (m, y, mode) -> FMULS (m, map y, mode) 
  | FLDS (m, y, mode) -> FLDS (m, map y, mode)
  | FLD (x, y) -> FLD (map x, map y)
  | FSTS (x, m, mode) -> FSTS (map x, m, mode)
  | FSTPS (x, m, mode) -> FSTPS (map x, m, mode)
  | FXCH (x, y) -> FXCH (map x, map y)
  | x -> x

(* map stack reg numbers to absolute *)
let rec map_to_abs map = function
    [] -> []
  | a :: b ->
      if (pops a) then
	(map_instr map a) :: map_to_abs (fun (ST x) -> map (ST (x + 1))) b
      else match a with
      |	FLD (x, _) ->
	  let newmap (ST x) = map (ST (x - 1)) in
	  FLD (map x, newmap tos) :: map_to_abs newmap b
      |	FLDS (x, _, mode) ->
	  let newmap (ST x) = map (ST (x - 1)) in
	  FLDS (x, newmap tos, mode) :: map_to_abs newmap b
      |	FXCH (x, y) ->
	  let (ST x) = map x and (ST y) = map y in
	  map_to_abs 
	    (fun v -> let (ST v') = map v in
	      if (v' == x) then
		(ST y)
	      else if (v' == y) then
		(ST x)
	      else (ST v'))
	    b
      |	_ -> (map_instr map a) :: map_to_abs map b


(* find int x, x >= a, such that (p x) is true *)
let rec suchthat a pred =
  if (pred a) then a else suchthat (a + 1) pred

let emit_xchg (ST dest) map =
  let itos = suchthat 0 (fun i -> let (ST j) = map (ST i) in j == 0) in
  ((fun (ST i) -> 
    if (i == dest) then tos
    else if (i == itos) then map (ST dest)
    else map (ST i)),
   match map (ST dest) with
   | ST 0 -> OTHER "# fxch st"
   | x -> FXCH (x, tos))
  
let rec map_to_stack = function
    [] -> ((fun (ST i) -> ST i), [])
  | a :: b ->
      let (map, rest) = map_to_stack b in
      (* is pop instruction, force source to be at top of the stack *)
      if (pops a) then
	let (ST source) = source_op a in
	let newmap (ST i) =
	  if (i == source) then
	    tos
	  else 
	    let (ST i') = map (ST i) in
	    ST (i' + 1) in
	(newmap, (map_instr newmap a) :: rest)
      else if (fadd_type a || fadds_type a) then
	let dest = dest_op a in
	let (newmap, xchg) = emit_xchg dest map in
	(newmap, (map_instr newmap a) :: xchg :: rest)
      else match a with
      |	FSTS (y, m, _) ->
	  let (newmap, xchg) = emit_xchg y map in
	  (newmap, (map_instr newmap a) :: xchg :: rest)
      |	FLD (x, y) ->
	  let (newmap, xchg) = emit_xchg y map in
	  let newmap' i =
	    let (ST i') = newmap i in
	    ST (i' - 1) in
	  (newmap', FLD (newmap' x, newmap y) :: xchg :: rest)
      |	FLDS (x, y, mode) ->
	  let (newmap, xchg) = emit_xchg y map in
	  let newmap' i =
	    let (ST i') = newmap i in
	    ST (i' - 1) in
	  (newmap', FLDS (x, newmap y, mode) :: xchg :: rest)
      |	a -> (map, (map_instr map a) :: rest)
      

let main() =
  let i = read_input() in
  let i = parse_input i in
  let i = map_to_abs (fun (ST x) -> ST (x + 8)) i in 
  let (_, i) = map_to_stack i in 
  let s = unparse_input i in
  write_output s

let _ = main()
