#!/bin/sh

(cd gensrc; make)
GENERATOR=./gensrc/genfft
GOPTS="-magic-pfftw -magic-inline-loads -magic-no-inline-single -magic-twiddle-positive  -magic-variables 4 -magic-loopi"
INDENT=indent

$GENERATOR $GOPTS -notwiddle 2  | $INDENT >pfftw_2.c
$GENERATOR $GOPTS -notwiddleinv 2  | $INDENT >pfftwi_2.c
$GENERATOR $GOPTS -notwiddle 4  | $INDENT >pfftw_4.c
$GENERATOR $GOPTS -notwiddleinv 4  | $INDENT >pfftwi_4.c
$GENERATOR $GOPTS -notwiddle 8 -magic-nreg 8 -magic-latency 2 | $INDENT >pfftw_8.c
$GENERATOR $GOPTS -notwiddleinv 8  -magic-dif -magic-nreg 8 -magic-latency 2 | $INDENT >pfftwi_8.c
$GENERATOR $GOPTS -notwiddle 16 -magic-dif -magic-nreg 8 -magic-latency 2 | $INDENT >pfftw_16.c
$GENERATOR $GOPTS -notwiddleinv 16 -magic-nreg 8 -magic-latency 3 -magic-dif | $INDENT >pfftwi_16.c
$GENERATOR $GOPTS -notwiddle 32  -magic-nreg 8 -magic-latency 1 -magic-delay-stores | $INDENT >pfftw_32.c
$GENERATOR $GOPTS -notwiddleinv 32  -magic-nreg 8 -magic-latency 1 -magic-delay-stores | $INDENT >pfftwi_32.c

$GENERATOR $GOPTS -twiddle 2 | $INDENT >pfftww_2.c
$GENERATOR $GOPTS -twiddleinv 2 | $INDENT >pfftwwi_2.c
$GENERATOR $GOPTS -twiddle 4 -magic-nreg 8 -magic-latency 1 -magic-delay-stores | $INDENT >pfftww_4.c
$GENERATOR $GOPTS -twiddleinv 4 -magic-latency 1 -magic-dif -magic-nreg 8 -magic-delay-stores | $INDENT >pfftwwi_4.c
#  $GENERATOR $GOPTS -twiddle 8 -magic-nreg 8 -magic-latency 1 | $INDENT >pfftww_8.c
#  $GENERATOR $GOPTS -twiddleinv 8 -magic-nreg 8 -magic-latency 1 | $INDENT >pfftwwi_8.c
#  $GENERATOR $GOPTS -twiddle 16 | $INDENT >pfftww_16.c
#  $GENERATOR $GOPTS -twiddleinv 16 | $INDENT >pfftwwi_16.c

perl -w genpfftw.pl -fw 64 4 >pfftw_64.c
perl -w genpfftw.pl -bw 64 4 >pfftwi_64.c
perl -w genpfftw.pl -rt 64 4 >pfftwr_64.c
perl -w genpfftw.pl -fw 128 4 >pfftw_128.c
perl -w genpfftw.pl -bw 128 4 >pfftwi_128.c
perl -w genpfftw.pl -rt 128 4 >pfftwr_128.c
perl -w genpfftw.pl -fw 256 4 >pfftw_256.c
perl -w genpfftw.pl -bw 256 4 >pfftwi_256.c
perl -w genpfftw.pl -rt 256 4 >pfftwr_256.c
perl -w genpfftw.pl -fw 512 4 >pfftw_512.c
perl -w genpfftw.pl -bw 512 4 >pfftwi_512.c
perl -w genpfftw.pl -rt 512 4 >pfftwr_512.c
perl -w genpfftw.pl -fw 1024 4 >pfftw_1024.c
perl -w genpfftw.pl -bw 1024 4 >pfftwi_1024.c
perl -w genpfftw.pl -rt 1024 4 >pfftwr_1024.c
