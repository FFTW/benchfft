trysize=256
make optim
CFLAGS="-DSINGLE_PRECISION"

for size in 4; do
for nreg in 6 7 8; do
for latency in 1 2 3 4; do
for dif in "-magic-pfftw" "-magic-dif"; do
for delay in "-magic-pfftw" "-magic-delay-stores"; do
echo "$size.$nreg.$latency.$dif.$delay."
make pfftww.$size.$nreg.$latency.$dif.$delay.opts pfftwwi.$size.$nreg.$latency.$dif.$delay.opts >/dev/null
as pfftww.$size.$nreg.$latency.$dif.$delay.opts -o try_1.o
as pfftwwi.$size.$nreg.$latency.$dif.$delay.opts -o try_2.o
gcc -O -fomit-frame-pointer -I.. $CFLAGS -DSIZE="$trysize" ../speed.c try_1.o try_2.o ../libpfftw.a -o try
./try
done
done
done
done
done