#include <pfftw-int.h>

void PFFTWI(256)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_256)[];
     PFFTWI(64)(input + 64 * 0);
     PFFTWI(64)(input + 64 * 1);
     PFFTWI(64)(input + 64 * 2);
     PFFTWI(64)(input + 64 * 3);
     PFFTWI(twiddle_4)(input, PFFTW(W_256), 64);
}
