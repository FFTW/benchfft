$spill_area = "pfftw_spill_area";
$stack_offset = 0;
$max_spill = -1;
print ".globl ${spill_area}\n";
while (<>) {
    if (/^\tf(.*) (\d+)\(%esp\)$/) {
	print "\tf${1} (${spill_area} + ${2})\n";
	if ($2 > $max_spill) {$max_spill = $2;}
    } elsif (/^\tf(.*) \(%esp\)$/) {
	print "\tf${1} ${spill_area}\n";
	if ($max_spill < 0) {$max_spill = 0;}
    } elsif (/^\tsubl \$(\d+),%esp/) {
	$stack_offset = $1;
    } elsif (/^\taddl \$(\d+),%esp/) {
	die if ($1 != $stack_offset);
    } elsif (/^\tmovl (\d+)\(%esp\),(.+)/) {
	$n=$1-$stack_offset;
	print "\tmovl ${n}(%esp),$2\n";
    } else {
	print $_;
    }
}

if ($max_spill >= 0) {
    $max_spill = $max_spill + 8;
    print "\t.comm ${spill_area},${max_spill},8\n";
}
