#include "pfftw-int.h"
#include <stdio.h>
#include <malloc.h>

#ifndef SIZE
#define SIZE 256
#endif

typedef long long fftw_time;
#define fftw_get_time(x) asm volatile("rdtsc" : "=A"(*(x)))
#define fftw_time_diff(x,y) ((x) - (y))

/*
 * put array in data area so that it will not
 * conflict with roots of unity
 */
fftw_complex A[SIZE] = {{0.0, 0.0}};

/* null pseudo-fft routines to measure timing overhead */
#define pfftw_s_0(A)
#define pfftw_d_0(A)
#define pfftwi_s_0(A)
#define pfftwi_d_0(A)

#define TIMINGS 7

fftw_time start[TIMINGS] = {0};
fftw_time stop[TIMINGS] = {0};

#define TIME(result, what) do {                                   	\
     for (i = 0; i < TIMINGS; ++i) {                              	\
	  fftw_get_time(&start[i]);                               	\
	  what;                                                   	\
	  fftw_get_time(&stop[i]);                                	\
     } 									\
     for (i = 0; i < TIMINGS;++i) 					\
	  result[i] = (int)fftw_time_diff(stop[i],start[i]); 		\
} while(0)

int resultf[TIMINGS] = {0};
int resultb[TIMINGS] = {0};

int main(int argc, char *argv[])
{
     int i;
     int min;

     for (i = 0; i < SIZE; ++i)
	  A[i].re = A[i].im = 0.0;

     /* bring the start and stop arrays into cache */
     memcpy(start, start, sizeof(start));
     memcpy(stop, stop, sizeof(stop));

     TIME(resultf, PFFTW(SIZE)(A));
     TIME(resultb, PFFTWI(SIZE)(A));

     printf("%6d %d+", SIZE, sizeof(fftw_real));
     min = 2147483647;
     for (i = 0; i < TIMINGS; ++i) {
	  printf(" %7d", resultf[i]);
	  if (resultf[i] < min) min = resultf[i];
     }
     printf(" |%7d\n", min);

     printf("%6d %d-", SIZE, sizeof(fftw_real));
     min = 2147483647;
     for (i = 0; i < TIMINGS; ++i) {
	  printf(" %7d", resultb[i]);
	  if (resultb[i] < min) min = resultb[i];
     }
     printf(" |%7d\n", min);

     exit(0);
}
