#include "pfftw-int.h"
#include <stdio.h>
#include <malloc.h>
#include <sys/time.h>
#include <sys/types.h>

#ifndef SIZE
#define SIZE 256
#endif

#ifdef linux
typedef struct timeval fftw_time;
#define fftw_get_time(x) gettimeofday((x), (struct timezone *)0)
#define fftw_time_diff(x,y) (((x).tv_usec - (y).tv_usec) + 1000000 * ((x).tv_sec - (y).tv_sec))
#define fftw_time_zero {0, 0}
#else
typedef hrtime_t fftw_time;
#define fftw_get_time(x) *x = gethrtime()
#define fftw_time_diff(x,y) ((x) - (y))
#define fftw_time_zero 0
#endif

/*
 * put array in data area so that it will not
 * conflict with roots of unity
 */
fftw_complex A[SIZE] = {{0.0, 0.0}};

/* null pseudo-fft routines to measure timing overhead */
#define pfftw_s_0(A)
#define pfftw_d_0(A)
#define pfftwi_s_0(A)
#define pfftwi_d_0(A)

#define TIMINGS 7

fftw_time start[TIMINGS] = {fftw_time_zero};
fftw_time stop[TIMINGS] = {fftw_time_zero};

#define TIME(result, what) do {					\
     for (i = 0; i < TIMINGS; ++i) {				\
	  fftw_get_time(&start[i]);				\
          what;							\
	  fftw_get_time(&stop[i]);				\
     }								\
     for (i = 0; i < TIMINGS;++i)				\
	  result[i] = (int)fftw_time_diff(stop[i],start[i]);	\
} while(0)

int resultf[TIMINGS] = {0};
int resultb[TIMINGS] = {0};

int main(int argc, char *argv[])
{
     int i;
     int min;

     for (i = 0; i < SIZE; ++i)
	  A[i].re = A[i].im = 0.0;

     /* bring the start and stop arrays into cache */
     memcpy(start, start, sizeof(start));
     memcpy(stop, stop, sizeof(stop));

     TIME(resultf, PFFTW(SIZE)(A));
     TIME(resultb, PFFTWI(SIZE)(A));

     printf("%6d %d+", SIZE, sizeof(fftw_real));
     min = 2147483647;
     for (i = 0; i < TIMINGS; ++i) {
	  printf(" %7d", resultf[i]);
	  if (resultf[i] < min) min = resultf[i];
     }
     printf(" |%7d\n", min);

     printf("%6d %d-", SIZE, sizeof(fftw_real));
     min = 2147483647;
     for (i = 0; i < TIMINGS; ++i) {
	  printf(" %7d", resultb[i]);
	  if (resultb[i] < min) min = resultb[i];
     }
     printf(" |%7d\n", min);

     exit(0);
}
