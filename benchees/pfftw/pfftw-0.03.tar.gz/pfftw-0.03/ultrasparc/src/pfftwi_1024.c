#include <pfftw-int.h>

void PFFTWI(1024)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_1024)[];
     PFFTWI(128)(input + 128 * 0);
     PFFTWI(128)(input + 128 * 1);
     PFFTWI(128)(input + 128 * 2);
     PFFTWI(128)(input + 128 * 3);
     PFFTWI(128)(input + 128 * 4);
     PFFTWI(128)(input + 128 * 5);
     PFFTWI(128)(input + 128 * 6);
     PFFTWI(128)(input + 128 * 7);
     PFFTWI(twiddle_8)(input, PFFTW(W_1024), 128);
}
