trysize=64
CFLAGS="-funroll-loops -DDOUBLE_PRECISION"

for size in 4; do
for nreg in 20 21 22 23 24 25 26 27 28 29 30 31; do
for latency in 1 2 3 4 5 6 7 8 9 10; do
for dif in "-magic-pfftw" "-magic-dif"; do
for delay in "-magic-pfftw" "-magic-delay-stores"; do
for recycle in "-magic-pfftw" "-magic-recycle"; do
for recycle2 in "-magic-pfftw" "-magic-recycle2"; do
echo "$size.$nreg.$latency.$dif.$delay.$recycle.$recycle2."
as -xarch=v8plusa pfftww.$size.$nreg.$latency.$dif.$delay.$recycle.$recycle2.s -o try_1.o
as -xarch=v8plusa pfftwwi.$size.$nreg.$latency.$dif.$delay.$recycle.$recycle2.s -o try_2.o
gcc -O -fomit-frame-pointer -I.. $CFLAGS -DSIZE="$trysize" ../speed.c try_1.o try_2.o ../libpfftw.a -o try
./try
./try
./try
./try
./try
./try
./try
./try
./try
./try
done
done
done
done
done
done
done
