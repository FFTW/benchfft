#include <pfftw-int.h>

void PFFTW(512)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_512)[];
     PFFTW(twiddle_8)(input, PFFTW(W_512), 64);
     PFFTW(64)(input + 64 * 0);
     PFFTW(64)(input + 64 * 1);
     PFFTW(64)(input + 64 * 2);
     PFFTW(64)(input + 64 * 3);
     PFFTW(64)(input + 64 * 4);
     PFFTW(64)(input + 64 * 5);
     PFFTW(64)(input + 64 * 6);
     PFFTW(64)(input + 64 * 7);
}

int PFFTW(permutation_512)(int i)
{
    int i1 = i % 8;
    int i2 = i / 8;
    if (i1 <= (8 / 2))
       return (i1 * 64 + PFFTW(permutation_64)(i2));
    else
       return (i1 * 64 + PFFTW(permutation_64)((i2 + 1) % 64));
}

