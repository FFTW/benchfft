(cd gensrc; make)
GENERATOR=./gensrc/genfft
GOPTS="-magic-pfftw -magic-no-inline-loads -magic-no-inline-single -magic-twiddle-positive  -magic-variables 4 -magic-loopi -magic-latency 7 -magic-load-latency 2 -magic-nreg 28"
INDENT=indent
REWRITE="perl rewrite-decl.pl"

for size in 2 4 8 16 32; do
for nreg in 20 21 22 23 24 25 26 27 28 29 30 31; do
for latency in 1 2 3 4 5 6 7 8 9 10; do
for dif in "-magic-pfftw" "-magic-dif"; do
for delay in "-magic-pfftw" "-magic-delay-stores"; do
for recycle in "-magic-pfftw" "-magic-recycle"; do
for recycle2 in "-magic-pfftw" "-magic-recycle2"; do
$GENERATOR $GOPTS -notwiddle $size -magic-nreg $nreg -magic-latency $latency $dif $delay $recycle $recycle2 | $REWRITE | $INDENT >pfftw.$size.$nreg.$latency.$dif.$delay.$recycle.$recycle2.c
$GENERATOR $GOPTS -notwiddleinv $size -magic-nreg $nreg -magic-latency $latency $dif $delay $recycle $recycle2 | $REWRITE | $INDENT >pfftwi.$size.$nreg.$latency.$dif.$delay.$recycle.$recycle2.c
done
done
done
done
done&
done
wait
done

for size in 2 4 8 16; do
for nreg in 20 21 22 23 24 25 26 27 28 29 30 31; do
for latency in 1 2 3 4 5 6 7 8 9 10; do
for dif in "-magic-pfftw" "-magic-dif"; do
for delay in "-magic-pfftw" "-magic-delay-stores"; do
for recycle in "-magic-pfftw" "-magic-recycle"; do
for recycle2 in "-magic-pfftw" "-magic-recycle2"; do
$GENERATOR $GOPTS -twiddle $size -magic-nreg $nreg -magic-latency $latency $dif $delay $recycle $recycle2 | $REWRITE | $INDENT >pfftww.$size.$nreg.$latency.$dif.$delay.$recycle.$recycle2.c
$GENERATOR $GOPTS -twiddleinv $size -magic-nreg $nreg -magic-latency $latency $dif $delay $recycle $recycle2 | $REWRITE | $INDENT >pfftwwi.$size.$nreg.$latency.$dif.$delay.$recycle.$recycle2.c
done
done
done
done
done&
done
wait
done

