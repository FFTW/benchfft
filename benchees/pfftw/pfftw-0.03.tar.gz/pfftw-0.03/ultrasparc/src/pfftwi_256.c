#include <pfftw-int.h>

void PFFTWI(256)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_256)[];
     PFFTWI(32)(input + 32 * 0);
     PFFTWI(32)(input + 32 * 1);
     PFFTWI(32)(input + 32 * 2);
     PFFTWI(32)(input + 32 * 3);
     PFFTWI(32)(input + 32 * 4);
     PFFTWI(32)(input + 32 * 5);
     PFFTWI(32)(input + 32 * 6);
     PFFTWI(32)(input + 32 * 7);
     PFFTWI(twiddle_8)(input, PFFTW(W_256), 32);
}
