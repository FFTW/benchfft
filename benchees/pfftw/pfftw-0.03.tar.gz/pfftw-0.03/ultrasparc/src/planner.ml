(*
 * static planner, which produces ``optimal'' plans based on the
 * cycle counts produced by gcc
 *)
let forw_cost =
  ([(2, 8);
     (4, 20);
     (8, 56);
     (16, 148);
     (32, 394)],
   [(4, (23, 31));
     (8, (66, 75));
     (16, (183, 236))])

let back_cost =
  ([(2, 8);
     (4, 20);
     (8, 56);
     (16, 148);
     (32, 394)],
   [(4, (23, 36));
     (8, (62, 81));
     (16, (191, 233))])

let maximize f =
  let rec loop best best_val = function
      [] -> best
    | a :: b -> 
	let this_val = f a in
	if (this_val > best_val) then
	  loop a this_val b
	else
	  loop best best_val b
  in function
      [] -> failwith "maximize"
    |	a :: b ->
	loop a (f a) b

let function_call_cost = 2 (* approximate *)

let rec myassoc x = function
    [] -> None
  | (a,b)::l -> if a = x then Some b else myassoc x l

type codelet = TWIDDLE of int | NOTW of int

let rec planner (notw_cost, twiddle_cost) n =
  match myassoc n notw_cost with
    Some c -> ([NOTW n], c)
  | None ->
      let radix (r, (d1, d2)) =
	let (p, c) = planner (notw_cost, twiddle_cost) (n / r) in
	(TWIDDLE r :: p), ((c + function_call_cost) * r + d1 + function_call_cost + ((n / r - 1) * d2))
      in let subplans = List.map radix twiddle_cost in
      maximize (fun (p, c) -> (-c)) subplans

      
  
