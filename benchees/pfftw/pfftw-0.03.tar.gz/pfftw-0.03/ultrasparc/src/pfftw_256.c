#include <pfftw-int.h>

void PFFTW(256)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_256)[];
     PFFTW(twiddle_8)(input, PFFTW(W_256), 32);
     PFFTW(32)(input + 32 * 0);
     PFFTW(32)(input + 32 * 1);
     PFFTW(32)(input + 32 * 2);
     PFFTW(32)(input + 32 * 3);
     PFFTW(32)(input + 32 * 4);
     PFFTW(32)(input + 32 * 5);
     PFFTW(32)(input + 32 * 6);
     PFFTW(32)(input + 32 * 7);
}

int PFFTW(permutation_256)(int i)
{
    int i1 = i % 8;
    int i2 = i / 8;
    if (i1 <= (8 / 2))
       return (i1 * 32 + PFFTW(permutation_32)(i2));
    else
       return (i1 * 32 + PFFTW(permutation_32)((i2 + 1) % 32));
}

