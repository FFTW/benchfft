#!/bin/sh

(cd gensrc; make)
GENERATOR=./gensrc/genfft
GOPTS="-magic-pfftw -magic-no-inline-loads -magic-no-inline-single -magic-twiddle-positive  -magic-variables 4 -magic-loopi -magic-latency 7 -magic-load-latency 2 -magic-nreg 28"
REWRITE="perl rewrite-decl.pl"
INDENT=indent

$GENERATOR $GOPTS -notwiddle 2  | $REWRITE | $INDENT >pfftw_2.c
$GENERATOR $GOPTS -notwiddleinv 2  | $REWRITE | $INDENT >pfftwi_2.c
$GENERATOR $GOPTS -notwiddle 4  | $REWRITE | $INDENT >pfftw_4.c
$GENERATOR $GOPTS -notwiddleinv 4  | $REWRITE | $INDENT >pfftwi_4.c
$GENERATOR $GOPTS -notwiddle 8 -magic-nreg 30 -magic-latency 9 -magic-delay-stores -magic-recycle  | $REWRITE | $INDENT >pfftw_8.c
$GENERATOR $GOPTS -notwiddleinv 8  -magic-nreg 24 -magic-latency 6 -magic-dif -magic-delay-stores -magic-recycle  | $REWRITE | $INDENT >pfftwi_8.c
$GENERATOR $GOPTS -notwiddle 16 -magic-nreg 30 -magic-latency 9 -magic-recycle2 | $REWRITE | $INDENT >pfftw_16.c
$GENERATOR $GOPTS -notwiddleinv 16 -magic-nreg 25 -magic-latency 10 -magic-recycle | $REWRITE | $INDENT >pfftwi_16.c
$GENERATOR $GOPTS -notwiddle 32 -magic-nreg 24 -magic-latency 9 -magic-recycle  | $REWRITE | $INDENT >pfftw_32.c
$GENERATOR $GOPTS -notwiddleinv 32 -magic-nreg 23 -magic-latency 9 -magic-dif -magic-recycle | $REWRITE | $INDENT >pfftwi_32.c

$GENERATOR $GOPTS -twiddle 2 | $REWRITE | $INDENT >pfftww_2.c
$GENERATOR $GOPTS -twiddleinv 2 | $REWRITE | $INDENT >pfftwwi_2.c
$GENERATOR $GOPTS -twiddle 4 -magic-nreg 31 -magic-latency 8 -magic-delay-stores | $REWRITE | $INDENT >pfftww_4.c
$GENERATOR $GOPTS -twiddleinv 4 -magic-nreg 30 -magic-latency 4 -magic-dif | $REWRITE | $INDENT >pfftwwi_4.c
$GENERATOR $GOPTS -twiddle 8  -magic-nreg 31 -magic-latency 7 -magic-dif -magic-delay-stores -magic-recycle | $REWRITE | $INDENT >pfftww_8.c
$GENERATOR $GOPTS -twiddleinv 8 -magic-nreg 28 -magic-latency 3 -magic-dif -magic-delay-stores | $REWRITE | $INDENT >pfftwwi_8.c
$GENERATOR $GOPTS -twiddle 16 | $REWRITE | $INDENT >pfftww_16.c
$GENERATOR $GOPTS -twiddleinv 16 | $REWRITE | $INDENT >pfftwwi_16.c

perl -w genpfftw.pl -fw 64 8 >pfftw_64.c
perl -w genpfftw.pl -bw 64 8 >pfftwi_64.c
perl -w genpfftw.pl -rt 64 8 >pfftwr_64.c
perl -w genpfftw.pl -fw 128 8 >pfftw_128.c
perl -w genpfftw.pl -bw 128 8 >pfftwi_128.c
perl -w genpfftw.pl -rt 128 8 >pfftwr_128.c
perl -w genpfftw.pl -fw 256 8 >pfftw_256.c
perl -w genpfftw.pl -bw 256 8 >pfftwi_256.c
perl -w genpfftw.pl -rt 256 8 >pfftwr_256.c
perl -w genpfftw.pl -fw 512 8 >pfftw_512.c
perl -w genpfftw.pl -bw 512 8 >pfftwi_512.c
perl -w genpfftw.pl -rt 512 8 >pfftwr_512.c
perl -w genpfftw.pl -fw 1024 8 >pfftw_1024.c
perl -w genpfftw.pl -bw 1024 8 >pfftwi_1024.c
perl -w genpfftw.pl -rt 1024 8 >pfftwr_1024.c
