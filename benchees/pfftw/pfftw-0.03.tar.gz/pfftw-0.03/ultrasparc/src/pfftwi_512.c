#include <pfftw-int.h>

void PFFTWI(512)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_512)[];
     PFFTWI(64)(input + 64 * 0);
     PFFTWI(64)(input + 64 * 1);
     PFFTWI(64)(input + 64 * 2);
     PFFTWI(64)(input + 64 * 3);
     PFFTWI(64)(input + 64 * 4);
     PFFTWI(64)(input + 64 * 5);
     PFFTWI(64)(input + 64 * 6);
     PFFTWI(64)(input + 64 * 7);
     PFFTWI(twiddle_8)(input, PFFTW(W_512), 64);
}
