#include <pfftw-int.h>

void PFFTWI(128)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_128)[];
     PFFTWI(16)(input + 16 * 0);
     PFFTWI(16)(input + 16 * 1);
     PFFTWI(16)(input + 16 * 2);
     PFFTWI(16)(input + 16 * 3);
     PFFTWI(16)(input + 16 * 4);
     PFFTWI(16)(input + 16 * 5);
     PFFTWI(16)(input + 16 * 6);
     PFFTWI(16)(input + 16 * 7);
     PFFTWI(twiddle_8)(input, PFFTW(W_128), 16);
}
