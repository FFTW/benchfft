while (<>) {
    if (/.*fftw_real R(\d+);/) {
	$m=2*$1;
	print "DECL_REGISTER($1,$m);\n";
    } else {
	print $_;
    }
}
