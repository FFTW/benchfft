#include <pfftw-int.h>

void PFFTW(128)(fftw_complex *input) 
{ 
     extern fftw_complex PFFTW(W_128)[];
     PFFTW(twiddle_8)(input, PFFTW(W_128), 16);
     PFFTW(16)(input + 16 * 0);
     PFFTW(16)(input + 16 * 1);
     PFFTW(16)(input + 16 * 2);
     PFFTW(16)(input + 16 * 3);
     PFFTW(16)(input + 16 * 4);
     PFFTW(16)(input + 16 * 5);
     PFFTW(16)(input + 16 * 6);
     PFFTW(16)(input + 16 * 7);
}

int PFFTW(permutation_128)(int i)
{
    int i1 = i % 8;
    int i2 = i / 8;
    if (i1 <= (8 / 2))
       return (i1 * 16 + PFFTW(permutation_16)(i2));
    else
       return (i1 * 16 + PFFTW(permutation_16)((i2 + 1) % 16));
}

