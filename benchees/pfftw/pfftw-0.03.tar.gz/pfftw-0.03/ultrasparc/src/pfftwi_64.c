#include <pfftw-int.h>

void PFFTWI(64)(fftw_complex *input) 
{
     extern fftw_complex PFFTW(W_64)[];
     PFFTWI(8)(input + 8 * 0);
     PFFTWI(8)(input + 8 * 1);
     PFFTWI(8)(input + 8 * 2);
     PFFTWI(8)(input + 8 * 3);
     PFFTWI(8)(input + 8 * 4);
     PFFTWI(8)(input + 8 * 5);
     PFFTWI(8)(input + 8 * 6);
     PFFTWI(8)(input + 8 * 7);
     PFFTWI(twiddle_8)(input, PFFTW(W_64), 8);
}
