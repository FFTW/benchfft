/* -*- C -*- */

/* pfftw-int.h -- internal definitions */
/* $Id: pfftw-int.h 1.1 Tue, 02 Nov 1999 17:15:02 +0100 athena $ */

#include <pfftw.h>

#define CONCAT_AUX(a, b) a ## b
#define CONCAT(a, b) CONCAT_AUX(a,b)

#ifdef SINGLE_PRECISION
#define fftw_real float
#define fftw_complex fftw_complex_s
#define PFFTW(name)  CONCAT(pfftw_s_, name)
#define PFFTWI(name)  CONCAT(pfftwi_s_, name)
#define REAL_REG31 "%f31" 
#define REAL_REG30 "%f29" 
#define REAL_REG29 "%f27" 
#define REAL_REG28 "%f25" 
#define REAL_REG27 "%f23" 
#define REAL_REG26 "%f21" 
#define REAL_REG25 "%f19" 
#define REAL_REG24 "%f17" 
#define REAL_REG23 "%f15" 
#define REAL_REG22 "%f13" 
#define REAL_REG21 "%f11" 
#define REAL_REG20 "%f9" 
#define REAL_REG19 "%f7" 
#define REAL_REG18 "%f5" 
#define REAL_REG17 "%f3" 
#define REAL_REG16 "%f1" 
#define REAL_REG15 "%f30" 
#define REAL_REG14 "%f26" 
#define REAL_REG13 "%f22" 
#define REAL_REG12 "%f18" 
#define REAL_REG11 "%f14" 
#define REAL_REG10 "%f10" 
#define REAL_REG9 "%f6" 
#define REAL_REG8 "%f2" 
#define REAL_REG7 "%f28" 
#define REAL_REG6 "%f20" 
#define REAL_REG5 "%f12" 
#define REAL_REG4 "%f4" 
#define REAL_REG3 "%f24" 
#define REAL_REG2 "%f8" 
#define REAL_REG1 "%f16" 
#define REAL_REG0 "%f0" 
#define DECL_REGISTER(n, m) register fftw_real R##n asm(REAL_REG##n)
#else
#ifdef DOUBLE_PRECISION
#define fftw_real double
#define fftw_complex fftw_complex_d
#define PFFTW(name)  CONCAT(pfftw_d_, name)
#define PFFTWI(name)  CONCAT(pfftwi_d_, name)
#define DECL_REGISTER(n, m) register fftw_real R##n asm("%f" #m)
#else
#error "Either SINGLE_PRECISION or DOUBLE_PRECISION must be defined"
#endif
#endif

#define FFTW_KONST(x) ((fftw_real) x)
#define const

void PFFTW(twiddle_2)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTW(twiddle_4)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTW(twiddle_8)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTW(twiddle_16)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTWI(twiddle_2)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTWI(twiddle_4)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTWI(twiddle_8)(fftw_complex *A, const fftw_complex *W, int iostride);
void PFFTWI(twiddle_16)(fftw_complex *A, const fftw_complex *W, int iostride);
