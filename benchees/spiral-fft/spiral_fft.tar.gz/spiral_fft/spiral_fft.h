/*
 * Copyright (c) 2000 Carnegie Mellon University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/* spiral_fft.h 
 *
 * This file contains modified code from the
 * file fft.h in the fft package by Sebastian Egner.
 * More information about that package can be found at 
 * http://avalon.ira.uka.de/home/egner
 *
 * Modifications to Egner's FFT:
 *
 * - The generic base field feature was removed. 
 *
 * - The finite field GF(2^8) implementation was removed.
 *
 * - The rader, goodThomas, and bluestein methods were removed.
 *
 * + The method "twiddle" was added.  A twiddle method is a 
 *   decomposition in which the left child is computed with
 *   unrolled code.  This allows the twiddle factor multiplications
 *   to be done inside a small code module ("codelet" in FFTW
 *   notation).
 * 
 * + The order in which the roots of unity for the cooleyTukey 
 *   method are stored was changed so that they can be accessed
 *   more quickly when an FFT is computed.
 * 
 * + The cooleyTukey algorithm was transposed, meaning that,
 *   instead of computing 
 *   L (I (x) F) T (F (x) I), 
 *   the program now computes 
 *   (F (x) I) T (I (x) F) L.  This was done to allow
 *   the twiddle codelets to be inserted.
 *   
 * + The cooleyTukey algorithm was made fully recursive.  That is,
 *   instead of computing
 *   L (I (x) L) (I (x) F) (I (x) T) (I (x) F (x) I) T (F (x) I)
 *   the program now computes
 *   L {I (x) [L (I (x) F) T (F (x) I)]} T (F (x) I) 
 * 
 * + The small code modules were replaced with no-twiddle codelets
 *   and (when possible) twiddle codelets from FFTW.  no-twiddle
 *   codelets compute 
 *   x = F x
 *   at arbitrary stride, and the twiddle codelets compute
 *   x = (F (x) I) T x 
 *   at arbitrary stride.
 * 
 * + All methods were changed to compute
 *   x = F x, performed at arbitrary stride,
 *   instead of 
 *   x = (I (x) F (x) I) x.
 *  
 * These changes cut the execution time of the program by at least
 * 50% for FFT sizes of 2^5 - 2^20.
 */

#if !defined(FFT_H)
#define FFT_H

/**************************************************************/
/*               begin configurable section                   */
/**************************************************************/
/* comment out the #define's and #include's below as necessary
 * to configure the program for your compiler/operating system.
 */

/* Some compilers/operating systems provide alloca() for 
 * allocating space on the runtime stack. This is very 
 * efficient and should be used if possible. Otherwise
 * malloc()/free() are used.  Uncomment the following 
 * define if your compiler provides alloca().
 */
#define FFT_STACK_ALLOC_WITH_ALLOCA

/* Uncomment the following #define if you are using MS Visual 
 * C++.  Visual C++ provides _alloca() (defined in the file 
 * malloc.h) instead of alloca().
 */
/* #define FFT_VISUAL_C_ALLOCA */

/* Uncomment the following #include if your compiler
 * uses alloca.h for alloca().  (Some compilers, such
 * as MS Visual C++, do not use an alloca.h header,
 * even though they do provide an alloca()-type function.)
 */
#include <alloca.h>

/* If the compiler complains about too large macro expansion
 * text in the macro Apply_perm(), then comment out the following
 * #define and recompile. Commenting out the following #define 
 * replaces the large macro Apply_perm() by a C-function.
 */
#define FFT_HAS_LARGE_MACROS 

/* Some compilers complain about unused parameters of functions
 * although they are sometimes necessary.  To suppress the 
 * variable name of an unused parameter, comment out the following
 * #define.
 */
#define FFT_NAMES_FOR_UNUSED_PARAMS

/* Complex numbers in this package can be stored either
 * in structs with two members, one for the real
 * part and one for the imaginary part, or in arrays
 * with two elements.  Define FFT_STRUCT_SCALARS to
 * store complex numbers in structs, or define
 * FFT_ARRAY_SCALARS to store complex numbers in arrays.
 */
#define FFT_STRUCT_SCALARS
/* #define FFT_ARRAY_SCALARS */

/* DFT methods for the parser.  Change these to whatever you'd
 * like.  E.g., if you don't like typing out "iterative" to specify
 * the q-power method, you can #define QPOWER as "qp".
 */
#define DIRECT			"direct"
#define SMALL			"small"
#define COOLEY_TUKEY		"ct"
#define QPOWER			"iterative"

/* maximal length of the signal vector of an FFT 
   (should be < 2^28 = 268435456 for 32-bit (int)s)
*/
#define FFT_MAX_EXP    28
#define FFT_MAX_LENGTH 268435456

/**************************************************************/
/*                 end configurable section                   */
/**************************************************************/

/* Functions for manipulating complex numbers
   ==========================================
     fft_setNumerical(x, re, im)    explicit assign
     fft_value                      a type to be used in declarations
     FFT_VALUES_PER_SCALAR          how many (fft_value)-objects make a
                                    scalar; see comment below

     (int) fft_rootOfUnity(x, n, k) assigns x = w^k for a fixed primitive
                                    n-th root of unity w
     (int) fft_rational(x, k, n)    assigns x = k/n

     fft_set(x, y)                  (*x) = (*y);
     fft_add(x, y, z)               (*x) = (*y) + (*z);
     fft_sub(x, y, z)               (*x) = (*y) - (*z);
     fft_mul(x, y, z)               (*x) = (*y) * (*z);

   where

     (int) n, k             : integers where 0 <= k < n
     (fft_value *) x, y, z  : pointer to scalars.
     (double) re, im        : explicit numerical values

   Comments
     * A scalar is declared by fft_value scalar[FFT_VALUES_PER_SCALAR],
       a vector of scalars by fft_value *vector. 
*/

#ifdef FFT_STRUCT_SCALARS

typedef struct { double re, im; } fft_value;
#define                           FFT_VALUES_PER_SCALAR 1

#define fft_setNumerical( x, re_part, im_part ) \
  ( x->re = (double)(re_part), x->im = (double)(im_part) )

#define fft_rootOfUnity(x, N, k) \
  ((x)->re = cos( TWO_PI * k / N ), (x)->im = -sin( TWO_PI * k / N), 1)

#define fft_rational(x, k, n) \
  ((x)->re = (double)(k) / (double)(n), (x)->im = 0.0, 1)

#define fft_set(x, y) \
  { (x)->re = (y)->re; (x)->im = (y)->im; }

#define fft_add(x, y, z) \
  { (x)->re = (y)->re + (z)->re; (x)->im = (y)->im + (z)->im; }

#define fft_sub(x, y, z) \
  { (x)->re = (y)->re - (z)->re; (x)->im = (y)->im - (z)->im; }

#define fft_mul(x, y, z) \
  { double _r = (y)->re * (z)->re - (y)->im * (z)->im, \
           _i = (y)->re * (z)->im + (y)->im * (z)->re; \
    (x)->re = _r; (x)->im = _i; }

#define c_re(x) (x)->re
#define c_im(x) (x)->im

#endif /* ifdef FFT_STRUCT_SCALARS */
/* ======================================================================= */

#ifdef FFT_ARRAY_SCALARS

typedef double fft_value;
#define        FFT_VALUES_PER_SCALAR 2

#define fft_setNumerical(x, re, im) \
  ( (x)[0] = (fft_value)(re), (x)[1] = (fft_value)(im))

#define fft_rootOfUnity(x, N, k) \
  ( (x)[0] = (fft_value) cos( TWO_PI * k / N ), \
    (x)[1] = (fft_value) -sin( TWO_PI * k / N ), 1)

#define fft_rational(x, k, n) \
  ( (x)[0] = (fft_value)(k) / (fft_value)(n), \
    (x)[1] = (fft_value) 0.0, 1)

#define fft_set(x, y) \
  { (x)[0] = (y)[0]; (x)[1] = (y)[1]; }

#define fft_add(x, y, z) \
  { (x)[0] = (y)[0] + (z)[0]; (x)[1] = (y)[1] + (z)[1]; }

#define fft_sub(x, y, z) \
  { (x)[0] = (y)[0] - (z)[0]; (x)[1] = (y)[1] - (z)[1]; }

#define fft_mul(x, y, z) \
  { fft_value _r = (y)[0] * (z)[0] - (y)[1] * (z)[1], \
              _i = (y)[0] * (z)[1] + (y)[1] * (z)[0]; \
    (x)[0] = _r; (x)[1] = _i; }

#define c_re(x) (x)[0]
#define c_im(x) (x)[1]

#endif /* ifdef FFT_ARRAY_SCALARS */
/* ======================================================================= */

/* declarations for scalars and vectors of scalars */
#define Scalar(x) fft_value (x)[FFT_VALUES_PER_SCALAR]
#define Vector(x) fft_value *(x)

/* access to a vector component */
#if (FFT_VALUES_PER_SCALAR == 1)
#define at(vector, index) ((vector) + (index))
#else
#define at(vector, index) ((vector) + (index)*FFT_VALUES_PER_SCALAR)
#endif

/* Compiler and Operating System Interfacing
   =========================================
   All error messages are produced through the function fft_error()
   which gets a single string with the detailed information.
*/
/* the function to call with the error message */
#define fft_error(msg) \
  { fprintf(stderr, "fatal: %s. Exiting.\n", (msg)); \
    *((char *)0) = 0; /* crash */ exit(1); }

#ifdef FFT_NAMES_FOR_UNUSED_PARAMS
#define UNUSED_PARAMETER(x) x
#else
#define UNUSED_PARAMETER(x)
#endif

/* maximal length of a permuation */
#define FFT_MAX_PERM FFT_MAX_LENGTH

/* the type of indices for permutations */
#if (FFT_MAX_PERM <= 32766)
typedef short int fft_perm; /* assuming 16 bits signed */
#else
typedef int       fft_perm; /* assuming 32 bits signed */
#endif

/* Individual Methods
   ==================

   The following individual methods for the FFT are available:

                length               restriction/comment

   null         N                    `fake' implementation
   direct       N                    by matrix multiplication    
   small        N                    straight-line implementation
   twiddle      N = R*S              R is computed using a small
   cooleyTukey  N = R*S              R is not computed using a small
   qPower       N = q^e              2 <= q, e arbitrary      

   To every indiviual method there is an instance creation function
   fft_new_<method>(..args..). The creation function takes as arguments
   either integer parameters or the smaller fft-objects. If the resulting 
   fft-object does cannot be created an error message is issued.
*/

/* symbolic constants for (fft_t *)F->type */
enum fft_methods { FFT_NULL, FFT_DIRECT, FFT_SMALL, FFT_TWIDDLE,
  FFT_COOLEY_TUKEY, FFT_QPOWER };

/* datatype for the precomputed information of an FFT */
typedef struct fft_s {
  int       type,                                    /* FFT_<method> */
            N,                                  /* length of the FFT */
            n;                                            /* N = 2^n */
  void    (*apply) (struct fft_s *F, int stride, fft_value *x);
  void    (*deleteObj) (struct fft_s *F); /* delete is a C++ keyword */
  union tagPriv {
    struct tagDirect {
      fft_value    *rootOfUnity;          /* all N-th roots of unity */
    } direct;
    struct tagTwiddle {
      int           r, s;                        /* R = 2^r, S = 2^s */
      fft_value    *twiddle_factors;              /* twiddle factors */
      fft_perm     *L;                         /* output-permutation */
      struct fft_s *fft_S;                                 /* DFT(S) */
  	  void (*tw_apply) (int iostride, fft_value *A, fft_value *W, 
		    int R, int dist);
    } twiddle;
    struct tagCooleyTukey {
      int           r, s;                        /* R = 2^r, S = 2^s */
      fft_value    *twiddle_factors;              /* twiddle factors */
      fft_perm     *L;                         /* output-permutation */
      struct fft_s *fft_R,                                 /* DFT(R) */
                   *fft_S;                                 /* DFT(S) */
    } cooleyTukey;
    struct tagQPower{
      int           q_exp, e;                     /* N = (2^q_exp)^e */
      fft_value    *rootOfUnity;          /* all N-th roots of unity */
      fft_perm     *R;                          /* input-permutation */
      struct fft_s *fft_q;                                 /* DFT(q) */
    } qPower;
  } priv;                                /* private is a C++ keyword */
} fft_t;

/* creation functions for the specific methods */
extern fft_t *fft_new_null( int n );
extern fft_t *fft_new_direct( int n );
extern fft_t *fft_new_small( int n );
extern fft_t *fft_new_cooleyTukey( fft_t *fft_R, fft_t *fft_S );
extern fft_t *fft_new_twiddle( int R, fft_t *fft_S );
extern fft_t *fft_new_qPower( fft_t *fft_q, int e );

/* Generic Interface
   =================

   The evaluation of the FFT is done in two steps:
     1. construct an FFT as an object.
     2. apply the FFT-object to a signal vector.

   The first step is done with a call to fft_new_<method>()
   either for an individual method or with a call to a
   generic method. 

   The second step is a call to fft_apply_<mode>() which applies
   the FFT-object to a signal vector.
   
   In addition there are two functions to multiply with a 
   scalar and to apply the reversing permutation (2,N)(3,N-1).. 
   which is important in the definition of some convention
   for the inverse.
*/


/* deletion of an fft-object (generic function for all fft-objects) */
#define fft_delete(fft) \
  (fft->deleteObj)(fft)

/* multiply x = a*x */
extern void fft_apply_scalar(
  fft_t *F, int stride, fft_value *x, 
  fft_value *a
);

/* apply reversing permutation to x */
extern void fft_apply_reverse(
  fft_t *F, int stride, fft_value *x
);

/* [forward-without-factor]-application */
#define fft_apply(fft, stride, x) \
  (fft->apply)((struct fft_s *)(fft), stride, x)

#define fft_apply_inverse(fft, stride, x) \
  { fft_value temp[1]; (fft->apply)((struct fft_s *)(fft), stride, x); \
    fft_setNumerical( temp, 1/(double) N, 0 ); \
    fft_apply_scalar(fft, stride, x, temp); \
    fft_apply_reverse(fft, stride, x); } 

/* Supporting Functions
   ====================

   A number of supporting functions make life easier when the
   user wants to experiment with the individual methods:
   fft-objects can be printed, constructed from printed form
   and it can be checked if a specific method is applicable. 
*/

/* (char *) fft_print(indent, F)
     returns a pointer to a newly allocated string which contains
     the printed representation of the tree of methods used for
     the fft F. The parameter indent controls the indentation.
     If indent < 0 then everything is printed as compact as possible.
     If indent >= 0 then comments are added and indentation to
     column (2 indent + 1) takes place at every newline. No initial
     or trailing newline or indentation is produced.
     The the output is of the following form

       <fft> ::= 
       null[ <int> ]
     | direct[ <int> ]
     | small[ <int> ]
	   | twiddle[ small[ <int> ], <fft> ]
     | cooleyTukey[ <fft>, <fft> ]
     | qPower[ <fft>, <int> ]
     | unrecognized[{type -> <int>, N -> <int>}]

     Comments are printed as "(* .. *)"; they cannot be nested.
*/
extern char *fft_print( int indent, fft_t *F );

/* (fft_t *) fft_parse(char **msg, char *in)
     returns an fft-object constructed from parsing the printed
     representation of (char *)in. The syntax accepted is the
     same as produced by fft_print, except for unrecognized[..].
     If a syntactical or semantical error occurs then (*msg) is 
     assigned a newly allocated string containing an error message. 
     The error message starts with "[%d]" where %d denotes one of
     the following error classes
       [1] syntax error
       [3] length of a transform is out of range
       [7] wrong arguments to C-function
       [8] unrecognized fft-method
*/
extern fft_t *fft_parse( char **msg, char *in );

/* (char *) fft_applicable(int method, int N, int nq, int q[])
     tests if the given method (FFT_NULL, etc.) on length N
     with additional parameters q[0], .., q[nq-1] is applicable
     and if not produce an error message. The result is a newly
     allocated string containing detailed information. The message
     starts with "[%d]" where %d identifies the error class as 
     in fft_parse(). The method is applicable NULL is returned.
*/
extern char *fft_applicable( int method, int N, int nq, int q[] );

fft_t * get_tree( int n );
/* Given the log (base 2) of the size of the matrix, returns
  the fastest WHT tree for computing it found on this system, if
  a tree of this size has been found.  Returns NULL on failure --
  either the tree is not in the file, not properly specified, or
  the table of trees does not exist. */

double get_tree_time( int n );
/* Gets the time required to do WHT using the fastest tree of size n.
  Returns -1 if the file is not found, no tree of this size is in the
  table, or there is no time associated with a tree of this size. */

int add_tree( fft_t * tree, double time );
/* Updates the tree table, adding this tree, and removing the previous one
  of this size if it exists.  It does not check to make sure that this
  new tree is faster than the old one.  Returns 0 on failure, 1 on success.
  */

/* ====================================================================== */
/* Definitions for FFTW codelets: */
typedef double fftw_real;

#define FFTW_KONST(x) ((fftw_real) x)

#endif /* !defined(FFT_H) */
