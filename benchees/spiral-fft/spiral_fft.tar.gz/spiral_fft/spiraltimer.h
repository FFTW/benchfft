/*
 * Copyright (c) 2000 Carnegie Mellon University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

//    David Sepiashvili
//    Version 2.1     11/16/99

/********************************************************************/
/*                           CLOCK SOURCE                           */
/********************************************************************/
/* USAGE: uncomment exactly one of the defines to choose a clock    */
/* NOTES: CLOCK_STD should work on any platform and any compiler    */
/********************************************************************/

#define CLOCK_SOURCE   CLOCK_STD

#define CLOCK_STD   1 // standard system counter
#define CLOCK_UNIX  2 // unix specific system counter (user time)
#define CLOCK_TSCM  3 // pentium time-stamp counter (MS VC++ 6.0)
#define CLOCK_TSCU  4 // pentium time-stamp counter (UNIX compilers)


/********************************************************************/
/*                      UNITS OF MEASUREMENT                        */
/********************************************************************/

// translation is done using this formula:
//   UNITS = SECONDS * UNITS_PER_SECOND

//#define UNITS_PER_SECOND   UNITS_CLOCKCYCLES
#define UNITS_PER_SECOND   UNITS_SECONDS

#define CLOCK_SPEED_CPU (double)( 450*1000*1000)  // this cpu
#define CLOCK_SPEED_REF (double)(1000*1000*1000)  // a reference cpu

#define UNITS_SECONDS          1
#define UNITS_REF_SECONDS      (CLOCK_SPEED_CPU/CLOCK_SPEED_REF)
#define UNITS_CLOCKCYCLES      CLOCK_SPEED_CPU
#define UNITS_REF_CLOCKCYCLES  CLOCK_SPEED_CPU

// EXPLANATION:
// -> UNITS_SECONDS - already in seconds, so do nothing to convert
// -> UNITS_CLOCKCYCLES - trivially is equal to CLOCK_SPEED_CPU
// -> UNITS_REF_CLOCKCYCLES - on a reference computer this code
//      would still take the same number of clock cycles
// -> UNITS_REF_SECONDS - since on a reference machine this code
//      takes CLOCK_SPEED_CPU cycles, and there are CLOCK_SPEED_REF
//      in one second, it will be CLOCK_SPEED_CPU/CLOCK_SPEED_REF


/********************************************************************/
/*                      EPORTABLE DEFINITIONS                       */
/********************************************************************/


typedef void (*FUNCTION)(void); 


typedef struct EXPERIMENT {
// input vars
    FUNCTION func;          // function you are measuring
    FUNCTION func_ini;      // function to initialize input params
    double accuracy;        // desired relative accuracy
    double timeout;         // timeout value
// output vars
    double runtime;         // run-time estimate
    double totaltime;       // time spent on this experiment
    long   reps_quant;      // # of reps to get a small quant_err
    long   reps;
    double quant_err;
    double resolution;      // clock resolution
    double min;
    double max;
    double mean;
    double var;
    double spread;
} EXPERIMENT;

double  spiraltimer_measure     (FUNCTION f, double err, double timeout);
double  spiraltimer_measure_ini (FUNCTION f, FUNCTION fini, double err, double timeout);
double  spiraltimer_measure_exp (EXPERIMENT*);

/********************************************************************/
