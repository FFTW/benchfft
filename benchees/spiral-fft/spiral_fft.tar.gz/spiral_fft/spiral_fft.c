/*
 * Copyright (c) 2000 Carnegie Mellon University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/* spiral_fft.c
 *
 * This file contains modified code from the 
 * file fft.c in the fft package by Sebastian Egner
 * More information about that package can be found at
 * http://avalon.ira.uka.de/home/egner
 *
 * Modifications to Egner's FFT:
 *
 * - The generic base field feature was removed. 
 *
 * - The finite field GF(2^8) implementation was removed.
 *
 * - The rader, goodThomas, and bluestein methods were removed.
 *
 * + The method "twiddle" was added.  A twiddle method is a 
 *   decomposition in which the left child is computed with
 *   unrolled code.  This allows the twiddle factor multiplications
 *   to be done inside a small code module ("codelet" in FFTW
 *   notation).
 * 
 * + The order in which the roots of unity for the cooleyTukey 
 *   method are stored was changed so that they can be accessed
 *   more quickly when an FFT is computed.
 * 
 * + The cooleyTukey algorithm was transposed, meaning that,
 *   instead of computing 
 *   L (I (x) F) T (F (x) I), 
 *   the program now computes 
 *   (F (x) I) T (I (x) F) L.  This was done to allow
 *   the twiddle codelets to be inserted.
 *   
 * + The cooleyTukey algorithm was made fully recursive.  That is,
 *   instead of computing
 *   L (I (x) L) (I (x) F) (I (x) T) (I (x) F (x) I) T (F (x) I)
 *   the program now computes
 *   L {I (x) [L (I (x) F) T (F (x) I)]} T (F (x) I) 
 * 
 * + The small code modules were replaced with no-twiddle codelets
 *   and (when possible) twiddle codelets from FFTW.  no-twiddle
 *   codelets compute 
 *   x = F x
 *   at arbitrary stride, and the twiddle codelets compute
 *   x = (F (x) I) T x 
 *   at arbitrary stride.
 * 
 * + All methods were changed to compute
 *   x = F x, performed at arbitrary stride,
 *   instead of 
 *   x = (I (x) F (x) I) x.
 *  
 * These changes cut the execution time of the program by at least
 * 50% for FFT sizes of 2^5 - 2^20.
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include "spiral_fft.h"

#define TWO_PI			6.2831853071795864769252867665590057683943388

/* the max string length for error messages: */
#define MAX_ERROR_CHARS 200

/* Memory Management
   =================

   All variable sized storage is allocated/deallocated
   through malloc( )/free( ). There are no limitations due
   to static allocation of input size dependent variables.

   The buffers used in computations are allocated with
   alloca( ) so that the fft-object can be shared by multiple
   threads and no malloc/free is necessary for every single fft.
*/
static void *Malloc( size_t length ) {
  void *p;

  /* avoid mallocs of size below 32 bytes */
  if (length < 32 )
    length = 32;

  p = malloc( length );
  if (p == NULL )
    fft_error( "out of memory in malloc( )" );
  return p;
}

static void Free( void *p ) {
  free( p );
}

#ifdef FFT_STACK_ALLOC_WITH_ALLOCA
#ifdef FFT_VISUAL_C_ALLOCA
#define Alloca( length ) _alloca( length )
#else
#define Alloca( length ) alloca( length )
#endif /* ifdef FFT_VISUAL_C_ALLOCA */
#define Dealloca( p )
#else
#define Alloca( length ) malloc( length )
#define Dealloca( p )    free( p )
#endif /* ifdef FFT_STACK_ALLOC_WITH_ALLOCA */

/* Error Messages
   ==============

   The global function or macro fft_error( msg ) is called with
   the entire error message printed into a C-string which is
   either a constant or has been allocated with Malloc( ).
*/
#define strlen_int 20

static void Error( char *msg ) {
  fft_error( msg );
}

static void Error_int( char *fmt, int x1 ) {
  char *msg;

  msg = (char *) Malloc( strlen( fmt ) + strlen_int );
  sprintf( msg, fmt, x1 );
  fft_error( msg );  
  Free( msg );
}

static void Error_int2( char *fmt, int x1, int x2 ) {
  char *msg;

  msg = (char *) Malloc( strlen( fmt ) + 2*strlen_int );
  sprintf( msg, fmt, x1, x2 );
  fft_error( msg );  
  Free( msg );
}

static void Error_int3( char *fmt, int x1, int x2, int x3 ) {
  char *msg;

  msg = (char *) Malloc( strlen( fmt ) + 3*strlen_int );
  sprintf( msg, fmt, x1, x2, x3 );
  fft_error( msg );
  Free( msg );
}

/* abbreviations for the frequent operations */
#define set fft_set
#define add fft_add
#define sub fft_sub
#define mul fft_mul

/* ( fft_value * ) new_vector( N )
   delete_vector( x )
     create and delete a vector of length N

   ( fft_value * ) newa_vector( N )
   deletea_vector( x )
     allocate/deallocate a vector of length N from the stack.
*/     

static fft_value *new_vector( int N ) {
  return 
    ( fft_value * ) Malloc( 
      N * FFT_VALUES_PER_SCALAR * sizeof( fft_value )
    );
}

static void delete_vector( Vector(x) ) {
  Free( x );
}

#define newa_vector( N ) \
  (fft_value *) Alloca( (N) * FFT_VALUES_PER_SCALAR * sizeof( fft_value ) )

#define deletea_vector( x )

/* rootOfUnity( w, n, k )
     makes w a the k-th power of a fixed primitive n-th root
     of unity. 
     
   rootsOfUnity( w, n )
     assigns all n-th roots of unity to w[0], w[1], .., w[n-1].
*/

static void rootOfUnity( Scalar(w), int N, int k ) {
  while (k < 0)
    k += N;
  k = k % N;

  fft_rootOfUnity( w, N, k );
}

static void rootsOfUnity( Vector(w), int N ) {
  int k;

  fft_setNumerical( at( w, 0 ), 1, 0 );
  for (k = 1; k < N; ++k )
    rootOfUnity( at( w, k ), N, k );
}

/* Permutations
   ============

   We implement permutations on {0..n-1} where n <= FFT_MAX_PERM.
   The permutations are stored in cycle notation so that
   in-place application is possible with a single register.
   In particular let s[0], s[1], .. stores the first cycle
   until a negative value s[k] occurs, then -s[k]-1 is the
   last point of the first cycle. s[k+1] is the first point
   of the second cycle etc. until a cycle of length one occurs.

   Multiplication of permutations and inverses are best performed
   before calling new_perm, which converts to cycle structure.
   In particular,
     ( s^-1 )[ s[i] ] = i,       and
     ( s*t )[ i ]     = t[s[i]]  for all i in [0..n-1].

   Applying permutation s to a vector x is identical to multiplying

     P( s ) x = [ x[s[i]] : i in [0..n-1] ]

   where P( s ) = [ delta_( s[i], j ) ]_ij is the permutation matrix of s.
*/

/* fft_perm
     is an integer type which contains signed integers
     to store the image points of a permutation. The type
     may be ( short int ) if FFT_MAX_PERM < 2^15 - 1.

   FFT_MAX_PERM
     is a symbolic constant which limits the length of the
     maximal permutation possible ( defined in fft.h ).

   Apply_perm( r, N, perm, s, x )
     assignes x = ( 1_r ( x ) P( perm ) ( x ) 1_t ) . x for the permutation
     perm of [0..N-1 ) which has been created by new_perm( ).
        There is a macro version and a function version of this
     object. The macro version is to be prefered but since it
     the expansion text is considerably long the function version
     is supplied to be used if the compiler complains.

   ( fft_perm * )new_perm( n, s )
   delete_perm( s )
     allocate/deallocate new permutations. new_perm first converts 
     into cycle form, delete_perm returns NULL.

   fprint_perm( out, s )
     fprints the permutation s ( in cycles ) to ( FILE * )out. Note
     that the permutation printed is on {1..n} instead of {0..n-1}!
     This is for debugging purposes only.
*/

#ifdef FFT_HAS_LARGE_MACROS /* from `spiral_fft.h' */

/* the function in condensed form */
#define Apply_perm( N, perm, stride, x ) \
{ fft_perm *t,i0,i; Scalar(xi); Scalar(temp); \
  t  = ( perm ); while (*t >= 0) { i0 = *( t++ ); i = i0; \
  set( xi, at( ( x ), i*( stride ) ) ); while (( *t ) >= 0) { set( temp, xi ); \
  i = *( t++ ); set( xi, at( ( x ), i*( stride ) ) ); \
  set( at( ( x ), i*( stride ) ), temp ); } \
  set( temp, xi ); i = -( *( t++ ) )-1; set( xi, at( ( x ), i*( stride ) ) ); \
  set( at( ( x ), i*( stride ) ), temp ); set( at( ( x ), i0*( stride ) ), xi ); } }

#else

static void Apply_perm( int N, fft_perm perm[], int stride, Vector(x) ) {
  fft_perm *t,                    /* runs through perm */
            i0,                /* first point in orbit */
            i;               /* current point in orbit */
  Scalar(xi);        /* x[ir*N*s + i*s + is] = x0[i*s] */
  Scalar(temp);                    /* temporary buffer */

  t  = perm;
  while (*t >= 0 ) {
    /* apply the cycle ( t[0], t[1], .., t[r-2], -t[r-1]-1 ) 
       where t is being moved, i0 is the first point,
       i is the current point, xi is the value at i
    */
    i0 = *( t++ );
    i  = i0;
    set( xi, at( x, i*stride ) );
    while (( *t ) >= 0) {
      set( temp, xi );
      i = *( t++ );
      set( xi, at( x, i*stride ) );
      set( at( x, i*stride ), temp );
    }
    set( temp, xi );
    i = -( *( t++ ) )-1;
    set( xi, at( x, i*stride ) );
    set( at( x, i*stride ), temp );
    set( at( x, i0*stride ), xi );
  }
}

#endif /* FFT_HAS_LARGE_MACROS */

/* make_perm( n1, s1, n, s )
     converts the permutation [s[0], .., s[n-1]] into
     cycle form [s1[0], .. s1[n1-1]] suitable for Apply_perm. 
     The array pointed to by s1 must have length at least n+1.
     This function use only used by new_perm( ).
*/

static void make_perm( int *n1, fft_perm *s1, int n, fft_perm *s ) {
  int       nt;
  fft_perm  i0, i, ti;
  fft_perm *t;

  if (!( ( 1 <= n ) && ( n <= FFT_MAX_PERM ) ) )
    Error_int2( 
      "n = %d must be in [0..%d ) in make_perm( )", 
           n, FFT_MAX_PERM
    );

  t = ( fft_perm * ) Malloc( n * sizeof( fft_perm ) );

  /* t = s^-1 and check if t is a permutation */
  for (i = 0; i < n; ++i )
    t[i] = -1;
  for (i = 0; i < n; ++i) {
    if (( s[i] < 0 ) || ( s[i] >= n ) )
      Error_int3( 
        "s[%d] = %d must be in [0..%d ) in make_perm( )",
           i, s[i], n );
    t[s[i]] = i;
  }
  for (i = 0; i < n; ++i )
    if (t[i] == -1 )
      Error( "s[] does not define a permutation in make_perm( )" );

  /* clear the cycles in t one after the other */
  nt = 0;
  i0 = 0;
  while (i0 < n) {

    /* find start of next non-trivial cycle */
    while (( i0 < n ) && ( t[i0] == i0 ) )
      ++i0;

    /* clear the cycle ( i0, t[i0], t[t[i0]], .. ) */
    if (i0 < n) {
      i = i0;
      while (t[i] != i0) {
        s1[nt++] = i;
        ti       = t[i];
        t[i]     = i;
        i        = ti;
      } 
      s1[nt++] = -i-1;
      t[i]    = i;      
    }    
  }

  /* add end mark */
  s1[nt++] = -1;
  *n1 = nt;

  Free( t );
}

static fft_perm *new_perm( int n, fft_perm *s ) {
  fft_perm *s0, *s1,
            n1, i;

  /* copy s into s1 with space for the end mark */
  s1 = ( fft_perm * ) Malloc( ( n+1 ) * sizeof( fft_perm ) );
  make_perm( &n1, s1,  n, s );

  /* copy into a new memory region of matching size */
  s0 = ( fft_perm * ) Malloc( n1 * sizeof( fft_perm ) );
  for (i = 0; i < n1; ++i )
    s0[i] = s1[i];

  Free( s1 );
  return s0;
}

static void delete_perm( fft_perm *s ) {
  Free( s );
}

/* for debugging only..
static void fprint_perm( FILE *out, fft_perm *s ) {
  if (s[0] < 0) {
    fprintf( out, "( )" );
    return;
  }
  while (s[0] >= 0) {
    fprintf( out, "( %d", s[0] +1 );
    while (s[1] >= 0) {
      ++s;
      fprintf( out, ",%d", s[0] +1 );
    }
    ++s;
    fprintf( out, ",%d )", -s[0]-1 +1 );
    ++s;
  }
  fprintf( out, "\n" );
}

..for debugging only */

/* Number Theory
   =============

   A few tools from number theory are needed for the FFT.
   We implement them in (int), assuming (int) to be at
   least 32 bits. All functions, except the most primitive,
   are designed for maximum reliability, rather than for speed.
   The usable range of numbers is limited to 
     -2^28 .. 2^28
   to avoid silent overflow in additions.
*/

#define mod( x, m ) ((x) < 0 ? ((x) + (m)) % (m) : (x) % (m))
#define div( x, m ) ((x) / (m))

/* addMod( x, y, m )
     compute mod( x + y, m ) for m > 0.
*/
#define addMod( x, y, m ) mod( (x) + (y), m )

/* Generic-FFT
   ===========
*/
void fft_apply_scalar( fft_t *F, int stride, Vector(x), Scalar(a) ) {
  int    i,                         /* counter for [0..N ) */
	       N;
  Vector(x1);                        /* pointer through x */

  x1 = x;
  N = F->N;

  for (i = 0; i < N; ++i) {
    mul( x1, x1, a );
    x1 = at( x1, stride );
  }  
}

void fft_apply_reverse( fft_t *F, int stride, Vector(x) ) {
  int    N,                              /* length of FFT */
         k;                         /* counter for [0..N ) */
  Vector(x1);                        /* pointer through x */
  Vector(x2);                        /* pointer through x */
  Scalar(temp);                 /* temporary for swapping */

  /* x = R x at stride <stride>, where R( 0 ) = 0, R( k ) = N-k */ 
  N = F->N;
  x1 = at( x, 1 * stride );
  x2 = at( x, ( N-1 ) * stride );

  for (k = 1; k < N-k; ++k) {
	  set( temp, x1 ); set( x1, x2 ); set( x2, temp );
	  x1 = at( x1,  stride );
	  x2 = at( x2, -stride );
  }
}

/* Null-FFT 
   ========

   For debugging and profiling we supply a fake FFT.
   In addition fft_new_null( ) creates a new ( fft_t ) structure to
   be used by other methods.
*/
static void apply_null( 
  struct fft_s *UNUSED_PARAMETER( F ), 
  int           UNUSED_PARAMETER( stride ), 
  fft_value    *UNUSED_PARAMETER( x )
 ) {
  return;
}

static void delete_null( struct fft_s *F ) {
  Free( F );
}

fft_t *fft_new_null( int n ) {
  fft_t *F;
  Scalar(dummy);
  char  *msg;
  int N;

  N = 1 << n;

  msg = fft_applicable( FFT_NULL, n, 0, NULL );
  if (msg != NULL) {
    Error( msg );
    return NULL;
  }

  F            = (fft_t *) Malloc( sizeof( fft_t ) );
  F->type      = FFT_NULL;
  F->n         = n;
  F->N         = N;
  F->apply     = apply_null;
  F->deleteObj = delete_null;

  /* build w(N) */
  rootOfUnity( dummy, N, 1 );

  return F;
}

/* Direct FFT (Matrix Multiplication)
   ==================================
*/
static void apply_direct( struct fft_s *F, int stride, Vector(x) ) {
  int    N,                           /* length */
         i, j,           /* counter for [0..N ) */
         ij;                       /* i*j mod N */
  Vector(w);             /* N-th roots of unity */
  Vector(x0);      /* pointer for signal values */
  Vector(y0);      /* pointer for signal values */
  Scalar(temp);  /* temporary to accumulate sum */
  Vector(y) = newa_vector( F->N );    /* buffer */

  N = F->N;
  w = F->priv.direct.rootOfUnity;

  /* [y[i] : i in [0..N )] = [x[i * stride] : i in [0..N )] */
  x0 = x;
  y0 = y;
  for (i = 0; i < N; ++i) {
    set( y0, x0 );
    x0 = at( x0, stride );
    y0 = at( y0, 1 );
  }

  /* [x[i * stride] : i in [0..N )] = 
     Sum( w( N )^( i*j ) y[j] : j in [0..N ) ) 
  */
  for (i = 0; i < N; ++i) {
    x0  = at( x, i * stride );
    y0  = y;

	ij  = 0;
    set( x0, y0 ); /* w( N )^ij = 1 */
    y0  = at( y0, 1 );
    ij += i;
    for (j = 1; j < N; ++j) {
      mul( temp, y0, at( w, ij ) ); 
      add( x0, x0, temp );
      y0 = at( y0, 1 );
      ij = addMod( ij, i, N );
    }
  }
  deletea_vector( y );
}

static void delete_direct( struct fft_s *F ) {
  delete_vector( F->priv.direct.rootOfUnity );
  delete_null( F );
}

fft_t *fft_new_direct( int n ) {
  fft_t *F;
  char  *msg;
  int N;

  N = 1 << n;

  msg = fft_applicable( FFT_DIRECT, n, 0, NULL );
  if (msg != NULL) {
    Error( msg );
    return NULL;
  }

  /* create F */
  F            = fft_new_null( n );
  F->type      = FFT_DIRECT;
  F->N         = N;
  F->n         = n;
  F->apply     = apply_direct;
  F->deleteObj = delete_direct;

  /* precompute N-th roots of unity */
  F->priv.direct.rootOfUnity = new_vector( N );
  rootsOfUnity( F->priv.direct.rootOfUnity, N );
  return F;
}

/* Small-FFT
   =========

   For n <= FFT_MAX_SMALL we supply a straight-line implementation
   of the FFT(2^n). These functions are the basis of most other FFTs.
   If the small FFTs are modified or extended make sure
   `spiral_fft.h': FFT_MAX_SMALL is corrected.
*/

/* maximal length of the straight-line encoded FFTs */
#define FFT_MAX_SMALL 6

void apply_small1( struct fft_s *F, int stride, Vector(x) );
void apply_small2( struct fft_s *F, int stride, Vector(x) ); 
void apply_small3( struct fft_s *F, int stride, Vector(x) );
void apply_small4( struct fft_s *F, int stride, Vector(x) );
void apply_small5( struct fft_s *F, int stride, Vector(x) );
void apply_small6( struct fft_s *F, int stride, Vector(x) );

static void delete_small( struct fft_s *F ) {
  delete_null( F );
}

fft_t *fft_new_small( int n ) {
  fft_t *F;
  char  *msg;
  int N;

  N = 1 << n;

  msg = fft_applicable( FFT_SMALL, n, 0, NULL );
  if (msg != NULL) {
    Error( msg );
    return NULL;
  }

  F            = fft_new_null( n );
  F->type      = FFT_SMALL;
  F->N         = N;
  F->n         = n;
  F->deleteObj = delete_small;

  switch (n) {
    case 1: F->apply = apply_small1; break;
    case 2: F->apply = apply_small2; break;
    case 3: F->apply = apply_small3; break;
    case 4: F->apply = apply_small4; break;
	  case 5: F->apply = apply_small5; break;
	  case 6: F->apply = apply_small6; break;
    default:
      Error_int( "unrecognized n = %d in fft_new_small( )", n );
      delete_null( F );
      return NULL;
      break;
  }
  return F;
}

/* Cooley-Tukey-FFT
   ================
*/
static void apply_cooleyTukey( struct fft_s *F, int stride, Vector(x) ) {
  int        N, R, S,  /* length, N = R * S */
             i, j, S_times_stride;        
  fft_value *x_ptr, *tf_ptr;

  N = F->N;
  R = 1 << F->priv.cooleyTukey.r;
  S = 1 << F->priv.cooleyTukey.s;

  S_times_stride = S * stride;

  /* x = L^N_n * x, performed at stride = <stride>  */
  Apply_perm( N, F->priv.cooleyTukey.L, stride, x );

  /* x = T^N_m * (I_n (x) F_m) * x, performed at stride = <stride> */

  /* Do the first FFT outside of a loop, since
   * the first chunk of T^N_m of size m contains
   * all ones.
   */
  fft_apply( F->priv.cooleyTukey.fft_S, stride, x );

  x_ptr = at( x, S_times_stride );
  tf_ptr = F->priv.cooleyTukey.twiddle_factors;

  /* Start with i=1 and j=1 to omit multiplications
   * by twiddle factors that equal one.
   */
  for (i = 1; i < R; ++i) {
	  fft_apply( F->priv.cooleyTukey.fft_S, stride, x_ptr );

	  x_ptr = at( x_ptr, stride );
	  for (j = 1; j < S; ++j ) {
		  mul( x_ptr, x_ptr, tf_ptr ) 
		  x_ptr = at( x_ptr, stride );
		  tf_ptr = at( tf_ptr, 1 );
	  }
  }
  x_ptr = x;

  /* x = (F_n (x) I_m) * x, performed at stride = <stride> */
  for (i = 0; i < S; ++i) {
	  fft_apply( F->priv.cooleyTukey.fft_R, S_times_stride, x_ptr );
	  x_ptr = at( x_ptr, stride );
  }
}

/* ======================================================================== */
static void delete_cooleyTukey( struct fft_s *F ) {
  fft_delete( F->priv.cooleyTukey.fft_S );
  fft_delete( F->priv.cooleyTukey.fft_R );
  delete_perm( F->priv.cooleyTukey.L );
  delete_vector( F->priv.cooleyTukey.twiddle_factors );
  delete_null( F );
}

/* ======================================================================== */
fft_t *fft_new_cooleyTukey( fft_t *fft_R, fft_t *fft_S ) 
{
  fft_t    *F;
  int       N, R, S,              /* length N = R * S */
            n, r, s,            /* N = 2^n; n = r + s */
            k;                       /* index [0..N ) */
  int i, j;
  fft_perm *perm;        /* intermediate buffer for L */
  char     *msg;
  int       q[2];
  double two_pi_over_N, e_power;
  fft_value *tf_ptr;

  r = fft_R->n; q[0] = r;
  s = fft_S->n; q[1] = s;
  n = r + s;

  R = 1 << r; 
  S = 1 << s; 
  N = 1 << n;

  two_pi_over_N = TWO_PI / (double) N;

  msg = fft_applicable( FFT_COOLEY_TUKEY, n, 2, q );
  if (msg != NULL) {
    Error( msg );
    return NULL;
  }

  perm = (fft_perm *) Malloc( N * sizeof( fft_perm ) );

  /* create F */
  F                     = fft_new_null( n );
  F->type               = FFT_COOLEY_TUKEY;
  F->N                  = N;
  F->n                  = n;
  F->apply              = apply_cooleyTukey;
  F->deleteObj          = delete_cooleyTukey;
  F->priv.cooleyTukey.r = r;
  F->priv.cooleyTukey.s = s;

  /* Precompute the twiddle factors not equal to one:
   * ( Only N-R-S+1 twiddle factors are not equal to one. )
   */
  F->priv.cooleyTukey.twiddle_factors = new_vector( N - R - S + 1 );

  tf_ptr = F->priv.cooleyTukey.twiddle_factors;

  /* The first chunk (length S) of T^N_S is all ones
   * and the first twiddle factor in each chunk of
   * T^N_S is one, so start both i and j at one.
   * That is, don't precompute twiddle factors that
   * equal one.
   */
  for (i = 1; i < R; ++i ) {
    for (j = 1; j < S; ++j ) {
		  e_power = two_pi_over_N * i * j;
  	  fft_setNumerical( tf_ptr, cos( e_power ), -sin( e_power ) );
		  tf_ptr = at( tf_ptr, 1 );
	  }
  }

  /* precompute output-permutation L */
  for (k = 0; k < N; ++k )
    perm[k] = mod( k, S ) * R + div( k, S );

  F->priv.cooleyTukey.L = new_perm( N, perm );

  /* construct DFT( R ), DFT( S ) */
  F->priv.cooleyTukey.fft_R = (struct fft_s *) fft_R;  
  F->priv.cooleyTukey.fft_S = (struct fft_s *) fft_S;

  Free( perm );
  return F;
}

/* ======================================================================== */
/* Twiddle FFT
   ===========

   This node is just like a Cooley-Tukey node, except that
   the left child is always a small.  This allows us to
   move the multiplication by twiddle factors into a
   small code module.  
*/

/* small code modules that perform multiplication by twiddle
   factors as well as straight-line encoded ffts:
*/
void apply_twiddle1( int iostride, Vector(x), fft_value *W, 
					int n, int dist );

void apply_twiddle2( int iostride, Vector(x), fft_value *W, 
					int n, int dist ); 

void apply_twiddle3( int iostride, Vector(x), fft_value *W, 
					int n, int dist );

void apply_twiddle4( int iostride, Vector(x), fft_value *W, 
					 int n, int dist );

void apply_twiddle5( int iostride, Vector(x), fft_value *W, 
					 int n, int dist );

void apply_twiddle6( int iostride, Vector(x), fft_value *W, 
					 int n, int dist );

/* ======================================================================== */
static void apply_twiddle( struct fft_s *F, int stride, Vector(x) ) {
  int    N, R, S,  /* length, N = R * S      */
         i,        /* counter                */
		     stride_times_S;

  N = F->N;
  R = 1 << F->priv.twiddle.r;
  S = 1 << F->priv.twiddle.s;

  stride_times_S = stride * S;

  /* x = L^N_R * x, performed at stride = <stride> */
  Apply_perm( N, F->priv.twiddle.L, stride, x );

  /* x = (I_R (x) F_S) * x, performed at stride = <stride> */
  for (i = 0; i < R; i++ )
  {
	  fft_apply( F->priv.twiddle.fft_S, stride, 
		  at( x, i * stride_times_S ) );
  }

  /* x = (F_R (x) I_S) * T^N_S * x, 
     performed at stride = <stride> 
  */
  F->priv.twiddle.tw_apply 
	  (stride_times_S, x, F->priv.twiddle.twiddle_factors, S, stride);
}

/* ======================================================================== */
static void delete_twiddle( struct fft_s *F ) {
  fft_delete( F->priv.twiddle.fft_S );
  delete_perm( F->priv.twiddle.L );
  delete_vector( F->priv.twiddle.twiddle_factors );
  delete_null( F );
}

/* ======================================================================== */
fft_t *fft_new_twiddle( int r, fft_t *fft_S ) {
  fft_t     *F;
  int        n, s,                     /* n = r + s */
             N, R, S,  /* N = 2^n, R = 2^r, S = 2^s */
             k,                    /* index [0..N ) */
             i, j, ij;
  int        q[2];
  double     two_pi_over_N;
  fft_perm  *perm;     /* intermediate buffer for L */
  char      *msg;
  fft_value *tf_ptr;  /* pointer to twiddle factors */

  q[0] = r;
  s    = fft_S->n; 
  q[1] = s;
  n    = r + s;
  N    = 1 << n;
  R    = 1 << r;
  S    = 1 << s;

  two_pi_over_N = TWO_PI / (double) N;

  msg = fft_applicable( FFT_COOLEY_TUKEY, n, 2, q );
  if (msg != NULL) {
    Error( msg );
    return NULL;
  }

  perm = (fft_perm *) Malloc( N * sizeof( fft_perm ) );

  /* create F */
  F                 = fft_new_null( n );
  F->type           = FFT_TWIDDLE;
  F->N              = N;
  F->n              = n;
  F->apply          = apply_twiddle;
  F->deleteObj      = delete_twiddle;
  F->priv.twiddle.r = r;
  F->priv.twiddle.s = s;

  /* precompute the N-th roots of unity */
  F->priv.twiddle.twiddle_factors = new_vector( N );
  tf_ptr = F->priv.twiddle.twiddle_factors;

  for (i = 0; i < S; i++) {
	  for (j = 0; j < (R - 1); j++) {
      k = i * (R - 1) + j;
		  ij = i * (j + 1);

		  fft_setNumerical( at( tf_ptr, k ), cos( two_pi_over_N * ij ),
			  -sin( two_pi_over_N * ij ) );
	  }
  }

  /* precompute output-permutation L */
  for (k = 0; k < N; ++k )
    perm[k] = mod( k, S ) * R + div( k, S );

  F->priv.twiddle.L = new_perm( N, perm );

  /* assign pointer to appropriate codelet */  
  switch (r) {
    case 1: F->priv.twiddle.tw_apply = apply_twiddle1; break;
    case 2: F->priv.twiddle.tw_apply = apply_twiddle2; break;
    case 3: F->priv.twiddle.tw_apply = apply_twiddle3; break;
    case 4: F->priv.twiddle.tw_apply = apply_twiddle4; break;
	  case 5: F->priv.twiddle.tw_apply = apply_twiddle5; break;
	  case 6: F->priv.twiddle.tw_apply = apply_twiddle6; break;
    default:
      Error_int( "unrecognized n = %d in fft_new_twiddle()", n );
      delete_null( F );
      return NULL;
      break;
  }

  /* construct DFT( S ) */
  F->priv.twiddle.fft_S = (struct fft_s *) fft_S;

  Free( perm );
  return F;
}

/* ======================================================================== */
/* q-Power-FFT
   ===========
*/
static void apply_2Power( struct fft_s *F, int stride, Vector(x) ) {
  int        N, e,                /* fetched from F */
             a, qa, Qa,     /* q^a, q^( ( e-1 )-a ) */
             dxk,               /* inner step of xk */
             T1,  /* twiddle exponent divided by Qa */
             k2,                       /* temporary */
             iQa, iqa;            
  fft_value *xk;                  /* signal pointer */
  Vector(w);                      /* w[N]^( T1 Qa ) */

  N = F->N;
  e = F->priv.qPower.e;

  /* x = R * x, performed at stride = <stride> */
  Apply_perm( N, F->priv.qPower.R, stride, x );

  /* for convenience:
       qa = q^a
       Qa = q^((e-1)-a)  for all a in [1..e-1]
  */
  qa = 1;
  Qa = N >> 1;

  /* x = (I_{q^(e-1)} (x) DFT_2) * x, 
     performed at stride = <stride> 
  */
  for (iQa = 0; iQa < Qa; iQa++) {
	  apply_small1( F->priv.qPower.fft_q, stride, 
		  at( x, iQa * (stride << 1) ) );
  }

  /* apply twiddles and tensored DFT_q */
  for (a = 1; a < e; ++a) {
    qa = qa << 1;
    Qa = Qa >> 1;
    /* x = diag(w^t(a,k) : k in [0..N)) * x,
       performed at stride <stride>
       where t(a,k) = (k % (q * qa)) / qa * (k % qa) * Qa.
    */
    w = at( F->priv.qPower.rootOfUnity, Qa );
    dxk = -stride + 2 * qa * stride;

    for (T1 = 1; T1 < qa; ++T1) {
      xk = at( x, (qa + T1) * stride );
      for (k2 = 0; k2 < Qa; ++k2) {
        mul( xk, xk, w );
        xk = at( xk, qa * (stride << 1) );
      }
      w = at( w, Qa );
    }

    /* x = (I_{q^((e-1)-a)} (x) DFT_2 (x) I_{q^a}) * x, 
	     performed at stride = <stride>                    
    */
	  xk = x;
	  for (iQa = 0; iQa < Qa; iQa++) {
		  for (iqa = 0; iqa < qa; iqa++) {
			  apply_small1( F->priv.qPower.fft_q,	qa * stride, xk );
			  xk = at( xk, stride );
		  }
		  xk = at( xk, qa * stride );
	  }
  }
}

static void apply_qPower( struct fft_s *F, int stride, Vector(x) ) {
  int N, q, e,                /* fetched from F */
      a, qa, Qa,        /* q^a, q^( ( e-1 )-a ) */
      iQa, iqa;

  fft_value *xk;              /* signal pointer */
  Scalar(w);              /* N-th root of unity */
  fft_t *fft_q;          /* the FFT of length q */

  /* treat the 2-power case individually */
  if (F->priv.qPower.q_exp == 1) {
    apply_2Power( F, stride, x );
    return;
  }

  /* fetch some constants */
  N     = F->N;
  q     = 1 << F->priv.qPower.q_exp;
  e     = F->priv.qPower.e;
  fft_q = F->priv.qPower.fft_q;

  /* x = R * x, performed at stride = <stride> */
  Apply_perm( N, F->priv.qPower.R, stride, x );

  /* x = (1_{r q^(e-1)} (x) DFT_q (x) 1_{q^0 s}) * x */

  /* for convenience:
       qa = q^a
       Qa = q^((e-1) - a)  for all a in [0..e-1]
  */
  qa = 1;
  Qa = N/q;  

  /* x = (1_{q^(e-1)} (x) DFT_q) * x, performed at stride = <stride> */  
  xk = x;
  for (iQa = 0; iQa < Qa; iQa++) {
	  fft_apply( fft_q, stride, xk );
	  xk = at( xk, q * stride );
  }

  /* apply twiddles and tensored DFT_q */
  for (a = 1; a < e; ++a) {
    qa *= q; 
    Qa /= q;
    /* x = diag( w^t(a, k) : k in [0..N) ) * x, 
       performed at stride = <stride>,
       where t(a, k) = (k % (q*qa)) / qa * (k % qa) * Qa.
    */

    if (q > 8) {
      /* use simple twiddle factor mults */
      { int k, t;
        for (k = 0; k < N; ++k) {
          t = (k % (q * qa)) / qa * (k % qa) * Qa;
          if (t > 0) {
            set( w, at( F->priv.qPower.rootOfUnity, t ) );
            xk = at( x, k * stride );
            mul( xk, xk, w );
          }
        }
      }
    } else {
   /* unrolled twiddle factor mults */
      {
        /*inner step of xk */
        int T1,  /* twiddle exponent divided by Qa */
			      k1, k2;                   /* temporary */

		    for (T1 = 1; T1 <= (q - 1) * (qa - 1); ++T1) {
			  /* w = w[N]^( T1 Qa ) */
			    set( w, at( F->priv.qPower.rootOfUnity, T1 * Qa ) );
			    for (k1 = (T1 / qa) + 1; k1 < q; ++k1) {
				    if (T1 % k1 == 0) {
					    xk = at( x, (k1 * qa + T1 / k1) * stride );
					    for (k2 = 0; k2 < Qa; ++k2) {
						  /* x[k * stride] *= w
						     where k = k2*q*qa + k1*qa + T1/k1
						  */
  						  mul( xk, xk, w );
  						  xk = at( xk, qa * q * stride );
              }
            }
          }
        }
      }
    }
    /* x = (I_{q^((e-1)-a)} (x) DFT_q (x) I_{q^a}) * x,
	     performed at stride = <stride>
	   */
	  xk = x;
	  for (iQa = 0; iQa < Qa; ++iQa) {
		  for (iqa = 0; iqa < qa; ++iqa) {
			  fft_apply( fft_q, qa * stride, xk );
			  xk = at( xk, stride );
		  }
	  	xk = at( xk, qa * stride * (q - 1) );
  	}
  }
}

static void delete_qPower( struct fft_s *F ) {
  fft_delete( F->priv.qPower.fft_q );
  delete_perm( F->priv.qPower.R );
  delete_vector( F->priv.qPower.rootOfUnity );
  delete_null( F );
}

fft_t *fft_new_qPower( fft_t *fft_q, int e ) {
  fft_t    *F;
  int       N, q,                    /* N = q^e */
            n,                       /* N = 2^n */
            q_exp,               /* q = 2^q_exp */
            k, Rk,             /* index, R( k ) */ 
            k1, a;        /* temporary, counter */
  fft_perm *perm;               /* buffer for R */
  char     *msg;
  int       qvec[2];

  q_exp   = fft_q->n;
  q       = 1 << q_exp;
  qvec[0] = q_exp;
  qvec[1] = e;
  n       = q_exp * e;
  N       = 1 << n;

  msg = fft_applicable( FFT_QPOWER, n, 2, qvec );
  if (msg != NULL) {
    Error( msg );
    return NULL;
  }
  perm = (fft_perm *) Malloc( N * sizeof( fft_perm ) );

  /* create F */
  F                    = fft_new_null( n );
  F->type              = FFT_QPOWER;
  F->N                 = N;
  F->n                 = n;
  F->apply             = apply_qPower;
  F->deleteObj         = delete_qPower;
  F->priv.qPower.e     = e;
  F->priv.qPower.q_exp = q_exp;

  /* precompute the N-th roots of unity */
  F->priv.qPower.rootOfUnity = new_vector( N );
  rootsOfUnity( F->priv.qPower.rootOfUnity, N );

  /* precompute the permutation R */
  for (k = 0; k < N; ++k )
    perm[k] = k;
  for (k = 0; k < N; ++k) {
    /* Rk = q-digits of k reversed */
    Rk = mod( k, q );
    k1 = div( k, q );
    for (a = 1; a < e; ++a) {
      Rk = Rk * q + mod( k1, q );
      k1 = k1 / q;
    }

    /* swap k and Rk ( but only once ) */
    if (Rk < k) {
      perm[k]  = Rk;
      perm[Rk] = k;
    }
  }
  F->priv.qPower.R = new_perm( N, perm );

  /* construct the FFT on q points */
  F->priv.qPower.fft_q = (struct fft_s *) fft_q;

  Free( perm );
  return F;
}


/* Print FFT-Method as a Tree
   ==========================
*/
static int print1( char *out, int indent, fft_t *F ) {
  int s_length, /* length of string produced ( excl. trailing 0 ) */
      dn;                     /* a new portition of text */

  fft_t *F_temp;

#define print_string( s ) \
  { dn = sprintf( out + s_length, s ); \
    if (dn < 0 ) Error( "sprintf( ) failed" ); s_length += dn; }

#define print_string_int( s, x ) \
  { dn = sprintf( out + s_length, s, x ); \
    if (dn < 0 ) Error( "sprintf( ) failed" ); s_length += dn; }

#define print_fft( indent, F ) \
  { dn = print1( out + s_length, indent, F ); \
    if (dn < 0 ) Error( "sprintf( ) failed" ); s_length += dn; }

#define print_newline( indent ) \
  { int i; print_string( "\n" ); \
    for (i = 0; i < indent; ++i ) print_string( "  " ); }

  s_length = 0;
  switch (F->type) {
    case FFT_DIRECT:
      print_string_int( "direct[%d]", F->n );
      break;
    case FFT_SMALL:
      print_string_int( "small[%d]", F->n );
      break;
    case FFT_TWIDDLE:
	    F_temp = fft_new_small( F->priv.twiddle.r );
      if (indent < 0) {
        print_string( "twiddle[ " );
        print_fft( indent, F_temp );
	    	print_string( "," );
        print_fft( indent, F->priv.twiddle.fft_S );
        print_string( "]" );
      } else {
        print_string_int( "twiddle[ (* n = %d = ", F->n );
        print_string_int( "%d + ", F->priv.twiddle.r );
        print_string_int( "%d *)", F->priv.twiddle.s );
        print_newline( indent+1 );
        print_fft( indent + 1, F_temp );
        print_string( "," );
        print_newline( indent + 1 );
        print_fft( indent + 1, F->priv.twiddle.fft_S );
        print_newline( indent );
        print_string( "]" );
      }
	    delete_small( F_temp );
      break;
    case FFT_COOLEY_TUKEY:
      if (indent < 0) {
        print_string( "cooleyTukey[" );
        print_fft( indent, F->priv.cooleyTukey.fft_R );
        print_string( "," );
        print_fft( indent, F->priv.cooleyTukey.fft_S );
        print_string( "]" );
      } else {
        print_string_int( "cooleyTukey[ (* n = %d = ", F->n );
        print_string_int( "%d + ", F->priv.cooleyTukey.r );
        print_string_int( "%d *)", F->priv.cooleyTukey.s );
        print_newline( indent + 1 );
        print_fft( indent + 1, F->priv.cooleyTukey.fft_R );
        print_string( "," );
        print_newline( indent + 1 );
        print_fft( indent + 1, F->priv.cooleyTukey.fft_S );
        print_newline( indent );
        print_string( "]" );
      }
      break;

    case FFT_QPOWER:
      if (indent < 0) {
        print_string( "qPower[" );
        print_fft( indent, F->priv.qPower.fft_q );
        print_string_int( ",%d]", F->priv.qPower.e );
      } else {
        print_string_int( "qPower[ (* n = %d = ", F->n );
        print_string_int( "%d * ", F->priv.qPower.q_exp );
        print_string_int( "%d *)", F->priv.qPower.e );
        print_newline( indent + 1 );
        print_fft( indent + 1, F->priv.qPower.fft_q );
        print_string( "," );
        print_newline( indent + 1 );
        print_string_int( "%d", F->priv.qPower.e );
        print_newline( indent );
        print_string( "]" );
      }
      break;

    default:
      print_string_int( "unrecognized[{type -> %d, ", F->type );
      print_string_int( "n -> %d}]", F->n );
      break;
  }
  return s_length;

#undef print_string
#undef print_string_int
#undef print_fft
#undef print_newline
}

char *fft_print( int indent, fft_t *F ) {
  char *out, *out1;
  int s_length;

  /* print into sufficiently large buffer first, then copy */
  out1 = (char *) Malloc( 10000 * sizeof( char ) );
  s_length    = print1( out1, indent, F );
  out  = (char *) Malloc( (s_length + 1) * sizeof( char ) );
  strcpy( out, out1 );
  Free( out1 );
  return out;
}

/* Parse FFT-Method from a String
   ==============================
*/

/* (int) parse_exp( msg, in, x )
     parses an integer from the string in and stores it into x.
     The function returns the number of characters consumed and
     stores an error message if it has not been successful
*/
static int parse_exp( char **msg, char *in, int *x ) {
  int exp_length, /* length of the exponent literal */ 
      i;                        /* counter for in[] */
      
  /* the exponent is in[0], .., in[exp_length-1] */
  exp_length = 0;
  while (( '0' <= in[exp_length]) && (in[exp_length] <= '9'))
    ++exp_length;
  if (exp_length == 0) {
    *msg = (char *) Malloc( MAX_ERROR_CHARS );
    sprintf( *msg, "[1] digits expected in fft_parse()" );
    return -1;
  }

#define MAX_EXP_DIGITS  3 
  /* convert to (int) x */
	if (exp_length > MAX_EXP_DIGITS ) {
		*x = -1;
	} else {
		*x = 0;
		for (i = 0; i < exp_length; ++i)
			*x = 10 * (*x) + ((int) (in[i]) - (int) '0');

		if (*x > FFT_MAX_EXP) *x = -1;
	}

  /* check size */
  if (( *x < 1 ) || ( *x > FFT_MAX_EXP )) {
    *msg = (char *) Malloc( MAX_ERROR_CHARS );
    sprintf( *msg, "[1] exponent too large in parse_exp()" );
    return -1;
  }
  return exp_length;
}


static int parse_fft( char **msg, char *in, fft_t **F ) {
  fft_t *Fq[ 2 ];               /* fft-object arguments */
  int    num_char,         /* nr. of chars read from in */
         n,                       /* fft length N = 2^n */
         e;               /* exponent for qPower method */
  char  *functor;              /* space for the functor */ 

#define isFunctor( f ) \
  ((num_char == (int) strlen( f )) && (strncmp( in, f, num_char ) == 0)) 

#define read_exp( x ) \
  { num_char += parse_exp( msg, in+num_char, &x ); \
    if (*msg != NULL ) return -1; }

#define read_fft( F ) \
  { num_char += parse_fft( msg, in+num_char, &(F) ); \
    if (*msg != NULL ) return -1; }

#define require( c ) \
  { if (in[num_char] == (c)) { ++num_char; } else { \
    *msg = (char *) Malloc( MAX_ERROR_CHARS ); \
    sprintf( *msg, "[1] '%c' expected in parse_fft()", c ); return -1; } }

  /* read the functor up to '[' */
  num_char = 0;
  while (( in[num_char] != (char) 0) && (in[num_char] != '['))
    ++num_char;

  /* read the expression */
  if (isFunctor( DIRECT )) {
    require( '[' );
  	read_exp( n );
    require( ']' );

    *F = fft_new_direct( n );
    if (*F == NULL) return -1;
    return num_char;
  } else

  if (isFunctor( SMALL )) {
    require( '[' );
  	read_exp( n );
    require( ']' );

    *F = fft_new_small( n );
    if (*F == NULL) return -1;
    return num_char;
  } else

  if (isFunctor( COOLEY_TUKEY )) {
    require( '[' );
    read_fft( Fq[0] ); 
    require( ',' );
    read_fft( Fq[1] ); 
    require( ']' );

	  if (Fq[0]->type == FFT_SMALL)
		  *F = fft_new_twiddle( Fq[0]->n, Fq[1] );
	  else
	    *F = fft_new_cooleyTukey( Fq[0], Fq[1] );

    if (*F == NULL) return -1;
    return num_char;
  } else

  if (isFunctor( QPOWER )) {
    require( '[' );
    read_fft( Fq[0] ); 
    require( ',' );
    read_exp( e ); 
    require( ']' );

    *F = fft_new_qPower( Fq[0], e );
    if (*F == NULL) return -1;
    return num_char;
  } else

  /* unrecognized functor */
  functor = (char *) Malloc( (num_char + 1) * sizeof( char ) );
  strncpy( functor, in, num_char );
  functor[num_char] = ( char ) 0;
  *msg = (char *) Malloc( MAX_ERROR_CHARS );
  sprintf( *msg, "[1] unrecognized functor \"%s\" in parse_fft()", functor );
  return -1;

#undef isFunctor
#undef read_exp
#undef read_fft
#undef require
}

extern fft_t *fft_parse( char **msg, char *in ) {
  fft_t *F;  /* the resulting structure */
  char  *in1; /* a processed copy of in */
  int    i;            /* index into in */

  /* strip comments and whitespace from in */
  in1 = (char *) Malloc( (strlen( in ) + 1) * sizeof( char ) );
  i   = 0;
  while (*in != (char) 0) {
    switch (*in) {
      case ' ':
      case '\t':
      case '\n':
        ++in;
        break;
      case '(':
        if (*(in + 1) != '*') {
          in1[i++] = *(in++);
        } else {
          /* skip comment */
          do {
            ++in;
          } while (
            (*in != (char) 0) && 
            ((*in != '*') || (*(in + 1) != ')'))
          );
          if (*in == '*')
            in += 2;
        }
        break;
      default:
        in1[i++] = *(in++);
    }
  }
  in1[i] = (char) 0;

  /* recursive descent parser */
  *msg  = NULL;
  F     = NULL;
  parse_fft( msg, in1, &F );
  Free( in1 );
  if (*msg != NULL)
    return NULL;
  return F;
}

/* Test Applicability of a Specific FFT-Method
   ===========================================
*/
static char *check_size( char *method, int n ) {
  char  *msg;

  if ((n < 1) || (n > FFT_MAX_EXP)) {
    msg = (char *) Malloc( MAX_ERROR_CHARS );
    sprintf( msg, "[3] exponent n = %d must be in "
      "[1..%d] for fft_%s()", n, FFT_MAX_EXP, method );
    return msg;
  }
  return NULL;
}

char *fft_applicable( int method, int n, int nq, int q[] ) {
  char *msg;

  switch (method) {
    case FFT_NULL:
      if (nq != 0) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[7] wrong number of arguments (%d) "
          "for fft_applicable( FFT_NULL, .. )", nq );
        return msg;
      }
      return check_size( "null", n );
      break;
    case FFT_DIRECT:
      if (nq != 0) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[7] wrong number of arguments (%d) "
          "for fft_applicable( FFT_DIRECT, .. )", nq );
        return msg;
      }
      return check_size( "direct", n );
      break;
    case FFT_SMALL:
      if (nq != 0) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[7] wrong number of arguments (%d) "
          "for fft_applicable( FFT_SMALL, .. )", nq );
        return msg;
      }
      if ((n < 1) || (n > FFT_MAX_SMALL)) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[3] exponent n = %d must be in "
          "[1..%d] for FFT_SMALL()", n, FFT_MAX_SMALL );
        return msg;
      }
      msg = check_size( "small", n );
      if (msg != NULL )
        return msg;
      break;
    case FFT_COOLEY_TUKEY:
      if (nq != 2) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[7] wrong number of arguments (%d) "
          "for fft_applicable( FFT_COOLEY_TUKEY, .. )", nq );
        return msg;
      }
      if ((q[0] < 1) || (q[1] < 1) || (q[0] > FFT_MAX_EXP) ||
        (q[1] > FFT_MAX_EXP)) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[3] q[0] = %d and q[1] = %d must be in "
          "[1..%d] for FFT_COOLEY_TUKEY()", q[0], q[1], FFT_MAX_EXP );
        return msg;
      }
      /* currently this test is pointless, since n was 
         computed using n = q[0] + q[1]
      */
      if (n != q[0] + q[1]) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[7] length n = %d must be q[0]+q[1] "
          "for FFT_COOLEY_TUKEY()", n );
        return msg;        
      }
      return check_size( "cooleyTukey", n );
      break;
    case FFT_QPOWER:
      if (nq != 2) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[7] wrong number of arguments (%d) "
          "for fft_applicable( FFT_QPOWER, .. )", nq );
        return msg;
      }

      if ((q[0] < 1) || (q[1] < 1) || (q[0] > FFT_MAX_EXP) ||
        (q[1] > FFT_MAX_EXP)) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[3] q[0] = %d and q[1] = %d must be in "
          "[1..%d] for FFT_QPOWER", q[0], q[1], FFT_MAX_EXP );
        return msg;
      }

      if ((q[0] * q[1]) > FFT_MAX_EXP) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[3] q[0] * q[1] = %d must be in "
          "[1..%d] for FFT_QPOWER", q[0] * q[1], FFT_MAX_EXP );
        return msg;
      }
      /* currently this test is pointless, since n was 
         computed using n = q[0] * q[1]
      */
      if (n != (q[0] * q[1])) {
        msg = (char *) Malloc( MAX_ERROR_CHARS );
        sprintf( msg, "[7] exponent N = %d must be "
          "q[0]*q[1] for FFT_QPOWER()", n );
        return msg;        
      }
      return check_size( "qPower", n );
      break;
    default:
      msg = (char *) Malloc( MAX_ERROR_CHARS );
      sprintf( msg, "[8] unrecognized method = %d "
        "in fft_applicable()", method );
      return msg;
      break;
  }
  return NULL;
}
