/*
 * Copyright (c) 2000 Carnegie Mellon University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/* fft_measure.c
 *
 * Runtime measurement for the SPIRAL FFT package
 * ==============================================
 *
 * compile with: make fft_measure
 *
 * fft_measure 
 *   [ -s <stride> ] # <fft> (x) I_<stride> is measured
 *   [ -t <num> ]    # sec. to measure, default = 1
 *   [ -g ]          # output in gap syntax
 *   [ -d ]          # use the spiraltimer for the timings
 *   -w <fft-method>
 *
 * measures <fft-method> given as a string in fft-syntax
 * applied as
 *   fft_apply( fft, <stride>, x)
 * by repeating it at least <num> (a float) seconds. The time
 * returned is for one fft, performed on a vector of length
 * <size-fft> . <stride>. If <stride> is > 1 then an entire
 * <fft> tensor 1_<stride> is performed and the average time
 * of one <fft> returned. Performing only one <fft> with <stride>
 * may produce bad timings.
 * <stride> must be a 2-power. The default for stride is 1.
 * The option '-g' prints the output in gap readable syntax, i.e.
 *   theInput := <t>
 * where <t> is an integer representing the time in us/10.
 */

/* This file is similar to the file measure.c from the wht 
 * package by M. Pueschel.  More information about that 
 * package can be found at
 * http://www.ece.cmu.edu/~spiral/wht.html
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include "spiral_fft.h"
#include "spiraltimer.h"

#define MIN_MALLOC_SIZE	32

fft_t *F = NULL;
fft_value *x, *y;
long stride = 1;

static void copy_vector(int N, fft_value y[], fft_value x[]) {
  int i;

  for (i = 0; i < N; ++i)
	fft_set( at( y, i ), at( x, i ) );
}

/* random doubles in [0, 1] */
#define RAND() ((double) (rand() + 1.0L))/RAND_MAX

static void random_scalar(fft_value *x) {
#if defined(fft_struct_scalars)
  x->re = (double) RAND();
  x->im = (double) RAND();
#endif
#if defined(fft_array_scalars)
  x[0] = (fft_value) RAND();
  x[1] = (fft_value) RAND();
#endif
}

double gettime(void) {
  clock_t t;

  t = clock();
  if (t == -1) {
    fprintf(stderr, "error in clcok()\n");
    exit(-1);
  }
  return (double) t/CLOCKS_PER_SEC;
}

void init_wrapper_function( void )
{
	copy_vector( F->N * stride, y, x );
}

void fft_wrapper_function( void )
{
	int j;
	for (j = 0; j < stride; j++)
        fft_apply(F, stride, at( y, j ) );
}

int main(int argc, char *argv[])
{
  int n;
  long stride = 1;
  double t = 1.0;
  long N, Ns, i, j;
  char c, *msg;
  int gap = 0;
  int use_spiraltimer = 0;
  long reps;
  double t1, time;
  struct EXPERIMENT timer_struct;

  if (argc == 1) {
    printf(
      "usage: %s\n"
      "  [ -s <stride> ] <fft> (x) I_<stride> is measured\n"
      "  [ -t <num> ]    sec. to measure, default = 1\n"
      "  [ -g ]          output in gap syntax\n"
      "  [ -d ]          use the spiraltimer for the timings\n"
      "  -f <fft-method>\n", argv[0]
    );
    exit(0);
  }

#define CHECK_ARG() {if (argc == n+1) { \
  fprintf(stderr, "error, argument for option '-%c' missing\n", c); \
  exit(-1); } }

  /* check options and arguments */
  n = 0;
  while (++n < argc) {
    if (*argv[n]++ == '-') {
      c = *argv[n];
      switch (c) {
      case 's':

        CHECK_ARG();

        /* stride */
		sscanf(argv[++n], "%ld", &stride);
        break;

      case 't':

        CHECK_ARG();

        /* number of seconds to be measured */
		sscanf(argv[++n], "%lf", &t);
        break;

      case 'g':

        gap = 1;
        break;

      case 'd':
		use_spiraltimer = 1;
		break;

      case 'f':

        CHECK_ARG();

        /* create fft to be verified */
		F = fft_parse(&msg, argv[++n]);
        break;

      default:
        fprintf(stderr, "error, illegal option %c\n", c);
        exit(-1);
      }
    }
    else {
      fprintf(stderr, "error, options must be preceded by '-'\n");
      exit(-1);
    }  
  }

#undef CHECK_ARG

  /* fft present? */
  if (F == NULL) {
    fprintf(stderr, "fft must be given\n");
    exit(-1);
  }

  /* parameters */
  N = F->N;

  Ns = N * stride;

  if (Ns < MIN_MALLOC_SIZE)
	Ns = MIN_MALLOC_SIZE;

  /* allocate vectors */
  x = (fft_value *) malloc(Ns * FFT_VALUES_PER_SCALAR * sizeof(fft_value));
  y = (fft_value *) malloc(Ns * FFT_VALUES_PER_SCALAR * sizeof(fft_value));

  if ((x == NULL) || (y == NULL)) {
    fprintf(stderr, "fatal: out of memory");
    exit(-1);
  }

  for (i = 0; i < Ns; i++)
    random_scalar( at( x, i ) );  

  if (use_spiraltimer) {
	timer_struct.func_ini = init_wrapper_function;
	timer_struct.func = fft_wrapper_function;
	timer_struct.accuracy = 0;
	timer_struct.timeout = t;

    spiraltimer_measure_exp( &timer_struct );
	time = timer_struct.runtime;
  }
  else {
    /* how many repetitions? */
    reps = 1;
    time = 0;
    while (time < t) {
      t1 = gettime();
      for (i = 0; i < reps; i++) {
        copy_vector(Ns, y, x);
        for (j = 0; j < stride; j++)
          fft_apply(F, stride, at( y, j ) );
      }
      time = gettime() - t1;
      reps *= 2;
    }
    reps /= 2;

    /* measure */
    t1   = gettime();
    for (i = 0; i < reps; i++) {
      copy_vector(Ns, y, x);
      for (j = 0; j < stride; j++)
        fft_apply(F, stride, at( y, j ) );
    }
    time = gettime() - t1;

    /* substract copies */
    t1 = gettime();
    for (i = 0; i < reps; i++) {
      copy_vector(Ns, y, x);
	  for (j = 0; j < stride; j++)
		  ;
    }
    time = time - (gettime() - t1);
	time = time / (double) (reps * stride);
  }

  if (gap == 0) 
    printf("%e\n", time);
  else
    printf(
      "theInput := %ld; # us/10\n", 
      (long) (time * 10000000)
    );

  return 0;
}
































