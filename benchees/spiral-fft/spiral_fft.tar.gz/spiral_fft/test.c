/*
 * Copyright (c) 2000 Carnegie Mellon University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/* test.c */

#include <stdlib.h>
#include <stdio.h>
#include "spiral_fft.h"

#define RAND() ((double) (rand() + 1.0L))/RAND_MAX

int main(void) {
  fft_t * tree;
  fft_value input[1024];
  int i;
  char temp;

  /* initialize somehow */  
  for (i=0; i < 1024; i++) {
    input[ i ].re = RAND();
    input[ i ].im = RAND();
  }
  tree = get_tree(10);  /* (tree for size 2^10 = 1024) */

  if (tree == NULL) {	  
    printf("fft_trees file not found.\n");
  } else {
    fft_apply(tree, 1, input);  /* stride is 1 */
    printf( "Installation successful.\n\n" );
    printf( "Please press enter to exit" );
    scanf( "%c", &temp );
  }	

return(0);
}

/* Please note that if you change spiral_fft.h to store complex numbers in
 * two-element arrays instead of in structs (by #defining 
 * FFT_ARRAY_SCALARS and #undefining FFT_STRUCT_SCALARS in spiral_fft.h), 
 * you must multiply all array indices and malloc sizes by a factor of two.  
 */
