/*     
 * Copyright (c) 2000 Carnegie Mellon University
 * Copyright (c) 1997-1999 Massachusetts Institute of Technology
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,MA  02111-1307 USA
 * 
 */

/* fftw_notw_2.c */

/* This file is a slightly modified version of the 
 * file fn_4.c from the software package FFTW, 
 * version 2.1.1, by M. Frigo and S. G. Johnson.
 * Information about FFTW is available at 
 * http://www.fftw.org
 *
 * The modification to the FFTW file is that the
 * FFT is now applied in-place.  The file was modified
 * on 6/15/00.
 *
 * The function in this file can be replaced with any 
 * function that computes 
 *
 * x = F_4 * x, performed at stride = <stride>.
 */

#include "spiral_fft.h"

extern void apply_small2( struct fft_s *UNUSED_PARAMETER(F), int stride, Vector(x) ) 
{
     fftw_real tmp3;
     fftw_real tmp11;
     fftw_real tmp9;
     fftw_real tmp15;
     fftw_real tmp6;
     fftw_real tmp10;
     fftw_real tmp14;
     fftw_real tmp16;
     
     {
	  fftw_real tmp1;
	  fftw_real tmp2;
	  fftw_real tmp7;
	  fftw_real tmp8;
	  
	  tmp1 = c_re(at(x,0));
	  tmp2 = c_re(at(x,2 * stride));
	  tmp3 = tmp1 + tmp2;
	  tmp11 = tmp1 - tmp2;
	  tmp7 = c_im(at(x,0));
	  tmp8 = c_im(at(x,2 * stride));
	  tmp9 = tmp7 - tmp8;
	  tmp15 = tmp7 + tmp8;
     }
     {
	  fftw_real tmp4;
	  fftw_real tmp5;
	  fftw_real tmp12;
	  fftw_real tmp13;
	  
	  tmp4 = c_re(at(x,stride));
	  tmp5 = c_re(at(x,3 * stride));
	  tmp6 = tmp4 + tmp5;
	  tmp10 = tmp4 - tmp5;
	  tmp12 = c_im(at(x,stride));
	  tmp13 = c_im(at(x,3 * stride));
	  tmp14 = tmp12 - tmp13;
	  tmp16 = tmp12 + tmp13;
     }
     c_re(at(x,2 * stride)) = tmp3 - tmp6;
     c_re(at(x,0)) = tmp3 + tmp6;
     c_im(at(x,stride)) = tmp9 - tmp10;
     c_im(at(x,3 * stride)) = tmp10 + tmp9;
     c_re(at(x,3 * stride)) = tmp11 - tmp14;
     c_re(at(x,stride)) = tmp11 + tmp14;
     c_im(at(x,2 * stride)) = tmp15 - tmp16;
     c_im(at(x,0)) = tmp15 + tmp16;
}

