/*     
 * Copyright (c) 2000 Carnegie Mellon University
 * Copyright (c) 1997-1999 Massachusetts Institute of Technology
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,MA  02111-1307 USA
 * 
 */

/* fftw_notw_3.c */

/* This file is a slightly modified version of the 
 * file fn_8.c from the software package FFTW, 
 * version 2.1.1, by M. Frigo and S. G. Johnson.
 * Information about FFTW is available at 
 * http://www.fftw.org
 *
 * The modification to the FFTW file is that the
 * FFT is now applied in-place.  The file was modified
 * on 6/15/00.
 *
 * The function in this file can be replaced with any 
 * function that computes 
 *
 * x = F_8 * x, performed at stride = <stride>.
 */

#include "spiral_fft.h"

static const fftw_real K707106781 = FFTW_KONST(+0.707106781186547524400844362104849039284835938);

extern void apply_small3( struct fft_s *UNUSED_PARAMETER(F), int stride, Vector(x) ) 
{
     fftw_real tmp3;
     fftw_real tmp23;
     fftw_real tmp18;
     fftw_real tmp38;
     fftw_real tmp6;
     fftw_real tmp37;
     fftw_real tmp21;
     fftw_real tmp24;
     fftw_real tmp13;
     fftw_real tmp49;
     fftw_real tmp35;
     fftw_real tmp43;
     fftw_real tmp10;
     fftw_real tmp48;
     fftw_real tmp30;
     fftw_real tmp42;
     
     {
	  fftw_real tmp1;
	  fftw_real tmp2;
	  fftw_real tmp19;
	  fftw_real tmp20;
	  
	  tmp1 = c_re(at(x,0));
	  tmp2 = c_re(at(x,4 * stride));
	  tmp3 = tmp1 + tmp2;
	  tmp23 = tmp1 - tmp2;
	  {
	       fftw_real tmp16;
	       fftw_real tmp17;
	       fftw_real tmp4;
	       fftw_real tmp5;
	       
	       tmp16 = c_im(at(x,0));
	       tmp17 = c_im(at(x,4 * stride));
	       tmp18 = tmp16 + tmp17;
	       tmp38 = tmp16 - tmp17;
	       tmp4 = c_re(at(x,2 * stride));
	       tmp5 = c_re(at(x,6 * stride));
	       tmp6 = tmp4 + tmp5;
	       tmp37 = tmp4 - tmp5;
	  }
	  tmp19 = c_im(at(x,2 * stride));
	  tmp20 = c_im(at(x,6 * stride));
	  tmp21 = tmp19 + tmp20;
	  tmp24 = tmp19 - tmp20;
	  {
	       fftw_real tmp11;
	       fftw_real tmp12;
	       fftw_real tmp31;
	       fftw_real tmp32;
	       fftw_real tmp33;
	       fftw_real tmp34;
	       
	       tmp11 = c_re(at(x,7 * stride));
	       tmp12 = c_re(at(x,3 * stride));
	       tmp31 = tmp11 - tmp12;
	       tmp32 = c_im(at(x,7 * stride));
	       tmp33 = c_im(at(x,3 * stride));
	       tmp34 = tmp32 - tmp33;
	       tmp13 = tmp11 + tmp12;
	       tmp49 = tmp32 + tmp33;
	       tmp35 = tmp31 - tmp34;
	       tmp43 = tmp31 + tmp34;
	  }
	  {
	       fftw_real tmp8;
	       fftw_real tmp9;
	       fftw_real tmp26;
	       fftw_real tmp27;
	       fftw_real tmp28;
	       fftw_real tmp29;
	       
	       tmp8 = c_re(at(x,stride));
	       tmp9 = c_re(at(x,5 * stride));
	       tmp26 = tmp8 - tmp9;
	       tmp27 = c_im(at(x,stride));
	       tmp28 = c_im(at(x,5 * stride));
	       tmp29 = tmp27 - tmp28;
	       tmp10 = tmp8 + tmp9;
	       tmp48 = tmp27 + tmp28;
	       tmp30 = tmp26 + tmp29;
	       tmp42 = tmp29 - tmp26;
	  }
     }
     {
	  fftw_real tmp7;
	  fftw_real tmp14;
	  fftw_real tmp15;
	  fftw_real tmp22;
	  
	  tmp7 = tmp3 + tmp6;
	  tmp14 = tmp10 + tmp13;
	  c_re(at(x,4 * stride)) = tmp7 - tmp14;
	  c_re(at(x,0)) = tmp7 + tmp14;
	  tmp15 = tmp13 - tmp10;
	  tmp22 = tmp18 - tmp21;
	  c_im(at(x,2 * stride)) = tmp15 + tmp22;
	  c_im(at(x,6 * stride)) = tmp22 - tmp15;
     }
     {
	  fftw_real tmp51;
	  fftw_real tmp52;
	  fftw_real tmp47;
	  fftw_real tmp50;
	  
	  tmp51 = tmp18 + tmp21;
	  tmp52 = tmp48 + tmp49;
	  c_im(at(x,4 * stride)) = tmp51 - tmp52;
	  c_im(at(x,0)) = tmp51 + tmp52;
	  tmp47 = tmp3 - tmp6;
	  tmp50 = tmp48 - tmp49;
	  c_re(at(x,6 * stride)) = tmp47 - tmp50;
	  c_re(at(x,2 * stride)) = tmp47 + tmp50;
     }
     {
	  fftw_real tmp25;
	  fftw_real tmp36;
	  fftw_real tmp39;
	  fftw_real tmp40;
	  
	  tmp25 = tmp23 + tmp24;
	  tmp36 = K707106781 * (tmp30 + tmp35);
	  c_re(at(x,5 * stride)) = tmp25 - tmp36;
	  c_re(at(x,stride)) = tmp25 + tmp36;
	  tmp39 = tmp37 + tmp38;
	  tmp40 = K707106781 * (tmp35 - tmp30);
	  c_im(at(x,7 * stride)) = tmp39 - tmp40;
	  c_im(at(x,3 * stride)) = tmp39 + tmp40;
     }
     {
	  fftw_real tmp45;
	  fftw_real tmp46;
	  fftw_real tmp41;
	  fftw_real tmp44;
	  
	  tmp45 = tmp38 - tmp37;
	  tmp46 = K707106781 * (tmp42 + tmp43);
	  c_im(at(x,5 * stride)) = tmp45 - tmp46;
	  c_im(at(x,stride)) = tmp45 + tmp46;
	  tmp41 = tmp23 - tmp24;
	  tmp44 = K707106781 * (tmp42 - tmp43);
	  c_re(at(x,7 * stride)) = tmp41 - tmp44;
	  c_re(at(x,3 * stride)) = tmp41 + tmp44;
     }
}

