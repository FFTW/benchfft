/*
 * Copyright (c) 2000 Carnegie Mellon University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

//    David Sepiashvili
//    Version 2.1     11/16/99

/********************************************************************/
/*                        GENERAL DEFINITIONS                       */
/********************************************************************/

#include "spiraltimer.h"


/********************************************************************/
/*           SYSTEM SPECIFIC CLOCK: DEFINITIONS                     */
/********************************************************************/

//void spiraltimer_clock_start(CLOCK_DATA*);
//double spiraltimer_clock_stop(CLOCK_DATA*);
//double spiraltimer_clock_elapsed(CLOCK_DATA*);


/********************************************************************/
/*           SYSTEM SPECIFIC CLOCK: CLOCK_STD                       */
/********************************************************************/
#if(CLOCK_SOURCE==CLOCK_STD)

#include <time.h>
typedef struct CLOCK_DATA {
    int IsRunning;
    double elapsed;
    clock_t Ts;
    clock_t Tf;
} CLOCK_DATA;

void spiraltimer_clock_start(CLOCK_DATA* cd) {
    cd->IsRunning=1;
    cd->Ts=clock();
}



double spiraltimer_clock_elapsed(CLOCK_DATA* cd) {
    if (cd->IsRunning) {
        cd->Tf=clock();
        cd->elapsed=cd->Tf-cd->Ts;
        cd->elapsed=cd->elapsed*UNITS_PER_SECOND/CLOCKS_PER_SEC;
    }
    return cd->elapsed;
}

#endif

/********************************************************************/
/*           SYSTEM SPECIFIC CLOCK: CLOCK_UNIX                      */
/********************************************************************/
#if(CLOCK_SOURCE==CLOCK_UNIX)


#include <sys/time.h>
  #define ITIMER_SELECTED ITIMER_VIRTUAL    // user time
//#define ITIMER_SELECTED ITIMER_REAL       // user time  + system time

typedef struct CLOCK_DATA {
    int IsRunning;
    double elapsed;
    struct itimerval Ts;
    struct itimerval Tf;
} CLOCK_DATA;

void spiraltimer_clock_start(CLOCK_DATA* cd) {
    cd->IsRunning=1;
    cd->Ts.it_interval.tv_sec = 0;
    cd->Ts.it_interval.tv_usec = 0;
    cd->Ts.it_value.tv_sec = 86400;
    cd->Ts.it_value.tv_usec = 0;
    setitimer(ITIMER_SELECTED, &cd->Ts, NULL);
}

double spiraltimer_clock_elapsed(CLOCK_DATA* cd) {
    if (cd->IsRunning) {
        getitimer(ITIMER_SELECTED, &cd->Tf);
        cd->elapsed=(cd->Ts.it_value.tv_sec - cd->Tf.it_value.tv_sec) +
                   (cd->Ts.it_value.tv_usec - cd->Tf.it_value.tv_usec)*1e-6;
        cd->elapsed=cd->elapsed*UNITS_PER_SECOND;
    }
    return cd->elapsed;
}

#endif

/********************************************************************/
/*           SYSTEM SPECIFIC CLOCK: CLOCK_TSCM                      */
/********************************************************************/
#if(CLOCK_SOURCE==CLOCK_TSCM)

typedef struct CLOCK_DATA {
    unsigned long ini_lo;
    unsigned long ini_hi;
    unsigned long dif_lo;
    unsigned long dif_hi;
    long IsRunning;
    double elapsed;
} CLOCK_DATA;

void spiraltimer_clock_start(CLOCK_DATA* cd) {
    cd->IsRunning=1;
    _asm {
        push  eax
        push  ebx
        push  edx
        mov   eax,0
        cpuid
        mov   eax,0
        mov   edx,0
        rdtsc
        mov   ebx,cd
        mov   [ebx+0],eax
        mov   [ebx+4],edx
        pop   edx
        pop   ebx
        pop   eax
    }
}

double spiraltimer_clock_elapsed(CLOCK_DATA* cd) {
    if (cd->IsRunning) {
        _asm {
            push  eax
            push  ebx
            push  edx
            mov   eax,0
            cpuid
            mov   eax,0
            mov   edx,0
            rdtsc
            mov   ebx,cd
            sub   eax,[ebx+0]
            sbb   edx,[ebx+4]
            mov   [ebx+8],eax
            mov   [ebx+12],edx
            pop   edx
            pop   ebx
            pop   eax
        }
        cd->elapsed=(double)cd->dif_hi*256*256*256*256
                  +(double)cd->dif_lo;
        cd->elapsed=cd->elapsed*UNITS_PER_SECOND/CLOCK_SPEED_CPU;
    }
    return cd->elapsed;
}

#endif

/********************************************************************/
/*           SYSTEM SPECIFIC CLOCK: CLOCK_TSCU                      */
/********************************************************************/
#if(CLOCK_SOURCE==CLOCK_TSCU)

typedef struct CLOCK_DATA {
    unsigned long ini_lo;
    unsigned long ini_hi;
    unsigned long dif_lo;
    unsigned long dif_hi;
    long IsRunning;
    double elapsed;
} CLOCK_DATA;

void spiraltimer_clock_start(CLOCK_DATA* cd) {
    cd->IsRunning=1;
    __asm__ __volatile__("pushl  %%eax");
    __asm__ __volatile__("pushl  %%ebx");
    __asm__ __volatile__("pushl  %%edx");
    __asm__ __volatile__("movl   %%eax,0");
    __asm__ __volatile__("cpuid");
    __asm__ __volatile__("movl   %%eax,0");
    __asm__ __volatile__("movl   %%edx,0");
    __asm__ __volatile__("rdtsc");
    __asm__ __volatile__("movl   %%eax,%0":"=m"(cd->ini_lo));
    __asm__ __volatile__("movl   %%edx,%0":"=m"(cd->ini_hi));
    __asm__ __volatile__("popl   %%edx");
    __asm__ __volatile__("popl   %%ebx");
    __asm__ __volatile__("popl   %%eax");
}

double spiraltimer_clock_elapsed(CLOCK_DATA* cd) {
    if (cd->IsRunning) {
        __asm__ __volatile__("pushl  %%eax");
        __asm__ __volatile__("pushl  %%ebx");
        __asm__ __volatile__("pushl  %%edx");
        __asm__ __volatile__("movl   %%eax,0");
        __asm__ __volatile__("cpuid");
        __asm__ __volatile__("movl   %%eax,0");
        __asm__ __volatile__("movl   %%edx,0");
        __asm__ __volatile__("rdtsc");
        __asm__ __volatile__("subl   %0,%%eax"::"m"(cd->ini_lo):"eax");
        __asm__ __volatile__("sbbl   %0,%%edx"::"m"(cd->ini_hi):"edx");
        __asm__ __volatile__("movl   %%eax,%0":"=m"(cd->dif_lo));
        __asm__ __volatile__("movl   %%edx,%0":"=m"(cd->dif_hi));
        __asm__ __volatile__("popl   %%edx");
        __asm__ __volatile__("popl   %%ebx");
        __asm__ __volatile__("popl   %%eax");
        cd->elapsed=(double)cd->dif_hi*256*256*256*256
                  +(double)cd->dif_lo;
        cd->elapsed=cd->elapsed*UNITS_PER_SECOND/CLOCK_SPEED_CPU;
    }
    return cd->elapsed;
}

#endif

/********************************************************************/

double spiraltimer_clock_stop(CLOCK_DATA* cd) {
    spiraltimer_clock_elapsed(cd);
    cd->IsRunning=0;
    return cd->elapsed;
}

/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/

double spiraltimer_resolution() {
    CLOCK_DATA clockdata;
    double res,res_min=0;
    int i;
    for(i=0;i<10;i++) {
        spiraltimer_clock_start(&clockdata);
        do {
            res=spiraltimer_clock_elapsed(&clockdata);
        } while (res==0);
        spiraltimer_clock_stop(&clockdata);
        if (res<res_min || res_min==0) res_min=res;
    }
    return res_min;
}


double g_resolution=0;
double g_emptyloop=-1;

void function_empty() { }

double  spiraltimer_measure(FUNCTION f, double accuracy, double timeout) {
    EXPERIMENT ex;
    ex.func = f;
    ex.func_ini = 0;
    ex.accuracy = accuracy;
    ex.timeout = timeout;
    spiraltimer_measure_exp(&ex);
    return ex.runtime;
}

double  spiraltimer_measure_ini(FUNCTION f, FUNCTION fini, double accuracy, double timeout) {
    EXPERIMENT ex;
    ex.func = f;
    ex.func_ini = fini;
    ex.accuracy = accuracy;
    ex.timeout = timeout;
    spiraltimer_measure_exp(&ex);
    return ex.runtime;
}


double spiraltimer_measure_one(EXPERIMENT* ex) {
    // this function determines how many times you need to loop
    // in order to get specified accuracy

    CLOCK_DATA clockdata;
    long i,step;
    double t,t_max;

    ex->resolution = g_resolution;

    // in the future release the part below will be improved,
    // and will be based on actual experiments fo a given machine

    if (ex->timeout == 0 && ex->accuracy ==0) ex->accuracy = 0.1;

    if (ex->timeout == 0) {
        if (ex->accuracy <= 0.01) {
            ex->timeout = 10 / ex->accuracy * 0.01;
        } else if (ex->accuracy <= 0.1) {
            ex->timeout = 0.3 / ex->accuracy * 0.1;
        } else {
            ex->timeout = 0.01 / ex->accuracy * 0.1;
        }
    }

    ex->quant_err= ex->reps * ex->resolution / (ex->timeout*UNITS_PER_SECOND);


    //////////////////////////////////////////////
    // STEP 1: Determine n to satisfy quant_err //
    //////////////////////////////////////////////

    // this is a threshold value to satisfy max allowed error constrain
    t_max = (ex->resolution / ex->quant_err) + ex->resolution;
    
    // our goal is to set step in such a way that with new value of n
    // t is not much greater than t_max. If current t==0 then t<resolution
    // we want to maximize step given constrain step<t_max/t
    // by solving all this we get: choose step<t_max/resolution=1+1/allowed_error
    // In reality we want new t to be a little bit greater than t_max, so
    // by using step=1+1.1/quant_err we guaranteed that new t will not
    // be about 10% greater than t_max. Also we are guaranteed that step>=2
    step = (long)(1+1.1/ex->quant_err);
    

    // algorithm is to keep increasing n until we get time > threshold
    // when we get a value of 0, it is safe to increase n by step from above
    // when we finally get non-zero value, we can estimate the step.
    // since t_max/t>=1, n will be increasing. But to make sure it is increasing
    // fast enough we add another constrain, namely, n should increase at least by 10%
    for(ex->reps_quant=1;;) {
        spiraltimer_clock_start(&clockdata);
        for(i=0; i<ex->reps_quant; i++) {
            ex->func_ini();
            ex->func();
        }
        spiraltimer_clock_stop(&clockdata);
        t=spiraltimer_clock_elapsed(&clockdata);
        if (t>=t_max) break;
        if (t==0) {
            ex->reps_quant=ex->reps_quant*step;
        }
        else {
            ex->reps_quant=(long)(1+ex->reps_quant*(1.1*t_max/t));
        }
    }

    return t;
}

double spiraltimer_measure_exp(EXPERIMENT* ex) {

    #define REPS 10
    #define REPS_KEEP 7
    CLOCK_DATA total;
    CLOCK_DATA clockdata;
    double ta[REPS];
    double t;
    long i,k;
    FUNCTION f;

    if (g_emptyloop==-1) {
        g_emptyloop=0;
        g_emptyloop=spiraltimer_measure(function_empty,ex->accuracy,ex->timeout);
    }
    if (g_resolution==0) g_resolution=spiraltimer_resolution();

    ex->reps = REPS;
    if (ex->func_ini==0) ex->func_ini=function_empty;

    spiraltimer_clock_start(&total);    


    // compute overhead
    if (ex->func_ini==function_empty) {
        for (k=0; k<ex->reps; k++) ta[k]=g_emptyloop;
    } else {
        f=ex->func;
        ex->func=function_empty;
        ta[0]=spiraltimer_measure_one(ex)/ex->reps_quant;
        for (k=1; k<ex->reps; k++) {
            spiraltimer_clock_start(&clockdata);
            for(i=0; i<ex->reps_quant; i++) {
                ex->func_ini();
                ex->func();
            }
            ta[k]=spiraltimer_clock_stop(&clockdata)/ex->reps_quant;
        }
        ex->func=f;
    }

    // compute func + overhead, and subtract overhead
    ta[0]=spiraltimer_measure_one(ex)/ex->reps_quant-ta[0];
    for (k=1; k<ex->reps; k++) {
        spiraltimer_clock_start(&clockdata);
        for(i=0; i<ex->reps_quant; i++) {
            ex->func_ini();
            ex->func();
        }
        ta[k]=spiraltimer_clock_stop(&clockdata)/ex->reps_quant-ta[k];
    }

    // validate values
    for (k=0; k<ex->reps; k++) {
        //if (ta[k]<0) ta[k]=0;
    }    
    
    // sort the array
    for (k=1; k<ex->reps;) {
        if (ta[k]<ta[k-1]) {
            t=ta[k];
            ta[k]=ta[k-1];
            ta[k-1]=t;
            if (k==1) k=2; else k=k-1;
        } else {
            k++;
        }
    }

    // keep lowest REPS_KEEP elements
    ex->reps=REPS_KEEP;


    // compute statistics
    ex->mean = 0;
    for (k=0; k<ex->reps; k++) ex->mean += ta[k];
    ex->mean = ex->mean / ex->reps;
    ex->var = 0;
    for (k=0; k<ex->reps; k++) ex->var += (ta[k]-ex->mean)*(ta[k]-ex->mean);
    ex->var = ex->var / ex->reps;
    ex->min=ta[0];
    ex->max=ta[ex->reps-1];
    ex->spread = (ex->max - ex->min) / ex->mean;

    ex->runtime = ex->mean;
    if (ex->runtime < 0) ex->runtime = 0;

    //////////////////////////////////////////////
    // STEP 3: Done                             //
    //////////////////////////////////////////////

    ex->totaltime = spiraltimer_clock_stop(&total);    

    return ex->runtime;
}


/********************************************************************/
