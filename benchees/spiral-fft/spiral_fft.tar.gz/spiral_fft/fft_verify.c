/*
 * Copyright (c) 2000 Carnegie Mellon University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/* fft_verify.c
 *
 * Verification of SPIRAL in-place FFT package
 * ===========================================
 * Gavin Haentjens, 6/2/00
 *
 * compile with: make fft_verify 
 *
 * fft_verify [ <options> ] <method>    
 *
 * options:
 *   -s <int>       stride of the data to be transformed
 *   -inverse       apply inverse FFT
 *   -read          transform signal from stdin
 *   -print         print signals
 * -------------------------------------------------------------
 * verifies <fft-method> given as a string in fft-syntax by
 * comparing to a direct implementation.
 */

/* This file contains modified code from the file fftest.c from 
 * the fft package by Sebastian Egner.  More information about 
 * that package can be found at 
 * http://avalon.ira.uka.de/home/egner
 *
 * Modifications to Egner's code:
 *
 * - The timing feature was removed.
 * - The numerical recipes FFT implementation was removed.
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "spiral_fft.h"

#define MAX_ERROR pow( 10, -10 ) /* max allowable error */

/* Tools for Vectors 
   =================
*/
static void copy_vector(int n, int stride, fft_value y[], fft_value x[]) {
  int i;

  for (i = 0; i < n; ++i)
	fft_set( at( y, i * stride ), at( x, i * stride ) );
}

static void print_scalar( fft_value x[] ) {
#if defined( FFT_STRUCT_SCALARS )
  printf( "(%f)+I*(%f)", x->re, x->im );
#endif
#if defined( FFT_ARRAY_SCALARS )
  printf( "(%f)+I*(%f)", x[0], x[1] );
#endif
}

static void print_vector( int N, int stride, fft_value x[] ) {
  int k;
 
  if (N == 0) {
    printf("{ }\n");
    return;
  }
  printf( "{" );
  print_scalar( x );
  for (k = 1; k < N; ++k) {
    printf( ", " );
    print_scalar( at( x, k * stride ) );
  }
  printf( "}\n" );
}

static void max_difference_vector( fft_value md[], 
  int N, int stride, fft_value x[], fft_value y[]
) {
  int       k;
  fft_value d[FFT_VALUES_PER_SCALAR];

#if defined( FFT_STRUCT_SCALARS )
#define abs(x) (x->re * x->re + x->im * x->im)
#endif
#if defined( FFT_ARRAY_SCALARS )
#define abs(x) (x[0] * x[0] + x[1] * x[1])
#endif
  fft_rational( md, 0, 1 );
  for (k = 0; k < N; ++k) {
    fft_sub(d, at(x, k * stride), at(y, k * stride));
    if (abs(d) > abs(md)) {
      fft_set(md, d);
	    if (abs(d) > MAX_ERROR) {
		    fprintf( stderr, "difference at index %d: %f\n", k, 
			    abs(d) );
		    fprintf( stderr, "exiting\n" );
		    exit(-1);
	    }
	  }
  }
#undef abs
}

/* Pseudo-Random Generator
   =======================
*/
static int random_int( int n ) {
  static int 
    m = 1000001,
    a = 23, 
    c = 1,
    X = 0;
    
  X = (a*X + c) % m;
  return ((X >> 4) % n);
}

static void random_scalar( fft_value *x ) {
#if defined( FFT_STRUCT_SCALARS )
  x->re = (double) (random_int(65536) * 1.0/65535.0);
  x->im = (double) (random_int(65536) * 1.0/65535.0);
#endif
#if defined( FFT_ARRAY_SCALARS )
  x[0] = (fft_value)(random_int(65536) * 1.0/65535.0);
  x[1] = (fft_value)(random_int(65536) * 1.0/65535.0);
#endif
}

/* Reading of Input Vector
   ========================
*/
static void read_scalar( FILE *in, fft_value x[] ) {
  if (feof(in)) {
    random_scalar(x);
    return;
  }
  fprintf( stdout, "\nreal part: " );
#if defined( FFT_STRUCT_SCALARS )
  fscanf( in, "%lf", &(x->re) );     /* use "%lf" for doubles */
  fprintf( stdout, "imag. part: " );
  fscanf( in, "%lf", &(x->im) );
#endif
#if defined( FFT_ARRAY_SCALARS )
  fscanf( in, "%lf", &(x[0]));
  fprintf( stdout, "imag. part: " );
  fscanf( in, "%lf", &(x[1]) );
#endif
}

/* Application
   ===========
*/
int main( int argc, char *argv[], char *envp[] ) {
  fft_t     *F, *F1;                 /* the fft-objects */
  char      *msg,                      /* error message */
            *adr0, *adr1,       /* to find memory leaks */
            *out;                  /* printed form of F */
  int        inverse,             /* apply inverse fft? */
             read_input,                 /* read input? */
             print,                   /* print signals? */
             s,                   /* stride of the data */
             usage,             /* print usage message? */
             N, Ns,                 /* size to allocate */
             n,                              /* N = 2^n */
             i,                              /* counter */
             dummy;    /* dummy variable for random_int */
  fft_value  diff[ FFT_VALUES_PER_SCALAR ];/* d(x0, x1) */
  fft_value *x0, *x1;    /* initial, transformed signal */

  inverse      = 0;
  read_input   = 0;
  print        = 0;
  s            = 1;
  usage        = (argc < 2);

  for (i = 1; (i < argc) && (!usage); ++i) {
#define isOption(opt) \
  ((strcmp(argv[i], opt) == 0) && (i+1 < argc))

    if (isOption("-inverse")) {
      inverse = 1;
    } else
    if (isOption("-read")) {
      read_input = 1;
    } else
    if (isOption("-print")) {
      print = 1;
    } else
    if (isOption("-s")) {
      dummy = sscanf(argv[++i], "%d", &s);
      if (!( s >= 1 ))
        usage = 1;
    } 
#undef isOption
  }

  if (usage) {
    fprintf(stderr, 
      "usage: %s [ <options> ] <method>\n"
      "options:\n"
      "  -inverse       apply inverse FFT\n"
      "  -read          transform signal from stdin\n"
      "  -print         print signals\n"
      "  -s <int>       stride of the data to be transformed\n"
    ,
      argv[0]
    );
    exit(1);
  }

  /* check malloc/free pointers (not portable) */
  printf( "\n(* initial *)\n" );
  adr0 = (char *) malloc(32);
  adr1 = (char *) malloc(32);
  free(adr1);
  free(adr0);
  printf("malloc[initial] = {%d, %d};\n\n", (int)adr0, (int)adr1);

  /* create the fft-object F */
  printf("(* setup *)\n");
  { 
    F  = fft_parse(&msg, argv[argc-1]);

    if (msg != NULL) {
      fprintf(stdout, "error: %s\n", msg);
      exit(1);
    }
    N = F->N;
    n = F->n;
    out = fft_print(1, F);
    printf("method =\n  %s;\n\n", out);
    free(out);
  }

  /* create the input signal and allocate output signal */
  Ns = N * s;
  if (Ns < 32)
    Ns = 32; /* avoid small mallocs */
  x0 = 
    (fft_value *) malloc( 
      Ns * FFT_VALUES_PER_SCALAR * sizeof(fft_value) 
    );
  x1 = 
    (fft_value *) malloc( 
      Ns * FFT_VALUES_PER_SCALAR * sizeof(fft_value) 
    );
  if ((x0 == NULL) || (x1 == NULL)) {
    fprintf(stderr, "fatal: out of memory");
    exit(1);
  }
  if (! read_input) {
    for (i = 0; i < 100; ++i) 
      dummy = random_int(65536);
    for (i = 0; i < N; ++i)
      random_scalar(at(x0, i * s));
  } else {
    for (i = 0; i < N; ++i)
	{
      fprintf( stdout, "x[%d]:", i * s );
      read_scalar(stdin, at(x0, i * s));
	}
  }
  if (print) {
    printf("(* input signal *)\n");
    printf("x0 =\n  ");
    print_vector(N, s, x0);
    printf("\n\n");
  }

  /* transform */
  printf( 
    "(* transformation: x1 = method . x0, performed at stride %d *)\n\n", s);
  if (inverse) {
    copy_vector(N, s, x1, x0);
    fft_apply_inverse(F, s, x1);
  } else {
    copy_vector(N, s, x1, x0);
    fft_apply(F, s, x1);
  }
  if (print) {
    printf("x1 =\n  ");
    print_vector(N, s, x1);
    printf("\n");
  }

  /* check */
  printf( 
    "(* check: x2 = direct^-1 . x1, performed at stride %d *)\n\n", s );
  printf( "n = %d\n\n", n );
  F1 = fft_new_direct( n );
  if (inverse)
    fft_apply(F1, s, x1);
  else
    fft_apply_inverse(F1, s, x1);
  fft_delete(F1);
  if (print) {
    printf("x2 =\n  ");
    print_vector(N, s, x1);
    printf("\n");
  }
  max_difference_vector( diff, N, s, x0, x1 );
  printf( "max. difference between x0 and x2 = " );
  print_scalar(diff);
  printf( ";\n\n" );

  /* report malloc/free addresses */
  fft_delete(F);
  free(x0);
  free(x1);
  printf("(* final *)\n");
  adr0 = (char *) malloc(32);
  adr1 = (char *) malloc(32);
  free(adr1);
  free(adr0);
  printf("malloc[final] = {%d, %d};\n\n", (int)adr0, (int)adr1);
  /* everything's fine */
  printf( "correct\n" );
  return 0;
}
