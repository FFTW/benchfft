/*     
 * Copyright (c) 2000 Carnegie Mellon University
 * Copyright (c) 1997-1999 Massachusetts Institute of Technology
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,MA  02111-1307 USA
 * 
 */

/* fftw_twid_2.c */

/* This file is a slightly modified version of the 
 * file ftw_4.c from the software package FFTW, 
 * version 2.1.1, by M. Frigo and S. G. Johnson.
 * Information about FFTW is available at 
 * http://www.fftw.org
 *
 * The modifications to the FFTW file are that some of
 * the variable names were changed, and the accessing of
 * complex numbers was changed, to accommodate complex 
 * numbers stored in both structs and two-element arrays.  
 * The modifications were made on 6/15/00.
 *
 * The function in this file can be replaced with any 
 * function that computes 
 *
 * x = (F_4 (x) I_<S>) * T^(4*<S>)_<S> * x, 
 *  performed at stride = <iostride>.
 */

#include "spiral_fft.h"

extern void apply_twiddle2( int iostride, Vector(A), fft_value *W, int S, int dist ) 
{
     int i;
     fft_value *inout;

     inout = A;
     for (i = S; i > 0; i = i - 1, inout = at( inout, dist ), 
		 W = at( W, 3 ) ) {
	  fftw_real tmp1;
	  fftw_real tmp25;
	  fftw_real tmp6;
	  fftw_real tmp24;
	  fftw_real tmp12;
	  fftw_real tmp20;
	  fftw_real tmp17;
	  fftw_real tmp21;
	  
	  tmp1 = c_re(at(inout,0));
	  tmp25 = c_im(at(inout,0));
	  {
	       fftw_real tmp3;
	       fftw_real tmp5;
	       fftw_real tmp2;
	       fftw_real tmp4;
	       
	       tmp3 = c_re(at(inout,2 * iostride));
	       tmp5 = c_im(at(inout,2 * iostride));
	       tmp2 = c_re(at(W,1));
	       tmp4 = c_im(at(W,1));
	       tmp6 = (tmp2 * tmp3) - (tmp4 * tmp5);
	       tmp24 = (tmp4 * tmp3) + (tmp2 * tmp5);
	  }
	  {
	       fftw_real tmp9;
	       fftw_real tmp11;
	       fftw_real tmp8;
	       fftw_real tmp10;
	       
	       tmp9 = c_re(at(inout,iostride));
	       tmp11 = c_im(at(inout,iostride));
	       tmp8 = c_re(at(W,0));
	       tmp10 = c_im(at(W,0));
	       tmp12 = (tmp8 * tmp9) - (tmp10 * tmp11);
	       tmp20 = (tmp10 * tmp9) + (tmp8 * tmp11);
	  }
	  {
	       fftw_real tmp14;
	       fftw_real tmp16;
	       fftw_real tmp13;
	       fftw_real tmp15;
	       
	       tmp14 = c_re(at(inout,3 * iostride));
	       tmp16 = c_im(at(inout,3 * iostride));
	       tmp13 = c_re(at(W,2));
	       tmp15 = c_im(at(W,2));
	       tmp17 = (tmp13 * tmp14) - (tmp15 * tmp16);
	       tmp21 = (tmp15 * tmp14) + (tmp13 * tmp16);
	  }
	  {
	       fftw_real tmp7;
	       fftw_real tmp18;
	       fftw_real tmp27;
	       fftw_real tmp28;
	       
	       tmp7 = tmp1 + tmp6;
	       tmp18 = tmp12 + tmp17;
	       c_re(at(inout,2 * iostride)) = tmp7 - tmp18;
	       c_re(at(inout,0)) = tmp7 + tmp18;
	       tmp27 = tmp25 - tmp24;
	       tmp28 = tmp12 - tmp17;
	       c_im(at(inout,iostride)) = tmp27 - tmp28;
	       c_im(at(inout,3 * iostride)) = tmp28 + tmp27;
	  }
	  {
	       fftw_real tmp23;
	       fftw_real tmp26;
	       fftw_real tmp19;
	       fftw_real tmp22;
	       
	       tmp23 = tmp20 + tmp21;
	       tmp26 = tmp24 + tmp25;
	       c_im(at(inout,0)) = tmp23 + tmp26;
	       c_im(at(inout,2 * iostride)) = tmp26 - tmp23;
	       tmp19 = tmp1 - tmp6;
	       tmp22 = tmp20 - tmp21;
	       c_re(at(inout,3 * iostride)) = tmp19 - tmp22;
	       c_re(at(inout,iostride)) = tmp19 + tmp22;
	  }
     }
}

