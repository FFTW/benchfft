/* The following definitions can be changed to tweak your    */
/* code.  But they probably won't help a whole lot.  You     */
/* can calculate their values by running meminit.            */

#define CODESIZE              2
#define Ramsize               33554432
#define CacheL1size           8192
#define CacheL2size           262144
#define Cacheburst            32
#define Memorytreshold        16384
#define Maxblocksize          4194304
#define Cachetreshold         32768
#define Cacheburstblocksize   4
#define Cacheblocksize        32
#define Blocksize             16384
