#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define FILEBUFFSIZE  1048576L        /* Number of float i/o at once */
                                      /* Test with testfilebuff      */

FILE *chkfopen (char *path, char *mode);
void chkfread (void *data, size_t type, size_t number, FILE *stream);
void chkfwrite (void *data, size_t type, size_t number, FILE *stream);
int chkfseek (FILE *stream, long offset, int whence);
int chkfstat (int filedes, struct stat *buf);
