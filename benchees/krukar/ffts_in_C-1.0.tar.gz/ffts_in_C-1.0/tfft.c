#include <stdio.h>
#define LENGTH 1024
#define NTRIALS 1

main()
{
	int i,j;
	float time,total,second(),signex,scale;
	float x[2*LENGTH], arr[2*LENGTH];
	int nrlpts,nhcpts,lwrk,ierr;
	int isign,logn;
	float work[4*LENGTH],table[LENGTH];

	for(i=0;i<LENGTH;i++) arr[i] = i;
	memcpy(x,arr,LENGTH*sizeof(float));

	nrlpts = LENGTH;
	nhcpts = LENGTH/2+1;
	lwrk = 4*LENGTH;
	scale = 1.0/LENGTH;

	isign = 0;
	logn = 10;
	/* cfftx_(&isign, &logn, table, x, work); */
	time = second();
	for(i=0;i<NTRIALS;i++){
		isign = 1;
		/* cfftx_(&isign, &logn, table, x, work); */
		isign = (-1);
		/* cfftx_(&isign, &logn, table, x, work); */
		rfft(x, LENGTH);
		rfft(x, LENGTH);
		rifft(x, LENGTH);
	        /* signex = 1.0;					  */
                /* fftrc_(x,&nrlpts,&signex,arr,&nhcpts,work,&lwrk,&ierr);*/
		/* for(j=0;j<=LENGTH;j++) arr[j]=arr[j]*scale;		  */
		/* signex = (-1.0);					  */
		/* fftcr_(arr,&nhcpts,&signex,x,&nrlpts,work,&lwrk,&ierr);*/
	}
	time = second()-time;
	printf("%d fft pairs required %f seconds\n",NTRIALS,time);
	for(i=0;i<LENGTH;i++) arr[i] = i;
	for(i=0;i<LENGTH/2;i++)
	    printf("%f  %f\t\t%f  %f\n",arr[2*i],arr[2*i+1],x[2*i],x[2*i+1]);
}
