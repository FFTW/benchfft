/*
 * include/mp/mpreal.h
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2001
 *
 */
#ifndef ARPREC_MPREAL_H
#define ARPREC_MPREAL_H

#define ARPREC_DEBUG 0
/* #define NAN 0.0 */

#include "mp.h"
#include "mp_real_temp.h"
#include "c_mp.h"

/*
 *  This class represents MP real numbers.
 */
class mp_real: public mp
{
public:
  // double mpr[mp5];
  double *mpr;
  bool    alloc;

protected:

  //high precision helper functions.
  static void mplconv(int iq, int n, int nsq, double *a, 
		      double *b, double *c);
  static void mpfftrc(int is, int m, int n, int nsq, double *x, double *y);
  static void mpfft1(int is, int m, int m1, int m2, 
		     double *x, double *y);
  static void mpfft1_radix_two(int is, int m, int n1, int n2, 
		     double *x, double *y);
  static void mpfft3(int is, int l, int ns, int m, int n, 
			    double *x, double *y);
  static void mpfft3_radix2(int is, int l, int ns, int m, int n, 
			    double *x, double *y);
  static void mpfft2(int is, int ns, int m, int n, double *x, double *y,
		     double* &out);
  static void mpfftcr(int is, int m, int n, int nsq, 
		      double *x, double *y);
  static void mpoutx_help(const mp_real& a, char *b, int n);


public:
  //This is included for users who access the underlying data structure.
  //it should not be used in the library.
  double *mpr_location() const {return mpr;}

  //basic procedures
  inline static void zero(mp_real &a) { a.mpr[1] = a.mpr[2] = 0.; }
  static void mpadd(const mp_real &a, const mp_real &b, mp_real& c);
  static void mpeq(const mp_real& a, mp_real& b);
  static void mpdiv(const mp_real& a, const mp_real& b, mp_real& c);
  static void mpdivd(const mp_real& a, double b, int n, mp_real& c);
  static void mpmul(const mp_real& a, const mp_real&b, mp_real& c);
  static void mpmuld(const mp_real& a, double b, int n, mp_real& c);
  static void mpmulacc(const mp_real &a, const mp_real &b, mp_real &c);
  static void mpnorm(double d[], mp_real &a);
  static void mpnpwr(const mp_real& a, int n, mp_real& b);
  static void mpdexc(const char a[], int l, mp_real& b);
  static void mpinpc(const char a[], int n, mp_real& b);
  static void mpinpcExit();
  static void mpout(const mp_real& a, int la, char* cs, int& l);
  static void mpoutc(const mp_real& a, char* b, int& n);
  static void mproun(mp_real &a);
  static void mpsub(const mp_real &a, const mp_real &b, mp_real& c);
  static int mpcpr(const mp_real& a, const mp_real& b);
  static void mpexp(const mp_real& a, const mp_real& al2, mp_real& b);
  static void mplog(const mp_real& a, const mp_real& al2, mp_real& b, int nit = 3);
  static void mpnint(const mp_real& a, mp_real &b);
  static void mpcssh(const mp_real& a, const mp_real& al2, mp_real& x,
		     mp_real& y);
  static void mpcssn(const mp_real& a, const mp_real& pi, mp_real &x,
		     mp_real &y);
  static void mppi(mp_real& pi);
  static void mpang(const mp_real& x, const mp_real& y, 
		      const mp_real& pi, mp_real& a);
  static void mpsqrt(const mp_real& a, mp_real& b);

  // high precision routines
  static void mppix(mp_real& pi);
  static void mpmulx(const mp_real& a, const mp_real& b, mp_real& c);
  static void mpdivx(const mp_real& a, const mp_real& b, mp_real& c);
  static void mpsqx(const mp_real& a, mp_real& b);
  static void mpsqrtx(const mp_real& a, mp_real& b);
  static void mpexpx(const mp_real& a, const mp_real& pi, 
		     const mp_real& al2, mp_real& b);
  static void mplogx(const mp_real& a, const mp_real& pi, const mp_real& al2, 
		     mp_real& b);
  static void mpagmx(mp_real &a, mp_real& b);
  static void mpnpwx(const mp_real& a, int n, mp_real& b);
  static void mpcshx(const mp_real& a, const mp_real& pi, 
		     const mp_real& al2, mp_real& x, mp_real& y);
  static void mpinix(int n); 
  static void mpoutx(const mp_real& a, int la, char *b, int& n);


public:
  //basic procedures that users should have access to. 
  static void mprand(mp_real& a);
  static void mpinfr(const mp_real& a, mp_real& b, mp_real& c, 
		     int want_fraction=1);
  static void mpdmc(double a, int n, mp_real& b);
  static void mpmdc(const mp_real& a, double& d, int& n);
  static void mpsort(int n, mp_real *a, int *ip);
  static void mpangx(const mp_real& x, const mp_real& y, 
		     const mp_real& pi, mp_real& a);
  static void mpcssx(const mp_real& a, const mp_real& pi,
		     mp_real& x, mp_real& y);
  static void mpnrt(const mp_real& a, int n, mp_real& b);
  static void mpnrtx(const mp_real& a, int n, mp_real& b);
  static void mpdotd(int n, int isa, const mp_real a[],
                     int isb, const double db[], mp_real& c);

  //low-level input/output. These should be user accessible
  static void read_mp_real(istream& in, mp_real& a);
  static void write_mp_real(ostream& out, const mp_real& a);
  //base 10 human readable output.
  friend ostream& operator<<(ostream& s, const mp_real& ja);
  friend istream& operator>>(istream& s, mp_real& ja);

  //Conversion to double. This is intentionally not an operator.
  friend inline double dble(const mp_real& a);

#ifdef ARPREC_HAS_QD
  //Conversion to dd_real (double-double class)
  friend dd_real to_dd_real(mp_real &a);  
#endif

  //arithmetic operators
  friend inline mp_real_temp operator-(const mp_real &a, const mp_real &b);
  friend inline mp_real_temp operator+(const mp_real &a, const mp_real &b);
  friend inline mp_real_temp operator*(const mp_real &a, const mp_real &b);
  friend inline mp_real_temp operator*(const mp_real &a, const double b);
  friend inline mp_real_temp operator*(const double b, const mp_real& a);
  friend inline mp_real_temp operator/(const mp_real &a, const mp_real &b);
  friend inline mp_real_temp operator/(const mp_real &a, const double b);
  friend inline mp_real_temp operator/(const double b, const mp_real &a);

  friend inline bool operator>(const mp_real& a, const mp_real& b);
  friend inline bool operator>=(const mp_real& a, const mp_real& b);
  friend inline bool operator<(const mp_real& a, const mp_real& b);
  friend inline bool operator<=(const mp_real& a, const mp_real& b);
  friend inline bool operator==(const mp_real& a, const mp_real& b);
  friend inline bool operator!=(const mp_real& a, const mp_real& b);

  friend inline bool operator>(double a, const mp_real& b);
  friend inline bool operator>=(double a, const mp_real& b);
  friend inline bool operator<(double a, const mp_real& b);
  friend inline bool operator<=(double a, const mp_real& b);
  friend inline bool operator==(double a, const mp_real& b);
  friend inline bool operator!=(double a, const mp_real& b);

  friend inline bool operator>(const mp_real& a, double b);
  friend inline bool operator>=(const mp_real& a, double b);
  friend inline bool operator<(const mp_real& a, double b);
  friend inline bool operator<=(const mp_real& a, double b);
  friend inline bool operator==(const mp_real& a, double b);
  friend inline bool operator!=(const mp_real& a, double b);

  friend inline mp_real_temp power(const mp_real& a, int n);
  friend inline mp_real_temp power(const mp_real& a, const mp_real& b);
  friend inline mp_real_temp power(const mp_real& a, double b);
  friend inline mp_real_temp abs(const mp_real& a);
  friend inline mp_real_temp sqrt(const mp_real& a);
  friend inline mp_real_temp aint(const mp_real& a);
  friend inline mp_real_temp anint(const mp_real& a);
  friend inline mp_real_temp exp(const mp_real& a);
  friend inline mp_real_temp log(const mp_real& a);
  friend inline mp_real_temp log10(const mp_real& a);
  friend inline mp_real_temp sin(const mp_real& a);
  friend inline mp_real_temp cos(const mp_real& a);
  friend inline mp_real_temp tan(const mp_real& a);
  friend inline mp_real_temp sinh(const mp_real& a);
  friend inline mp_real_temp cosh(const mp_real& a);
  friend inline mp_real_temp tanh(const mp_real& a);
  friend inline mp_real_temp atan(const mp_real& a);
  friend inline mp_real_temp atan2(const mp_real& y, const mp_real& x);
  friend inline mp_real_temp asin(const mp_real& a);
  friend inline mp_real_temp acos(const mp_real& a);
  friend inline mp_real_temp sqr(const mp_real& a);/*square of a*/
  friend inline mp_real_temp fmod(const mp_real& a, const mp_real& b);
  friend inline mp_real_temp mp_rand();
  //simultaneous cosine, sine.
  friend inline void mpcsshf(const mp_real& a, mp_real& cosh, mp_real& sinh);
  friend inline void mpcssnf(const mp_real& a, mp_real& cosine, mp_real& sine);
  friend class mp;
  friend class mp_complex;

  // A hack for mpdotd.
  friend void c_mpdotd(int &n, int &isa, double *a, int &isb,
		       const double *db, double *c);

  // Subscript operator. For non-const objects.
  // @return reference to the mantissa element.
  inline double& operator[](int index) { return mpr[index]; }

  // Subscript operator. For const objects.
  // @return the mantissa element.
  inline double operator[](int index) const { return mpr[index]; }

  // Assignment operator.
  inline mp_real& operator=(const int&);
  inline mp_real& operator=(const double&);
  inline mp_real& operator=(const mp_real&);
  inline mp_real& operator=(const mp_real_temp&);
  inline mp_real& operator=(const char*);
  inline mp_real& operator+=(const mp_real&);
  inline mp_real& operator-=(const mp_real&); 
  inline mp_real& operator*=(const mp_real&);
  inline mp_real& operator*=(double);
  inline mp_real& operator/=(const mp_real&);
  inline mp_real& operator/=(double);
  // negation operator.
  inline mp_real_temp operator-() const;

//  inline operator double() const;
#if 0
  mp_real& operator=(const mp_complex&);
  mp_real& operator=(const mp_int&);
#endif  

  // destructor
  ~mp_real() { if(mpr && alloc) delete [] mpr; }

  // constructor
  mp_real() {
    // defaults to mp_real of array size mp5
    if (mpnw == 0) {
      alloc = false;
      mpr = NULL;
    } else {
      alloc = true;
      mpr = new double[mpnw+5];
#if (ARPREC_DEBUG)
      for (int i = 0; i < mpnw+5; i++)
        mpr[i] = NAN;
#endif
      mpr[0] = mpnw+5;
      mpr[1] = mpnw;
    }
  }

  mp_real(size_t s) {
    alloc = true;
    mpr = new double[s];
#if (ARPREC_DEBUG)
      for (int i = 0; i < s; i++)
        mpr[i] = NAN;
#endif
    mpr[0] = s; 
    mpr[1] = mpnw;
  }

  mp_real(int s) {
    if(s > 0) {
      alloc = true;
      mpr = new double[s];
#if (ARPREC_DEBUG)
      for (int i = 0; i < s; i++)
        mpr[i] = NAN;
#endif
      mpr[0] = s;
      mpr[1] = mpnw;
    } else {
      mpr = 0;
      alloc = false;
    }
  }

  mp_real(const mp_real& other) {
    /*
    int nw = (int) other.mpr[0];
    int nm = (int) other.mpr[1];
    if (nm < 0)
      nm = -nm;
    nm += 3;
    */

    int s = int(other.mpr[0]);
    alloc = true;
    mpr = new double[s];
#if (ARPREC_DEBUG)
      for (int i = 0; i < s; i++)
        mpr[i] = NAN;
#endif
    memcpy(mpr, other.mpr, sizeof(double) * s);
    /*
    for(int i=0;i<s;i++)
      mpr[i] = other.mpr[i];
    */
  }

  /* Allocates an array of n mp_reals.  The raw data array will be
     in a contiguous block, making it easier for block transfer operations.
     The array created must be freed using free_array(mp_real *).
   */
  static mp_real *alloc_array(int n) {
    int old_mpnw = mpnw;
    mpnw = 0;
    
    mp_real *m = new mp_real[n];
    int sz = old_mpnw + 5;
    double *raw_data = new double[n * sz];
#if (ARPREC_DEBUG)
      for (int i = 0; i < n*sz; i++)
        raw_data[i] = NAN;
#endif
    double *p = raw_data;

    for (int i = 0; i < n; i++, p += sz) {
      p[0] = (double) sz;
      p[1] = old_mpnw;
      m[i].setData(p);
    }

    mpnw = old_mpnw;
    return m;
  }

  static void free_array(mp_real *m) {
    double *raw_data = m[0].getData();
    delete [] m;
    delete [] raw_data;
  }

  void setData(double *data) {
    mpr = data;
  }

  double *getData() {
    return mpr;
  }

  mp_real(double dp, int n=0, size_t s = mp5) {
    // makes mp_real from double (and possibly exponent)
    alloc = true;
    mpr = new double[s];
#if (ARPREC_DEBUG)
      for (int i = 0; i < s; i++)
        mpr[i] = NAN;
#endif
    mpr[0] = s;
    mpdmc(dp, n, *this);
  }
  mp_real(const mp_real_temp& other) {
    alloc = true;
    mpr = other.mpr;
  }
  mp_real(const double *dp) {
    alloc = false;
    mpr = (double *)dp;
  }
  mp_real(double *dp) {
    alloc = false;
    mpr = dp;
  }
  mp_real(const char *a, size_t s = (mpnw + 5)) {
    alloc = true;
    mpr = new double[s];
    mpr[0] = s; 
    char *az = new char[strlen(a)+1];
    strcpy(az, a);
    mpdexc(az, strlen(az), *this);
    delete [] az;
  }

  /*
  inline static void swap(mp_real &x, mp_real &y) {
    double t;
    int n1 = (int) x.mpr[0];
    int n2 = (int) y.mpr[0];
    int n = MIN(n1, n2);

    for (int i = 0; i < n; i++) {
      t = y.mpr[i];
      y.mpr[i] = x.mpr[i];
      x.mpr[i] = t;
    }
  }
  */

  mp_real_temp toTempAndDestroy() { 
    mp_real_temp ret(this->mpr); mpr = 0; return ret;
  }

  // Helper function for debugging.
  static void print_mpreal(char* functionName, const mp_real& mpr);

  //friend modifier neccessary so these can use protected constants
  friend double mp_two_prod_positive(double a, double b, double &err);
  friend double mp_two_prod(double a, double b, double &err);

};

ostream& operator<<(ostream& s, const mp_real& ja);

#if (ARPREC_INLINE)
#include "mp_inline.h"
#else
double quick_two_sum(double a, double b, double &err);
double quick_two_diff(double a, double b, double &err);
double two_sum(double a, double b, double &err);
double two_diff(double a, double b, double &err);
void split(double a, double &hi, double &lo);
double two_sqr(double a, double &err);
double nint(double d);
double SLOPPY_ANINT_POSITIVE(double a); 
double FLOOR_POSITIVE(double a);
double CEIL_POSITIVE(double a);
double AINT(double a);
double POSITIVE_AINT(double a);
double ANINT(double a); 
double SLOPPY_ANINT(double a);
double aint(double a);
double anint(double a);
void sincosh(double t, double &sinh_t, double &cosh_t);
double sqr(double t);
void dd_add_d(double a[], double b, double c[]);
void dd_add_dd(double a[], double b[], double c[]);
double mp_two_prod(double a, double b, double &err);
double mp_two_prod_positive(double a, double b, double &err);

mp_real_temp operator+(const mp_real &a, const mp_real &b);
mp_real_temp operator-(const mp_real &a, const mp_real &b);
mp_real_temp operator*(const mp_real &a, const mp_real &b);
mp_real_temp operator*(const mp_real &a, const double b);
mp_real_temp operator*(const double b, const mp_real &a);
mp_real_temp operator/(const mp_real &a, const mp_real &b);
mp_real_temp operator/(const mp_real &a, const double b);
mp_real_temp operator/(const double b, const mp_real &a);
bool operator>(const mp_real& a, const mp_real& b);
bool operator>=(const mp_real& a, const mp_real& b);
bool operator<(const mp_real& a, const mp_real& b);
bool operator<=(const mp_real& a, const mp_real& b);
bool operator==(const mp_real& a, const mp_real& b);
bool operator!=(const mp_real& a, const mp_real& b);
mp_real_temp abs(const mp_real& a);
mp_real_temp acos(const mp_real& a);
mp_real_temp aint(const mp_real& a);
mp_real_temp anint(const mp_real& a);
mp_real_temp asin(const mp_real& a);
mp_real_temp atan(const mp_real& a);
mp_real_temp atan2(const mp_real& y, const mp_real& x);
mp_real_temp cos(const mp_real& a);
mp_real_temp cosh(const mp_real& a);
double dble(const mp_real& a);
mp_real_temp exp(const mp_real& a);
mp_real_temp fmod(const mp_real& a, const mp_real &b);
mp_real_temp log(const mp_real& a);
mp_real_temp log10(const mp_real& a);
mp_real_temp mp_rand();
void mpcsshf(const mp_real& a, mp_real& b, mp_real& c);
void mpcssnf(const mp_real& a, mp_real& b, mp_real& c);
mp_real_temp power(const mp_real& a, int n);
mp_real_temp power(const mp_real& a, const mp_real& b);
mp_real_temp power(const mp_real& a, double b);
mp_real_temp sin(const mp_real& a);
mp_real_temp sinh(const mp_real& a);
mp_real_temp sqrt(const mp_real& a);
mp_real_temp sqr(const mp_real& a);
mp_real_temp tan(const mp_real& a);
mp_real_temp tanh(const mp_real& a);
mp_real_temp operator+(const mp_real &a, int b);
mp_real_temp operator+(int b, const mp_real &a);
mp_real operator+=(mp_real &a, int b);
mp_real_temp operator-(int b, const mp_real &a);
mp_real_temp operator-(const mp_real &a, int b);
mp_real operator-=(mp_real &a, int b);
mp_real_temp operator*(const mp_real &a, int b);
mp_real operator*=(mp_real &a, int b);
mp_real_temp operator*(int b, const mp_real &a);
mp_real_temp operator/(const mp_real &a, int b);
mp_real operator/=(mp_real &a, int b);
mp_real_temp operator/(int b, const mp_real &a);
bool operator>(int b, const mp_real &a);
bool operator>(const mp_real &a, int b);
bool operator<(int b, const mp_real &a);
bool operator<(const mp_real &a, int b);
bool operator<=(int b, const mp_real &a);
bool operator<=(const mp_real &a, int b);
bool operator>=(int b, const mp_real &a);
bool operator>=(const mp_real &a, int b);
bool operator==(int b, const mp_real &a);
bool operator==(const mp_real &a, int b);
bool operator!=(int b, const mp_real &a);
bool operator!=(const mp_real &a, int b);
mp_real_temp operator+(const mp_real &a, double b);
mp_real_temp operator+(double b, const mp_real &a);
mp_real operator+=(mp_real &a, double b);
mp_real_temp operator-(double b, const mp_real &a);
mp_real_temp operator-(const mp_real &a, double b);
mp_real operator-=(mp_real &a, double b);
bool operator>(double b, const mp_real &a);
bool operator>(const mp_real &a, double b);
bool operator<(double b, const mp_real &a);
bool operator<(const mp_real &a, double b);
bool operator<=(double b, const mp_real &a);
bool operator<=(const mp_real &a, double b);
bool operator>=(double b, const mp_real &a);
bool operator>=(const mp_real &a, double b);
bool operator==(double b, const mp_real &a);
bool operator==(const mp_real &a, double b);
bool operator!=(double b, const mp_real &a);
bool operator!=(const mp_real &a, double b);
#endif

#endif
/* ARPREC_MPREAL_H */
