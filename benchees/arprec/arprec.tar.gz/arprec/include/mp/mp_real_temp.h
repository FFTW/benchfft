/*
 * include/mp/mp_real_temp.h
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2001
 *
 */
#ifndef __MPREAL_TEMP_H
#define __MPREAL_TEMP_H


class mp_real_temp
{
 protected:
 public:
  double *mpr;
  mp_real_temp(size_t s = mp::mp5) {
    mpr = new double[s];
    mpr[0] = s;
  }
  mp_real_temp(double *dp) { mpr = dp; }
  mp_real_temp(const double *dp) { mpr = (double *)dp; }
  mp_real_temp(const mp_real_temp& other) { mpr = other.mpr; } 
  // intentionally no deconstructor -- might use reference counting later.

  //inline operator double() const;
};

#endif
