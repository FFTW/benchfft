/*
 * include/mp/mp_complex_inline.h
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2001
 *
 */
#ifndef MP_COMPLEX_INLINE_H
#define MP_COMPLEX_INLINE_H


inline mp_complex_temp operator+(const mp_complex &a, 
				 const mp_complex &b)
{
  return mp_complex_temp(a.real+b.real, a.imag+b.imag);
}

inline  mp_complex_temp operator+(const mp_complex &a, const mp_real &breal)
{
  mp_real temp(a.imag);
  return mp_complex_temp(a.real+breal, temp.toTempAndDestroy());
}

inline  mp_complex_temp operator+(const mp_real &breal, const mp_complex &a)
{
  mp_real temp(a.imag);
  return mp_complex_temp(a.real+breal, temp.toTempAndDestroy());
}

inline mp_complex_temp operator-(const mp_complex &a, 
				 const mp_complex &b)
{
  return mp_complex_temp(a.real-b.real, a.imag-b.imag);
}

inline  mp_complex_temp operator-(const mp_complex &a, 
				   const mp_real &breal)
{
  mp_real temp(a.imag);
  return mp_complex_temp(a.real - breal, temp.toTempAndDestroy());
}

inline  mp_complex_temp operator-(const mp_real &breal, 
				   const mp_complex &a)
{
  mp_real temp(a.imag);
  // bug fix -- XSL
  temp[1] = -temp[1];
  return mp_complex_temp(breal - a.real, temp.toTempAndDestroy());
}

inline mp_complex_temp operator*(const mp_complex &a, 
				 const mp_complex &b)
{
  mp_complex c;
  mp_complex::mpcmulx(a, b, c);
  return c.toTempAndDestroy();
}

inline mp_complex_temp operator/(const mp_complex &a, 
				 const mp_complex &b)
{
  mp_complex c;
  mp_complex::mpcdivx(a, b, c);
  return c.toTempAndDestroy();
}

inline mp_complex_temp operator/(const mp_complex &a, 
				 const mp_real &b)
{
  mp_complex c;
  mp_real::mpdivx(a.real, b, c.real);
  mp_real::mpdivx(a.imag, b, c.imag);
  return c.toTempAndDestroy();
}

inline mp_complex_temp operator/(const mp_complex &a, 
				 double b)
{
  mp_complex c;
  mp_real::mpdivd(a.real, b, 0, c.real);
  mp_real::mpdivd(a.imag, b, 0, c.imag);
  return c.toTempAndDestroy();
}

inline mp_complex_temp operator/(const mp_real &a, 
				 const mp_complex &b)
{
  mp_real c;
  c = sqr(b.real) + sqr(b.imag);
  c = a/c;
  mp_real_temp ret_imag(b.imag * c);
  ret_imag.mpr[1] = -ret_imag.mpr[1]; //conjugate result.
  return mp_complex_temp(b.real*c,ret_imag); 
}

inline mp_complex_temp operator/(double b, 
				 const mp_complex& a)
{
  return mp_real(b) / a;
}

inline mp_complex_temp operator/(int b, 
				 const mp_complex& a)
{
  return mp_real((double)b) / a;
}

inline mp_complex_temp operator*(const mp_complex& a, double b)
{
  mp_complex ret;
  mp_complex::mpcmuld(a, b, 0, ret);
  return ret.toTempAndDestroy();
}

inline mp_complex_temp operator*(double b, const mp_complex& a)
{
  return a * b;
}

inline mp_complex_temp operator*(const mp_complex& a, const mp_real& b)
{
  mp_complex c;
  mp_real::mpmulx(a.real, b, c.real);
  mp_real::mpmulx(a.imag, b, c.imag);
  return c.toTempAndDestroy();
}

inline mp_complex_temp operator*(const mp_real& b, const mp_complex& a) {
  return a * b;
}


inline mp_complex_temp exp(const mp_complex& a) {
  mp_real b;
  mp_complex c;
  mp_real::mpexpx(a.real, mp_real::mppic, mp_real::mpl02, b);
  mp_real::mpcssx(a.imag, mp_real::mppic, c.real, c.imag);
  mp_real::mpmulx(b, c.real, c.real);
  mp_real::mpmulx(b, c.imag, c.imag);
  return c.toTempAndDestroy();
}

inline mp_complex_temp log(const mp_complex& a) {
  mp_real b, c;
  mp_complex ret;
  mp_real::mpsqx(a.real, b);
  mp_real::mpsqx(a.imag, c);
  mp_real::mpadd(b, c, c);
  mp_real::mplogx(c, mp_real::mppic, mp_real::mpl02, b);
  mp_real::mpmuld(b, 0.5, 0, ret.real);
  mp_real::mpangx(a.real, a.imag, mp_real::mppic, ret.imag);
  return ret.toTempAndDestroy();
}

inline mp_complex_temp sin(const mp_complex &a) {
  mp_real mpt1, mpt2, mpt3, mpt4, mpt5, mpt6;
  mp_complex c;
  mp_real::mpeq(a.imag, mpt2);
  mpt2[1] = - mpt2[1];
  mp_real::mpexpx(mpt2,  mp_real::mppic, mp_real::mpl02, mpt1);
  mpt3[1] = 1.0; mpt3[2] = 0.0; mpt3[3] = 1.0; mpt3[4] = 0.0;
  mp_real::mpdivx(mpt3, mpt1, mpt2);
  mp_real::mpcssx(a.real, mp_real::mppic, mpt3, mpt4);
  mp_real::mpadd(mpt1, mpt2, mpt5);
  mp_real::mpmuld(mpt5, 0.5, 0, mpt6);
  mp_real::mpmulx(mpt6, mpt4, c.real);
  mp_real::mpsub(mpt1, mpt2, mpt5);
  mp_real::mpmuld(mpt5, -0.5, 0, mpt6);
  mp_real::mpmulx(mpt6, mpt3, c.imag);
  return c.toTempAndDestroy();
}

#if 0  // bug -- XSL
inline mp_complex_temp cos(const mp_complex &a) {
  mp_real mpt1, mpt2, mpt3, mpt4, mpt5, mpt6;
  mp_complex c;
  mp_real::mpeq(a.imag, mpt2);
  mpt2[1] = -mpt2[1];
  mp_real::mpexpx(mpt2, mp_real::mppic, mp_real::mpl02, mpt1);
  mpt3[1] = 1.0; mpt3[2] = 0.0; mpt3[3] = 1.0; mpt3[4] = 0.0;
  mp_real::mpcssx(a.real, mp_real::mppic, mpt3, mpt4);
  mp_real::mpadd(mpt1, mpt2, mpt5);
  mp_real::mpmuld(mpt5, 0.5, 0, mpt6);
  mp_real::mpmulx(mpt6, mpt4, c.real);
  mp_real::mpsub(mpt1, mpt2, mpt5);
  mp_real::mpmuld(mpt5, 0.5, 0, mpt6);
  mp_real::mpmulx(mpt6, mpt4, c.imag);
  return c.toTempAndDestroy();
}
#else
inline mp_complex_temp cos(const mp_complex &a) {
  mp_real mpt1, mpt2, mpt3, mpt4, mpt5, mpt6;
  mp_complex c;
  mp_real::mpeq(a.imag, mpt2);
  mpt2[1] = -mpt2[1];
  mp_real::mpexpx(mpt2, mp_real::mppic, mp_real::mpl02, mpt1);
  mpt3[1] = 1.0; mpt3[2] = 0.0; mpt3[3] = 1.0; mpt3[4] = 0.0;
  mp_real::mpdivx(mpt3, mpt1, mpt2);
  mp_real::mpcssx(a.real, mp_real::mppic, mpt3, mpt4);
  mp_real::mpadd(mpt1, mpt2, mpt5);
  mp_real::mpmuld(mpt5, 0.5, 0, mpt6);
  mp_real::mpmulx(mpt6, mpt3, c.real);
  mp_real::mpsub(mpt1, mpt2, mpt5);
  mp_real::mpmuld(mpt5, 0.5, 0, mpt6);
  mp_real::mpmulx(mpt6, mpt4, c.imag);
  return c.toTempAndDestroy();
}
#endif

inline mp_complex &mp_complex::operator+=(const mp_complex &other) 
{
  mp_real::mpadd(this->real, other.real, this->real);
  mp_real::mpadd(this->imag, other.imag, this->imag);
  return *this;
}

inline mp_complex &mp_complex::operator-=(const mp_complex &other) 
{
  mp_real::mpsub(this->real, other.real, this->real);
  mp_real::mpsub(this->imag, other.imag, this->imag);
  return *this;
}

inline mp_complex &mp_complex::operator*=(const mp_complex &other) 
{
  mp_complex temp;
  mpcmulx(*this, other, temp);
  mpceq(temp, *this);
  return *this;
}

inline mp_complex &mp_complex::operator/=(const mp_complex &other) 
{
  mp_complex temp;
  mpcdivx(*this, other, temp);
  mpceq(temp, *this);
  return *this;
}

inline mp_complex &mp_complex::operator+=(const mp_real &other) 
{
  mp_real::mpadd(this->real, other, this->real);
  return *this;
}

inline mp_complex &mp_complex::operator-=(const mp_real &other) 
{
  mp_real::mpsub(this->real, other, this->real);
  return *this;
}

inline mp_complex &mp_complex::operator*=(const mp_real &other) 
{
  mp_real::mpmulx(this->real, other, this->real);
  mp_real::mpmulx(this->imag, other, this->imag);
  return *this;
}

inline mp_complex &mp_complex::operator/=(const mp_real &other) 
{
  mp_real::mpdivx(this->real, other, this->real);
  mp_real::mpdivx(this->imag, other, this->imag);
  return *this;
}

inline bool operator==(const mp_complex &a, const mp_complex &b)
{
  return (a.real == b.real) && (a.imag == b.imag);
}

inline bool operator!=(const mp_complex &a, const mp_complex &b)
{
  return (a.real != b.real) || (a.imag != b.imag);
}

inline mp_complex_temp sqr(const mp_complex &a)
{
  mp_complex c;
  mp_complex::mpcsqx(a, c);
  return c.toTempAndDestroy();
}

inline mp_complex_temp sqrt(const mp_complex &a)
{
  mp_complex c;
  mp_complex::mpcsqrtx(a, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp abs(const mp_complex &a)
{
  return sqrt(sqr(a.real) + sqr(a.imag));
}

inline mp_real_temp arg(const mp_complex &a)
{
  //y first argument
  return atan2(a.imag, a.real);
}

inline mp_complex &mp_complex::operator=(const mp_complex &other)
{
  this->real = other.real;
  this->imag = other.imag;
  return *this;
}

inline mp_complex &mp_complex::operator=(const mp_real &other)
{
  this->real = other;
  mp_real::zero(this->imag);
  return *this;
}

inline mp_complex &mp_complex::operator=(mp_complex_temp &other)
{
  this->real = other.real;
  this->imag = other.imag;
  return *this;
}


inline mp_complex &mp_complex::operator/=(double other) 
{
  return *this = *this / other;
}


inline mp_complex &mp_complex::operator/=(int other) 
{
  return *this = *this / other;
}


inline mp_complex_temp power(const mp_complex& a, int n)
{
  mp_complex c;
  mp_complex::mpcpwx(a, n, c);
  return c.toTempAndDestroy();
}

inline mp_complex_temp power(const mp_complex& a, const mp_real& b)
{
  mp_complex c;
  c = log(a);
  c *= b;
  c = exp(c);
  return c.toTempAndDestroy();
}

inline mp_complex_temp power(const mp_complex& a, const mp_complex& b)
{
  mp_complex c;
  c = log(a);
  c *= b;
  c = exp(c);
  return c.toTempAndDestroy();
}



#endif /* MP_COMPLEX_INLINE_H */
