/*
 * include/mp/mp_inline.h
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2001
 *
 */
#ifndef __MP_INLINE_H
#define __MP_INLINE_H

#include "mp.h"

#include "mp_small_inline.h"

inline void mp_real::mproun(mp_real &a) {
  // This performs rounding and truncation of the MP number A.  It is called
  // by MPNORM, and also by other subroutines when the precision level is
  // reduced by one.  It is not intended to be directly called by the user.
  //
  // Maximum space of A used:  MPNW + 5 cells.
  //
  // The parameter AMX is the absolute value of the largest exponent word
  // allowed for MP numbers.
  // const double amx = 33554432.0;//=pow(2.0, 25); // float: 2.e6
  const double amx = 2.1475e9; //=pow(2.0, 31);
  int i, ia, k, na, n4, AllZero, LoopBreak;
  double a2;

  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(a);
    return;
  }

  // Check for initial zeroes.
  //cerr << "0" << endl;
  a2 = a[2]; // exponent
  a[2] = 0.0;
  ia = a[1] >= 0 ? 1 : -1; // sign (1., a(1))
  na = MIN (int (ABS (a[1])), mpnw);
  na = MIN (na, int(a[0])-5);
  n4 = na + 4; //index of last addressable word.
  //cerr << "1" << endl;
     
  if (a[FST_M] == 0.) {
    // Find the first nonzero word and shift the entire number left.
    // The length of the result is reduced by the length of the shift.

    AllZero = 1;
    for (i = 4; i <= n4; ++i) {
      if (a[i] != 0.0) {
        AllZero = 0;
        break;
      }
    }
       
    if ( AllZero ) {
      zero(a);
      return;
    }

    k = i - FST_M; // number of leading zeros

    // !dir$ ivdep
    for (i = FST_M; i <= n4 - k; ++i)
      a[i] = a[i+k];

    a2 = a2 - k;
    na -= MAX (k - 2, 0);
    if (k == 2) a[na + FST_M] = 0.0; // BUG FIX
  }
  //cerr << "2" << endl;

  // Perform rounding depending on MPIRD.

  if (na == mpnw && MPIRD >= 1) {
    //printf("G = %g\n", a[na+3]);
    //cerr << "na+3 = " << na+3 << endl;
    if ( (MPIRD == 1 && a[na+3] >= 0.5 * mpbdx) || 
         (MPIRD == 2 && a[na+3] >= 1) )
      //cerr << "2.1" << endl;
      //cerr << "a = " << a[na + 3] << endl;
      a[na+2] += 1.0;

    // Zero out unused words.
    a[na+3] = a[na+4] = 0.0;

    // Release carries as far as necessary due to rounding.
    LoopBreak = 0;
    for (i = na + 2; i >= FST_M; --i) {
      if (a[i] < mpbdx) {
        LoopBreak = 1; // goto 140
        break;
      }
      a[i] -= (double) mpbdx;
      ++a[i-1];
    }

    // Release of carries due to rounding continued all the way to the start
    // -- i.e. number was entirely 9's.
    if ( !LoopBreak ) {
      a[3] = a[2];
      na = 1;
      a2++;
    }
  }
  //cerr << "3" << endl;

  // 140
  if (a[na+2] == 0.) {
    // At least the last mantissa word is zero.  Find the last nonzero word
    // and adjust the length of the result accordingly.
    AllZero = 1;
    for (i = na + 1; i >= FST_M; --i) {
      if (a[i] != 0.) {
        AllZero = 0;
        break; // goto 160
      }
    }
    if ( AllZero ) {
      zero(a);
      return;
    }

    // 160
    na = i - 2;
    a[na+4] = 0.0;
  }
  //cerr << "4" << endl;

  // Check for overflow and underflow.
  if (a2 < -amx) {
    if (MPKER[68] != 0) {
      cerr << "*** MPROUN: Exponent underflow.\n";
      MPIER = 68;
      if (MPKER[MPIER] == 2)  mpabrt();
    }
  } else if (a2 > amx) {
    if (MPKER[69] != 0) {
      cerr << "*** MPROUN: Exponent overflow.\n";
      MPIER = 69;
      if (MPKER[MPIER] == 2)  mpabrt();
    }
  }
  //cerr << "5" << endl;

  // Check for zero.

  if (a[FST_M] == 0.) {
    zero(a);
  } else {
    a[1] = ia >= 0 ? na : -na; // sign (na, ia)
    a[2] = a2;
  }
}


inline void mp_real::mpnorm(double d[], mp_real &a) {
  // This converts the MP number in array D of MPCOM4 to the standard
  // normalized form in A.  The MP routines often leave negative numbers or
  // values exceeding the radix MPBDX in result arrays, and this fixes them.
  // MPNORM assumes that two extra mantissa words are input at the end of D.
  // This reduces precision loss when it is necessary to shift the result to
  // the left.  This routine is not intended to be called directly by the user.
  // Debug output starts with MPIDB = 10.
  //
  // Max SP space for A: MPNW + 5 cells.
  // 
  // The first 3 words of D have special meanings:
  //     d[0] : not accessed
  //     d[1] : sign and number of words in D
  //     d[2] : exponent
  // Before normalization, each word of D may have up to 53 bits and may be
  // negative. After normalization, each word is in [0, 2^50-1]
  //     
  double a2, t1, t2, t3;
  int i, ia, na, nd, n4;

  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(a);
    return;
  }

  if (MPIDB >= 9) {
    mp_real t;
    t[1] = d[1]; t[2] = d[2];
    for (i = FST_M; i < ABS(t[1]) + FST_M; ++i) t[i] = d[i];
    print_mpreal((char*)"MPNORM I ", t);
  }

  ia = (int) SIGN(1.0, d[1]);
  nd = (int) ABS(d[1]);
  na = MIN(nd, mpnw);
  na = MIN(na, (int(a[0]) - 5)); // do not exceed the allocated memory
  if (na == 0) {
    zero(a);
    if (MPIDB >= 9) print_mpreal((char*)"MPNORM O ", a);
    return;
  }
  n4 = na + 4; 
        /* n4 is often mpnw+FST_M+1. The carry release loop usually starts
         *  one word after the last word necessary for the specified
         * precision mpnw. */
        // if na == int(a[0]) - 5, then n4 is the last addressable word.
  a2 = d[2];

  // Carry release loop.
  t1 = 0.0;
  for (i = n4; i >= FST_M; --i) {
    t3 = t1 + d[i];  // exact 
    t2 = t3 * mprdx;
    t1 = int (t2);   // carry <= 1
    if ( t2 < 0.0 && t1 != t2 ) // make sure d[i] will be >= 0.0
      t1 -= 1.0;
    a[i] = t3 - t1 * mpbdx;
  }
  a[2] = t1;

  if ( a[2] < 0.0 ) {
    // The leading word is negative -- negate all words and re-normalize
    ia = -ia;
    
    for (i = 2; i <= n4; ++i)
      a[i] = -a[i];
    for (i = n4; i >= FST_M; --i) {
      if ( a[i] < 0 ) {
        a[i] = (double)mpbdx + a[i]; // <= 2^50-1
        a[i-1] -= 1.0;
      }
    }
  }
  // Now either a[2]>0.0. or a[2] == 0.0.

  if ( a[2] > 0.0 ) {
    // A nonzero carry is "spilled" into a[2].  Shift the entire number
    // right one cell.  The exponent and length of the result are increased
    // by one.
    if(na != (mpnw) && na <= (int(a[0])-5)) {
      // can afford to up by one word.
      for (i = n4+1; i >= FST_M; --i) a[i] = a[i-1];
      na = MIN (na+1, mpnw);
      a2 += 1;
    } else {
      //can't up by a word.  must truncate one word. 
      for (i = n4; i >= FST_M; --i) a[i] = a[i-1];
      a2 += 1;
    }
  }

  // Perform rounding and truncation.
  a[1] = ia >= 0 ? na : -na;
  a[2] = a2;

  mproun(a);
  return;
}


inline void mp_real::mpeq(const mp_real& a, mp_real& b)
{
  // This routine sets the MP number B equal to the MP number A.  Debug output
  // starts with MPIDB = 10.
  //
  // Max DP space for B: MPNW + 3 cells.
  //
  // The fact that only MPNW + 3 cells, and not MPNW + 4 cells, are copied is
  // important in some routines that increase the precision level by one.
  
  int i, ia, na, nb;
  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if (MPIDB >= 10) cerr << "MPEQ\n";

  ia = int(SIGN(1.0, a[1]));
  na = MIN(int(ABS(a[1])), mpnw);
  nb = MIN(na, int(b[0])-FST_M-1);
  if (na == 0) {
    zero(b);
    return;
  }

  b[1] = SIGN(nb, ia);
  for (i = 2; i < nb + FST_M; ++i) b[i] = a[i];
}



inline void mp_real::mpsub(const mp_real &a, const mp_real &b, mp_real& c)
{
  // This routine subtracts MP numbers A and B to yield the MP difference C,
  // by negating B and adding.  Debug output starts with MPIDB = 9.
  //
  // Max SP space for C: MPNW + 5 cells.

  int i, BreakLoop;
  double b1;

  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(c);
    return;
  }
  
  if (MPIDB >= 9) cerr << " MPSUB\n";

  // Check if A = B.  This is necessary because A and B might be same array,
  // in which case negating B below won't work.

  // check if A == B points to the same object 
  if(&a == &b) {
    zero(c);
    if(MPIDB >= 9) print_mpreal((char*)"MPSUB O ", c);
    return;
  }
  
  // check if their exponent and mantissas are the same
  if (a[1] == b[1]) {
    BreakLoop = 0;
    for (i = 2; i < int(ABS(a[1])) + FST_M; ++i) {
      if (a[i] != b[i]) {
        BreakLoop = 1;
        break;
      }
    }
    if (!BreakLoop) {
      zero(c);
      if(MPIDB >= 9) print_mpreal((char*)"MPSUB O ", c);
      return;
    }
  }
  
  // Save the sign of B, and then negate B.
  b1 = b[1];
  double *temp; // use temp to keep const modifier
  temp = b.mpr;
  temp[1] = -b1;

  // Perform addition and restore the sign of B.
  mpadd(a, b, c);
  
  // When restoring the sign of b, we must make sure that
  // b and c were not the same object.  if they were,
  // then b was overwriten, and c already contains the correct
  // result.
  if(&b != &c)
     temp[1] = b1;

  return;
}



/* mp-real + mp-real */
inline mp_real_temp operator+(const mp_real &a, const mp_real &b)
{
  mp_real c;
  mp_real::mpadd(a, b, c);
  return c.toTempAndDestroy();
}

/* mp-real - mp-real */
inline mp_real_temp operator-(const mp_real &a, const mp_real &b)
{
  mp_real c;
  mp_real::mpsub(a, b, c);
  return c.toTempAndDestroy();
}

/* mp-real * mp-real */
inline mp_real_temp operator*(const mp_real &a, const mp_real &b)
{
  mp_real c;
  mp_real::mpmulx(a, b, c);
  return c.toTempAndDestroy();
}

/* mp-real * double */
inline mp_real_temp operator*(const mp_real &a, const double b)
{
  mp_real c;
  mp_real::mpmuld(a, b, 0, c);
  return c.toTempAndDestroy();
}

/* double * mp-real */
inline mp_real_temp operator*(const double b, const mp_real &a)
{
  mp_real c;
  mp_real::mpmuld(a, b, 0, c);
  return c.toTempAndDestroy();
}


/* mp-real / mp-real */
inline mp_real_temp operator/(const mp_real &a, const mp_real &b)
{
  mp_real c;
  mp_real::mpdivx(a, b, c);
  return c.toTempAndDestroy();
}

/* mp-real / double */
inline mp_real_temp operator/(const mp_real &a, const double b)
{
  mp_real c;
  mp_real::mpdivd(a, b, 0, c);
  return c.toTempAndDestroy();
}

/* double / mp_real */
inline mp_real_temp operator/(const double b, const mp_real &a)
{
  return mp_real(b, 0, (size_t)8) / a;
}


inline mp_real& mp_real::operator=(const int& ib)
{
  if(ib == 0) { zero(*this); return *this; }
  // else
  mpdmc(double(ib), 0, *this);
  return *this;
}

inline mp_real& mp_real::operator=(const double& db)
{
  if(db == 0.0) { zero(*this); return *this; }
  // else
  mpdmc(double(db), 0, *this);
  return *this;
}

inline mp_real& mp_real::operator=(const mp_real& jb)
{
  if(&jb != this) {
    mpeq(jb, *this);
  }
  return *this;
}

inline mp_real& mp_real::operator=(const mp_real_temp& jb)
{
  if (!mpr) {
    mpr = jb.mpr;
    return *this;
  }

  double n1 = mpr[0];
  double n2 = jb.mpr[0];
  //Must check to make sure that precision limits
  // for the assigned variable will not change.
  if (n1 == n2) {
    if(alloc) {
      delete [] mpr;
      mpr = jb.mpr;
    } else {
      memcpy(mpr, jb.mpr, sizeof(double) * (int) n1);
      delete [] jb.mpr;
      /*
      for (int i = 0; i < n1; i++)
        mpr[i] = jb.mpr[i];
      */
    }
  } else if (n1 < n2) {
    // May Need to truncate some words. use rounding.
    double nw = mpr[0];
    double sgn = SIGN(1.0, jb.mpr[1]);
    mpr[1] = sgn * MIN(fabs(jb.mpr[1]), double(nw-FST_M-2.0));
    for (int i = 2; i < nw; i++)
      mpr[i] = jb.mpr[i];
    mproun(*this);

    delete [] jb.mpr;

    /*
    double tnw = this->mpr[0];
    double sgn, old_nw;
    delete [] mpr;
    mpr = jb.mpr;
    old_nw = mpr[1];
    sgn = SIGN(1.0, mpr[1]);
    mpr[1] = sgn * MIN(fabs(mpr[1]), double(tnw-FST_M-2.0));
    mpr[0] = tnw;
    if (old_nw == mpr[1])
      return *this;
    else {
      mproun(*this);
      return *this;
    }
    */
  } else {
    /* last case: this->mpr[0] > jb.mpr[0] 
       Need to copy to maintain same maximum number of words. */
    int i, end = int(fabs(jb.mpr[1]))+FST_M;
    for(i = 1; i < end; i++) mpr[i] = jb.mpr[i];
    delete jb.mpr;
    return *this;
  } 

  return *this;
}

inline mp_real& mp_real::operator=(const char *a)
{
  char *az = new char[strlen(a)+1];
  strcpy(az, a);
  mp_real::mpdexc(az, strlen(az), *this);
  delete [] az;
  return *this;
}

inline mp_real& mp_real::operator+=(const mp_real &b)
{
  //same variable input-output safe
  mp_real::mpadd(*this, b, *this);
  return *this;
}

inline mp_real& mp_real::operator*=(const mp_real &b)
{
  //same variable input-output safe
  mp_real::mpmulx(*this, b, *this);
  return *this;
}

inline mp_real& mp_real::operator*=(double b)
{
  //same variable input-output safe
  mp_real::mpmuld(*this, b, 0, *this);
  return *this;
}

inline mp_real& mp_real::operator-=(const mp_real &b)
{
  //same variable input-output safe (for the first & third arguments only!)
  mp_real::mpsub(*this, b, *this);
  return *this;
}

inline mp_real& mp_real::operator/=(const mp_real &b)
{
  //same variable input-output safe
  mp_real::mpdivx(*this, b, *this);
  return *this;
}

inline mp_real& mp_real::operator/=(double b)
{
  //same variable input-output safe
  mp_real::mpdivd(*this, b, 0, *this);
  return *this;
}

inline bool operator>(const mp_real& a, const mp_real& b)
{
  return mp_real::mpcpr(a, b) == 1;
}

inline bool operator>=(const mp_real& a, const mp_real& b)
{
  return mp_real::mpcpr(a, b) >= 0;
}

inline bool operator<(const mp_real& a, const mp_real& b)
{
  return mp_real::mpcpr(a, b) < 0;
}

inline bool operator<=(const mp_real& a, const mp_real& b)
{
  return mp_real::mpcpr(a, b) <= 0;
}

inline bool operator==(const mp_real& a, const mp_real& b)
{
  return mp_real::mpcpr(a, b) == 0;
}

inline bool operator!=(const mp_real& a, const mp_real& b)
{
  return mp_real::mpcpr(a, b) != 0;
}

/* (- mp-real) */
inline mp_real_temp mp_real::operator-() const
{
  mp_real c(*this);
  //mp_real c;
  //mp_real::mpeq(*this, c);
  c[1] = -c[1];  // bug? -- XSL
  return c.toTempAndDestroy();
}

inline mp_real_temp abs(const mp_real& a)
{
  mp_real ret;
  mp_real::mpeq(a, ret);
  ret[1] = fabs(ret[1]);
  return ret.toTempAndDestroy();
}

inline mp_real_temp acos(const mp_real& a)
{
  mp_real c, temp, temp2,  f(size_t(6));
  // compute b = sqrt(1- a^2);
  f[1] = 1.0; f[2] = 0.0; f[3] = 1.0; f[4] = 0.0;
  mp_real::mpmulx(a, a, temp);
  mp_real::mpsub(f, temp, temp2);
  mp_real::mpsqrtx(temp2, temp);  
  mp_real::mpangx(a, temp, mp::mppic, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp aint(const mp_real& a)
{
  mp_real ret, junk(0);
  mp_real::mpinfr(a, ret, junk, 0);
  return ret.toTempAndDestroy();
}

inline mp_real_temp anint(const mp_real& a)
{
  mp_real ret;
  mp_real::mpnint(a, ret);
  return ret.toTempAndDestroy();
}

inline mp_real_temp asin(const mp_real& a)
{
  mp_real c, temp, temp2,  f(size_t(6));
  // compute b = sqrt(1- a^2);
  f[1] = 1.0; f[2] = 0.0; f[3] = 1.0; f[4] = 0.0;
  mp_real::mpmulx(a, a, temp);
  mp_real::mpsub(f, temp, temp2);
  mp_real::mpsqrtx(temp2, temp);
  mp_real::mpangx(temp, a, mp::mppic, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp atan(const mp_real& a)
{
  mp_real c;
  mp_real::mpangx(mp_real(1.0), a, mp::mppic, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp atan2(const mp_real& y, const mp_real& x)
{
  mp_real c;
  //XSL mp_real::mpangx(y, x, mp::mppic, c);
  mp_real::mpangx(x, y, mp::mppic, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp cos(const mp_real& a)
{
  mp_real c, junk;
  mp_real::mpcssx(a, mp::mppic, c, junk);
  return c.toTempAndDestroy();
}

inline mp_real_temp cosh(const mp_real& a)
{
  mp_real c, junk;
  mp_real::mpcshx(a, mp::mppic, mp::mpl02, c, junk);
  return c.toTempAndDestroy();
}

inline double dble(const mp_real& a)
{
  double ret;
  int n;
  mp_real::mpmdc(a, ret, n);
  if(n == 0)
    return ret;
  else
    return ret * pow(2.0, n);
}

inline mp_real_temp exp(const mp_real& a)
{
  mp_real c;
  mp_real::mpexpx(a, mp::mppic, mp::mpl02, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp fmod(const mp_real& a, const mp_real &b)
{
  mp_real c, d, e;
  int nws = c.mpnw;
  c.mpnw = MIN(c.mpnw, int(a[2]) - int(b[2]) + 3);
  c.mpnw = MAX(c.mpnw, 1);
  mp_real::mpdivx(a, b, c);
  c.mpnw = nws;
  mp_real::mpinfr(c, d, e);
  mp_real::mpmulx(d, b, e);
  mp_real::mpsub(a, e, c);  /// THIS LINE WAS CHANGED

  //now make sure that division was correct
  //it is possible that it was slightly wrong.
  double a2 = a[1];
  double c2 = c[1];
  double b2 = b[1];
  if(a2 > 0.0) {
    if(c2 < 0.0) {
      mp_real::mpadd(c, (b>0.0) ? b : mp_real(-b), c);
    } else if(b2 > 0.0) {
      if(c >= b) {
        mp_real::mpsub(c, b, c);
      }
    } else if(b2 < 0.0) {
      c[1] = -c[1];
      if(c <= b) {
        mp_real::mpsub(c, b, c);
      }
      c[1] = -c[1];
    }
  } else {
    if(c2 > 0.0) {
      mp_real::mpsub(c, (b>0.0) ? b : mp_real(-b), c);
    } else if(b2 < 0.0) {
      if(c <= b) {
        mp_real::mpsub(c, b, c);
      }
    } else if(b2 > 0.0) {
      c[1] = -c[1];
      if(c >= b) {
        mp_real::mpsub(c, b, c);
      }
      c[1] = -c[1];
    }
  }
  return c.toTempAndDestroy();
}

inline mp_real_temp log(const mp_real& a)
{
  mp_real c;
  mp_real::mplogx(a, mp::mppic, mp::mpl02, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp log10(const mp_real& a)
{
  mp_real c;
  mp_real::mplogx(a, mp::mppic, mp::mpl02, c);
  mp_real::mpdivx(c, mp::mpl10, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp mp_rand()
{
  mp_real a;
  mp_real::mprand(a);
  return a.toTempAndDestroy();
}

inline void mpcsshf(const mp_real& a, mp_real& b, mp_real& c)
{
  mp_real::mpcshx(a, mp::mppic, mp::mpl02, b, c);
  return;
}

inline void mpcssnf(const mp_real& a, mp_real& b, mp_real& c)
{
  mp_real::mpcssx(a, mp::mppic, b, c);
  return;
}

inline mp_real_temp power(const mp_real& a, int n)
{
  mp_real c;
  mp_real::mpnpwx(a, n, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp power(const mp_real& a, const mp_real& b)
{
  mp_real t1, t2;
  mp_real::mplogx(a, mp::mppic, mp::mpl02, t1);
  mp_real::mpmulx(t1, b, t2);
  mp_real::mpexpx(t2, mp::mppic, mp::mpl02, t1);
  return t1.toTempAndDestroy();
}

inline mp_real_temp power(const mp_real& a, double b)
{
  mp_real t1, t2;
  mp_real::mplogx(a, mp::mppic, mp::mpl02, t1);
  mp_real::mpmuld(t1, b, 0, t2);
  mp_real::mpexpx(t2, mp::mppic, mp::mpl02, t1);
  return t1.toTempAndDestroy();
}

inline mp_real_temp sin(const mp_real& a)
{
  mp_real c, junk;
  mp_real::mpcssx(a, mp::mppic, junk, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp sinh(const mp_real& a)
{
  mp_real c, junk;
  mp_real::mpcshx(a, mp::mppic, mp::mpl02, junk, c);
  return c.toTempAndDestroy();
}

inline mp_real_temp sqrt(const mp_real& a)
{
  mp_real ret;
  mp_real::mpsqrtx(a, ret);
  return ret.toTempAndDestroy();
}

inline mp_real_temp sqr(const mp_real& a)
{
  mp_real ret;
  mp_real::mpsqx(a, ret);
  return ret.toTempAndDestroy();
}

inline mp_real_temp tan(const mp_real& a)
{
  mp_real c, d;
  mp_real::mpcssx(a, mp::mppic, d, c);
  return c / d;
}

inline mp_real_temp tanh(const mp_real& a)
{
  mp_real c, d;
  mp_real::mpcshx(a, mp::mppic, mp::mpl02, d, c);
  return c / d;
}

/**
 * Operations with int need to have explicit operators.
 * If they did not, the mp_real(int) would be used, 
 * which creates a mp_real of a certain size, rather
 * than an mp_real representing an integer.
 */
inline mp_real_temp operator+(const mp_real &a, int b)
{
  return a + mp_real(double(b), 0, (size_t)8);
}

inline mp_real_temp operator+(int b, const mp_real &a)
{
  return a + mp_real(double(b), 0, (size_t)8);
}

inline mp_real operator+=(mp_real &a, int b)
{
  return a += mp_real(double(b), 0, (size_t)8);
}

inline mp_real_temp operator-(int b, const mp_real &a)
{
  return mp_real(double(b), 0, (size_t)8) - a;
}

inline mp_real_temp operator-(const mp_real &a, int b)
{
  return a - mp_real(double(b), 0, (size_t)8);
}

inline mp_real operator-=(mp_real &a, int b)
{
  return a -= mp_real(double(b), 0, (size_t)8);
}

inline mp_real_temp operator*(const mp_real &a, int b)
{
  return a * double(b);
}

inline mp_real operator*=(mp_real &a, int b)
{
  return a *= double(b);
}

inline mp_real_temp operator*(int b, const mp_real &a)
{
  return a * double(b);
}

inline mp_real_temp operator/(const mp_real &a, int b)
{
  return a / double(b);
}

inline mp_real operator/=(mp_real &a, int b)
{
  return a /= double(b);
}

inline mp_real_temp operator/(int b, const mp_real &a)
{
  return mp_real(b, 0, (size_t)8) / a;
}

inline bool operator>(int b, const mp_real &a)
{
  return mp_real(double(b)) > a;
}

inline bool operator>(const mp_real &a, int b)
{
  return a > mp_real(double(b));
}

inline bool operator<(int b, const mp_real &a)
{
  return mp_real(double(b)) < a;
}

inline bool operator<(const mp_real &a, int b)
{
  return a < mp_real(double(b));
}

inline bool operator<=(int b, const mp_real &a)
{
  return mp_real(double(b)) <= a;
}

inline bool operator<=(const mp_real &a, int b)
{
  return a <= mp_real(double(b));
}

inline bool operator>=(int b, const mp_real &a)
{
  return mp_real(double(b)) >= a;
}

inline bool operator>=(const mp_real &a, int b)
{
  return a >= mp_real(double(b));
}

inline bool operator==(int b, const mp_real &a)
{
  return mp_real(double(b)) == a;
}

inline bool operator==(const mp_real &a, int b)
{
  return a == mp_real(double(b));
}

inline bool operator!=(int b, const mp_real &a)
{
  return mp_real(double(b)) != a;
}

inline bool operator!=(const mp_real &a, int b)
{
  return a != mp_real(double(b));
}

/**
 * operators with double
 */

inline mp_real_temp operator+(const mp_real &a, double b)
{
  return a + mp_real(b, 0, (size_t)8);
}

inline mp_real_temp operator+(double b, const mp_real &a)
{
  return a + mp_real(b, 0, (size_t)8);
}

inline mp_real operator+=(mp_real &a, double b)
{
  return a += mp_real(double(b), 0, (size_t)8);
}

inline mp_real_temp operator-(double b, const mp_real &a)
{
  return mp_real(b, 0, (size_t)8) - a;
}

inline mp_real_temp operator-(const mp_real &a, double b)
{
  return a - mp_real(b, 0, (size_t)sizeof(double));
}

inline mp_real operator-=(mp_real &a, double b)
{
  return a -= mp_real(b, 0, (size_t)8);
}

inline bool operator>(double b, const mp_real &a)
{
  return mp_real(b) > a;
}

inline bool operator>(const mp_real &a, double b)
{
  return a > mp_real(b);
}

inline bool operator<(double b, const mp_real &a)
{
  return mp_real(b) < a;
}

inline bool operator<(const mp_real &a, double b)
{
  return a < mp_real(b);
}

inline bool operator<=(double b, const mp_real &a)
{
  return mp_real(b) <= a;
}

inline bool operator<=(const mp_real &a, double b)
{
  return a <= mp_real(b);
}

inline bool operator>=(double b, const mp_real &a)
{
  return mp_real(b) >= a;
}

inline bool operator>=(const mp_real &a, double b)
{
  return a >= mp_real(b);
}

inline bool operator==(double b, const mp_real &a)
{
  return mp_real(b) == a;
}

inline bool operator==(const mp_real &a, double b)
{
  return a == mp_real(b);
}

inline bool operator!=(double b, const mp_real &a)
{
  return mp_real(b) != a;
}

inline bool operator!=(const mp_real &a, double b)
{
  return a != mp_real(b);
}

/*
inline mp_real::operator double() const {
  return dble(*this);
}
*/

#endif
    /* __MP_INLINE_H */
