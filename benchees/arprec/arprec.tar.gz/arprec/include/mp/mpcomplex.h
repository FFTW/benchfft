/*
 * include/mp/mpcomplex.h
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2001
 *
 */
#ifndef __MPCOMPLEX_H
#define __MPCOMPLEX_H

#include "mpreal.h"
#include "mp_complex_temp.h"

class mp_complex : public mp
{
 protected:
 public:
  mp_real real, imag;

 public:
  // destructor
  // No need to call the destructor for mp_real, because the destructor for
  // them will be called automatically since they are directly allocated in
  // the class.   -- Yozo
  // ~mp_complex() { real.~mp_real();  imag.~mp_real();}
  // constructor
  mp_complex():real(), imag() {}
  mp_complex(size_t s):real(s), imag(s) {}
  mp_complex(int s):real(s), imag(s) {}
  mp_complex(const mp_real& a, const mp_real& b):real(a), imag(b) {}
  mp_complex(const mp_real& a):real(a) { mp_real::zero(imag); }
  mp_complex(const mp_complex& other):real(other.real), imag(other.imag) {}
  mp_complex(double dpr, double dpi, int n=0, size_t s = mp5)
            : real(dpr, n, s), imag(dpi, n, s) {}
  // XSL    : real(dpr, n, s), imag(dpr, n, s) {}
  mp_complex(double *r, double *i): real(r), imag(i) {}
  mp_complex(const double *r, const double *i): real(r), imag(i) {}
  mp_complex(const mp_complex_temp& other):real(other.real), imag(other.imag) 
    {}
  // XSL added
  //mp_complex(const double *dp) { 
  //real.mpr = (double *)dp; imag.mpr = (double *)&dp[mp5];
  //}
  //mp_complex(double *dp) { 
  //real.mpr = dp; imag.mpr = &dp[mp5];
  //}
  // end XSL

  mp_complex_temp toTempAndDestroy() { 
    return mp_complex_temp(real.toTempAndDestroy(), imag.toTempAndDestroy());
  }
  
  static void zero(mp_complex& a) { 
    mp_real::zero(a.real); 
    mp_real::zero(a.imag); 
  }

  //general math- advanced and not advanced
  static void mpcmuld(const mp_complex& a, double db, int n, 
		      mp_complex& b);
  static void mpcadd(const mp_complex& a, const mp_complex& b, mp_complex& c);
  static void mpcsub(const mp_complex& a, const mp_complex& b, mp_complex& c);
  static void mpcmul(const mp_complex& a, const mp_complex& b, mp_complex& c);
  static void mpcmulx(const mp_complex& a, const mp_complex& b, mp_complex& c);
  static void mpcdiv(const mp_complex& a, const mp_complex& b,
		     mp_complex& c);
  static void mpcdivx(const mp_complex& a, const mp_complex& b,
		      mp_complex& c);
  static void mpceq(const mp_complex& a, mp_complex& b);
  static void mpcsqx(const mp_complex& a, mp_complex& c);
  static void mpcagx(mp_complex& a, mp_complex& b);
  static void mpcsqrtx(const mp_complex& a, mp_complex& b);
  static void mpcpwx(const mp_complex& a, int n, mp_complex& b);
  static void mpcpwr(const mp_complex& a, int n, mp_complex& b);
  static void mpcsqrt(const mp_complex &a, mp_complex& b);


  friend mp_complex_temp operator+(const mp_complex &a, 
					  const mp_complex &b);
  friend mp_complex_temp operator+(const mp_complex &a, const mp_real &breal);
  friend mp_complex_temp operator+(const mp_real &breal, const mp_complex &a);

  friend mp_complex_temp operator-(const mp_complex &a, 
				   const mp_complex &b);
  friend mp_complex_temp operator-(const mp_complex &a, 
				   const mp_real &breal);
  friend mp_complex_temp operator-(const mp_real &breal, 
				   const mp_complex &a);

  friend mp_complex_temp operator*(const mp_complex &a, 
					  const mp_complex &b);
  friend mp_complex_temp operator/(const mp_complex &a, 
					 const mp_complex &b);
  friend mp_complex_temp operator/(const mp_complex &a, 
					 const mp_real &b);
  friend mp_complex_temp operator/(const mp_real &a, 
					 const mp_complex &b);
  friend mp_complex_temp operator/(const mp_complex &a, 
					 double b);
  friend mp_complex_temp operator/(double b, const mp_complex &a);
  friend mp_complex_temp operator/(int b, const mp_complex &a);

  friend mp_complex_temp operator*(const mp_complex& a, const mp_real& b);
  friend mp_complex_temp operator*(const mp_real& b, const mp_complex& a);
  friend mp_complex_temp operator*(const mp_complex& a, double b);
  friend mp_complex_temp operator*(double b, const mp_complex& a);
  friend mp_complex_temp exp(const mp_complex& a);
  friend mp_complex_temp log(const mp_complex& a);
  friend mp_complex_temp sin(const mp_complex &a);
  friend mp_complex_temp cos(const mp_complex &a);
  friend mp_complex_temp sqr(const mp_complex &a);
  friend mp_complex_temp sqrt(const mp_complex &a);
  friend mp_real_temp abs(const mp_complex &a);
  friend mp_real_temp arg(const mp_complex &a);
  friend mp_complex_temp power(const mp_complex& a, int n);
  friend mp_complex_temp power(const mp_complex& a, mp_real& b);
  friend mp_complex_temp power(const mp_complex& a, mp_complex& b);

  mp_complex &operator+=(const mp_complex &other);
  mp_complex &operator-=(const mp_complex &other);
  mp_complex &operator*=(const mp_complex &other);
  mp_complex &operator/=(const mp_complex &other);

  mp_complex &operator+=(const mp_real &other);
  mp_complex &operator-=(const mp_real &other);
  mp_complex &operator*=(const mp_real &other);
  mp_complex &operator/=(const mp_real &other);

  mp_complex &operator/=(double other);
  mp_complex &operator/=(int other);

  mp_complex &operator=(const mp_complex &other);
  mp_complex &operator=(const mp_real &other);
  mp_complex &operator=(mp_complex_temp &other);

  mp_complex_temp operator-() {
    return mp_complex_temp(-(this->real), -(this->imag));
  }


  friend bool operator==(const mp_complex &a, const mp_complex &b);
  friend bool operator!=(const mp_complex &a, const mp_complex &b);


  friend class mp_real;
};

#if (ARPREC_INLINE)
#include "mp_complex_inline.h"
#else
mp_complex_temp operator+(const mp_complex &a, const mp_complex &b);
mp_complex_temp operator+(const mp_complex &a, const mp_real &breal);
mp_complex_temp operator+(const mp_real &breal, const mp_complex &a);
mp_complex_temp operator-(const mp_complex &a, const mp_complex &b);
mp_complex_temp operator-(const mp_complex &a, const mp_real &breal);
mp_complex_temp operator-(const mp_real &breal, const mp_complex &a);
mp_complex_temp operator*(const mp_complex &a, const mp_complex &b);
mp_complex_temp operator/(const mp_complex &a, const mp_complex &b);
mp_complex_temp operator/(const mp_complex &a, const mp_real &b);
mp_complex_temp operator/(const mp_complex &a, double b);
mp_complex_temp operator/(const mp_real &a, const mp_complex &b);
mp_complex_temp operator/(double b, const mp_complex& a);
mp_complex_temp operator/(int b, const mp_complex& a);
mp_complex_temp operator*(const mp_complex& a, double b);
mp_complex_temp operator*(double b, const mp_complex& a);
mp_complex_temp operator*(const mp_complex& a, const mp_real& b);
mp_complex_temp operator*(const mp_real& b, const mp_complex& a);
mp_complex_temp exp(const mp_complex& a);
mp_complex_temp log(const mp_complex& a);
mp_complex_temp sin(const mp_complex &a);
mp_complex_temp cos(const mp_complex &a);
mp_complex_temp cos(const mp_complex &a);
bool operator==(const mp_complex &a, const mp_complex &b);
bool operator!=(const mp_complex &a, const mp_complex &b);
mp_complex_temp sqr(const mp_complex &a);
mp_complex_temp sqrt(const mp_complex &a);
mp_real_temp abs(const mp_complex &a);
mp_real_temp arg(const mp_complex &a);
mp_complex_temp power(const mp_complex& a, int n);
mp_complex_temp power(const mp_complex& a, const mp_real& b);
mp_complex_temp power(const mp_complex& a, const mp_complex& b);

#endif

#endif /* __MPCOMPLEX_H */
