/*
 * include/mp/mp_int_inline.h
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2001
 *
 */
#ifndef __MPINT_INLINE_H
#define __MPINT_INLINE_H



inline bool operator==(const mp_int& a, const mp_real& b) {
  return operator==((const mp_real &)a, (const mp_real &)b);
}

inline bool operator!=(const mp_int& a, const mp_real& b) {
  return operator!=((const mp_real &)a, (const mp_real &)b);
}

inline bool operator>(const mp_int& a, const mp_real& b) {
  return operator>((const mp_real &)a, (const mp_real &)b);
}

inline bool operator<(const mp_int& a, const mp_real& b) {
  return operator<((const mp_real &)a, (const mp_real &)b);
}

inline bool operator>=(const mp_int& a, const mp_real& b) {
  return operator>=((const mp_real &)a, (const mp_real &)b);
}

inline bool operator<=(const mp_int& a, const mp_real& b) {
  return operator<=((const mp_real &)a, (const mp_real &)b);
}



inline bool operator==(const mp_real& a, const mp_int& b) {
  return operator==((const mp_real &)a, (const mp_real &)b);
}

inline bool operator!=(const mp_real& a, const mp_int& b) {
  return operator!=((const mp_real &)a, (const mp_real &)b);
}

inline bool operator>(const mp_real& a, const mp_int& b) {
  return operator>((const mp_real &)a, (const mp_real &)b);
}

inline bool operator<(const mp_real& a, const mp_int& b) {
  return operator<((const mp_real &)a, (const mp_real &)b);
}

inline bool operator>=(const mp_real& a, const mp_int& b) {
  return operator>=((const mp_real &)a, (const mp_real &)b);
}

inline bool operator<=(const mp_real& a, const mp_int& b) {
  return operator<=((const mp_real &)a, (const mp_real &)b);
}


inline bool operator==(const mp_int& a, const mp_int& b) {
  return operator==((const mp_real &)a, (const mp_real &)b);
}

inline bool operator!=(const mp_int& a, const mp_int& b) {
  return operator!=((const mp_real &)a, (const mp_real &)b);
}

inline bool operator>(const mp_int& a, const mp_int& b) {
  return operator>((const mp_real &)a, (const mp_real &)b);
}

inline bool operator<(const mp_int& a, const mp_int& b) {
  return operator<((const mp_real &)a, (const mp_real &)b);
}

inline bool operator>=(const mp_int& a, const mp_int& b) {
  return operator>=((const mp_real &)a, (const mp_real &)b);
}

inline bool operator<=(const mp_int& a, const mp_int& b) {
  return operator<=((const mp_real &)a, (const mp_real &)b);
}

inline mp_int& mp_int::operator++()
{
  mp_int *a = new mp_int(*this);
  if(mpr[1] == 0.0) {
    mpr[1] = 1.0;
    mpr[2] = 0.0;
    mpr[FST_M] = 1.0;
    return *a;
  }

  if(mpr[2]+1.0 < ABS(mpr[1])) {
    mp_int_prec_error((char*)"operator++()");
  }
  if(mpr[2]+1.0 > ABS(mpr[1])) {
    mpadd(*this, mp_real(1.0), *this);
    return *a;
  } else {
    double b;
    if(mpr[1] >= 0) {
      b = (mpr[FST_M + int(ABS(mpr[1]))] += 1.0);
      if(b >= mpbdx) {
	//Take the pointer of the function mpnorm in the hope that
	//it will not expand inline here
	(&mpnorm)(mpr, *this);
      }
      return *a;
    } else {
      b = (mpr[FST_M + int(ABS(mpr[1]))] -= 1.0);
      if(b <= 0.0) {
	(&mpnorm)(mpr, *this);
      }
      return *a;
    }
  }
}

inline mp_int& mp_int::operator++(int)
{
  if(mpr[1] == 0.0) {
    mpr[1] = 1.0;
    mpr[2] = 0.0;
    mpr[FST_M] = 1.0;
    return *this;
  }

  if(mpr[2]+1.0 < ABS(mpr[1])) {
    mp_int_prec_error((char*)"operator++(int)");
  }
  if(mpr[2]+1.0 > ABS(mpr[1])) {
    mpadd(*this, mp_real(1.0), *this);
    return *this;
  } else {
    double b;
    if(mpr[1] >= 0) {
      b = (mpr[FST_M + int(ABS(mpr[1]))] += 1.0);
      if(b >= mpbdx) {
	//Take the pointer of the function mpnorm in the hope that
	//it will not expand inline here
	(&mpnorm)(mpr, *this);
      }
      return *this;
    } else {
      b = (mpr[FST_M + int(ABS(mpr[1]))] -= 1.0);
      if(b <= 0.0) {
	(&mpnorm)(mpr, *this);
      }
      return *this;
    }
  }
}

inline mp_int& mp_int::operator--()
{
  mp_int *a = new mp_int(*this);
  if(mpr[1] == 0.0) {
    mpr[1] = -1.0;
    mpr[2] = 0.0;
    mpr[FST_M] = 1.0;
    return *a;
  }

  if(mpr[2]+1.0 < ABS(mpr[1])) {
    mp_int_prec_error((char*)"operator--()");
  }
  if(mpr[2]+1.0 > ABS(mpr[1])) {
    mpadd(*this, mp_real(-1.0), *this);
    return *a;
  } else {
    double b;
    if(mpr[1] < 0) {
      b = (mpr[FST_M + int(ABS(mpr[1]))] += 1.0);
      if(b >= mpbdx) {
	//Take the pointer of the function mpnorm in the hope that
	//it will not expand inline here
	(&mpnorm)(mpr, *this);
      }
      return *a;
    } else {
      b = (mpr[FST_M + int(ABS(mpr[1]))] -= 1.0);
      if(b <= 0.0) {
	(&mpnorm)(mpr, *this);
      }
      return *a;
    }
  }
}

inline mp_int& mp_int::operator--(int)
{
  if(mpr[1] == 0.0) {
    mpr[1] = -1.0;
    mpr[2] = 0.0;
    mpr[FST_M] = 1.0;
    return *this;
  }

  if(mpr[2]+1.0 < ABS(mpr[1])) {
    mp_int_prec_error((char*)"operator--(int)");
  }
  if(mpr[2]+1.0 > ABS(mpr[1])) {
    mpadd(*this, mp_real(-1.0), *this);
    return *this;
  } else {
    double b;
    if(mpr[1] < 0) {
      b = (mpr[FST_M + int(ABS(mpr[1]))] += 1.0);
      if(b >= mpbdx) {
	//Take the pointer of the function mpnorm in the hope that
	//it will not expand inline here
	(&mpnorm)(mpr, *this);
      }
      return *this;
    } else {
      b = (mpr[FST_M + int(ABS(mpr[1]))] -= 1.0);
      if(b <= 0.0) {
	(&mpnorm)(mpr, *this);
      }
      return *this;
    }
  }
}


inline void divrem(const mp_int &dividend, const mp_int &divisor,
		   mp_int& quotient, mp_int& remainder)
{
  int nws = quotient.mpnw;
  quotient.mpnw = int(dividend[2] - divisor[2]) + 3;

  //Check to see if we have enough precision availible.
  if(quotient.mpnw > quotient.mpwds+6) {
    mp_int::mp_int_prec_error((char*)"divrem");
  }
  mp_real t((size_t)(int(dividend[0])));
  mp_real::mpdivx(dividend, divisor, quotient);
  mp_real::mpinfr(quotient, quotient, t, 0);
  quotient.mpnw = nws;

  mp_real::mpmulx(quotient, divisor, t);
  mp_real::mpsub(dividend, t, remainder);

  //check to see if quotient off by one.
  //This can happen when the division should have 
  //resulted in an integer, but ended up an epsilon off,
  //or when the division was just under and integer, 
  //such as 3.999999, and the division rounded up.
  if(dividend[1] > 0.0) {
    if(remainder[1] < 0.0) {
      if(quotient[1] >= 0.0) {
	quotient--;
	mp_real::mpadd(remainder, divisor, remainder);
      } else {
	//divisor < 0
	quotient++;
	mp_real::mpsub(remainder, divisor, remainder);
      }
    } else if(divisor[1] > 0.0) {
      //quotient positive
      if(remainder >= divisor) {
	mp_real::mpsub(remainder, divisor, remainder);
	quotient++;
      }
    } else {
      //divisor < 0, quotient negative
      remainder[1] = -remainder[1];
      if(remainder <= divisor) {
	mp_real::mpsub(remainder, divisor, remainder);
	quotient--;
      }
      remainder[1] = -remainder[1];
    }
  } else {
    //dividend < 0.0
    if(remainder[1] > 0.0) {
      if(quotient[1] >= 0.0) {
	//divisor < 0
	quotient--;
	mp_real::mpadd(remainder, divisor, remainder);
      } else {
	//divisor > 0
	quotient++;
	mp_real::mpsub(remainder, divisor, remainder);
      }
    } else if(divisor[1] < 0.0) {
      //quotient positive
      if(remainder <= divisor) {
	mp_real::mpsub(remainder, divisor, remainder);
	quotient++;
      }
    } else {
      //divisor > 0, quotient negative
      remainder[1] = -remainder[1];
      if(remainder >= divisor) {
	mp_real::mpsub(remainder, divisor, remainder);
	quotient--;
      }
      remainder[1] = -remainder[1];
    }
  }

  return;
}

inline mp_int_temp operator+(const mp_int& a, const mp_int& b)
{
  mp_int c;
  mp_real::mpadd(a, b, c);
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}

inline mp_int_temp operator+(const mp_int& a, int b)
{
  mp_int c, temp(b);
  mp_real::mpadd(a, temp, c);
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}

inline mp_int_temp operator+(int b, const mp_int& a)
{
  mp_int c, t(b); 
  mp_real::mpadd(a, t, c);
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}

inline mp_real_temp operator+(const mp_int& a, double b)
{
  mp_real c, t(b); 
  mp_real::mpadd(a, t, c);
  return c.toTempAndDestroy();
}


inline mp_real_temp operator+(double b, const mp_int& a)
{
  mp_real c, t(b); 
  mp_real::mpadd(a, t, c);
  return c.toTempAndDestroy();
}

inline mp_int_temp operator-(const mp_int& a, const mp_int& b)
{
  mp_int c;
  mp_real::mpsub(a, b, c);
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}


inline mp_int_temp operator-(const mp_int& a, int b)
{
  mp_int c, t(b); 
  mp_real::mpsub(a, t, c);
  return c.toTempAndDestroy();
}

inline mp_int_temp operator-(int b, const mp_int& a)
{
  mp_int c, t(b); 
  mp_real::mpsub(t, a, c);
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}

inline mp_real_temp operator-(const mp_int& a, double b)
{
  mp_real c, t(b); 
  mp_real::mpsub(a, t, c);
  return c.toTempAndDestroy();
}


inline mp_real_temp operator-(double b, const mp_int& a)
{
  mp_real c, t(b); 
  mp_real::mpsub(t, a, c);
  return c.toTempAndDestroy();
}

inline mp_int_temp operator*(const mp_int& a, const mp_int& b)
{
  mp_int c;
  mp_real::mpmulx(a, b, c);
  return c.toTempAndDestroy();
}

inline mp_int_temp operator*(const mp_int& a, int b)
{
  mp_int c;
  mp_real::mpmuld(a, double(b), 0, c);
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}


inline mp_int_temp operator*(int b, const mp_int& a)
{
  mp_int c;
  mp_real::mpmuld(a, double(b), 0, c);
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}

inline mp_real_temp operator*(const mp_int& a, double b)
{
  return operator*((const mp_real &)a, b);
}

inline mp_real_temp operator*(double b, const mp_int& a)
{
  return operator*((const mp_real &)a, b);
}

inline mp_int_temp operator/(const mp_int& a, const mp_int& b)
{
  mp_int c((size_t)(a[2] - b[2] + 11.0));
  if(a[1] == 0.0) {
    mp_real::zero(c);
    return c.toTempAndDestroy();
  }

  int nws = c.mpnw;
  c.mpnw = int(a[2] - b[2]) + 4;
  if(c.mpnw > c.mpwds+1) {
    mp_int::mp_int_prec_error((char*)"operator/(mp_int, mp_int)");
  }
  mp_real t;
  int roun = mp_real::MPIRD;
  mp_real::MPIRD = 0; //set to round toward zero. works most of the time.
  mp_real::mpdivx(a, b, c);
  mp_real::mpinfr(c, c, t);
  mp_real::MPIRD = roun; //restore MPIRD.

  //Check to see if one off.
  //A check is needed in exact and almost exact cases.
  t[1] = ABS(t[1]);
  if(t[1] == 0.0 || t > 0.999) {
    c.mpnw = nws;
    mp_int t2;
    mp_int::mpmulx(c, b, t2);
    mp_int::mpsub(a, t2, t2);
    if(a[1] > 0.0) {
      if(b[1] > 0.0) {
	if(t2 < mp_int(0)) {
	  c--;
	} else if(t2 >= b) {
	  c++;
	} 
      } else {
	if(t2 < mp_int(0)) {
	  c++;
	} else if(t2 >= -b) {
	  c--;
	}
      }
    } else {
      if(b[1] > 0.0) {
	if(t2 > mp_int(0)) {
	  c++;
	} else if(t2 <= -b) {
	  c--;
	}
      } else {
	if(t2 > mp_int(0)) {
	  c--;
	} else if(t2 <= b) {
	  c++;
	}
      }
    }
  }

  c.mpnw = nws;
  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}

inline mp_int& mp_int::operator/=(const mp_int& other)
{
  *this = *this / other;
  mp_int::ovcheck(*this);
  return *this;
}

inline mp_int_temp operator/(const mp_int& a, int b)
{
  mp_int c((size_t)(a[0]));
  int nws = c.mpnw;
  c.mpnw = int(a[2]) + 3;
  if(c.mpnw > c.mpwds+6) {
    mp_int::mp_int_prec_error((char*)"operator/(mp_int, int)");
  }

  mp_real t;
  mp_real::mpdivd(a, b, 0, c);
  mp_real::mpinfr(c, c, t, 0);
  c.mpnw = nws;

  mp_int::ovcheck(c);
  return c.toTempAndDestroy();
}

inline mp_int& mp_int::operator/=(int other)
{
  *this = *this / other;
  mp_int::ovcheck(*this);
  return *this;
}


inline int operator/(int a, const mp_int& b)
{
  if(b[1] == 0.0) {
    cerr << (char*)"\n*** MPINT, operator/(int, mp_int) : division by zero";
    mp_int::mpabrt();
  }
  if(b[2] > 0.0 || b[FST_M] > ABS(double(a))) {
    return 0 ;
  }
  return a / int(b[FST_M] * b[1]);
}

inline mp_real_temp operator/(const mp_int& a, double b)
{
  return operator/((const mp_real &)a, b);
}

inline mp_real_temp operator/(double b, const mp_int& a)
{
  return operator/(mp_real(b), (const mp_real &)a);
}

inline mp_int_temp operator%(const mp_int& a, const mp_int &b)
{
  mp_int c((size_t)(a[2] - b[2] + 11.0));
  mp_int d((size_t)(a[0]));
  divrem(a, b, c, d);
  return d.toTempAndDestroy();
}

inline int operator%(int a, const mp_int &b)
{
  if(b[1] == 0.0) {
    cerr << (char*)"\n*** MPINT, operator%(int, mp_int) : modulus by zero";
    mp_int::mpabrt();
  }
  if(b[2] > 0.0 || b[FST_M] > ABS(double(a))) {
    return a;
  }
  return a % int(b[FST_M]);
}

inline int operator%(const mp_int& a, int b)
{
  mp_int t;
  t = a / b;
  t *= b;
  t = a - t;
  //t should now have at most 1 mantissa word.
  return int(t[FST_M] * t[1]);  
}

inline mp_int& mp_int::operator%=(const mp_int& other) 
{
  mp_int c((size_t)(mpr[2] - other[2] + 11.0));
  divrem(*this, other, c, *this);
  return *this;
}

inline mp_int& mp_int::operator%=(int other)
{
  return *this %= mp_int(other);
}

inline mp_int_temp power(const mp_int &a, int n)
{
  mp_int ret;
  mp_int::mpnpwx(a, n, ret);
  mp_int::mpnint(ret, ret);//wastefull.
  mp_int::ovcheck(ret);
  return ret.toTempAndDestroy();
}

inline mp_int_temp power(const mp_int &a, const mp_int& b)
{
  mp_real c(power((const mp_real &)a, (const mp_real &)b));
  // XSL if(ABS(c[1]) > c[2] + 1.0) {
  //    mp_int::mp_int_prec_error((char*)"power(mp_int, mp_int)");
  //  }
  mp_int d((size_t)(int(c[0])));
  mp_real::mpnint(c, d);
  mp_int::ovcheck(d);
  return d.toTempAndDestroy();
}


inline int integer(const mp_int& a)
{
  int ret;
  ret = int(a[FST_M] * a[1]);
  //check for correctness is commented out.  Use at your own risk.
  /*  if(ABS(a[1]) > 1.0 || ret != a) {
    cerr << (char*)"\n*** Integer conversion : A cannot be held by an integer";
    }*/
  return ret;
}

#endif 
