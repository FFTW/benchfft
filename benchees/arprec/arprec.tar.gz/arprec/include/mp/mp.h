/*
 * include/mp.h
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2001
 *
 */
#ifndef ARPREC_MP_H
#define ARPREC_MP_H

#include "mp/arprec_config.h"

#if !(ARPREC_INLINE)
#define inline
#endif

#if (ARPREC_HAVE_STD)
#include <cstdio>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cassert>
#include <cstring>
using std::istream;
using std::ostream;
using std::cerr;
using std::cout;
using std::endl;
#else
#include <stdio.h>
#include <iostream.h>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include <string.h>
#endif


/*
 * This class contains shared variables, macros, and functions that
 * are used by other mp-classes that inherit it.
 */

/* Constants */

/* This gives the index of the first mantissa word in a double MP array.
   The double MP array A is structured as follows:
       Index                   Content
       -----                   -------
       0                    :  the array size
       1                    :  number of mantissa words, with sign
       2                    :  exponent
       3 .. |A[1]|+2        :  mantissa words
       |A[1]|+3 .. |A[1]|+4 :  2 scratch words for rounding purpose
   So, total #words A[0] = |A[1]|+5
*/
#define FST_M       3
/* Macros */
#define MIN(a, b) ( (a) < (b) ? (a) : (b) )
#define MAX(a, b) ( (a) > (b) ? (a) : (b) )
#define ABS(a)    ( (a) < 0 ? -(a) : (a) )

/* The following parameters are all that need to be changed in normal usage:

  MPIPL   Initial precision level, in digits.
  MPIOU   Initial output precision level, in digits.
  MPIEP   Log_10 of initial MP epsilon level.
*/
class mp_real;

/* New data types */
class mp
{
 public:


  /* call the function mp_init to re-initialize the mp_library
     with a different precision level.  set new_all to 1 to force
     a change of the pi constant, etc. if you just want
     to change the working precision temporarily, try changing
     mp::mpnw directly or using 
     mp::mpsetprec. */
     
  static int mp_init(int new_mpipl, char *filename = 0, int new_all = 0);
  static void mp_finalize();
  static void mp_output_init(char *filename);
  static void mpsetoutputprec(int num_digits);
  static int mpgetoutputprec()  {return mpoud;}
  static void mpsetprec(int num_digits);
  static int mpgetprec();
  static void mpsetprecwords(int num_words);
  static int mpgetprecwords() {return mpnw;}

  static int mpipl;
  static int mpiou;
  static int mpiep;
  static int mpwds; 
  static int mp5;
  static const int initial_mpipl;

  static int fmpwds5; // the static word size used in Fortran 90 wrapper.

  // Current output precision (in digits).
  static int mpoud;
  
  static int mp2; 

  static int mp21;

  // Log 2.
  static mp_real mpl02; 
  
  // Log 10.
  static mp_real mpl10;
  
  // Pi.
  static mp_real mppic;
  
  // Current MP epsilon value. 10^MPIEP.
  static mp_real mpeps;
  
  // ARPREC debug level. Initial value: 0
  static int MPIDB; 
	
  // Number of words in debug output. Initial value: 22.
  static int MPNDB;
	
  // ARPREC error indicator. Initial value: 99.
  static int MPIER; 
	
  // Cross-over point for advanced routines. 
  //Initial value: mpmcrx.
  static int MPMCR;
	
  // ARPREC rounding option. Initial value: 1.
  static int MPIRD;
	
  // Array of error options. Initial value: 2.
  static int MPKER[79+1];
  
  // array pointers for mpmulx, other high precision routines.
  // They store roots of unity (complex).
  static double *mpuu1, *mpuu2, *mpuu3;

  // used to store old FPU control word, if any.
  // set and used by mp_init and mp_finalize.
  static unsigned int old_cw;

protected:
	
  // Depends on the system word size.
  //  On IEEE systems and most other 32 bit systems, set to 4096.D0
  static const double mpbbx;
  static const double mpbdx; 
  static const double mprdx; 
  static const double mpbx2; 
  static const double mprbx; 
  static const double mprx2; 
  static const double mprxx;
  
	
  // Depends on the system word size.
  // On IEEE systems and most other 64 bit systems, set to 52.
  static const int mpnbt;
	
  // Depends on the system word size.
  // On IEEE systems and most other 64 bit systems, set to 64.
  static const int mpnpr;
	
  // Depends on the system word size.
  // On IEEE systems and most other 32 bit systems, set to 7.
  // On Cray system, set to 8.
  static const int mpmcrx;
	
  // This is spacing parameters to avoid bank and cache conflicts in the FFT routines.
  // Value of 32 appears to work well on most systems.
  static const int mpnrow;
	
  // This is spacing parameters to avoid bank and cache conflicts in the FFT routines.
  // Value of 3 appears to work well on most systems. 
  static const int mpnsp1; 
	
  // This is spacing parameters to avoid bank and cache conflicts in the FFT routines.
  // Value of 17 appears to work well on most systems.
  static const int mpnsp2;
	
  // Fortran's sign function.
  // @return the absolute value of a with sign of b.
    inline static double SIGN(double a, double b) 
    { return (b>=0 ? fabs(a) : -fabs(a));}

  inline static int SIGN(int a, int b)
  { return (b>=0 ? ABS(a) : -ABS(a));}

  //  This routine terminates execution. 
  static void mpabrt();

public:
  /*
   *  Current precision level, in words.
   *  Initial value: 16.
   */
  static int mpnw; // mpwds + 1
	
	
 public:
  
  // Initializes mppic.
  static mp_real& init_mppic();
  
  // Initializes mpl02.
  static mp_real& init_mpl02();
  
  // Initializes mpl10.
  static mp_real& init_mpl10();
  
  // Initializes mpeps.
  static mp_real& init_mpeps();
  
  
};

#endif
    /* ARPREC_MP_H */
