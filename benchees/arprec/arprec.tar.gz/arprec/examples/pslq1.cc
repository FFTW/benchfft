#if (ARPREC_HAVE_STD)
#include <cstdio>
#include <cstring>
#include <cfloat>
#include <cmath>
#else
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <math.h>
#endif
#include "mp/mpreal.h"

#include "pslq1.h"

int pslq1(const matrix<mp_real> &x, matrix<mp_real> &rel, 
          const mp_real &eps, double gamma) {
  int print_interval = 100;
  int check_interval = 500;
  int n = x.size();
  matrix<mp_real> b(n, n);
  matrix<mp_real> h(n, n-1);
  matrix<mp_real> y(n);
  mp_real t;
  mp_real teps = eps * 1.0e20;
  mp_real max_bound = 0.0;

  int result;

  init_pslq(x, y, h, b);
  if (debug_level >= 3) {
    y.print("Initial y:");
    b.print("Initial B:");
    h.print("Initial H:");
  }
  result = reduce_pslq(h, y, b, eps);

  pslq_iter = 0;
  while (result == RESULT_CONTINUE) {
    pslq_iter++;
    if (debug_level >= 2) {
      if (pslq_iter % print_interval == 0)
        printf("Iteration %5d\n", pslq_iter);
    }

    result = iterate_pslq(gamma, y, h, b, eps, teps);

    if (debug_level >= 3) {
      y.print("Updated y: ");
      b.print("Updated B: ");
      h.print("Updated H: ");
    }

    if (pslq_iter % check_interval == 0) {
      /* Find min and max magnitude in y vector. */
      mp_real u, v;
      matrix_minmax(y, u, v);

      if (debug_level >= 2) {
        printf("Iteration %5d: min, max of y =", pslq_iter);
        print(u);
        print(v);
        printf("\n");
      }

      /* Compute norm bound. */
      bound_pslq(h, u);
      if (u > max_bound)
        max_bound = u;

      if (debug_level >= 2) {
        printf("Iteration %5d: norm bound =", pslq_iter);
        print(u);
        printf(", max bound =");
        print(max_bound);
        printf("\n");
      }
    }

  } 

  int jm = -1;
  if (result == RESULT_RELATION_FOUND) {
    mp_real u, v;

    /* Output final norm bound. */
    matrix_minmax(y, u, v);
    bound_pslq(h, t);
    printf("Relation detected at iteration %d\n", pslq_iter);
    printf("  min, max of y =");
    print(u);
    print(v);
    printf(", bound = ");
    print(t);
    printf("\n");

    /* Relation found.  Select the relation with smallest norm. */
    u = DBL_MAX;
    for (int j = 0; j < n; j++) {
      if (abs(y(j)) < eps) {
        t = 0.0;

        for (int i = 0; i < n; i++) {
          t += sqr(b(i, j));
        }
        t = sqrt(t);

        if (t < u) {
          u = t;
          jm = j;
        }
      }
    }

    if (jm < 0) {
      fprintf(stderr, "ERROR: Invalid index.\n");
      exit(-1);
    }

    for (int i = 0; i < n; i++) {
      rel(i) = b(i, jm);
    }

  }

  return result;
}

