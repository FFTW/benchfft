/*
 * Contains function used for timing.
 */
#include <sys/time.h>
#include "timer.h"

void tic(TimeVal *tv) {
  gettimeofday(tv, 0L);
}

double toc(TimeVal *tv) {
  TimeVal tv2;
  
  gettimeofday(&tv2, 0L);

  double  sec = (double) (tv2.tv_sec - tv->tv_sec);
  double usec = (double) (tv2.tv_usec - tv->tv_usec);
  
  return (sec + 1.0e-6 * usec);
}  

