#if (ARPREC_HAVE_STD)
#include <cstdio>
#include <cstring>
#include <cfloat>
#include <cmath>
#else
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <math.h>
#endif

#include "mp/mpreal.h"

#include "pslq1.h"
#include "pslq_main.h"

int main(int argc, char **argv) {
  int mode = 0;
  int n;
  int r = 5, s = 5;
  int nr_digits   = 180;
  int n_eps;

  /* Parse command line arguments. */
	parse_command(argc, argv, mode, n, r, s, nr_digits, n_eps);

  n = r * s + 1;
  n_eps = (nr_digits < 60 ? 10 : 20) - nr_digits;

  printf("nr_digits = %d\n", nr_digits);
  printf("debug_level = %d\n", debug_level);
  printf("n = %d\n", n);
  if (debug_level > 0) {
    printf("r = %d, s = %d\n", r, s);
    printf("n_eps = %d\n", n_eps);
  }


  /* Initialize data */
  mp::mp_init(nr_digits);
  matrix<mp_real> x(n);
  matrix<mp_real> rel(n);
  mp_real eps = power(mp_real(10.0), n_eps);

  init_data(mode, n, r, s, x, rel);

  if (debug_level > 0) {
    x.print("Initial x:");
  }

  /* Perform Level-1 PSLQ. */
  int result = pslq1(x, rel, eps);

  if (result == RESULT_RELATION_FOUND) {
    puts("Relation found:");
    for (int i = 0; i < n; i++) {
      printf("%3d  ", i);
      print(rel(i));
      printf("\n");
    }
  } else {
    puts("Precision exhausted.");
  }

  /* Output recovered relation. */

  mp::mp_finalize();
  return 0;
}

