/*
 * Contains function used for timing.
 */

#ifndef _TIMER_H_
#define _TIMER_H_

#include <sys/time.h>

typedef struct timeval TimeVal;

void   tic(TimeVal *tv);   /* start timing. */
double toc(TimeVal *tv);   /* stop  timing. */

#endif  /* _TIMER_H_ */

