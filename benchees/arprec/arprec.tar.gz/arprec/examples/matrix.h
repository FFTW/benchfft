#ifndef MP_MATRIX_H_
#define MP_MATRIX_H_

/* To enable index bounds check, set this flag to 1. */
#define MATRIX_DEBUG 0

/* 
 * class matrix<T>
 *
 * Simple template for a matrix class. 
 * Matrix elements are accessed through the (i, j) operator:  a(i, j).
 * All data are stored in column major format.  The access a(i) is
 * also allowed (for vectors).  If T is a type with contiguous data, 
 * then matrix<T> will store its elements in a contiguous block.
 *
 * Note that matrix<T> derives from matrix_base<T>, since 
 * The matrix_base<T> class does no initialization.  Use the matrix<T>
 * class instead.  This is done due to incompatible constructor 
 * between T = double and T = mp_real, to make the data contiguous.
 */

template <class T> 
class matrix_base {
protected:
  int n, m;
  T *elements;

  matrix_base<T> () { }
  matrix_base<T> (matrix_base<T> &m) { }
public:

  inline matrix_base(int n0, int m0 = 1) : n(n0), m(m0) { }

  inline int size() const {
    return n * m;
  }

	inline void getSize(int &r, int &c) const {
		r = n;
		c = m;
	}

  inline T &elem(int i) const {
#if (MATRIX_DEBUG)
    if (i < 0 || i >= m*n) {
      cerr << "ERROR: matrix(i): index out of bounds: " << i << endl;
      exit(-1);
    } else
      return elements[i];
#else
    return elements[i];
#endif
  }

  inline T &elem(int i, int j) const {
#if (MATRIX_DEBUG)
    int k = n * j + i;
    if (k < 0 || k >= m*n) {
      cerr << "ERROR: matrix(i, j): index out of bounds: " 
        << i << ", " << j << endl;
      exit(-1);
    }
    return elements[n * j + i];
#else
    return elements[n * j + i];
#endif
  }

  inline T &operator()(int i) const {
    return elem(i);
  }

  inline T &operator()(int i, int j) const {
    return elem(i, j);
  }

  inline T *getElements() const {
    return elements;
  }

  void identity() {
    for (int i = 0; i < n; i++)
      for (int j = 0; j < m; j++)
        elem(i, j) = ((i == j) ? 1.0 : 0.0);
  }

  void zero() {
    for (int i = 0; i < n; i++)
      for (int j = 0; j < m; j++)
        elem(i, j) = 0.0;
  }

  void print(const char *name = NULL) const {
		if (name)
			printf("%s\n", name);
		if (m == 1) {
			for (int i = 0; i < n; i++) {
				::print(elem(i));
			}
			printf("\n");
		} else {
			for (int i = 0; i < n; i++) {
				printf("Row %d\n", i);
				for (int j = 0; j < n; j++) {
					::print(elem(i, j));
				}
				printf("\n");
			}
		}
	}

	inline matrix_base<T> &operator=(const matrix_base<T> &x) {
		if (x.m != m || x.n != n) {
			fprintf(stderr, "ERROR (matrix<T>::operator=): dimension mismatch.\n");
			exit(-1);
		}
		for (int i = 0; i < m*n; i++)
			elements[i] = x.elements[i];
		return *this;
	}

};

template <class T>
class matrix : public matrix_base<T> {
protected:
  matrix (matrix<T> &a) { }
public:
  matrix(int n0, int m0 = 1) : matrix_base<T>(n0, m0) {
    elements = new T[m * n];
  }

  ~matrix() {
    delete [] elements;
  }
};

template <>
class matrix<mp_real> : public matrix_base<mp_real>  {
protected:
  matrix (matrix<mp_real> &a) { }

public:
  matrix(int n0, int m0 = 1) : matrix_base<mp_real>(n0, m0) {
    int mn = m * n;
    elements = mp_real::alloc_array(mn);
  }

  ~matrix() {
    mp_real::free_array(elements);
  }

  inline double *getData() const {
    return elements[0].mpr;
  }

	inline matrix<mp_real> &operator=(const matrix<mp_real> &x) {
    matrix_base<mp_real>::operator=(x);
    return *this;
  }

};

#endif

