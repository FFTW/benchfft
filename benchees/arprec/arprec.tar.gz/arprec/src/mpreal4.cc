/*
 * src/mpreal4.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 * Additional routines, mostly those for which speed is less important.
 */
#include "mp/mpreal.h"

/*
#ifndef drand48
double drand48(void);
#endif
*/

void mp_real::mpdexc(const char a[], int l, mp_real& b)
{
  /**
   * This routine converts the character*1 string A, which
   * represents a multiprecision number in Fortran style, i.e.
   * '1234567890' or '1.23456789D-21', into standard MP binary format.
   * This routine is not intended to be called directly by the user.
   *
   * This routine has not been thoroughly tested.
   */

  int i;
  int foundExponent = 0;

  for( i = 0; i < l; i++) {
    if (a[i] == 'D' || a[i] == 'E' || a[i] == 'd' ||
      a[i] == 'e') {
      foundExponent = 1;
      break;
    }
  }

  if (!foundExponent) {
    mpinpc (a, l, b);
    return;
  }
	
  char *c = new char[mpipl+101];
  int i1 = i + 1; 
  int l1 = i; 
  int l2 = l - i1; 
  c[0] = '1';
  c[1] = '0';
  c[2] = '^';
  
  for (i = 0; i < l2; ++i) c[i+3] = a[i+i1];
  
  c[l2+3] = 'x';
  
  for (i = 0; i < l1; ++i) c[i+l2+4] = a[i];
  c[i+l2+4]='\0';
	
  mpinpc(c, l1+l2+4, b);
  delete [] c;
  return;
}


void mp_real::mpinpc (const char a[], int n, mp_real& b)
{
  /**
   * Converts the char[] array A of length N into the MP number B.  The
   * string A must be in the format '10^s a x tb.c' where a, b and c are digit
   * strings; s and t are '-', '+' or blank; x is either 'x' or '*'.  Blanks
   * may be embedded anywhere.  The exponent digit string a is limited to 
   * nine digits and 80 total characters, including blanks.  
   * The exponent portion (i.e. the portion up to and including x) 
   * and the period may optionally
   * be omitted.
   * Debug output starts with MPIDB = 7.
   *
   * This routine has not been thoroughly tested.
   */
  int i, j, is, id; 
  double bi;
  char ai;
  mp_real f(9), sk0(mpnw+6), sk1(mpnw+6), sk2(mpnw+6);
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(b);
    return;
  }
  
  if (MPIDB >= 7) {
    int no = MIN (n, int (7.225 * MPNDB) + 20);
    cerr << "MPINPC I ";
    for(i = 0; i < no; ++i) {
      cerr << a[i];
      if (i%78 == 0) cerr << endl;
    } 
  }
  
  char *ca = new char[81];
  //int nws = mpnw++;
  int i1 = 0;
  int nn = 0;
  
  //  Find the carat, period, plus or minus sign, whichever comes first.
  
  bool caretFound = false;
  
  for (i = 0; i < n; ++i) {
    ai = a[i];
    if (ai == '^') {
      caretFound = true;
      break;
    }
    if (ai == '.' || ai == '+' || ai == '-') break;
  }
  
  for (j = 0; j < 81; ++j) ca[j]='\0';
	
  if (caretFound) {
    // Make sure number preceding the caret is 10.
    int i2 = i-1;
    if (i2 > 79) {
      delete [] ca;
      mpinpcExit();
      return;
    }
		
    j = 0;
    for (i = 0; i <= i2; ++i) {
      ai = a[i];
      if (ai == ' ') continue;
      else if (!isdigit(ai)) {
        delete [] ca;
        mpinpcExit();
        return;
      }
      ca[j++] = ai;
    }

    if (ca[0]!='1' || ca[1]!='0') {
      delete [] ca;
      mpinpcExit();
      return;
    }

    // Find the x or *.
    i1 = i2 + 2; // first char after carat
    bool exit = true;
    for (i = i1; i < n; ++i) {
      ai = a[i];
      if (ai == 'x' || ai == '*') {
        exit = false;
        break;
      }
    }
    if (exit) {
      delete [] ca;
      mpinpcExit();
      return;
    }
		
    //  Convert the exponent.
    i2 = i - 1;
    int l1 = i2 - i1;
    if (l1 > 79) {
      delete [] ca;
      mpinpcExit();
      return; 
    }
    id = 0;
    is = 1;
    j = 0;
    for (i = 0; i <= l1; ++i) {
      ai = a[i+i1];
      if (ai == ' ' || ai == '+') continue;
      else if (ai == '-' && id == 0) {
        id = 1;
        is = -1;
      } else {
        if (!isdigit(ai)) {
          delete [] ca;
          mpinpcExit();
          return;
        }
        id = 1; 
        ca[j++] = ai;
      }
    } // end for i = ...

    ca[j]='\0';
    nn = atoi(ca);
    nn = is * nn;
    i1 = i2 + 2;
  } // end if (caretFound) ...

  //  Find the next nonblank character.
  bool exit = true;
  for (i = i1; i < n; ++i) {
    if (a[i] != ' ') {
      exit = false;
      break;
    }
  }
  if (exit) {
    delete [] ca;
    mpinpcExit();
    return;
  }
  
  //  Check if the nonblank character is a plus or minus SIGN.
  i1 = i;
  if (a[i1] == '+') {
    i1 = i1 + 1;
    is = 1;
  } else if (a[i1] == '-') {
    i1 = i1 + 1;
    is = -1;
  } else {
    is = 1;
  }

  int nb = 0;
  int ib = 0;
  id = 0;
  zero(sk2);
  f[1] = 1.;
  f[2] = 0.;
  int ip;     // position of period
  int it = 0; // iteration count
  
  int mm;
  bool cont = true;
  while (cont) {
    ip = 0;
    for (mm = 0; mm < 6; ++mm) ca[mm]='0';
		
    //  Scan for digits, looking for the period also. On the first pass we just
    //  count, so that on the second pass it will come out right.
    for (i = i1; i < n; ++i) {
      ai = a[i];
      if (ai == ' ') {
      } else if (ai == '.') {
        if (ip != 0) {
          delete [] ca;
          mpinpcExit();
          return;
        }
        ip = id; // period removed in the 1st pass, but position remembered
      } else if(ai == ',' || ai == '\t' || ai == '\r' || ai == '\n') {
	ai = ' ';
      } else if (!isdigit(ai)) {
        delete [] ca;
        mpinpcExit();
        return;
      } else {
        id++;
        ca[ib++] = ai;
      }
      if (ib == 6 || i == (n-1) && ib != 0) {
        if (it != 0) { // second pass
          nb++;
          ca[ib]='\0';
          
          bi = atoi(ca);
					
          mpmuld (sk2, 1e6, 0, sk0);
          
          if (bi != 0) {
	    f[1] = 1.;
            f[3] = double(bi); // *cast*
          } else {
	    f[1] = 0.;
          }
          mpadd (sk0, f, sk2);
          for (mm = 0; mm < 6; ++mm) ca[mm]='0';
        }
        if ( (i+1) != n ) ib = 0;
      }
    } // for i = ...
    
    if (it == 0) {
      ib = 6 - ib;
      if (ib == 6) ib = 0; // digits are multiple of 6
      it = 1;
    } else
      cont = false;
  }
  
  if (is == -1) sk2[1] = -sk2[1];
  if (ip == 0) ip = id;
  
  nn = nn + ip - id;
  f[1] = 1.;
  f[3] = 10.;
  mpnpwr(f, nn, sk0);
  mpmul(sk2, sk0, sk1);
  mpeq(sk1, b);
  mproun(b);
  
  delete [] ca;
  if (MPIDB >= 7) print_mpreal((char*)"MPINPC O ", b);
  return;
}

void mp_real::mpinpcExit()
{
  /**
   * A helper function for mpinpc.
   */
  if (MPKER[41] != 0) {
    cerr << "*** MPINPC: Syntax error in literal string.\n";
    MPIER = 41;
    if (MPKER[MPIER] == 2)  mpabrt();
  }
}


void mp_real::mppi(mp_real& pi)
{
  /**
   * This computes Pi to available precision (MPNW mantissa words). For
   * extra high levels of precision, use MPPIX.  The last word of the
   * result is not reliable.  Debug output starts with MPIDB = 7.
   *
   * Required space in pi : mpnw + 4 cells.
   * 
   * The algorithm that is used for computing Pi, which is due to Salamin
   * and Brent, is as follows: 
   *
   * Set A_0 = 1, B_0 = 1/Sqrt(2), and D_0 = Sqrt(2) - 1/2.
   * 
   * Then from k = 1 iteratoe the following operations:
   * 
   * A_k = 0.5 * (A_{k-1} + B_{k-1})
   * B_l = Sqrt (A_{k-1} * b_{k-1})
   * D_k = D_{k-1} - 2^k * (A_k - B_k) ^2.
   * 
   * The P_k = (A_k + B_k) ^2 / D_k  converges quadratically to Pi.
   * In other words, each iteration approximately doubles the 
   * number of correct digits, providing all iterations are
   * done with the maximum precision.
   */
  const double cl2 = 1.4426950408889633;
  
  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(pi);
    return;
  }

  // Perform calculations to one extra word accuracy.
  double t1;
  int mq, k;
  int nws = mpnw;
  size_t n6 = (size_t)(mpnw +6);
  mpnw++;
  mp_real sk0(n6),
    sk1(n6),
    sk2(n6),
    sk3(n6),
    sk4(n6),
    f(size_t(8));
    
  // Determine the number of iterations required for the
  // given precision level.
  
  t1 = nws * log10(mpbdx);
  mq = int(cl2 * (log(t1) - 1.0) + 1.0);
  
  // Initialize as above.
  //sk0 = 1.0;
  sk0[1] = 1.0; sk0[2] = 0.0; sk0[3] = 1.0;
  //f = 2.0;
  f[1] = 1.0; f[2] = 0.0; f[3] = 2.0; f[4] = 0.0;
  mpsqrt(f, sk2);
  mpmuld(sk2, 0.5, 0, sk1);
  // f = 1/2;
  f[2] = -1; f[3] = 0.5 * mpbdx;
  mpsub(sk2, f, sk4);

  // Perform iterations as described above.
  
  for(k=1; k<=mq ; k++) {
    mpadd(sk0, sk1, sk2);
    mpmul(sk0, sk1, sk3);
    mpsqrt(sk3, sk1);
    mpmuld(sk2, 0.5, 0, sk0);
    mpsub(sk0, sk1, sk2);
    mpmul(sk2, sk2, sk3);
    t1 = pow(2.0, k);
    mpmuld(sk3, t1, 0, sk2);
    mpsub(sk4, sk2, sk3);
    mpeq(sk3, sk4);
  }
  
  // Complete computation.
  
  mpadd(sk0, sk1, sk2);
  mpmul(sk2, sk2, sk3);
  mpdiv(sk3, sk4, sk2);
  mpeq(sk2, pi);
  
  // Restore original precision level.
  mpnw = nws;
  mproun(pi);
  
  if(MPIDB >= 7) cout <<"\nComputed Pi : "<< pi;
  return;
}

void mp_real::mprand(mp_real& a)
{
  // This returns a pseudo-random MP number A between 0 and 1. 
  // Debug output starts with MPIDB == 9.
  // Please note : if drand48 is used elsewhere, 
  // This sequence may not be repeateable!

  double t1;
  int nwds;

  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(a);
    return;
  }
  
  nwds = MIN(mpnw, int(a[0])-5);

  a[1] = nwds;
  a[2] = -1.0;
  if(mpnbt > 48) {
    for(int i =FST_M; i<nwds+FST_M;i++) {
      t1 = drand48(); //drand48()in [0.0, 1.0)
      t1 += 0.125 * drand48();
      t1 /= 1.125; // drand48 only has 48 bit random numbers, we need mpnbt bits
      a[i] = aint(t1 * mpbdx);
    }
  } else {
    for(int i =FST_M; i<nwds+FST_M;i++) {
      a[i] = aint(drand48() * mpbdx);
    }
  }
  a[nwds+FST_M] = a[nwds+FST_M+1] = 0.0;

  // possibly (very unlikely) there are leading or trailing zeros.
  mproun(a);
  
  if(MPIDB >= 9)
    cout << "\nMPRAND 0";
  return;
}

void mp_real::mpsort(int n, mp_real *a, int *ip)
{
  /**
   * This routine sorts the entries of the N-long
   * MP vector A into ascending order using the quicksort agorithm.
   * The permutation vector that would sort the vector is returned in IP.
   */
  int left, right, lowest, highest;
  int low_stack[50], high_stack[50];
  int stack_counter=0;
  int temp, pivot_spot;
  mp_real pivot_value;
  int i;
  if(n<=1)
    return;

  /* setup phase */
  low_stack[stack_counter] = 0;
  high_stack[stack_counter] = n-1;

  for(i=0;i<n;i++) 
    ip[i] = i;
  /* main loop */
  while(stack_counter >= 0) {
    lowest = left = low_stack[stack_counter];
    highest = right = high_stack[stack_counter];
    
    if((right - left) <= 0) {
      stack_counter--;
      continue;
    }
    if((right-left) == 1) {
      if(a[ip[left]] > a[ip[right]]) {
	//swap 
	temp = ip[left];
	ip[right] = ip[left];
	ip[left] = temp;
      }
      stack_counter--;
      continue;
    }

    /*partition phase*/
    /* pick pivot from the middle- it is likley that the a vector 
       is almost in order */
    pivot_spot = (left + right + 1) /2;
    //Swap left with pivot.
    temp = ip[left];
    ip[left] = ip[pivot_spot];
    ip[pivot_spot] = temp; 
    pivot_spot = left;
    
    pivot_value = a[ip[left++]];
    while(left < right) {
      while(a[ip[left]] < pivot_value && left<highest)
	left++;
      while(a[ip[right]] >= pivot_value && right >lowest)
	right--;
      if(left<right) {
	temp = ip[left];
	ip[left] = ip[right];
	ip[right] = temp;
      }
    }
    //swap pivot and ip[right]
    temp = ip[pivot_spot];
    ip[pivot_spot] = ip[right];
    ip[right] = temp;
    /*additional sort prep phase */

    /* write over current spot on stack */
    if(lowest < right - 1) {
      low_stack[stack_counter] = lowest;
      high_stack[stack_counter] = right-1;
      stack_counter++;
    }
    if(right+1 < highest) {
      low_stack[stack_counter] = right+1;
      high_stack[stack_counter] = highest;
    } else {
      stack_counter--;
    }
  }
  return;  
}


istream& operator>>(istream& s, mp_real& ja)
{
  char *az = new char[mp::mpipl + 102];
  int i=0;
  az[0] = 0;
  while(i<mp::mpipl+100 && az[i] != ',' && !s.eof()) {
    s.get(az[++i]);
  }
  az[i+1] = 0;
  printf("\nstring is ::%s::\n", az+1);
  mp_real::mpinpc(az+1, i, ja);
  delete [] az;
  return s;
}

#ifdef ARPREC_HAS_QD
dd_real to_dd_real(mp_real &a)
{
  /**
   * Rounds to dd_real.
   * This method is very inefficient, try to 
   * avoid using it in nested loops.
   */
  mp_real temp1, temp2;
  double hi;
  int nhi;
  mp_real::mpmdc(a, hi, nhi);
  mp_real::mpdmc(hi, nhi, temp1);
  mp_real::mpsub(a, temp1, temp2);
  double lo;
  int nlo;
  mp_real::mpmdc(temp2, lo, nlo);
  if(nhi)
    hi *= pow(2.0, nhi);
  if(nlo)
    lo *= pow(2.0, nlo);
  return dd_real(hi, lo);
}
#endif

void mp_real::read_mp_real(istream& in, mp_real& a)
{
  /** 
   * reads an mp_real number in from the stream IN and places the
   * result in A.  The form of the mp_real is a linear array of
   * doubles, which is copied into the mpr array of A.
   * beware that input formatting is machine dependent
   */
  double in0, a0;
  union {
    double d;
    char c[sizeof(double)];
  } temp;
  int i;
  a0 = a[0];
  in.read(&temp.c[0], sizeof(double));
  in0 = temp.d;
  if(!in || in0 <FST_M+2 || in0 > 10000000) {
    cerr << "\n*** READ_MP_REAL : Error reading in istream.";
    mpabrt();
  }
  // if(in0 > a0) then we truncate
  for(i=1;!in.eof() && i<int(MIN(in0, a0));i++) {
    in.read(&temp.c[0], sizeof(double));
    a[i] = temp.d;
  }
  for(;!in.eof() && i<in0;i++) {
    //truncate.
    in.ignore(sizeof(double));
  }
  if(i < int(in0)) {
    //eof
    cerr << "\n*** READ_MP_REAL : Prematurre end of stream.";
    mpabrt();
  }
  a[1] = SIGN(1.0, a[1]) * MIN(a[1], a[0]-FST_M-2);
  return;
}

void mp_real::write_mp_real(ostream& out, const mp_real& a)
{
  /** 
   * Writes the mp_real number A out to the stream OUT.
   * The form of the output is a linear array of 
   * doubles, which is copied from the mpr array of A.
   * beware that output formatting is machine dependent
   */
  double a0;
  union {
    double d;
    char c[sizeof(double)];
  } temp;
  int i;
  a0 = a[0];
  if(!out) {
    cerr << "\n*** WRITE_MP_REAL : Error writing to istream.";
    mpabrt();
  }
  temp.d = a0;
  out.write(&temp.c[0], sizeof(double));
  for(i=1;i<int(ABS(a[1])+FST_M);i++) {
    temp.d = a[i];
    out.write(&temp.c[0], sizeof(double));
  }
  temp.d = 0.0;
  for(;i<int(a0);i++) {
    out.write(&temp.c[0], sizeof(double));
  }
  return;
}
