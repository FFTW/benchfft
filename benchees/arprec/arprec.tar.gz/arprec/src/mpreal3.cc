/*
 * src/mpreal3.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 * This file contains more modest precision routines.
 */
#include "mp/mpreal.h"

void mp_real::mpout(const mp_real& a, int la, char* cs, int& l)
{
  /**
   * This routine writes the exponent plus LA mantissa digits of the MP number
   * A to the character array CS. CS must
   * be dimensioned at least LA + 25.  The digits of A may span more than one
   * line (newlines are included in the array).  
   * A comma is placed at the end of the last line to denote the end of
   * the MP number.  Here is an example of the output:
   *
   * 10 ^  -4 x  3.14159265358979323846264338327950288419716939937510,
   */

  int ll, nws;
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    return;
  }
  
  nws = mpnw;
  ll = int(la / log10 (mpbdx) + 3.0);
  mpnw = MIN (mpnw, ll);

  mpoutc(a, cs, l);

  mpnw = nws;
  l = MIN (l, la + 20) + 1;
  if(isdigit(cs[l-1]) && cs[l-1] >= '5') {
    int i;
    for(i=l-2;i>0 && cs[i] == '9'; i--);
    if(!i) {
      //This shouldn't happen.
      assert(0);
    }
    if(cs[i] == '.') {
      if(cs[i-1] == '9') {
	//This is a bug.  This should push the exponent up by one.
	//instead, it just leaves a bunch of nines.
	long exponent;
	int n=i, j= l-1;
	for(i=0;i<j && cs[i] != '^';i++);
	if(i == j){
	  cerr << "\n*** MPOUT : error when rounding 9's";
	  cs[l-1] = ',';
	  cs[l] = '\0';
	  return;
	}
	for(;j>i && cs[j] != 'x';j--);
	if(i == j) {
	  cerr << "\n*** MPOUT : error when rounding 9's";
	  cs[l-1] = ',';
	  cs[l] = '\0';
	  return;
	}
	cs[j] = '\0';
	exponent = atol(cs+i+1);
	cs[j] = 'x';
	exponent++;
	sprintf(cs + (j-10), "%10ld", exponent);
	
	cs[n-1] = '1';
	cs[n+1] = ',';
	cs[n+2] = '\0';
	l = n+2;
      } else {
	cs[i-1]++;
	cs[i+1] = ',';
	cs[i+2] = '\0';
	l = i+2;
      }
    } else {
      cs[i]++;
      cs[i+1] = ',';
      cs[i+2] = '\0';
      l = i+2;
    }
  } else {
    int i;
    for(i=l-2;i>0 && cs[i] == '0'; i--);
    cs[i+1] = ',';
    cs[i+2] = '\0';
    l = i+2;
  }
  return;
}

void mp_real::mpoutc(const mp_real& a, char* b, int& n)
{
  /**
   * Converts the MP number A into character form in the char array B.
   * N (an output parameter) is the length of the output.  In other words,
   * A is contained in B(1), ..., B(N).  The format is analogous to the
   * Fortran exponential format (E format), except that the exponent is
   * placed first.
   * Debug output starts with MPIDB = 7.
   *
   * Max byte space for B: 15.05 * MPNW + 30 cells.
   *                              ( log10(2^50) * mpnw + 30 )
   * This routine is called by MPOUT, but it may be directly called by the
   * user if desired for custom output.
   *
   */
  int i, j, nn, no, nws;
  const double al2 = 0.301029995663981195; // log10(2)
  double aa, t1;
  char* ca = new char[17];
  int n6 = mpnw + 8;
  mp_real f(9), sk0(n6), sk1(n6);
  int BreakLoop, Loop;
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    b[0] = '\0';
    n = 0;
    return;
  }
	
  if (MPIDB >= 7) print_mpreal((char*)"MPOUTC I ", a);
	
  int ia = int(SIGN(1.0, a[1]));
  int na = MIN (int(ABS(a[1])), mpnw);
  nws = mpnw;
  mpnw = mpnw + 1;
  f[1] = 1.;  // MP number 10.
  f[2] = 0.;
  f[3] = 10.;
  
  //  Determine exact power of ten for exponent.
  int nx;
  if (na != 0) {
    aa = a[3];
    if (na >= 2) aa = aa + mprdx * a[4];
    if (na >= 3) aa = aa + mprx2 * a[5];
    if (na >= 4) aa = aa + mprdx * mprx2 * a[6];
    t1 = al2 * mpnbt * a[2] + log10 (aa);
    if (t1 >= 0.0) 
      nx = int(t1); // *cast*
    else 
      nx = int(t1 - 1.0); // *cast*
    
    if(nx >=0) {
      mpnpwr(f, nx, sk0);
      mpdiv(a, sk0, sk1);
    } else {
      mpnpwr(f, -nx, sk0);
      mpmul(a, sk0, sk1);
    }
    // If we didn't quite get it exactly right, multiply or divide by 10 to fix.
    Loop = 1;
    while (Loop) {
      if (sk1[2] < 0) { // exponent < 0
        --nx;
        mpmuld(sk1, 10.0, 0, sk0);
        mpeq(sk0, sk1);
      } else if (sk1[3] >= 10.) {
        ++nx;
        mpdivd (sk1, 10.0, 0, sk0);
        mpeq (sk0, sk1);
      } else {
	Loop = 0;
      }
    }
    sk1[1] = ABS(sk1[1]);
  } else {
    nx = 0;
  }
  
  // Now sk1 < 10
  // Place exponent first instead of at the very end as in Fortran.
  b[0] = '1';
  b[1] = '0';
  b[2] = ' ';
  b[3] = '^';
  sprintf(ca, "%10d", nx);
  int len = strlen(ca);
  int blank = 14-len;
  for(i = 4; i < blank; i++) b[i]=' ';
  for(i = 0; i < len; i++) b[blank+i] = ca[i]; 
  b[14] = ' ';
  b[15] = 'x';
  b[16] = ' ';
	
  //  Insert sign and first digit.
  if (ia == -1) b[17] = '-';
  else b[17] = ' ';
  if (na != 0) 
    nn = int(sk1[3]); // in [1, 10)
  else nn = 0;
  sprintf(ca, "%1d", nn);   
  b[18] = ca[0];
  b[19] = '.';
  int ix = 20;
  if (na == 0) {     
    n = ix;
    mpnw = nws;
    if (MPIDB >= 7) {
      no = MIN (n, 6 * MPNDB + 20);
      cerr << "MPOUTC O "; 
      for(i = 0; i < no; i++) cerr << b[i];
    }
    delete [] ca;
    b[n]='\0';
    return;
  }
	
  f[3] = double(nn); // *cast*
  mpsub (sk1, f, sk0); // remainder
  
  if (sk0[1] == 0) {     
    n = ix;
    if (MPIDB >= 7) {
      no = MIN (n, 6 * MPNDB + 20);
      cerr << "MPOUTC O "; 
      for(i=0; i<no; i++)
        cerr << b[i];
    }
    delete [] ca;
    b[n]='\0';
    return;
  }

  mpmuld (sk0, 1e6, 0, sk1);
  int nl = int(MAX (mpnw * log10 (mpbdx) / 6.0 - 1.0, 1.0));
  int mpnw_change = int(mpnbt * log(double(2.0))/log(double(10.0))/6.0)+2;

  //  Insert the digits of the remaining words. 6 decimal digits at a time.
  BreakLoop = 0;
  for (j = 1; j <= nl; ++j) {
    if (sk1[2] == 0.) {
      assert(sk1[3] <= 2e9);
      nn = int(sk1[3]);
      f[1] = 1;
      f[3] = double(nn);
    } else { // exponent < 0
      f[1] = 0;
      nn = 0;
    }
    
    sprintf(ca, "%6d", nn);
    for (i = 0; i < 6; ++i) b[i+ix] = (ca[i] != ' ' ? ca[i] : '0');
    
    ix += 6;
    mpsub(sk1, f, sk0);
    mpmuld(sk0, 1e6, 0, sk1);
    if (sk1[1] == 0) {
      BreakLoop = 1;
      break;
    }
    if(!((j) % (mpnw_change))) {
      mpnw--;
    }
  }

  //  Check if trailing zeroes should be trimmed.
  if (!BreakLoop) j = nl + 1;
  
  int l = --ix;
  if (b[l] == '0' ||
      (j > nl && b[l-1] == '0' && b[l-2] == '0' && b[l-3] == '0')) {
    b[l] = '\0';
    BreakLoop = 0;
    for (i = l - 1; i >= 20; --i) {
      if (b[i] != '0') {
        ix = i;
	BreakLoop = 1;
        break;
      }
      b[i] = '\0';
    }

    if (!BreakLoop) ix = 20;
    
  } else if (j > nl && b[l-1] == '9' && b[l-2] == '9' && b[l-3] == '9') {
    // Check if trailing nines should be rounded up.
    b[l] = '\0';
    int roundUp=0;

    BreakLoop = 0;
    for (i = l - 1; i >= 20; --i) {
      if (b[i] != '9') {
        BreakLoop = 1;
        break;
      }
      roundUp = 1;
      b[i] = '\0';
    }
    
    // We have rounded away all digits to the right of the decimal point,
    // and the digit to the left of the digit is a 9.  Set the digit to 1
    // and increase the exponent by one.
    if (!BreakLoop) {
      ix = 20;
      if (b[18] == '9') {
        b[18] = '1';
        sprintf(ca, "%10d", nx+1);
        for (i = 0; i < 10; ++i) b[i+4] = ca[i];   
      } else {
        ca[0] = b[18]; ca[1]='\0';
        nn = atoi(ca);
        sprintf(ca, "%1d", nn+1);
        b[18] = ca[0];
      }
    } else if(roundUp){
      ca[0] = b[i]; ca[1]='\0';
      nn = atoi(ca);
      sprintf(ca, "%1d", nn+1);
      b[i] = ca[0];
      ix = i;
    }
  } 
  
  n = ix;
  if (MPIDB >= 7) {
    no = MIN (n, 6 * MPNDB + 20);
    cerr << "MPOUTC O "; 
    for(i = 0; i <= no; ++i) cerr << b[i];
    cerr << endl;
  }
  b[++n]='\0';
  mpnw = nws;
  delete [] ca;
  return;
}
