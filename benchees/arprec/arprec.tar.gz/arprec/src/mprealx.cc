/*
 * src/mprealx.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 * This file contains the basic routines for very high levels of precision,
 * > 1000 digits.
 *
 * The main routines among these  mpmulx, which employs FFT for the
 * convolution in multiplication, and mpinix, which initializes certain
 * root of unity arrays for the fft.
 * All other routines in this file are here only to help mpmulx.
 *
 */
#include "mp/mpreal.h"


void mp_real::mpmulx(const mp_real& a, const mp_real& b, mp_real& c)
{
  /**
   * This routine multiplies MP number A and B to yield the MP product C.
   * Before calling MPMULX, the arrays UU1 and UU2 must be initialized by
   * calling MPINIX.  For modest levels of precision, use MPMUL.  Debug
   * output starts with MPIDB == 8.
   *
   * This routine returns up to mpnw mantissa words of the product.  
   * If the complete double-long product of A and B is desired (for example
   *  in large integer applications), then mpnw must be at least as large
   * as the sum of the mantissa lengths of a and b.  In other words, if the
   * precision levels of a and b are both 256 words, then mpnw must be at least
   * 512 words to obtain the complete double-long product in C.
   *
   * This subroutine uses an advanced technique involving the FFT.
   * For high precision it is significantly faster than the conventional
   * scheme used in MPMUL.
   */
  

  double t1, t2;
  int ia, ib, na, nb, ncr, i, nn, nc, nx;
  int na2, nb2;

  if(MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(c);
    return;
  }
  if (MPIDB >= 8) {
    cout << "\nMPMULX I";
  }
  
  ia = SIGN(1, int(a[1]));
  ib = SIGN(1, int(b[1]));
  na = MIN(int(ABS(a[1])), mpnw);
  nb = MIN(int(ABS(b[1])), mpnw);
  ncr = 1 << mpmcrx; // pow(2.0, mpmcrx);
  if(!na || !nb) {
    // one of the inputs is zero -- result is zero.
    zero(c);
    return;
  }

  // Check if precision level of one of the arguments is 
  // enough to justify the advanced routine.
  
  if(na <= ncr || nb <= ncr) {
    mpmul(a, b, c);
    return;
  }

  double *d1 = new double[4*mpnw+8];
  double *d2 = new double[4*mpnw+8];
  double *d3 = new double[8*mpnw+16];
  const double mp_down14 = 1.0 / 4096.0;
  const double mp_down24 = mprbx;
  const double mp_down34 = mp_down14 * mp_down24;
  const double mp_up14 = 4096.0;
  const double mp_up24 = mpbbx;
  const double mp_up34 = mp_up24 * mp_up14;

  // Place the input data in A and B into the scratch arrays DD1 and 
  // DD2.  this code alsp splits the input data into fourth sized words.
  // (mpnbt/4) bits for each new word (maximum)
  int i2=1;
  na2 = 4*na;
  nb2 = 4*nb;
  for(i=0;i<na;i++) {
    i2 = 4*i;
    t1 = a[i+FST_M];
    t2 = FLOOR_POSITIVE(mp_down34*t1);
    d1[i2] = t2;
    t1 -= mp_up34 * t2;
    t2 = int(mp_down24*t1);
    d1[i2+1] = t2;
    t1 -= mp_up24 * t2;
    t2 = int(mp_down14*t1);
    d1[i2+2] = t2;
    t1 -= mp_up14 * t2;
    d1[i2+3] = t1;
  }

  for(i = na2;i<nb2;i++)
    d1[i] = 0.0;

  for(i=0;i<nb;i++) {
    i2 = 4*i;
    t1 = b[i+FST_M];
    t2 = FLOOR_POSITIVE(mp_down34*t1);
    d2[i2] = t2;
    t1 -= mp_up34 * t2;
    t2 = int(mp_down24*t1);
    d2[i2+1] = t2;
    t1 -= mp_up24 * t2;
    t2 = int(mp_down14*t1);
    d2[i2+2] = t2;
    t1 -= mp_up14 * t2;
    d2[i2+3] = t1;
  }

  for(i = nb2;i<na2;i++)
    d2[i] = 0.0;

  // Call the convolution

  nn = MAX(na2, nb2);
  nx = int(ANINT(sqrt(3.0 * nn) + mprxx));
  mplconv(2, nn, nx, d1, d2, d3);

  // Recombine words and release carries.

  nc = MIN(na + nb, mpnw+3);
  int nc1 = nc-1;
  d1[1] = ia+ib ? nc : -nc;
  d1[2] = a[2] + b[2] + 1;

  d1[3] = d3[0] * mp_up24 + d3[1] * mp_up14 + d3[2];
  d1[nc+FST_M+1] = d1[nc+FST_M+2] = 0.0;
  
  for(i=0;i<nc1;i++) {
    i2 = i * 4 + 3;
    t1 = d3[i2];
    t2 = FLOOR_POSITIVE(t1 * mp_down14);
    t1 -= t2 * mp_up14;
    d1[i+FST_M] += t2;
    d1[i+FST_M+1] = t1 * mp_up34;
    t1 = d3[i2+1];
    t2 = int(t1 * mp_down24);
    t1 -= t2 * mp_up24;
    d1[i+FST_M] += t2;
    d1[i+FST_M+1] += t1 * mp_up24;
    t1 = d3[i2+2];
    t2 = int(t1 * mp_down34);
    t1 -= t2 * mp_up34;
    d1[i+FST_M] += t2;
    d1[i+FST_M+1] += t1 * mp_up14 + d3[i2+3];
  }
  //one more to do.
  t1 = d3[i2+4];
  t2 = FLOOR_POSITIVE(t1 * mp_down14);
  t1 -= t2 * mp_up14;
  d1[i+FST_M] += t2;
  d1[i+FST_M+1] = t1 * mp_up34;

  //now go on.
  int d_add=0;
  i=0;
  //eliminate leading zeros (except where something
  // will probably carry in)
  while(i<(nc1-3) && d1[i+FST_M] == 0.0 && d1[i+FST_M+1] < (mpbdx-2.0)) {
    i++;
  }
  if(i) {
    d1[2] -= double(i);
    d1[1] = SIGN(1.0, d1[1]) * (ABS(d1[1])  - double(i));
    d1[i+2] = d1[2];
    d1[i+1] = d1[1];
    d1 += i;
    d_add -= i;
  }

  // Fix up the result;
  mpnorm(d1, c);
  
  if(MPIDB >= 8) {
    cout << "\nMPMULX 0";
  }
  delete [] (d1+d_add);
  delete [] d2;
  delete [] d3;
  return;
}

void mp_real::mplconv(int iq, int n, int nsq, double *a, double *b, double *c)
{
  /**
   * This computes the linear convolution of the N-long inputs A and B.
   * |IQ| is the number of arguments (i.e., if IQ = 1, then B is ignored).
   * If IQ is negative (and N < 64) then only the second half of the result
   * vector is required (i.e. this is a call by itself -- see below).
   * NSQ = int(sqrt(3*N)) is an input required for the dimention of
   * DC1 and DC2 (see below).
   *
   * This routine employs an advanced FFT-based scheme, except for
   * small n.  This rouine is not intende to be called directly by the user.

   * Two machine-dependent parameters are ste in this routine:
   *    ERM = Maximum tolerated FFT roundoff erorr.  On IEEE systems ERM = 
   *    0.438.  It is not necessary to specify ERM for modest levels of
   *    precision -- see comments below.
   *    MBT = Number of mantissa bits in double precision data.  MBT = 53
   *    since this library is intended for IEEE systems only (without
   *    extended registers being used).
   */
  const double cl2 = 1.4426950408889633;
  int ncr1, k, n1, n2, m, m2, m21, m1, nm, i, j, n4;
  double t1 ;
  double td1;
  double temp;

  // Handle the case where N is less than ncr1 = pow(2, mpmcrx-1).
  // if IQ < 0, only the second half of the result vector is returned,
  // since the first half won't be used.

  ncr1 = 1 << (mpmcrx-1);
  if(n < ncr1) {
    if (iq == 1) {
      for(k=0;k<2*n;k++) {
	td1 = 0.0;
	n1 = MAX (k - n +1, 0);
	n2 = MIN(k+1, n);
	
	for(j=n1;j<n2;j++)
	  td1 += a[j] * a[k-j];

	c[k] = td1;
      }
    } else if(iq == 2) {
      for(k=0; k < 2*n; k++) {
	td1 = 0.0;
	n1 = MAX (k - n +1, 0);
	n2 = MIN(k+1, n);
	
	for(j=n1;j<n2;j++)
	  td1 += a[j] * b[k-j];

	c[k] = td1;
      }
    } else if (iq == -1) {
      for(k=0;k<n-1;k++)
	c[k] = 0.0;

      for(k=n-1; k < 2*n; k++) {
	td1 = 0.0;
	n1 = MAX (k - n +1, 0);
	//n2 == n always

	for(j=n1;j<n;j++)
	  td1 += a[j] * a[k-j];

	c[k] = td1;
      }
    } else if (iq == -2) {
      for(k=0;k<n-1;k++)
	c[k] = 0.0;

      for(k=n-1; k < 2*n; k++) {
	td1 = 0.0;
	n1 = MAX (k - n +1, 0);
	//n2 == n always

	for(j=n1;j<n;j++)
	  td1 += a[j] * b[k-j];

	c[k] = td1;
      }
    }
    return;
  }
  
  double *dc1 = new double[6*n + 2*nsq*mpnsp1+6];
  double *dc2 = new double[6*n + 2*nsq*mpnsp1+6]; //for complex numbers
  double *d1 = new double[3*n+2];
  double *d2 = new double[3*n+2];
  double *d3 = new double[3*n+2];


  // Determine M1 and N1.  Note that by this reckoning, N1 <= 1.5 N.
  // This is the reason for the 3*n/2 dimensions above.

  t1 = 0.75 * n;
  m1 = int(cl2 * log(t1) + 1 - mprxx);
  n1 = 1 << m1;
  m2 = m1 + 1;
  n2 = 2 * n1;
  n4 = 2 * n2;
  nm = MIN(2 * n, n2);
  if(ABS(iq) == 1) {
    for(i=0; i<n; i++)
      d1[i] = a[i];

    for(; i<n1; i++)
      d1[i] = 0.0;

    // Perform a forward real-to complex FFT on the vector in a.
    
    mpfftrc(1, m2, n2, n, d1, dc1);

    // square the resulting complex vector;
    for(i=0;i< 2*(n1+1);i+=2) {
      temp = dc1[i] * dc1[i+1];
      dc1[i]  =  sqr( dc1[i] ) - sqr ( dc1[i+1] );
      dc1[i+1] = 2.0 * temp;
    }
      
  } else {
    //ABS(iq) == 2.
    for(i=0;i<n;i++) {
      d1[i] = a[i];
      d2[i] = b[i];
    }
    
    for(i=n;i<n1;i++)
      d1[i] = d2[i] = 0.0;


    // Perform forward real-to-complex FFTs on the vectors in a and in b.
    mpfftrc(1, m2, n2, n, d1, dc1);
    mpfftrc(1, m2, n2, n, d2, dc2);
    

    // Multiply the resulting complex vectors.
      for(i=0;i<(n1+1)*2;i+=2) {
        temp = dc1[i] * dc2[i] - dc1[i+1] * dc2[i+1];
        dc1[i+1] = dc1[i] * dc2[i+1] + dc1[i+1] * dc2[i];
        dc1[i] = temp;
      }
  }

  // Perform an inverse complex-to-real FFT on the resulting data.
  
  mpfftcr(-1, m2, n2, nsq, dc1, dc2);

  // divide by N4.
  double an = 1.0 / n4;
  int ms;
  double td2;
 
  //usually this line is commented out. see below. 
  //#define MPMULX_ROUNDOFF_ERROR_TEST

  for(i=0;i<nm;i++) {
    td1 = an * (dc2[i]);
    td2 = nint(td1); 
#ifdef MPMULX_ROUNDOFF_ERROR_TEST
    d1[i] = ABS(td2 - td1);
#endif
    c[i] = td2;
  }
  
  /**
   * Find the largest FFT roundoff error.  Roundoff error is minimal unless
   * exceedingly high precision (i.e. over one million digits) is used.  Thus
   * this test may be disabled in normal use.  To disable this test,
   * comment out the above definition of MPMULX_ROUNDOFF_ERROR_TEST.
   * 
   * This code can be used as a rigorous system integrity test.
   * First set MBT according to the system being used (see above),
   * then set erm to be fairly small, say 0.001 or whatever is somewhat
   * larger that the largest FFT roundoff error typically encountered for 
   * a given precision level on the computer being used.  Enable this
   * test as explained in the previous paragraph.  Then if an anomalously 
   * large roundoff error is detected, a ahardware or compiler error
   * has likely occurred.
   */
#ifdef MPMULX_ROUNDOFF_ERROR_TEST
  {
    const double erm = 0.438, mbt = 53;
    int i2, i3, i4, i5;
    
    t1 = 0.0;

    for(i=0;i<nm;i++) {
      if(d1[i] > t1) {
	i1 = i;
	t1 = d1[i];
      }
    }
  
    // Check if maximum roundoff error exceeds the limit erm, which is set
    // above.  Also determine the number of fractional bits and how large
    // the error is in terms of units in the last place (ulp).
    if(t1 > erm) {
      if(MPKER[55] != 0) {
	t2 = an * d1[i1];
	i2 = cl2 * log(t1) + 1.0 + mprxx;
	i3 = cl2 * log(t2) + 1.0 + mprxx;
	i4 = mbt + i2 - i3;
	i5 = t1 * (1<<i4) + mprxx;
	cout << "\n*** MPLCONV : Excessive FFT roundoff error: "
	     <<i1 <<"\t"<<t1<<"\t"<<i4<<"\t"<<i5;
	MPIER = 55;
	if(MPKER[MPIER] == 2) mpabrt();
      }
    } 
  } 
#endif
 
  // Handle case where n > n1;
  // In other words, fix a few words if the convolution if
  // It was decided above that it was better to do an
  // FFT of size smaller than n. This can happen
  // when n is just a few more than a power of two.
  // The FFTs are done on power of two sized arrays only.

  if(n > n1) {
    m = n - n1;
    m2 = 2 * m;
    m21 = 2 * m - 1;
    ms = int(ANINT(sqrt(3.0 * m21) + mprxx));
    k = n1 - m + 1;
    if(ABS(iq) == 1) {
      for(i=0;i<m21;i++) 
	d1[i] = a[k+i];
      
      mplconv(-1, m21, ms, d1, d2, d3);
    } else {
      for(i=0;i<m21;i++) {
	d1[i] = a[k+i];
	d2[i] = b[k+i];
      }
      mplconv(-2, m21, ms, d1, d2, d3);
    }
    int ii;
    for(i=0;i<m2;i++) {
      ii = i + m2 - 2;
      c[i] -= d3[ii];
      c[i+n2] = d3[ii];
    }
  }
  delete [] dc1;
  delete [] dc2;
  delete [] d1;
  delete [] d2;
  delete [] d3;

  return;
} // end mp_real::mplconv


void mp_real::mpfftrc(int is, int m, int n, int n_nonzero, double *x, double *y)
{
  /**
   * This performs an N-point real-to-complex FFT, where N == 2^M.  X
   * is the double precision input array, and Y is the double complex output
   * array.  X must be dimensioned with N DP cells, and Y with N/2+N1*NSP1+1
   * cells, where N1 = 2^int(M/2).  This space requirement for Y
   *  is somewhat larger than is used in this function, because
   * MPFFT1, which is called by this function, requires more. IS is the
   * sign of the transform.  Before calling MPFFTRC, the UU1 and UU2 arrays 
   * must initialized by calling mp_initx.  This routine is not intended
   * to be called directly by the user.
   */
  double z1[2], z2[2], a1[2], a2[2], z3[2];
  int mx = int(mpuu1[0]), n1, n2,  n4, k, ku;

  // Check if input parameters are invalid.
  
  if((is != 1 && is != -1) || m<3 || m > mx) {
    if(MPKER[67] != 0) {
      cout <<"\n*** MPFFTRC : either the UU arrays have not been initialized,"
	   <<"\n\t or else one of the input parameters is invalid.";
      MPIER = 67;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }
  
  n1 = 1 << (m /2);
  n2 = n / 2;
  n4 = n / 4;
  double *dc1 = x;
  
  int m1, m2;


  for(k=n_nonzero;k<n;k++) x[k] = 0.0;
  m1 = ((m-1)+1)/2;
  m2 = (m-1) - m1;

  mpfft1(is, m-1, m1, m2, dc1, y);

  // Reconstruct the FFT of X.
  y[0] = 2.0 * (dc1[0] + dc1[1]);
  y[1] = 0.0;

  if(is == 1) {
    y[n2] = 2.0 * dc1[n2]; y[n2+1] = 2.0 * dc1[n2+1];
  } else {
    y[n2] = 2.0 * dc1[n2]; y[n2+1] = -2.0 * dc1[n2+1];
  }
  y[n] = 2.0 * (dc1[0] - dc1[1]); y[n+1] = 0.0;
  ku = n;

  if(is == 1) {
    for(k=2;k<n2;k+=2) {
      z1[0] = dc1[k]; z1[1] = dc1[k+1];
      z2[0] = dc1[n-k]; z2[1] = -dc1[n+1-k];
      //a1 = z1 + z2
      a1[0] = z1[0] + z2[0]; a1[1] = z1[1] + z2[1];
      
      z3[0] = z1[0] - z2[0]; z3[1] = z1[1] - z2[1];
      //a2 = -i * mpuu1(k+ku) * (z1 - z2)
      a2[0] = (mpuu1[(k+ku)] * z3[1]) + (mpuu1[(k+ku)+1] * z3[0]);
      a2[1] = mpuu1[(k+ku)+1] * z3[1] - mpuu1[(k+ku)] * z3[0];
      
      y[k] = a1[0] + a2[0]; y[k+1] = a1[1] + a2[1];
      //y[n2*2-k] = conj(a1 - a2);
      y[n-k] = a1[0] - a2[0]; y[n-k+1] = a2[1] - a1[1];
    }
  } else {
    for(k=2;k<n2;k+=2) {
      z1[0] = dc1[k]; z1[1] = dc1[k+1];
      z2[0] = dc1[n-k]; z2[1] = dc1[n-k+1];
      //a1 = z1 + z2;
      a1[0] = z1[0] + z2[0]; a1[1] = z1[1] + z2[1];

      //a2 = -i * conj( mpuu1[k+ku])  * (z1 - z2);
      z3[0] = z1[0] - z2[0]; z3[1] = z1[1] - z2[1];
      a2[0] = (mpuu1[k+ku] * z3[1]) - (mpuu1[k+ku+1] * z3[0]);
      a2[1] = - (mpuu1[k+ku] * z3[0]) - (mpuu1[k+ku+1] * z3[1]);
      
      y[k] = a1[0] + a2[0]; y[k+1] = a1[1] + a2[1];
      y[n-k] = a1[0] - a2[0]; y[n-k+1] = a2[1] - a1[1];//conj a1 - a2
    }
  }

  return;    
}

void mp_real::mpfft1(int is, int m, int m1, int m2, 
		     double *x, double *y) 
{
  /**
   * 
   *
   * This routine performs a complex-to-complex FFT. IS is the sign of
   * the transform (1 or -1). N = 2^m is the size of the transform.  N1 =
   * 2^M1 and N2 = 2^M2, where M1 and M2 are defined below.  Xi s the input and
   * output array, and Y is a scratch array.  X must have at least N, and Y 
   * at least N + N1 *MPNSP1 double-double complex cells.  The arrays MPUU1
   * and MPUU2 must have beeninitialized by calling MPINIX.  This routine is
   * not intendedto be called directly by the user.
   *
   * This employs the two pass variant of the "four-step" FFT.  See the article
   * by David H. Bailey in J. of Supercomputing, March 1990, p. 23-35. 
   *
   */

  //int n = 1 << m; // 2 ^ m
  //m1 = (m+1)/2;
  int n1 = 1 << m1;
  //m2 = m - m1;
  int n2 = 1 << m2;
  int nr1 = MIN(n1, mpnrow),
    nr2 = MIN(n2, mpnrow);
  int ku = int(mpuu2[2*(m-1)]);
  int i, j, k, iu;
  int n_fft;

  //z1(mpnrow+mpnsp1, n1), x(n1, n2), y(n2+mpnsp1, n1), 
  // z2(mpnrow+mpnsp1, n1)
  // are complex arrays
  int z1_lda =2*(mpnrow)+mpnsp1;
  int x_lda = n1*2;
  int y_lda = 2*(n2)+mpnsp1;
  int z2_lda = z1_lda;
  int z3_lda = z1_lda;
  int z1_col_start, y_col_start, x_col_start, mpuu2_start,
    z2_col_start;
  int z3_col_start;
  double *z1 = (new double[z1_lda*n1]);
  double *z2 = (new double[z2_lda*n1]);
  double *z3;
  
  for(i=0;i<n1;i += nr1) {
    n_fft = MIN(nr1, n1 - i);
    // Copy Nr1 rows of X (treated as a N1 x N2 complex array) into Z1
    for(j=0;j<n2;j++) {
      z1_col_start = z1_lda * j;
      x_col_start = x_lda * j;
      for(k=0;k<n_fft*2;k+=2) {
	z1[z1_col_start+k] = x[x_col_start + (i*2)+k];
	z1[z1_col_start+k+1] = x[x_col_start+(i*2)+k+1];
      }
    }
    
    // Perform roughly NR1 FFTs, each of length N2.

    mpfft2(is, n_fft, m2, n2, z1, z2, z3);
  
    // Multiply the resulting NR1 x N2 complex block by roots of unity
    // and store transposed into the appropreate section of Y.
   
    iu = i+ ku;// -n1 -1;
    iu = iu*2;
    if(is == 1) {
      if(i == 0) {
	for(k=0;k<n_fft;k++) {
	  y[k*y_lda] = z3[2*k];
	  y[k*y_lda+1] = z3[2*k+1];
	}
	for(j=1;j<n2;j++) {
	  mpuu2_start = iu + j*n1*2;
	  z3_col_start = j * z3_lda;
	  y[i*y_lda + j*2] = z3[z3_col_start];
	  y[i*y_lda + j*2+1] = z3[z3_col_start+1];
	  for(k=1;k<n_fft;k++) {
	    //y(j, i+k) = mpuu2(iu+k+j*n1) * z3(k, j)
	    y[(i+k)*y_lda + (j*2)] = 
	      mpuu2[mpuu2_start+2*k] * z3[z3_col_start + 2*k] -
	      mpuu2[mpuu2_start+2*k+1] * z3[z3_col_start + 2*k + 1];
	    y[(i+k)*y_lda + (j*2) + 1] = 
	      mpuu2[mpuu2_start+2*k] * z3[z3_col_start + 2*k + 1] +
	      mpuu2[mpuu2_start+2*k+1] * z3[z3_col_start + 2*k];
	  }
	}
      } else {
	for(j=0;j<n2;j++) {
	  mpuu2_start = iu + j*n1*2;
	  z3_col_start = j * z3_lda;
	  for(k=0;k<n_fft;k++) {
	    //y(j, i+k) = mpuu2(iu+k+j*n1) * z3(k, j)
	    y[(i+k)*y_lda + (j*2)] = 
	      mpuu2[mpuu2_start+2*k] * z3[z3_col_start + 2*k] -
	      mpuu2[mpuu2_start+2*k+1] * z3[z3_col_start + 2*k + 1];
	    y[(i+k)*y_lda + (j*2) + 1] = 
	      mpuu2[mpuu2_start+2*k] * z3[z3_col_start + 2*k + 1] +
	      mpuu2[mpuu2_start+2*k+1] * z3[z3_col_start + 2*k];
	  }
	}
      }
    } else {
      //inverse transform, cojugate mpuu2
      j = 0;
      if(i == 0) {
	for(k=0;k<n_fft;k++) {
	  y[k*y_lda] = z3[2*k];
	  y[k*y_lda+1] = z3[2*k+1];
	}
	j++;
      }
      for(/*j=j*/;j<n2;j++) {
	mpuu2_start = iu + j*n1*2;
	z3_col_start = j * z3_lda;
	for(k=0;k<n_fft;k++) {
	  //y(j, i+k) = conj(mpuu2(iu+k+j*n1)) * z3(k, j)
	  y[(i+k)*y_lda + (j*2)] = 
	    mpuu2[mpuu2_start+2*k] * z3[z3_col_start + 2*k] +
	    mpuu2[mpuu2_start+2*k+1] * z3[z3_col_start + 2*k + 1];
	  y[(i+k)*y_lda + (j*2) + 1] = 
	    mpuu2[mpuu2_start+2*k] * z3[z3_col_start + 2*k + 1] -
	    mpuu2[mpuu2_start+2*k+1] * z3[z3_col_start + 2*k];
	}
      }
    }
  }
  
  for(i=0;i<n2;i+= nr2) {
    // Copy NR2 rows of the Y array into Z2.
    
    n_fft = MIN(nr2, n2 - i);

    for(j=0;j<n1;j++) {
      z2_col_start= j * z2_lda;
      y_col_start = j * y_lda;
      for(k=0;k<n_fft*2;k+=2) {
	z2[z2_col_start + k] = y[i*2+k+y_col_start];
	z2[z2_col_start + k + 1] = y[i*2+k+y_col_start + 1];
      }
    }

    // Perform NR2 FFTs, each of length N1.
    mpfft2(is, n_fft, m1, n1, z2, z1, z3);
    
    // Copy NR2 x N1 complex block back into X array. It's a little more
    // complicated if M is odd.
    
    if(!(m & 0x1)) { // if m is even,...
      for(j=0;j<n1;j++) {
	x_col_start = j * x_lda;
	z3_col_start = j * z3_lda;
	for(k=0;k<2*n_fft;k+=2) {
	  x[x_col_start+(i*2)+k] = z3[z3_col_start + k];
	  x[x_col_start+(i*2)+k+1] = z3[z3_col_start + k + 1];
	}
      }
    } else {
      int j2;
      for(j=0;j<n1/2;j++) {
	j2 = 2 * j;
	x_col_start = j * x_lda;
	z3_col_start = j2 * z3_lda;
	for(k=0;k<n_fft*2;k+=2) {
	  x[x_col_start+(i*2)+k] = z3[z3_col_start + k];
	  x[x_col_start+(i*2)+k + 1] = z3[z3_col_start + k + 1];

	  x[x_col_start+(i*2)+k + 2*n2] = z3[z3_col_start + k + z3_lda];
	  x[x_col_start+(i*2)+k + 2*n2 + 1] =z3[z3_col_start + k + z3_lda + 1];
	}
      }
    }
  }

  delete [] z1;
  delete [] z2;
  return;
}

void mp_real::mpfft3_radix2(int is, int m, int ns, int junk1, int junk2,
		     double *x, double *y) 
{
  /**
   * Computes the first iteration of the radix two Stockham
   *  fft.. used only by mpfft2.
   * This routine is not intended to be called by the user
   *
   * arguments is, junk1, and junk2 are ignored. They are included
   * so that the argument list matches that of mpfft3.
   */
  int i, j, n_half, lda = 2*mpnrow +mpnsp1;
  int pos = 0;

  //n = 1 << m;
  n_half = 1 << (m-1);
  int other_half = lda * n_half;
  
  for(j=0;j<n_half;j++) {
    
    for(i=0;i<ns;i++) {
      y[pos+i*2] = x[pos+i*2] + x[pos+other_half+i*2];
      y[pos+i*2+1] = x[pos+i*2+1] + x[pos+other_half+i*2+1];
      
      y[pos+i*2+other_half] = x[pos+i*2] - x[pos+other_half+i*2];
      y[pos+i*2+other_half+1] = x[pos+i*2+1] - x[pos+other_half+i*2+1];
    }
    pos += lda;
  }
  return;
}


void mp_real::mpfft3(int is, int l, int ns, int m, int n, 
		     double *x, double *y) 
{
  /** 
   * This performs the L-th iteration of 
   * the Stockham FFT on the NS vectors in X.  Y is a scratch array, and UU1
   * is the root of unity array.  X, Y, and UU1 are double complex.  This
   * routine is not intended to be called directly by the user.
   */

  // dimensions : x[mpnrow+mpnsp1, n], y[mpnrow+mpnsp1, n].
  int lda = 2 * mpnrow + mpnsp1 ;
  int x_start_1, y_start_1, x_start, y_start;
  int next_quarter, next_quarter_y;
  double u1[2], u2[2], u3[2];
  register double z1[2], z2[2], z3[2], z4[2], z5[2];
  
  // set initial parameters.
  int L = 1 << l;
  int r = n >> l; // = n / L
  int Ls = L /4;
  //int rs = r * 4;
  int j, k, i;
  int rlda = r*lda;
  int rslda = rlda * 4; // = rs * lda
  int ku = 1 << l, ku2 = ku/2;
  next_quarter = rlda;
  next_quarter_y = rlda << (l-2); // = Ls*r*lda;
  if(is == 1) {
    x_start_1 = y_start_1 = 0;
    for(k=0;k<r;k++) {
      for(i=0;i<ns;i++) {
	z1[0] = x[x_start_1 + i*2];
	z1[1] = x[x_start_1 + 1 + i*2];
	
	z2[0] = x[x_start_1+next_quarter + i*2];
	z2[1] = x[x_start_1+next_quarter + 1 + i*2];
	
	z5[0] = z1[0] - x[x_start_1+2*next_quarter + i*2];
	z5[1] = z1[1] - x[x_start_1+2*next_quarter + i*2 + 1];
	
	z1[0] += x[x_start_1+2*next_quarter + i*2];
	z1[1] += x[x_start_1+2*next_quarter + i*2 + 1];
	
	z3[0] = z2[0] - x[x_start_1+3*next_quarter + i*2]; 
	z3[1] = z2[1] - x[x_start_1+3*next_quarter + i*2 + 1];
	
	z2[0] += x[x_start_1+3*next_quarter + i*2];
	z2[1] += x[x_start_1+3*next_quarter + i*2 + 1]; 
	
	y[y_start_1 + i*2] = z1[0] + z2[0];
	y[y_start_1+1 + i*2] = z1[1] + z2[1];
	
	y[y_start_1+next_quarter_y + i*2] = z5[0] - z3[1];
	y[y_start_1+next_quarter_y+1 + i*2] = z5[1] + z3[0];
	y[y_start_1+3*next_quarter_y + i*2] = z5[0] + z3[1];
	y[y_start_1+3*next_quarter_y+1 + i*2] = z5[1] - z3[0];
	
	y[y_start_1+2*next_quarter_y + i*2] = z1[0] - z2[0];
	y[y_start_1+2*next_quarter_y+ 1 + i*2] = z1[1] - z2[1];
	
      }
      x_start_1 += lda;
      y_start_1 += lda;
    } 
    x_start = 0;
    y_start = 0;
    for(j=1;j<Ls;j++) {
      u1[0] = mpuu1[ku+j*2];
      u1[1] = mpuu1[ku+j*2+1];
      u2[0] = mpuu1[ku2+j*2];
      u2[1] = mpuu1[ku2+j*2+1];
      u3[0] = mpuu3[ku+j*2];
      u3[1] = mpuu3[ku+j*2+1];
      x_start += rslda; // = j*rslda;
      y_start += rlda;// =  j*rlda;
    
      x_start_1 = x_start;
      y_start_1 = y_start;

      for(k=0;k<r;k++) {
	for(i=0;i<ns;i++) {
	  z1[0] = x[x_start_1 + i*2];
	  z1[1] = x[x_start_1 + 1 + i*2];
	  z2[0] = u1[0] * x[x_start_1+next_quarter + i*2] - 
	    u1[1] * x[x_start_1+next_quarter +1 + i*2];
	  z2[1] = u1[0] * x[x_start_1+next_quarter + 1 + i*2] +
	    u1[1] * x[x_start_1+next_quarter + i*2];
	  
	  z3[0] = u2[0] * x[x_start_1+2*next_quarter + i*2] - 
	    u2[1] * x[x_start_1+2*next_quarter +1 + i*2];
	  z3[1] = u2[0] * x[x_start_1+2*next_quarter + 1 + i*2] +
	    u2[1] * x[x_start_1+2*next_quarter + i*2];
	  
	  z4[0] = u3[0] * x[x_start_1+3*next_quarter + i*2] - 
	    u3[1] * x[x_start_1+3*next_quarter +1 + i*2];
	  z4[1] = u3[0] * x[x_start_1+3*next_quarter + 1 + i*2] +
	    u3[1] * x[x_start_1+3*next_quarter + i*2];
	  
	  z5[0] = z1[0] - z3[0];
	  z5[1] = z1[1] - z3[1];
	
	  z1[0] += z3[0];
	  z1[1] += z3[1];
	
	  z3[0] = z2[0] - z4[0];
	  z3[1] = z2[1] - z4[1];

	  z2[0] += z4[0];
	  z2[1] += z4[1];
	
	  y[y_start_1 + i*2] = z1[0] + z2[0];
	  y[y_start_1+1 + i*2] = z1[1] + z2[1];

	  y[y_start_1+next_quarter_y + i*2] = z5[0] - z3[1];
	  y[y_start_1+next_quarter_y+1 + i*2] = z5[1] + z3[0];
	  y[y_start_1+3*next_quarter_y + i*2] = z5[0] + z3[1];
	  y[y_start_1+3*next_quarter_y+1 + i*2] = z5[1] - z3[0];
	  
	  y[y_start_1+2*next_quarter_y + i*2] = z1[0] - z2[0];
	  y[y_start_1+2*next_quarter_y+ 1 + i*2] = z1[1] - z2[1];
	
	}
	x_start_1 += lda;
	y_start_1 += lda;
      } 
    }
  } else {
    x_start_1 = y_start_1 = 0;
    for(k=0;k<r;k++) {
      for(i=0;i<ns;i++) {
	z1[0] = x[x_start_1 + i*2];
	z1[1] = x[x_start_1 + 1 + i*2];
	
	z2[0] = x[x_start_1+next_quarter + i*2];
	z2[1] = x[x_start_1+next_quarter + 1 + i*2];
	
	z5[0] = z1[0] - x[x_start_1+2*next_quarter + i*2];
	z5[1] = z1[1] - x[x_start_1+2*next_quarter + i*2 + 1];
	
	z1[0] += x[x_start_1+2*next_quarter + i*2];
	z1[1] += x[x_start_1+2*next_quarter + i*2 + 1];
	
	z3[0] = z2[0] - x[x_start_1+3*next_quarter + i*2]; 
	z3[1] = z2[1] - x[x_start_1+3*next_quarter + i*2 + 1];
	
	z2[0] += x[x_start_1+3*next_quarter + i*2];
	z2[1] += x[x_start_1+3*next_quarter + i*2 + 1]; 
	
	y[y_start_1 + i*2] = z1[0] + z2[0];
	y[y_start_1+1 + i*2] = z1[1] + z2[1];
	
	y[y_start_1+next_quarter_y + i*2] = z5[0] + z3[1];
	y[y_start_1+next_quarter_y+1 + i*2] = z5[1] - z3[0];
	y[y_start_1+3*next_quarter_y + i*2] = z5[0] - z3[1];
	y[y_start_1+3*next_quarter_y+1 + i*2] = z5[1] + z3[0];
	
	y[y_start_1+2*next_quarter_y + i*2] = z1[0] - z2[0];
	y[y_start_1+2*next_quarter_y+ 1 + i*2] = z1[1] - z2[1];
	
      }
      x_start_1 += lda;
      y_start_1 += lda;
    } 
    x_start = 0;
    y_start = 0;
    for(j=1;j<Ls;j++) {
      u1[0] = mpuu1[ku+j*2];
      u1[1] = mpuu1[ku+j*2+1];
      u2[0] = mpuu1[ku2+j*2];
      u2[1] = mpuu1[ku2+j*2+1];
      u3[0] = mpuu3[ku+j*2];
      u3[1] = mpuu3[ku+j*2+1];
      x_start += rslda; // = j*rslda;
      y_start += rlda;  // = j*rlda;
      x_start_1 = x_start;
      y_start_1 = y_start;


      for(k=0;k<r;k++) {
	for(i=0;i<ns;i++) {
	  z1[0] = x[x_start_1 + i*2];
	  z1[1] = x[x_start_1 + 1 + i*2];
	
	  //conjugate roots of unity and multiply
	  z2[0] = u1[0] * x[x_start_1+next_quarter + i*2] + 
	    u1[1] * x[x_start_1+next_quarter +1 + i*2];
	  z2[1] = u1[0] * x[x_start_1+next_quarter + 1 + i*2] -
	    u1[1] * x[x_start_1+next_quarter + i*2];
	  
	  z3[0] = u2[0] * x[x_start_1+2*next_quarter + i*2] + 
	      u2[1] * x[x_start_1+2*next_quarter +1 + i*2];
	  z3[1] = u2[0] * x[x_start_1+2*next_quarter + 1 + i*2] -
	    u2[1] * x[x_start_1+2*next_quarter + i*2];
	  
	  z4[0] = u3[0] * x[x_start_1+3*next_quarter + i*2] + 
	    u3[1] * x[x_start_1+3*next_quarter +1 + i*2];
	  z4[1] = u3[0] * x[x_start_1+3*next_quarter + 1 + i*2] -
	    u3[1] * x[x_start_1+3*next_quarter + i*2];

	  z5[0] = z1[0] - z3[0];
	  z5[1] = z1[1] - z3[1];
	
	  z1[0] += z3[0];
	  z1[1] += z3[1];
	
	  z3[0] = z2[0] - z4[0];
	  z3[1] = z2[1] - z4[1];

	  z2[0] += z4[0];
	  z2[1] += z4[1];
	
	  y[y_start_1 + i*2] = z1[0] + z2[0];
	  y[y_start_1+1 + i*2] = z1[1] + z2[1];

	  y[y_start_1+next_quarter_y + i*2] = z5[0] + z3[1];
	  y[y_start_1+next_quarter_y+1 + i*2] = z5[1] - z3[0];
	  y[y_start_1+3*next_quarter_y + i*2] = z5[0] - z3[1];
	  y[y_start_1+3*next_quarter_y+1 + i*2] = z5[1] + z3[0];
      
	  y[y_start_1+2*next_quarter_y + i*2] = z1[0] - z2[0];
	  y[y_start_1+2*next_quarter_y+ 1 + i*2] = z1[1] - z2[1];
	
	}
	x_start_1 += lda;
	y_start_1 += lda;
      } //end for
    } //end for
      
  }//end if(is == 1) {} else {}
}


void mp_real::mpfft2(int is, int ns, int m, int n, double *x, double *y,
		     double* &out)
{
  /**
   * This performs NS simultaneous N-point complex-to-complex FFTs, 
   * where N = 2^M.  X is the input array, UU1 is the root
   * of unity array, and Y  is a scratch array.  X, Y, and UU1 are
   * double complex.  This routine is not intended to be called 
   * directly by the user. The output is put into either x or y,
   * depending on m, and the pointer OUT is set to equal x or y, 
   * whichever gets the output.
   *
   */
  
  int l;
  int m_odd=0;
  // dimensions : x[mpnrow+mpnsp1, n], y[mpnrow+mpnsp1, n].

  if(m & 0x1) {
    //m is odd, so we need to first perform one radix 2 iteration
    //before the radix 4 iterations start.

    mpfft3_radix2(is, m, ns, 0, 0, x, y);      
    for(l=3;l<=m;l+=4) {
      mpfft3(is, l, ns, m, n, y, x);
      if(l == m) {m_odd = 1; break;}
      mpfft3(is, l + 2, ns, m, n, x, y);
    }
    if(m_odd) {
      out = x;
    } else {
      out = y;
    }
    return;
  }
  //else , m^0x1 == 0

  for(l=2;l<=m;l+=4) {
    mpfft3(is, l, ns, 1, n, x, y);
    if(l == m) {m_odd = 1; break;}
    mpfft3(is, l + 2, ns, 1, n, y, x);
  }
  
  if(m_odd) {
    out = y;
  } else {
    out = x;
  }
  return;
}


    
void mp_real::mpinix(int n) 
{
  /**
   * This initializes the root of unity arrays UU1 and UU2, which are 
   * required by the FFT routines that are called by mpmulx.  Before
   * calling any of the advanced MP routines (i.e. those whose names end
   * in X), this routine must be called with N set to the largest precision
   * level mpnw that will be used in the subsequent application.  It is 
   * not necessary for the user to call mpinix if the advanced routines
   * are not called.
   */

  const double cl2 = 1.4426950408889633;
  const double pi = acos(-1.0);
  n *= 2;
  double l_temp = 0.75 * n;
  int m = int(cl2 * log(l_temp) + 1.0 - mprxx);
  int mq = m + 2;
  int nq = 1 << mq;
  if(mpuu1)
    delete [] mpuu1;
  mpuu1 = new double[2 * nq + 2];
  if(mpuu2)
    delete [] mpuu2;
  mpuu2 = new double[2 * (mq + nq + 1)];
  if(mpuu3)
    delete [] mpuu3;
  mpuu3 = new double[2 * nq + 2];
  mpuu1[0] = mq;
  mpuu1[1] = 0.0;
  int ku;
  int ln;
  int i, j;
  double t1, ti, sin_temp, cos_temp;
  
  ku = 2;
  ln = 2;
  mpuu1[2] = 1.0;
  mpuu1[3] = 0.0;
  //mpuu1 holds roots of unity from 0 to pi
  for(j=0;j<mq-1;j++) {
    t1 = pi / double(ln);
    
    for (i = 0; i<ln/2; i+=2) {
      mpuu1[2 * (i+ku)] = mpuu1[i+ku];
      mpuu1[2 * (i+ku) + 1] = mpuu1[i+ku+1];
      ti = double(i+1) * t1;
      sin_temp = sin(ti);
      cos_temp = cos(ti);
      mpuu1[2 * (i+ku+1)] = cos_temp;
      mpuu1[2 * (i+ku+1) + 1] = sin_temp;

      //multiply by i and use again for the roots above pi/2
      mpuu1[2* (i+ku) + ln] = -mpuu1[i+ku+1];
      mpuu1[2* (i+ku) + ln+1] = mpuu1[i+ku]; 

      mpuu1[2* (i+ku) + ln+2] = -sin_temp;
      mpuu1[2* (i+ku) + ln+3] = cos_temp;
      
    }
    
    ku += ln;
    ln *= 2;
  }


  ku = 2;
  ln = 2;
  mpuu3[2] = 1.0;
  mpuu3[3] = 0.0;
  for(j=0;j<mq-1;j++) {
    t1 = pi / double(ln);
    
    for (i = 0; i<ln/* /2*/; i+=2) {
      mpuu3[2 * (i+ku)] = mpuu3[i+ku];
      mpuu3[2 * (i+ku) + 1] = mpuu3[i+ku+1];
      ti = double(3 * (i+1)) * t1;
      sin_temp = sin(ti);
      cos_temp = cos(ti);
      mpuu3[2 * (i+ku+1)] = cos_temp;
      mpuu3[2 * (i+ku+1) + 1] = sin_temp;
    }
    
    ku += ln;
    ln *= 2;
  }
  
  double tpn;
  int nn, nn1, nn2, iu;
  int mm, mm1, mm2, k;

  ku = mq + 1;
  mpuu2[0] = mq;
  
  for(k=1;k<mq-1;k++) {
    mpuu2[2*k] = double(ku-1);
    mpuu2[2*k+1] = double(0.0);
    mm = k + 1;
    nn = 1 << mm;
    mm1 = (mm + 1) / 2;
    mm2 = mm - mm1;
    nn1 = 1 << mm1;
    nn2 = 1 << mm2;
    tpn = 2.0 * pi / double(nn);
    mpuu2[2*k+2] = double(nn1*nn2);
    
    for (j=0;j<nn2;j++) {
      for(i=0;i<nn1;i++) {
	iu = ku + i + j * nn1;
	t1 = tpn * double(i * j);
	sin_temp = sin(t1);
	cos_temp = cos(t1);
	mpuu2[(iu-1)*2] = cos_temp;
	mpuu2[(iu-1)*2+1] = sin_temp;
      }
    }
    ku += nn;
  }

  return;
}

void mp_real::mpfftcr(int is, int m, int n, int nsq, 
		      double *x, double *y)
{
  /**
   * This performs an N-point complex-to real FFT, where N = 2^M.
   * X is the double complex input array, and y is the double (real)
   * output array.  The array X is used as a scratch array in MPFFT1, 
   * and so is overwritten.  X must be dimensioned with N/2+N1*NSP1+1 
   * double complex cells, and Y with N double cells, where N = 2^M,
   * and N1 = 2^int(M/2).  this dimension requirement for X is
   * somewhat greater than is used in this function, because MPFFT1, 
   * which is called by this routine, requires more.  IS is the sign of
   * the transform.  Before calling MPFFTCR, the UU1 and UU2 arrays must
   * bt initialized by calling MPINIX.  This routine is not intended 
   * to be called direcly by the user.
   */
  double  a1[2], a2[2], x1[2], x2[2];
  int mx = int(mpuu1[0]), n1, n2, n21, n4, k, ku;

  // Check if input parameters are invalid.
  
  if((is != 1 && is != -1) || m<3 || m > mx) {
    if(MPKER[67] != 0) {
      cout <<"\n*** MPFFTRC : either the UU arrays have not been initialized,"
	   <<"\n\t or else one of the input parameters is invalid.";
      MPIER = 67;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }
  
  n1 = 1 << (m /2 );
  n2 = n / 2;
  n21 = n2 + 1;
  n4 = n / 4;

  // Construct the input to MPFFT1;
  
  y[0] = 0.5 * (x[0] + x[n]);
  y[1] = 0.5 * (x[0] - x[n]);
  
  if(is == 1) {
    y[n2] = x[n2];
    y[n2+1] = -x[n2+1];
  } else {
    y[n2] = x[n2];
    y[n2+1] = x[n2+1];
  }
  ku = n;
  
  if(is == 1) {
    for(k=2;k<n2; k+=2) {
      x1[0] = x[k]; x1[1] = x[k+1];
      
      x2[0] = x[n-k]; x2[1] = -x[n-k+1];
      
      a1[0] = x1[0] + x2[0]; a1[1] = x1[1] + x2[1];
      
      //x1 = x1 - x2;
      x1[0] -= x2[0]; x1[1] -= x2[1];

      // a2 = i * mpuu1[k+ku] * (x1 - x2)
      a2[0] = -(mpuu1[k+ku] * x1[1]) - (mpuu1[k+ku+1] * x1[0]);
      a2[1] = mpuu1[k+ku] * x1[0] - (mpuu1[k+ku+1] * x1[1]);
      
      y[k] = 0.5 * (a1[0] + a2[0]); 
      y[k+1] = 0.5 * (a1[1] + a2[1]);
      
      //y[n-k] = 0.5 * conj(a1-a2)
      y[n-k] = 0.5 * (a1[0] - a2[0]);
      y[n-k+1] = 0.5 * (a2[1] - a1[1]);
    }
  } else {
    for(k=2;k<n2; k+=2) {
      x1[0] = x[k]; x1[1] = x[k+1];
      
      x2[0] = x[n-k]; x2[1] = -x[n-k+1];
      
      a1[0] = x1[0] + x2[0]; a1[1] = x1[1] + x2[1];
      
      //x1 = x1 - x2;
      x1[0] -= x2[0]; x1[1] -= x2[1];

      // a2 = i * conj(mpuu1[k+ku]) * (x1 - x2)
      a2[0] = (mpuu1[k+ku+1] * x1[0]) - (mpuu1[k+ku] * x1[1]);
      a2[1] = (mpuu1[k+ku+1] * x1[1]) + (mpuu1[k+ku] * x1[0]);
      
      y[k] = 0.5 * (a1[0] + a2[0]); 
      y[k+1] = 0.5 * (a1[1] + a2[1]);
      
      //y[n-k] = 0.5 * conj(a1-a2)
      y[n-k] = 0.5 * (a1[0] - a2[0]);
      y[n-k+1] = 0.5 * (a2[1] - a1[1]);
    }
  }
  
  int m1, m2;
  m1 = ((m-1)+1)/2;
  m2 = (m-1) - m1;

  // Perform a normal N/2 point FFT on y.
  mpfft1(is, m-1, m1, m2, y, x);
  
  return;
}


