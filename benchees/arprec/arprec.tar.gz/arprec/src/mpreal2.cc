/*
 * src/mpreal2.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 */
#include "mp/mpreal.h"

void mp_real::mpnrt(const mp_real& a, int n, mp_real& b)
{
  /**
   * This computes the N-th root of the MP number A and returns the MP result
   * in B.  N must be at least one and must not exceed 2 ^ 30.  For extra high
   * levels of precision, use MPNRTX.  Debug output starts with MPIDB = 7.
   *
   * Max SP space for B: MPNW + 5 cells.
   *
   * This subroutine employs the following Newton-Raphson iteration, which
   * converges to A ^ (-1/N):
   *
   * X_{k+1} = X_k + (X_k / N) * (1 - A * X_k^N)
   *
   * The reciprocal of the final approximation to A ^ (-1/N) is the N-th root.
   * These iterations are performed with a maximum precision level MPNW that
   * is dynamically changed, approximately doubling with each iteration.
   * See the comment about the parameter NIT in MPDIVX.
   *
   * When N is large and A is very near one, the following binomial series is
   * employed instead of the Newton scheme:
   *
   * (1 + x)^(1/N)  =  1  +  x / N  +  x^2 * (1 - N) / (2! N^2)  +  ...
   * See the comment about the parameter NIT in MPDIVX.
   *
   *  It is important to note that the results of mpnrt are undefined
   * when a and b are the same object.
   */
  int k, n1;
  double t2, tn;
  const double alt = 0.693147180559945309, cl2 = 1.4426950408889633;
  const int nit = 3, n30 = 1 << 30; // 2 ^ 30
  size_t n5 = (size_t)(mpnw + 5);
  mp_real f1((size_t)8), f2((size_t)8), sk0(n5),
    sk1((size_t)n5), sk2(n5), sk3(n5);
  
  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  
  if (MPIDB >= 7) print_mpreal((char*)"MPNRT I: a ", a);
  
  int na = MIN ((int)ABS(a[1]), mpnw); // number of words in A
  
  if (na == 0) {
    zero(b);
    if (MPIDB >= 7) print_mpreal((char*)"MPNRT O: b ", b);
    return;
  }
  
  if (a[1] < 0) {
    if (MPKER[59] != 0) {
      cerr << (char*)"*** MPNRT: Argument is negative.\n";
      MPIER = 59;
      if (MPKER[MPIER] == 2)  mpabrt();
    }
    return;
  }
  
  if (n <= 0 || n > n30) {
    if (MPKER[60] != 0) {
      cerr << (char*)"*** MPNRT: Improper value of N: " << n << endl;
      MPIER = 60;
      if (MPKER[MPIER] == 2)  mpabrt();
    }
    return;
  }
  
  //  If N = 1, 2 or 3,  MPEQ, MPSQRT or MPCBRT.  These are faster.
  switch (n) {
  case 1:
    mpeq (a, b);
    if (MPIDB >= 7) print_mpreal((char*)"MPNRT O: b ", b);
    return;
  case 2:
    mpsqrt (a, b);
    if (MPIDB >= 7) print_mpreal((char*)"MPNRT O: b ", b);
    return;
#if 0
  case 3:
    mpcbrt (a, b);
    if (MPIDB >= 7) print_mpreal((char*)"MPNRT O: b ", b);
    return;
#endif
  default: break;
  }
  
  int nws = mpnw;
  f1[1] = 1.;
  f1[2] = 0.;
  f1[3] = 1.;
  f1[4] = 0.;
  
  //  Determine the least integer MQ such that 2 ^ MQ >= MPNW.
  double t1;
  t1 = mpnw;
  int mq = int(cl2 * log(t1) + 1.0 - mprxx); // *cast*
  
  //  Check how close A is to 1.
  mpsub(a, f1, sk0);
  if (sk0[1] == 0) {
    mpeq(f1, b);
    if (MPIDB >= 7) print_mpreal((char*)(char*)"MPNRT O: b ", b);
    return;
  }
  
  mpmdc(sk0, t1, n1);
  int n2 = int(cl2 * log (fabs (t1))); // *cast*
  t1 = t1 * pow(0.5, n2);
  n1 = n1 + n2;
  if (n1 <= -30) {
    t2 = n;
    n2 = int(cl2 * log (t2) + 1.0 + mprxx); // *cast*
    int n3 = - mpnbt * mpnw / n1;
    if (n3 < 1.25 * n2) {
      //  A is so close to 1 that it is cheaper to use the binomial series.
      mpnw = mpnw + 1;
      mpdivd(sk0, t2, 0, sk1);
      mpadd(f1, sk1, sk2);
      k = 0;
      
      do {
        k = k + 1;
        t1 = 1 - k * n;
        t2 = (k + 1) * n;
        mpmuld(sk1, t1, 0, sk3);
        mpdivd(sk3, t2, 0, sk1);
        mpmul(sk0, sk1, sk3);
        mpeq(sk3, sk1);
        mpadd(sk1, sk2, sk3);
        mpeq(sk3, sk2);
      } while (sk1[1] != 0 && sk1[2] >= -mpnw); 
      
      mpeq(sk2, b);
      mpdiv(f1, sk2, sk0);
      mpnw = nws;
      if (sk2[1] > b[1])
        mproun(b);
      
      if (MPIDB >= 7) print_mpreal((char*)"MPNRT O: b ", b);
      return;
    }
  }
  
  //  Compute the initial approximation of A ^ (-1/N).
  tn = n;
  mpmdc (a, t1, n1);
  n2 = int(-n1 / tn); // *cast*
  t2 = exp (-1.0 / tn * (log (t1) + (n1 + tn * n2) * alt));
  mpdmc (t2, n2, b);
  mpdmc (tn, 0, f2);
  mpnw = 3;
  int iq = 0;
  
  //  Perform the Newton-Raphson iteration described above with a dynamically
  //  changing precision level MPNW (one greater than powers of two).
  for (k = 1; k <= mq; ++k) {
    mpnw = MIN (2 * mpnw - 2, nws) + 1;
    int loop = 1;
    while (loop) {
      mpnpwr (b, n, sk0);
      mpmul (a, sk0, sk1);
      mpsub (f1, sk1, sk0);
      mpmul (b, sk0, sk1);
      mpdivd (sk1, tn, 0, sk0);
      mpadd (b, sk0, sk1);
      mpeq (sk1, b);
      if (k == mq - nit && iq == 0) 
        iq = 1;
      else 
        loop = 0;
    }
  }
  //  Take the reciprocal to give final result.
  mpdiv (f1, b, sk1);
  mpeq (sk1, b);
  
  mpnw = nws;
  if (sk1[1] > b[1])
    mproun (b);
  
  if (MPIDB >= 7) print_mpreal((char*)"MPNRT O: b ", b);
}


void mp_real::mpdotd(int n, int isa, const mp_real a[],
                     int isb, const double db[], mp_real& c)
{
  // This routine computes the dot product of the MP vector A with the DP
  // vector DB, returning the MP result in C.  This routine is used in the
  // author's customized PSLQ routine, resulting in substantial speedup.
  // The length of both the A and DB vectors is N, and ISA and ISB are the 
  // skip distances between successive elements of A and DB, measured in 
  // mp_real words, and in DP words, respectively. The DP values in DB must
  // be whole numbers, so for example they cannot be larger than 2^53 on
  // IEEE systems.  Debug output begins with MPIDB = 8.
  //
  //mp_real s1((size_t)(mpnw+6));
  double *s1;
  double *d1 = new double[mpnw+6], *d2 = new double[mpnw+6];
  double dt0, dt1, dt2, t[2];
  int i, ixd, ish, k, ka, kb, kz, m1, m2, m3, m4, m5, nd, nsh, n1;
  const int mpnpr4 = MAX(0 , (mp_real::mpnpr >> 2) - 1);

  // Set DMAX to the largest DP whole number that can be represented exactly:
  // 2.d0 ** 53 on IEEE systems, or 2.d0 ** 48 on Cray non-IEEE systems.
#define MPDOT_CHECK_FOR_ERROR 
#ifdef MPDOTD_CHECK_FOR_ERROR
  double dmax = 9007199254740992.0; // 2^53
#endif
  //double two30 = 1073741824.0;      // 2^30

  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(c);
    return;
  }

  if (MPIDB >= 8) {
    printf((char*)"mpdotd input: n = %d, isa = %d, isb = %d\n", n, isa, isb);
    for (k = 0; k < n; ++k) {
      ka = k * isa;
      kb = k * isb;
      mpmdc(a[ka], dt1, n1);
      dt1 = dt1 * pow(2.0, n1);
      printf((char*)"k = %d, dt1 = %25.16e, db = %25.16e\n", k, dt1, db[kb]);
    }
  }

  double two48 = 281474976710656.0; // 2^48
  for (i = 0; i < n; ++i) {
    kb = i * isb;
    if ( fabs(db[kb]) > two48 ) {  // use conventional loop
      // cout << "naive dot loop is called\n";
      mp_real s1, s2;
      zero(c);
      for (k = 0; k < n; ++k) {
        ka = k * isa;
        kb = k * isb;
        mpmuld (a[ka], db[kb], 0, s1);
        mpadd (s1, c, s2);
        mpeq (s2, c);
      }
      return;
    }
  }
  
  for (i = 1; i <= 4; ++i) d2[i] = 0.;
  for (i = 0; i < mpnw+6; ++i) d1[i] = 0.;

  // ND is the length of D1, IXD is the exponent as in ordinary arprec format.
  // In the code below ND + 1 mantissa words are maintained whenever possible.
  nd = 0;
  ixd = 0;

  // Loop over the n input data pairs.

  for (k = 0; k < n; ++k) {
    ka = k * isa;
    kb = k * isb;

    s1 = a[ka].mpr;
    
    int na = MIN ((int)ABS(s1[1]), mpnw); // number of words in a[k]
    dt0 = db[kb];

    if (na == 0 || dt0 == 0.0) continue; // This pair is zero.

    // Check to make sure the input DP value satisfies the requirements.
#ifdef MPDOTD_CHECK_FOR_ERROR
    /* Check not used */
    if (ABS (dt0) >= dmax || fmod (dt0, 1.0) != 0.) {
      if (MPKER[73] != 0) {
        printf((char*)"mpdotd: improper dp value: k = %d, dt0 = %25.15e\n", k, dt0);
        if (MPKER[73] == 2) mpabrt();
      }
      return;
      }
#endif


    // Save the two initial words of A.

    int ia1 = (int)s1[1];
    int ia2 = (int)s1[2];
    if (ia1 < 0) dt0 = - dt0;

    // Split the input DP value into high-order (<= 53-mpnbt bits) and 
    // low-order (<= mpnbt bits) values.
    dt1 = int (mprdx * dt0);
    dt2 = dt0 - mpbdx * dt1;

    if ( dt1 == 0.0 ) {
      // Only the low-order part of the DP value is nonzero.
      ish = ia2 - ixd;
      if (nd == 0) ish = 0;

      if (ish >= 0) {
        // The product a[k] * db[k] has greater exponent than the cumulative
        // sum. Thus the cumulative sum must be shifted to the right by
        // ish words.
        m1 = MIN (na, ish);
        m2 = MIN (na, nd + ish);
        m3 = na;
        m4 = MIN (MAX (na, ish), mpnw + 1);
        m5 = MIN (MAX (na, nd + ish), mpnw + 1);
        d2[1] = 0.;
        d2[2] = 0.;

        for (i = FST_M; i < m1 + FST_M; ++i) {
          t[0] = mp_two_prod(dt2, s1[i], t[1]);
          d2[i-1] += t[0];
          d2[i] = t[1];
        }

        for (i = m1 + FST_M; i < m2 + FST_M; ++i) {
          t[0] = mp_two_prod(dt2, s1[i], t[1]);
          d2[i-1] += t[0];
          d2[i] = t[1] + d1[i-ish];
        }

        for (i = m2 + FST_M; i < m3 + FST_M; ++i) {
          t[0] = mp_two_prod(dt2, s1[i], t[1]);
          d2[i-1] += t[0];
          d2[i] = t[1];
        }

        for (i = m3 + FST_M; i < m4 + FST_M; ++i)
          d2[i] = 0.0;
      
        for (i = m4 + FST_M; i < m5 + FST_M; ++i)
          d2[i] = d1[i-ish];

        // Copy d2 back to d1.
        if (d2[2] != 0) {
          ish = 1;
          ++m5;
          ixd = ia2 + 1;
        } else {
          ish = 0;
          ixd = ia2;
        }
        d1[2] = 0.0;
        for (i = 2; i < m5 + FST_M; ++i) d1[i+ish] = d2[i];

        nd = m5;
        d1[nd+3] = 0.0;
        d1[nd+4] = 0.0;

      } else {
        // The product a(k) * db(k) has smaller exponent than the cumulative
        // sum. Thus the product must be shifted to the right by -ish words.
        nsh = -ish;
        m1 = MIN (nd, nsh);
        m2 = MIN (nd, na + nsh);
        m3 = nd;
        m4 = MIN (MAX (nd, nsh), mpnw + 1);
        m5 = MIN (MAX (nd, na + nsh), mpnw + 1);
        
        for (i = m1 + FST_M; i < m2 + FST_M; ++i) {
          t[0] = mp_two_prod(dt2, s1[i-nsh], t[1]);
          d1[i-1] += t[0];
          d1[i] += t[1];
        }
        
        for (i = m3 + FST_M; i < m4 + FST_M; ++i)
          d1[i] = 0.0;

        for (i = m4 + FST_M; i < m5 + FST_M; ++i) {
          t[0] = mp_two_prod(dt2, s1[i-nsh], t[1]);
          d1[i-1] += t[0];
          d1[i] = t[1];
        }

        nd = m5;
        d1[nd+3] = 0.0;
        d1[nd+4] = 0.0;
      }

    } else {
      // All two parts of the input DP value are nonzero.
      ish = ia2 + 1 - ixd; // The product's exponent is incremented by 1.
      if (nd == 0) ish = 0;
      double s11 = s1[1];
      double s12 = s1[2];
      s1[1] = s1[2] = 0.0;

      if (ish >= 0) {
        // The product a[k] * db[k] has greater exponent that the cumulative
        // sum. Thus the cumulative sum must be shifted to the right by
        // ish words.
        m1 = MIN (na + 1, ish);
        m2 = MIN (na + 1, nd + ish);
        m3 = na + 1;
        m4 = MIN (MAX (na + 1, ish), mpnw + 1);
        m5 = MIN (MAX (na + 1, nd + ish), mpnw + 1);
        d2[1] = 0.0;
        d2[2] = 0.0;
        
        for (i = FST_M; i < m1 + FST_M; ++i) {
          t[0] = mp_two_prod(dt1, s1[i], t[1]);   // high-order part
          d2[i-1] += t[0];
          d2[i] = t[1];
          t[0] = mp_two_prod(dt2, s1[i-1], t[1]); // low-order part
          d2[i-1] += t[0];
          d2[i] += t[1];
        }

        for (i = m1 + FST_M; i < m2 + FST_M; ++i) {
          t[0] = mp_two_prod(dt1, s1[i], t[1]);   // high-order part
          d2[i-1] += t[0];
          d2[i] = t[1] + d1[i-ish];
          t[0] = mp_two_prod(dt2, s1[i-1], t[1]); // low-order part
          d2[i-1] += t[0];
          d2[i] += t[1];
        }

        for (i = m2 + FST_M; i < m3 + FST_M; ++i) {
          t[0] = mp_two_prod(dt1, s1[i], t[1]);   // high-order part
          d2[i-1] += t[0];
          d2[i] = t[1];
          t[0] = mp_two_prod(dt2, s1[i-1], t[1]); // low-order part
          d2[i-1] += t[0];
          d2[i] += t[1];
        }

        for (i = m3 + FST_M; i < m4 + FST_M; ++i)
          d2[i] = 0.0;
      
        for (i = m4 + FST_M; i < m5 + FST_M; ++i)
          d2[i] = d1[i-ish];

        // Copy d2 back to d1.
        if (d2[2] != 0) {
          ish = 1;
          ++m5;
          ixd = ia2 + 2;
        } else {
          ish = 0;
          ixd = ia2 + 1;
        }
        d1[2] = 0.0;
        for (i = 2; i < m5 + FST_M; ++i) d1[i+ish] = d2[i];

        nd = m5;
        d1[nd+3] = 0.0;
        d1[nd+4] = 0.0;

      } else {
        // The product a[k] * db[k] has smaller exponent that the cumulative
        // sum. Thus the product must be shifted to the right by -ish words.
        nsh = -ish;
        m1 = MIN (nd, nsh);
        m2 = MIN (nd, na + 1 + nsh);
        m3 = nd;
        m4 = MIN (MAX (nd, nsh), mpnw + 1);
        m5 = MIN (MAX (nd, na + 1 + nsh), mpnw + 1);

        for (i = m1 + FST_M; i < m2 + FST_M; ++i) {
          t[0] = mp_two_prod(dt1, s1[i-nsh], t[1]); // high-order part
          d1[i-1] += t[0];
          d1[i] += t[1];
          t[0] = mp_two_prod(dt2, s1[i-1-nsh], t[1]); // low-order part
          d1[i-1] += t[0];
          d1[i] += t[1];
        }

        for (i = m3 + FST_M; i < m4 + FST_M; ++i)
          d1[i] = 0.0;
        
        for (i = m4 + FST_M; i < m5 + FST_M; ++i) {
          t[0] = mp_two_prod(dt1, s1[i-nsh], t[1]); // high-order part
          d1[i-1] += t[0];
          d1[i] = t[1];
          t[0] = mp_two_prod(dt2, s1[i-1-nsh], t[1]); // low-order part
          d1[i-1] += t[0];
          d1[i] += t[1];
        }

        nd = m5;
        d1[nd+3] = 0.0;
        d1[nd+4] = 0.0;
      }
      s1[1] = s11;
      s1[2] = s12;
    }
    
    if (nd == 0) continue;

    // Release carry to avoid overflowing the exact integer capacity
    // (2^52-1) of a floating poitn word in D1.
    // Results may be negative, but that is not a problem -- these will be
    // fixed in the final call to mpnorm.
    if(!((k-1) & mpnpr4)) {
      dt2 = 0.0; // carry
      for (i = nd+2; i >= FST_M; --i) {
        dt1 = dt2 + d1[i];
        dt2 = int (dt1 * mprdx);   // carry < 2^(48 - mpnbt)
        d1[i] = dt1 - dt2 * mpbdx; // remainder of dt1 * 2^(-mpnbt)
      }
      d1[2] += dt2;
    }
    // If d1[2] is nonzero due to carry release, shift result to right.

    if (d1[2] != 0.0) {
      ish = 1;
      ++ixd;
      nd = MIN (nd + 1, mpnw + 1);
    } else {
      ish = 0;
    }

    if (ish != 0) {
      for (i = nd+2; i >= FST_M; --i) d1[i] = d1[i-ish];
      d1[1] = 0.0;
      d1[2] = 0.0;
    }
    d1[nd+3] = 0.0;
    d1[nd+4] = 0.0;
 
    // Check to see if there are leading zeros.
    for (i = FST_M; i < nd + FST_M; ++i)
      if (d1[i] != 0.0) break;

    if ( i == nd + FST_M) {
      // The cumulative sum is now zero.
      nd = 0;
      ixd = 0;
      d1[1] = 0.0;
      d1[2] = 0.0;
    } else {
      kz = i - FST_M;
      if (kz > 0) {
        // Leading zeroes -- shift cumulative sum to left.
        for (i = FST_M; i < nd - kz + FST_M; ++i)
          d1[i] = d1[i+kz];

        nd = nd - kz;
        ixd = ixd - kz;
        d1[nd+3] = 0.0;
        d1[nd+4] = 0.0;
      }
    }

  } // end for k = ...


  // Call mpnorm to fix up result and store in c.

  d1[1] = nd;
  d1[2] = ixd;

  mpnorm(d1, c);

  delete [] d1;
  delete [] d2;
  
  if (MPIDB >= 8) {
    mpmdc(c, dt1, n1);
    dt1 = dt1 * pow(2.0, n1);
    printf((char*)"mpdotd output: dt1 = %25.15e\n", dt1);
    print_mpreal((char*)"MPDOTD O: c ", c);
  }
}

