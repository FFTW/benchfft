/*
 * src/f77_mp.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 */
#include "config.h"
#include "mp/c_mp.h"
#include "mp/fpu.h"

#ifndef F77_FUNC_
#define F77_FUNC_(name, NAME)   name ## _
#endif

#define f77_mpadd        F77_FUNC_(f77_mpadd, F77_MPADD)
#define f77_mpadd_d      F77_FUNC_(f77_mpadd_d, F77_MPADD_D)
#define f77_mpadd_ji     F77_FUNC_(f77_mpadd_ji, F77_MPADD_JI)
#define f77_mpadd_jd     F77_FUNC_(f77_mpadd_jd, F77_MPADD_JD)
#define f77_mpadd_zq     F77_FUNC_(f77_mpadd_zq, F77_MPADD_ZQ)
#define f77_mpadd_zx     F77_FUNC_(f77_mpadd_zx, F77_MPADD_ZX)
#define f77_mpadd_zz     F77_FUNC_(f77_mpadd_zz, F77_MPADD_ZZ)
#define f77_mpsub        F77_FUNC_(f77_mpsub, F77_MPSUB)
#define f77_mpsub_d      F77_FUNC_(f77_mpsub_d, F77_MPSUB_D)
#define f77_mpsub_dq     F77_FUNC_(f77_mpsub_dq, F77_MPSUB_DQ)
#define f77_mpsub_ji     F77_FUNC_(f77_mpsub_ji, F77_MPSUB_JI)
#define f77_mpsub_ij     F77_FUNC_(f77_mpsub_ij, F77_MPSUB_IJ)
#define f77_mpsub_jd     F77_FUNC_(f77_mpsub_jd, F77_MPSUB_JD)
#define f77_mpsub_dj     F77_FUNC_(f77_mpsub_dj, F77_MPSUB_DJ)
#define f77_mpsub_zq     F77_FUNC_(f77_mpsub_zq, F77_MPSUB_ZQ)
#define f77_mpsub_qz     F77_FUNC_(f77_mpsub_qz, F77_MPSUB_QZ)
#define f77_mpsub_zx     F77_FUNC_(f77_mpsub_zx, F77_MPSUB_ZX)
#define f77_mpsub_xz     F77_FUNC_(f77_mpsub_xz, F77_MPSUB_XZ)
#define f77_mpsub_zz     F77_FUNC_(f77_mpsub_zz, F77_MPSUB_ZZ)
#define f77_mpneg_q      F77_FUNC_(f77_mpneg_q, F77_MPNEG_Q)
#define f77_mpneg_z      F77_FUNC_(f77_mpneg_z, F77_MPNEG_Z)
#define f77_mpmul        F77_FUNC_(f77_mpmul, F77_MPMUL)
#define f77_mpmul_ji     F77_FUNC_(f77_mpmul_ji, F77_MPMUL_JI)
#define f77_mpmul_qd     F77_FUNC_(f77_mpmul_qd, F77_MPMUL_QD)
#define f77_mpmul_qi     F77_FUNC_(f77_mpmul_qi, F77_MPMUL_QI)
#define f77_mpmul_zq     F77_FUNC_(f77_mpmul_zq, F77_MPMUL_ZQ)
#define f77_mpmul_zz     F77_FUNC_(f77_mpmul_zz, F77_MPMUL_ZZ)
#define f77_mpmul_zd     F77_FUNC_(f77_mpmul_zd, F77_MPMUL_ZD)
#define f77_mpdiv        F77_FUNC_(f77_mpdiv, F77_MPDIV)
#define f77_mpdiv_jj     F77_FUNC_(f77_mpdiv_jj, F77_MPDIV_JJ)
#define f77_mpdiv_ji     F77_FUNC_(f77_mpdiv_ji, F77_MPDIV_JI)
#define f77_mpdiv_ij     F77_FUNC_(f77_mpdiv_ij, F77_MPDIV_IJ)
#define f77_mpdiv_qi     F77_FUNC_(f77_mpdiv_qi, F77_MPDIV_QI)
#define f77_mpdiv_iq     F77_FUNC_(f77_mpdiv_iq, F77_MPDIV_IQ)
#define f77_mpdiv_qd     F77_FUNC_(f77_mpdiv_qd, F77_MPDIV_QD)
#define f77_mpdiv_dq     F77_FUNC_(f77_mpdiv_dq, F77_MPDIV_DQ)
#define f77_mpdiv_zq     F77_FUNC_(f77_mpdiv_zq, F77_MPDIV_ZQ)
#define f77_mpdiv_qz     F77_FUNC_(f77_mpdiv_qz, F77_MPDIV_QZ)
#define f77_mpdiv_zz     F77_FUNC_(f77_mpdiv_zz, F77_MPDIV_ZZ)
#define f77_mpdiv_zd     F77_FUNC_(f77_mpdiv_zd, F77_MPDIV_ZD)
#define f77_mpdiv_dz     F77_FUNC_(f77_mpdiv_dz, F77_MPDIV_DZ)
#define f77_mpdmc        F77_FUNC_(f77_mpdmc, F77_MPDMC)
#define f77_mpmdc        F77_FUNC_(f77_mpmdc, F77_MPMDC)
#define f77_mpeq         F77_FUNC_(f77_mpeq, F77_MPEQ)
#define f77_mpeq_int     F77_FUNC_(f77_mpeq_int, F77_MPEQ_INT)
#define f77_mpeq_d       F77_FUNC_(f77_mpeq_d, F77_MPEQ_D)
#define f77_mpeq_ji      F77_FUNC_(f77_mpeq_ji, F77_MPEQ_JI)
#define f77_mpeq_zq      F77_FUNC_(f77_mpeq_zq, F77_MPEQ_ZQ)
#define f77_mpeq_zx      F77_FUNC_(f77_mpeq_zx, F77_MPEQ_ZX)
#define f77_mpeq_zz      F77_FUNC_(f77_mpeq_zz, F77_MPEQ_ZZ)
#define f77_mppwr        F77_FUNC_(f77_mppwr, F77_MPPWR)
#define f77_mppwr_d      F77_FUNC_(f77_mppwr_d, F77_MPPWR_D)
#define f77_mppwr_qi     F77_FUNC_(f77_mppwr_qi, F77_MPPWR_QI)
#define f77_mppwr_jj     F77_FUNC_(f77_mppwr_jj, F77_MPPWR_JJ)
#define f77_mppwr_ji     F77_FUNC_(f77_mppwr_ji, F77_MPPWR_JI)
#define f77_mppwr_zi     F77_FUNC_(f77_mppwr_zi, F77_MPPWR_ZI)
#define f77_mppwr_zq     F77_FUNC_(f77_mppwr_zq, F77_MPPWR_ZQ)
#define f77_mppwr_zz     F77_FUNC_(f77_mppwr_zz, F77_MPPWR_ZZ)
#define f77_mpcpr        F77_FUNC_(f77_mpcpr, F77_MPCPR)
#define f77_mpcpr_i      F77_FUNC_(f77_mpcpr_i, F77_MPCPR_I)
#define f77_mpcpr_d      F77_FUNC_(f77_mpcpr_d, F77_MPCPR_D)
#define f77_mpcpr_z      F77_FUNC_(f77_mpcpr_z, F77_MPCPR_Z)
#define f77_mplet        F77_FUNC_(f77_mplet, F77_MPLET)
#define f77_mplet_i      F77_FUNC_(f77_mplet_i, F77_MPLET_I)
#define f77_mplet_d      F77_FUNC_(f77_mplet_d, F77_MPLET_D)
#define f77_mpget        F77_FUNC_(f77_mpget, F77_MPGET)
#define f77_mpget_i      F77_FUNC_(f77_mpget_i, F77_MPGET_I)
#define f77_mpget_d      F77_FUNC_(f77_mpget_d, F77_MPGET_D)
#define f77_mpltt        F77_FUNC_(f77_mpltt, F77_MPLTT)
#define f77_mpltt_i      F77_FUNC_(f77_mpltt_i, F77_MPLTT_I)
#define f77_mpltt_d      F77_FUNC_(f77_mpltt_d, F77_MPLTT_D)
#define f77_mpgtt        F77_FUNC_(f77_mpgtt, F77_MPGTT)
#define f77_mpgtt_i      F77_FUNC_(f77_mpgtt_i, F77_MPGTT_I)
#define f77_mpgtt_d      F77_FUNC_(f77_mpgtt_d, F77_MPGTT_D)

#define f77_mpabs        F77_FUNC_(f77_mpabs, F77_MPABS)
#define f77_mpabs_z      F77_FUNC_(f77_mpabs_z, F77_MPABS_Z)
#define f77_mparg        F77_FUNC_(f77_mparg, F77_MPARG)
#define f77_mpacos       F77_FUNC_(f77_mpacos, F77_MPACOS)
#define f77_mpasin       F77_FUNC_(f77_mpasin, F77_MPASIN)
#define f77_mpatan       F77_FUNC_(f77_mpatan, F77_MPATAN)
#define f77_mpatan2      F77_FUNC_(f77_mpatan2, F77_MPATAN2)
#define f77_mpcos        F77_FUNC_(f77_mpcos, F77_MPCOS)
#define f77_mpcos_z      F77_FUNC_(f77_mpcos_z, F77_MPCOS_Z)
#define f77_mpcosh       F77_FUNC_(f77_mpcosh, F77_MPCOSH)
#define f77_mpdble       F77_FUNC_(f77_mpdble, F77_MPDBLE)
#define f77_mpexp        F77_FUNC_(f77_mpexp, F77_MPEXP)
#define f77_mpexp_z      F77_FUNC_(f77_mpexp_z, F77_MPEXP_Z)
#define f77_mpaint       F77_FUNC_(f77_mpaint, F77_MPAINT)
#define f77_mpnint       F77_FUNC_(f77_mpnint, F77_MPNINT)
#define f77_mplog        F77_FUNC_(f77_mplog, F77_MPLOG)
#define f77_mplog_z      F77_FUNC_(f77_mplog_z, F77_MPLOG_Z)
#define f77_mplog10      F77_FUNC_(f77_mplog10, F77_MPLOG10)
#define f77_mpsin        F77_FUNC_(f77_mpsin, F77_MPSIN)
#define f77_mpsin_z      F77_FUNC_(f77_mpsin_z, F77_MPSIN_Z)
#define f77_mpsinh       F77_FUNC_(f77_mpsinh, F77_MPSINH)
#define f77_mpnrt        F77_FUNC_(f77_mpnrt, F77_MPNRT)
#define f77_mpsqrt       F77_FUNC_(f77_mpsqrt, F77_MPSQRT)
#define f77_mpsqrt_z     F77_FUNC_(f77_mpsqrt_z, F77_MPSQRT_Z)
#define f77_mptan        F77_FUNC_(f77_mptan, F77_MPTAN)
#define f77_mptanh       F77_FUNC_(f77_mptanh, F77_MPTANH)
#define f77_mpmod        F77_FUNC_(f77_mpmod, F77_MPMOD)
#define f77_mpcssnf      F77_FUNC_(f77_mpcssnf, F77_MPCSSNF)
#define f77_mpcsshf      F77_FUNC_(f77_mpcsshf, F77_MPCSSHF)
#define f77_mprand       F77_FUNC_(f77_mprand, F77_MPRAND)

#define f77_mpinp        F77_FUNC_(f77_mpinp, F77_MPINP)
#define f77_mpout        F77_FUNC_(f77_mpout, F77_MPOUT)
#define f77_mpout_z      F77_FUNC_(f77_mpout_z, F77_MPOUT_Z)
#define f77_mpinit       F77_FUNC_(f77_mpinit, F77_MPINIT)
#define f77_mpgetpar     F77_FUNC_(f77_mpgetpar, F77_MPGETPAR)
#define f77_mpsetpar     F77_FUNC_(f77_mpsetpar, F77_MPSETPAR)
#define f77_mpdotd       F77_FUNC_(f77_mpdotd, F77_MPDOTD)
#define f77_ovcheck      F77_FUNC_(f77_ovcheck, F77_OVCHECK)
#define f77_mpinfr       F77_FUNC_(f77_mpinfr, F77_MPINFR)
#define f77_mpswrite     F77_FUNC_(f77_mpswrite, F77_MPSWRITE)

#define f77_mpsetoutputprec F77_FUNC_(f77_mpsetoutputprec, F77_MPSETOUTPUTPREC)
#define f77_mpgetoutputprec F77_FUNC_(f77_mpgetoutputprec, F77_MPGETOUTPUTPREC)
#define f77_mpsetprec       F77_FUNC_(f77_mpsetprec, F77_MPSETPREC)
#define f77_mpgetprec       F77_FUNC_(f77_mpgetprec, F77_MPGETPREC)
#define f77_mpsetprecwords  F77_FUNC_(f77_mpsetprecwords, F77_MPSETPRECWORDS)
#define f77_mpgetprecwords  F77_FUNC_(f77_mpgetprecwords, F77_MPGETPRECWORDS)

#define f77_fpu_fix_start  F77_FUNC_(f77_fpu_fix_start, F77_FPU_FIX_START)
#define f77_fpu_fix_end   F77_FUNC_(f77_fpu_fix_end,  F77_FPU_FIX_STOP)

#ifdef __cplusplus
extern "C" {
#endif

void f77_mpinit(const int *mpipl, char *filename, const int *mpwds, int *mp5,
	      double *mpl02, double *mpl10, double *mppic, double *mpeps) {
  c_mpinit(*mpipl, filename, *mpwds, mp5, mpl02, mpl10, mppic, mpeps);
}

void f77_mpgetpar(const int *pnum, int *val)
{
  c_mpgetpar(*pnum, val);
}

void f77_mpsetpar(const int *pnum, const int *val)
{
  c_mpsetpar(*pnum, *val);
}


/* add */
void f77_mpadd(const double *a, const double *b, double *c) {
  c_mpadd(a, b, c);
}
void f77_mpadd_d(const double *a, const double *b, double *c) {
  c_mpadd_d(a, *b, c);
}
void f77_mpadd_ji(const double *a, const int *b, double *c) {
  c_mpadd_ji(a, *b, c);
}
void f77_mpadd_jd(const double *a, const double *b, double *c) {
  c_mpadd_jd(a, *b, c);
}
void f77_mpadd_zq(const double *a, const double *b, double *c) {
  c_mpadd_zq(a, b, c);
}
void f77_mpadd_zx(const double *a, const double *br, 
                  const double *bi, double *c) {
  c_mpadd_zx(a, *br, *bi, c);
}
void f77_mpadd_zz(const double *a, const double *b, double *c) {
  c_mpadd_zz(a, b, c);
}

/* sub */
void f77_mpsub(const double *a, const double *b, double *c) {
  c_mpsub(a, b, c);
}

void f77_mpsub_d(const double *a, const double *b, double *c) {
  c_mpsub_d(a, *b, c);
}
void f77_mpsub_dq(const double *a, const double *b, double *c) {
  c_mpsub_dq(*a, b, c);
}
void f77_mpsub_ji(const double *a, const int *b, double *c) {
  c_mpsub_ji(a, *b, c);
}
void f77_mpsub_ij(const int *a, const double *b, double *c) {
  c_mpsub_ij(*a, b, c);
}
void f77_mpsub_jd(const double *a, const double *b, double *c) {
  c_mpsub_jd(a, *b, c);
}
void f77_mpsub_dj(const double *a, const double *b, double *c) {
  c_mpsub_dj(*a, b, c);
}
void f77_mpsub_zq(const double *a, const double *b, double *c) {
  c_mpsub_zq(a, b, c);
}
void f77_mpsub_qz(const double *a, const double *b, double *c) {
  c_mpsub_qz(a, b, c);
}
void f77_mpsub_zx(const double *a, const double *br, 
                  const double *bi, double *c) {
  c_mpsub_zx(a, *br, *bi, c);
}
void f77_mpsub_xz(const double *ar, const double *ai, 
                  const double *b, double *c) {
  c_mpsub_xz(*ar, *ai, b, c);
}
void f77_mpsub_zz(const double *a, const double *b, double *c) {
  c_mpsub_zz(a, b, c);
}

/* negation */
void f77_mpneg_q(const double *a, double *c) {
  c_mpneg_q(a, c);
}
void f77_mpneg_z(const double *a, double *c) {
  c_mpneg_z(a, c);
}

/* mul */
void f77_mpmul(const double *a, const double *b, double *c) {
  c_mpmul(a, b, c);
}
void f77_mpmul_ji(const double *a, const int *b, double *c) {
  c_mpmul_ji(a, *b, c);
}
void f77_mpmul_qi(const double *a, const int *b, double *c) {
  c_mpmul_qi(a, *b, c);
}
void f77_mpmul_qd(const double *a, const double *b, double *c) {
  c_mpmul_qd(a, *b, c);
}
void f77_mpmul_zq(const double *a, const double *b, double *c) {
  c_mpmul_zq(a, b, c);
}
void f77_mpmul_zz(const double *a, const double *b, double *c) {
  c_mpmul_zz(a, b, c);
}
void f77_mpmul_zd(const double *a, const double *b, double *c) {
  c_mpmul_zd(a, *b, c);
}

/* div */
void f77_mpdiv(const double *a, const double *b, double *c) {
  c_mpdiv(a, b, c);
}
void f77_mpdiv_jj(const double *a, const double *b, double *c) {
  c_mpdiv_jj(a, b, c);
}
void f77_mpdiv_ji(const double *a, const int *b, double *c) {
  c_mpdiv_ji(a, *b, c);
}
void f77_mpdiv_ij(const int *a, const double *b, double *c) {
  c_mpdiv_ij(*a, b, c);
}
void f77_mpdiv_qi(const double *a, const int *b, double *c) {
  c_mpdiv_qi(a, *b, c);
}
void f77_mpdiv_iq(const int *a, const double *b, double *c) {
  c_mpdiv_iq(*a, b, c);
}
void f77_mpdiv_qd(const double *a, const double *b, double *c) {
  c_mpdiv_qd(a, *b, c);
}
void f77_mpdiv_dq(const double *a, const double *b, double *c) {
  c_mpdiv_dq(*a, b, c);
}
void f77_mpdiv_zq(const double *a, const double *b, double *c) {
  c_mpdiv_zq(a, b, c);
}
void f77_mpdiv_qz(const double *a, const double *b, double *c) {
  c_mpdiv_qz(a, b, c);
}
void f77_mpdiv_zz(const double *a, const double *b, double *c) {
  c_mpdiv_zz(a, b, c);
}
void f77_mpdiv_zd(const double *a, const double *b, double *c) {
  c_mpdiv_zd(a, *b, c);
}
void f77_mpdiv_dz(const double *a, const double *b, double *c) {
  c_mpdiv_dz(*a, b, c);
}

void f77_mpdmc(const double *a, double *b) {
  c_mpdmc(*a, b);
}
void f77_mpmdc(const double *a, double *b, int *n) {
  c_mpmdc(a, b, n);
}

/* assignment */
void f77_mpeq(const double *a, double *b) {
  c_mpeq(a, b);
}
void f77_mpeq_int(const int *a, double *b) {
  c_mpeq_int(*a, b);
}
void f77_mpeq_d(const double *a, double *b) {
  c_mpeq_d(*a, b);
}
void f77_mpeq_ji(const int *a, double *b) {
  c_mpeq_ji(*a, b);
}
void f77_mpeq_zq(const double *a, double *b) {
  c_mpeq_zq(a, b);
}
void f77_mpeq_zx(double *r, double *i, double *b) {
  c_mpeq_zx(r, i, b);
}
void f77_mpeq_zz(const double *a, double *b) {
  c_mpeq_zz(a, b);
}


/* power */
void f77_mppwr(const double *a, const double *b, double *c) {
  c_mppwr(a, b, c);
}
void f77_mppwr_d(const double *a, const double *b, double *c) {
  c_mppwr_d(a, *b, c);
}
void f77_mppwr_qi(const double *a, const int *b, double *c) {
  c_mppwr_qi(a, *b, c);
}
void f77_mppwr_jj(const double *a, const double *b, double *c) {
  c_mppwr_jj(a, b, c);
}
void f77_mppwr_ji(const double *a, const int *b, double *c) {
  c_mppwr_ji(a, *b, c);
}
void f77_mppwr_zi(const double *a, const int *b, double *c) {
  c_mppwr_zi(a, *b, c);
}
void f77_mppwr_zq(const double *a, const double *b, double *c) {
  c_mppwr_zq(a, b, c);
}

/* equality */
void f77_mpcpr(const double *a, const double *b, int *c) {
  c_mpcpr(a, b,c);
}
void f77_mpcpr_i(const double *a, const int *b, int *c) {
  c_mpcpr_i(a, *b, c);
}
void f77_mpcpr_d(const double *a, const double *b, int *c) {
  c_mpcpr_d(a, *b, c);
}
void f77_mpcpr_z(const double *a, const double *b, int *c) {
  c_mpcpr_z(a, b, c);
}

/* less-than-or-equal-to */
void f77_mplet(const double *a, const double *b, int *c) {
  c_mplet(a, b, c);
}
void f77_mplet_i(const double *a, const int *b, int *c) {
  c_mplet_i(a, *b, c);
}
void f77_mplet_d(const double *a, const double *b, int *c) {
  c_mplet_d(a, *b, c);
}

/* greater-than-or-equal-to */
void f77_mpget(const double *a, const double *b, int *c) {
  c_mpget(a, b, c);
}
void f77_mpget_i(const double *a, const int *b, int *c) {
  c_mpget_i(a, *b, c);
}
void f77_mpget_d(const double *a, const double *b, int *c) {
  c_mpget_d(a, *b, c);
}

/* less-than */
void f77_mpltt(const double *a, const double *b, int *c) {
  c_mpltt(a, b, c);
}
void f77_mpltt_i(const double *a, const int *b, int *c) {
  c_mpltt_i(a, *b, c);
}
void f77_mpltt_d(const double *a, const double *b, int *c) {
  c_mpltt_d(a, *b, c);
}

/* greater-than */
void f77_mpgtt(const double *a, const double *b, int *c) {
  c_mpgtt(a, b, c);
}
void f77_mpgtt_i(const double *a, const int *b, int *c) {
  c_mpgtt_i(a, *b, c);
}
void f77_mpgtt_d(const double *a, const double *b, int *c) {
  c_mpgtt_d(a, *b, c);
}

void f77_mpabs(const double *a, double *b) {
  c_mpabs(a, b);
}
void f77_mpabs_z(const double *a, double *b) {
  c_mpabs_z(a, b);
}

void f77_mparg(const double *a, double *b) {
  c_mparg(a, b);
}

/* trigonometric functions */
void f77_mpacos(const double *a, double *b) {
  c_mpacos(a, b);
}
void f77_mpasin(const double *a, double *b) {
  c_mpasin(a, b);
}
void f77_mpatan(const double *a, double *b) {
  c_mpatan(a, b);
}
void f77_mpatan2(const double *a, const double *b, double *c) {
  c_mpatan2(a, b, c);
}
void f77_mpcos(const double *a, double *b) {
  c_mpcos(a, b);
}
void f77_mpcos_z(const double *a, double *b) {
  c_mpcos_z(a, b);
}
void f77_mpdble(const double *a, double *b) {
  c_mpdble(a, b);
}
void f77_mpcosh(const double *a, double *b) {
  c_mpcosh(a, b);
}
void f77_mpexp(const double *a, double *b) {
  c_mpexp(a, b);
}
void f77_mpexp_z(const double *a, double *b) {
  c_mpexp_z(a, b);
}

void f77_mpaint(const double *a, double *b) {
  c_mpaint(a, b);
}
void f77_mpnint(const double *a, double *b) {
  c_mpnint(a, b);
}

void f77_mplog(const double *a, double *b) {
  c_mplog(a, b);
}
void f77_mplog_z(const double *a, double *b) {
  c_mplog_z(a, b);
}
void f77_mplog10(const double *a, double *b) {
  c_mplog10(a, b);
}
void f77_mpsin(const double *a, double *b) {
  c_mpsin(a, b);
}
void f77_mpsin_z(const double *a, double *b) {
  c_mpsin_z(a, b);
}
void f77_mpsinh(const double *a, double *b) {
  c_mpsinh(a, b);
}
void f77_mpnrt(const double *a, int *b, double *c) {
  c_mpnrt(a, b, c);
}
void f77_mpsqrt(const double *a, double *b) {
  c_mpsqrt(a, b);
}
void f77_mpsqrt_z(const double *a, double *b) {
  c_mpsqrt_z(a, b);
}

void f77_mptan(const double *a, double *b) {
  c_mptan(a, b);
}
void f77_mptanh(const double *a, double *b) {
  c_mptanh(a, b);
}

void f77_mpmod(const double *a, const double *b, double *c) {
  c_mpmod(a, b, c);
}
void f77_mpcsshf(const double *a, double *b, double *c) {
  c_mpcsshf(a, b, c);
}
void f77_mpcssnf(const double *a, double *b, double *c) {
  c_mpcssnf(a, b, c);
}

void f77_mprand(double *a) {
  c_mprand(a);
}

void f77_mpswrite(const double *a, int *la, char *s, int *l) {
  c_mpswrite(a, la, s, l);
}

void f77_ovcheck(const double *a) {
  c_ovcheck(a);
}

void f77_mpinfr(const double *a, double *b, double *c) {
  c_mpinfr(a, b, c);
}

/* Input */
void f77_mpinp(const double *q) {
  c_mpinp(q);
}

/* Output */
void f77_mpout(const double *q, char *c, int *l) {
  c_mpout(q, c, l);
}

void f77_mpout_z(const double *q) {
  c_mpout_z(q);
}


void f77_mpdotd(int *n, int *isa, double *a, int *isb, const double *db,
	      double *c) {
  c_mpdotd(n, isa, a, isb, db, c);
}

void f77_fpu_fix_start(unsigned int *old_cw) {
  fpu_fix_start(old_cw);
}

void f77_fpu_fix_end(unsigned int *old_cw) {
  fpu_fix_end(old_cw);
}

void f77_mpsetoutputprec(int *num_digits) {
  c_mpsetoutputprec(num_digits);
}

void f77_mpgetoutputprec(int *num_digits) {
  c_mpgetoutputprec(num_digits);
}

void f77_mpsetprec(int *num_digits) {
  c_mpsetprec(num_digits);
}

void f77_mpgetprec(int *num_digits) {
  c_mpgetprec(num_digits);
}

void f77_mpsetprecwords(int *num_words) {
  c_mpsetprecwords(num_words);
}

void f77_mpgetprecwords(int *num_words) {
  c_mpgetprecwords(num_words);
}

#ifdef __cplusplus
}
#endif

