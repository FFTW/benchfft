#include "mp/mpreal.h"
#include "mp/mpcomplex.h"

#if (ARPREC_HAVE_STD)
using std::abs;
#endif

void mp_real::mpsqrtx(const mp_real& a, mp_real& b)
{
  /* This computes the square root of the MP number A and returns the MP
   * result in B.  Before calling MPSQRTX, the arrays mpuu1 and mpuu3 must
   * be initialized by calling MPINIX.  For modest levels of precision,
   * use MPSQRT.
   */
  /**
   * This routine calles MPSQT to obtain an initial
   * approximation.  The newton iteration which
   * converges to 1 / Sqrt(A) used by this routine is :
   *
   *  x_{k+1} = x_k + 0.5 * (1 - A * x_k^2) * x_k
   *
   * Where the multiplication () * x_k is performed at half precision.
   *
   * The finial iteration uses a different iteration
   * and is due to A. Karp : 
   *
   *  x_n = (A * x_{n-1}) + 0.5 * [A - (A * x_{n-1}) ^ 2] * x_{n-1}
   *
   * Where the multiplication (A * x_{n-1}) and [] * x_{n-1} are
   * performed at half precision.
   *
   */
  
  const double cl2 = 1.4426950408889633;
  const int nit = 3;
  
  if (MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if(MPIDB >= 6) {
    cout << "\nMPSQRTX I";
  }
  
  double ia = SIGN(1.0, a[1]);
  int na = MIN(int(ABS(a[1])), mpnw);
  int ncr = 1 << mpmcrx;
  
  if(na == 0) {
    zero(b);
    return;
  }
  if(ia < 0.0) {
    if(MPKER[71] != 0) {
      cout <<"\n*** MPSQRTX: Argument is negative.";
      MPIER = 71;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }
  
  // Check if precision level is too low to justify the advanced routine.
  
  if(mpnw < ncr) {
    mpsqrt(a, b);
    return;
  }
  
  int nws = mpnw;
  size_t n6 = (size_t)(mpnw+6);
  mp_real sk0(n6), sk1(n6), sk2(n6);
  mp_real f((size_t(8)));
  // Determine the least integer MQ such that 2 ^ MQ > MPNW.

  double t1 = double(mpnw);
  int mq = int(cl2 * log(t1) + 1.0 - mprxx);
  
  // Compute the initial approximation of 1 / Sqrt(A).
  
  mpnw = ncr + 1;
  mpsqrt(a, sk0);
  mpdiv(sk0, a, b);
  f[1] = 1.0; f[2] = 0.0; f[3] = 1.0; f[4] = 0.0;
  int iq = 0, nw1=0, nw2=0, k;
  int prec_change = 1;
  
  // Perform the Newton-Raphson iteration described above with
  // a dynamically changing precision level MPNW (one greater than powers of two
  for(k=mpmcrx + 1; k < mq; k++) {
    if(prec_change) {
      nw1 = mpnw;
      mpnw = MIN(2*mpnw - 2, nws) +1;
      nw2 = mpnw;
    } else {
      prec_change = 1;
    }
    mpsqx(b, sk0);
    mpmulx(a, sk0, sk1);
    mpsub(f, sk1, sk0);
    mpnw = nw1;
    mpmulx(b, sk0, sk1);
    mpmuld(sk1, 0.5, 0, sk0);
    mpnw = nw2;
    mpadd(b, sk0, b);
    if(k >= mq - nit && iq == 0) {
      iq = 1;
      prec_change = 0;
      k--;
    }
  }
  
  // Perform last iteration using Karp's trick

  mpmulx(a, b, sk0);
  nw1 = mpnw;
  mpnw = MIN(2*mpnw-2, nws) + 1;
  nw2 = mpnw;
  mpsqx(sk0, sk1);
  mpsub(a, sk1, sk2);
  mpnw = nw1;
  mpmulx(sk2, b, sk1);
  mpmuld(sk1, 0.5, 0, sk2);
  mpnw = nw2;
  mpadd(sk0, sk2, b);
 
  //Restore original precision level.
   
  mpnw = nws;
  mproun(b);
  return;
}

void mp_real::mpsqx(const mp_real& a, mp_real& b)
{
  /**
   * This routine squares the MP number A to yield the MP product B. 
   * Before calling MPSQX, the arrays mpuu1 and mpuu3 must be initialized
   * by calling mpinix.  For modest levels of precision, use MPMUL.
   *
   * This function uses the same FFT technique as MPMULX.  It is 
   * faster because only one forward FFT has to be computed.
   */
  

  double t1, t2;
  int ia, na, ncr, i, i2=1, nn, nb, nx;

  if(MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if (MPIDB >= 8) {
    cout << "\nMPSQX I";
  }
  
  ia = SIGN(1, int(a[1]));
  na = MIN(int(ABS(a[1])), mpnw);
  ncr = 1 << mpmcrx; // pow(2.0, mpmcrx);
  if(!na) {
    // one of the inputs is zero -- result is zero.
    zero(b);
    return;
  }

  // Check if precision level of one of the arguments is 
  // enough to justify the advanced routine.
  
  if(na <= ncr) {
    mpmul(a, a, b);
    return;
  }

  //now allocate arrays.
  double *d1 = new double[4*mpnw+8];
  double *d3 = new double[8*mpnw+16];
  //mp_down14 represents value to multiply by
  //to get one fourth of 48 bits below the decimal point.
  const double mp_down14 = 1.0 / 4096.0;
  const double mp_down24 = mprbx;
  const double mp_down34 = mp_down14 * mp_down24;
  const double mp_up14 = 4096.0;
  const double mp_up24 = mpbbx;
  const double mp_up34 = mp_up24 * mp_up14;


  // Place the input data in A into the scratch array DD1. 
  // this code alsp splits the input data into fourth sized words.
  // (mpnbt/4) bits for each new word (maximum)
  
  for(i=0;i<na;i++) {
    i2 = 4*i;
    t1 = a[i+FST_M];
    t2 = FLOOR_POSITIVE(mp_down34*t1);
    d1[i2] = t2;
    t1 -= mp_up34 * t2;
    t2 = int(mp_down24*t1);
    d1[i2+1] = t2;
    t1 -= mp_up24 * t2;
    t2 = int(mp_down14*t1);
    d1[i2+2] = t2;
    t1 -= mp_up14 * t2;
    d1[i2+3] = t1;
  }

  // Call the convolution

  nn = 4 * na;
  nx = int(ANINT(sqrt(3.0 * nn) + mprxx));
  mplconv(1, nn, nx, d1, d1, d3);

  // Recombine words and release carries.

  nb = MIN(na + na, mpnw+3);
  int nb1 = nb - 1;
  d1[1] = nb; //result always positive
  d1[2] = a[2] + a[2] + 1;

  d1[3] = d3[0] * mp_up24 + d3[1] * mp_up14 + d3[2];
  d1[nb+FST_M+1] = d1[nb+FST_M+2] = 0.0;
  
  for(i=0;i<nb1;i++) {
    i2 = i * 4 + 3;
    t1 = d3[i2];
    t2 = FLOOR_POSITIVE(t1 * mp_down14);
    t1 -= t2 * mp_up14;
    d1[i+FST_M] += t2;
    d1[i+FST_M+1] = t1 * mp_up34;
    t1 = d3[i2+1];
    t2 = int(t1 * mp_down24);
    t1 -= t2 * mp_up24;
    d1[i+FST_M] += t2;
    d1[i+FST_M+1] += t1 * mp_up24;
    t1 = d3[i2+2];
    t2 = int(t1 * mp_down34);
    t1 -= t2 * mp_up34;
    d1[i+FST_M] += t2;
    d1[i+FST_M+1] += t1 * mp_up14 + d3[i2+3];
  }
  //one more to do.
  t1 = d3[i2+4];
  t2 = FLOOR_POSITIVE(t1 * mp_down14);
  t1 -= t2 * mp_up14;
  d1[i+FST_M] += t2;
  d1[i+FST_M+1] = t1 * mp_up34;
  
  //now go on.
  int d_add=0;
  i=0;
  //eliminate leading zeros (except where something
  // will probably carry in)
  while(i<(nb1-3) && d1[i+FST_M] == 0.0 && d1[i+FST_M+1] < (mpbdx-2.0)) {
    i++;
  }
  if(i) {
    d1[2] -= double(i);
    d1[1] = SIGN(1.0, d1[1]) * (ABS(d1[1])  - double(i));
    d1[i+2] = d1[2];
    d1[i+1] = d1[1];
    d1 += i;
    d_add -= i;
  }

  // Fix up the result;
  mpnorm(d1, b);
  
  if(MPIDB >= 8) {
    cout << "\nMPSQX 0";
  }
  delete [] (d1+d_add);
  delete [] d3;
  return;
}


void mp_real::mppix(mp_real& pi)
{
  /**
   * This computes Pi to available precision (MPNW mantissa words). For
   * modest levels of precision, use MPPI.  The last word of the
   * result is not reliable. 
   *
   * MPPIX uses almost the same algorithm as MPPI. 
   *
   * Required space in pi : mpnw + 4 cells.
   * 
   * The algorithm that is used for computing Pi, which is due to Salamin
   * and Brent, is as follows: 
   *
   * Set A_0 = 1, B_0 = 1/Sqrt(2), and D_0 = Sqrt(2) - 1/2.
   * 
   * Then from k = 1 iteratoe the following operations:
   * 
   *  A_k = 0.5 * (A_{k-1} + B_{k-1})
   *  B_l = Sqrt (A_{k-1} * b_{k-1})
   *  D_k = D_{k-1} - 2^k * (A_k - B_k) ^2.
   * 
   * The P_k = (A_k + B_k) ^2 / D_k  converges quadratically to Pi.
   * In other words, each iteration approximately doubles the 
   * number of correct digits, providing all iterations are
   * done with the maximum precision.
   */
  const double cl2 = 1.4426950408889633;
  int ncr = 1 <<mpmcrx;
  
  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(pi);
    return;
  }

  if (mpnw < ncr) {
    // not worth using mppix.  use mppi.
    mppi(pi); return;
  }

  // Perform calculations to one extra word accuracy.
  double t1;
  int mq, k;
  int nws = mpnw;
  size_t n6 = mpnw +6;
  mpnw++;
  mp_real sk0(n6),
    sk1(n6),
    sk2(n6),
    sk3(n6),
    sk4(n6),
    f(size_t(8));
    
  // Determine the number of iterations required for the
  // given precision level. This formula is good only for this
  // Pi algorithm
  
  t1 = nws * log10(mpbdx);
  mq = int(cl2 * (log(t1) - 1.0) + 1.0);
  
  // Initialize as above.
  //sk0 = 1.0;
  sk0[1] = 1.0; sk0[2] = 0.0; sk0[3] = 1.0;
  //f = 2.0;
  f[1] = 1.0; f[2] = 0.0; f[3] = 2.0; f[4] = 0.0;
  mpsqrtx(f, sk2);
  mpmuld(sk2, 0.5, 0, sk1);
  // f = 1/2;
  f[2] = -1; f[3] = 0.5 * mpbdx;
  mpsub(sk2, f, sk4);

  // Perform iterations as described above.
  
  for(k=1; k<=mq ; k++) {
    mpadd(sk0, sk1, sk2);
    mpmulx(sk0, sk1, sk3);
    mpsqrtx(sk3, sk1);
    mpmuld(sk2, 0.5, 0, sk0);
    mpsub(sk0, sk1, sk2);
    mpmulx(sk2, sk2, sk3);
    t1 = pow(2.0, k);
    mpmuld(sk3, t1, 0, sk2);
    mpsub(sk4, sk2, sk3);
    mpeq(sk3, sk4);
  }
  
  // Complete computation.
  
  mpadd(sk0, sk1, sk2);
  mpmulx(sk2, sk2, sk3);
  mpdivx(sk3, sk4, sk2); 
  mpeq(sk2, pi);
  
  // Restore original precision level.
  mpnw = nws;
  mproun(pi);
  
  if(MPIDB >= 7) cout <<"\nComputed Pi : "<< pi;
  return;
}


void mp_real::mpexpx(const mp_real& a, const mp_real& pi, 
		     const mp_real& al2, mp_real& b)
{
  /**
   * This computes the exponential function of the MP number A and 
   * places the MP result in B.  Pi is the MP value of Mp produced
   * by mppix.  AL2 is the MP value of Log(2) produced by a prior call to 
   * MPLOG or MPLOGX.  Before calling MPEXPX, the arrays mpuu1
   * and mpuu2 must be initialized by calling mpinix.  For modest
   * levels of pecision, use MPEXP.
   * The last word of the result is not reliable.  
   *
   * This routine uses the Newton iteration 
   *  
   *  b_{k+1} = b_k [a - log b_k] + b_k
   *
   * with a dynamically changing level of precision. Logs are performed
   * using MPLOGX.  See the comment about the parameter NIT in MPDIVX.
   * The multiplication b_k * [] is performed at roughly half precision.
   *
   */
  const double alt = 0.693147180559945309;
  const double cl2 = 1.4426950408889633,
    cpi = 3.141592653589793238;
  int nit = 3;
  double t1, t2;
  int n1, n2;

  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if(MPIDB >= 5) cout <<"\nMPEXPX I";
  
  int ncr = 1 << (mpmcrx+1);

  // Check if precision level is low to justify the advanced routine.
  
  if (mpnw <= ncr) {
    mpexp(a, al2, b); 
    return;
  }

  mpmdc(a, t1, n1);
  if(n1)
    t1 *= pow(2.0, n1);
  
  // Check if Log(2) has been precomputed.
  
  mpmdc(al2, t2, n2);
  if(n2 != -mpnbt || ABS(t2 * mp::mprdx - alt) > mprx2) {
    if (MPKER[37] != 0) {
      cout << "\n*** MPEXPX: LOG(2) must be precomputed.";
      MPIER = 37;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  // check if Pi has been precomputed.
  mpmdc(pi, t2, n2);
  if(n2 != 0 || fabs(t2 - cpi) > mprx2) {
    if(MPKER[38] != 0) {
      cout <<"\n*** MPEXPX: Pi must be precomputed.";
      MPIER = 38;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  // Check for overflows and underflows.
  // The constant is roughly (2^26 * 48)* log(2),
  // Which allows a result with (word) exponent up to 2^26.
  if(abs(t1) > 2232783353.0) {
    if(t1 > 0.0) {
      if(MPKER[39] != 0) {
	cout << "\n*** MPEXPX: Argument is too large";
	MPIER = 39;
	if(MPKER[MPIER] == 2) mpabrt();
      }
      return;
    } else {
      zero(b);
      return;
    }
  }

  size_t n6 = (size_t)(mpnw + 6);
  int nws = mpnw;
  mp_real sk1(n6), sk2(n6);

  // Determine the least integer MQ such that 2 ^ MQ >= mpnw.
  
  int mq = int(cl2 * log(double(nws)) + 1.0 - mprxx);

  // compute initial approximation to exp(a).
  
  mpnw = ncr+1;
  mpexp(a, al2, b);
  int k, prec_change = 1, iq = 0, nws1, nws2;
  //step up precision
  for(k=mpmcrx+2;k<=mq;k++) {
    nws1 = MIN(mpnw+5, nws) +1;
    if(prec_change) {
      mpnw = MIN(2 * mpnw -2, nws) + 1;
    } else {
      prec_change = 1;
    }
    nws2 = mpnw;
    mplogx(b, pi, al2, sk1);
    mpsub(a, sk1, sk2);
    mpnw = nws1;
    mpmulx(b, sk2, sk2);
    mpnw = nws2;
    //step up precision before add.
    mpnw = MIN(mpnw + 5, nws) + 1;
    mpadd(b, sk2, b);
    mpnw = nws2;
    if(!iq && mq -nit >= k) {
      k--;
      prec_change = 0;
      iq = 1;
    }
  }
  if(MPIDB >= 6) cout <<"\nMPEXPX 0";
  mpnw = nws;
  mproun(b);
  return;
}

void mp_real::mplogx(const mp_real& a, const mp_real& pi, const mp_real& al2, 
		     mp_real& b)
{
  /**
   * This computes the natrural logarithm of the MP number a and places
   * the MP result in B.  PI is the MP value of Pi produced previously
   * by a call to MPPI or MPPIX.  AL2 is the MP value of Log(2), produced by a
   * previous call to MPLOG or MPLOGX.  Before calling MPLOGX, the
   * mpuu1 and mpuu2, and mpuu3 arrays must be initialized by calling
   * MPINIX. For modest levels of precision, use mplog.  the last 
   * word of the result is not reliable.  Debug tarts with MPIDB = 6.
   *
   * This routine uses the following algorithm, which is due to Salamin.
   * If a is extremeley close to 1, use a Taylor series.  Otherwise,
   * Select n such that z = x 2^n is at least 2^m, where m is the number
   * of bits of desired precision in the result.  Then,
   *
   *   Log(x) = Pi  / [2 AGM (1, 4/x) ].
   */
  double t1, t2, tn;
  const double alt = 0.693147180559945309, cpi = 3.141592653589793;
  const int mzl = -5;
  int it2, n1;
  
  if(MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if(MPIDB >= 6) cout << "\nMPLOGX I";

  int ia = SIGN(1, int(a[1]));
  int na = MIN(ABS(int(a[1])), mpnw);
  int ncr = 1 << (mpmcrx-2); //This version of log is faster at
			// smaller number of words.
  int n2;

  // Check if precision level is too low to justify the advanced routine.

  if (mpnw <= ncr) {
    mplog(a, al2, b);
    return;
  }
  
  if(ia < 0 || na == 0) {
    //input is less than or equal to zero.
    if(MPKER[52] != 0) {
      cout <<"\n*** MPLOGX: Argument is less than or equal to zero.";
      MPIER = 52;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  // check if Pi has been precomputed.
  mpmdc(pi, t1, n1);
  if(n1 != 0 || ABS(t1 - cpi) > mprx2) {
    if(MPKER[53] != 0) {
      cout << "\n*** MPLOGX: PI must be precomputed. ";
      MPIER = 53;
      if(MPKER[MPIER] == 2) mpabrt();      
    }
    return;
  }

  // Unless the input is 2, Log(2) must have been precomputed.
 
  if(a[1] != 1.0 || a[2] != 0.0 || a[3] != 2.0) {
    it2 = 0;
    mpmdc(al2, t2, n2);
    if(n2 != -mpnbt || ABS(t2 * mprdx - alt) > mprx2) {
      if(MPKER[54] != 0) {
	cout << "\n*** MPLOGX: Log (2) must be precomputed.";
	MPIER = 54;
      if(MPKER[MPIER] == 2) mpabrt();
      }
      return;
    }
  } else {
    it2 = 1;
  }
  
  int nws = mpnw;
  mpnw++;

  size_t n6 = (size_t)(mpnw + 6);
  mp_real sk0(n6), sk1(n6), sk2(n6), sk3(n6), f1((size_t)8), f4((size_t)8);
  f1[1] = 1.0; f1[2] = 0.0; f1[3] = 1.0; f1[4] = 0.0;
  f4[1] = 1.0; f4[2] = 0.0; f4[3] = 4.0; f4[4] = 0.0;

  // If argument is 1 the result is zero.  If the argement is
  //extremeley close to 1, employ  a Taylor's series instead.

  mpsub(a, f1, sk0);
  if(sk0[1] == 0.0) {
    zero(b);
    return;
  } else if(sk0[2] < mzl) {
    mpeq(sk0, sk1);
    mpeq(sk1, sk2);
    int i1 = 1;
    int tl = int(sk0[2] - mpnw - 1);
    double st, is = 1.0;
    if(MPIDB >= 6) {
      cout <<"\nUsing Taylor series in MPLOGX.";
    }
    do {
      i1++;
      is = -is;
      st  = is * i1;
      mpmulx(sk1, sk2, sk3);
      mpdivd(sk3, st, 0, sk2);
      mpadd(sk0, sk2, sk3);
      mpeq(sk3, sk0);
    } while(sk2[2] >= tl);

    mpeq(sk0, b);
    return;
  }
  
  // If input is exactly 2, set the exponent to a large value. Otherwise,
  // multiply the input by a large power of two.

  mpmdc(a, t1, n1);
  n2 = mpnbt * (mpnw / 2 + 2) - n1;
  tn = n2;
  if(it2 == 1) 
    mpdmc(1.0, n2, sk0);
  else 
    mpmuld(a, 1.0, n2, sk0);

  // Perform AGM iterations.
  mpeq(f1, sk1);
  mpdivx(f4, sk0, sk2);
  mpagmx(sk1, sk2);
  
  // Compute B = Pi / (2 * A), where A is the limit of the AGM iterations.

  mpmuld(sk1, 2.0, 0, sk0);
  mpdivx(pi, sk0, sk1);
  // If the input was exactly 2, divide by TN.  Otherwise,
  // subtract TN * Log(2).
  
  if(it2 == 1) {
    mpdivd(sk1, tn, 0, b);
  } else {
    mpmuld(al2, tn, 0, sk2);
    mpsub(sk1, sk2, b);
  }
  mpnw = nws;

  if(MPIDB >= 6) cout << "MPLOGX 0";
  return;
}

void mp_real::mpagmx(mp_real &a, mp_real& b)
{
  /**
   * This performs the arithmetic-geometric mean (AGM) iterations.
   * this routine is called by MPLOGX.  It is not intended to be 
   * called directly by the user.
   */

  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(a); zero(b);
    return;
  }
  size_t n6 = (size_t)(mpnw + 6);
  mp_real sk0(n6), sk1(n6);
  int l1 = 0;
  double s1;
  sk0[2] = 10000000.0;// high value to force second iteration.

  do {
    l1++;
    if (l1 == 50) {
      if(MPKER[5] != 0) {
	cout <<"\n*** MPAGMX: Iteration limit exceeded.";
	MPIER = 5;
	if(MPKER[MPIER] == 2) mpabrt();
      }
      break;
    }
    
    s1 = sk0[2];
    mpadd(a, b, sk0);
    mpmuld(sk0, 0.5, 0, sk1);
    mpmulx(a, b, sk0);
    mpsqrtx(sk0, b);
    mpeq(sk1, a);
    mpsub(a, b, sk0);
    
    // Check for convergence.
  }
  while(sk0[1] != 0.0 && (sk0[2] < s1 || sk0[2] >= -2));
  if(MPIDB >= 6) cout <<"\nMPAGMX : Iteration = "<<l1<<", Tol. Achieved = "
		      <<sk0[2];
  return;
}
  

void mp_real::mpdivx(const mp_real& a, const mp_real& b, mp_real& c)
{
  /**
   * This divides the MP number A by the MP number B and returns the MP
   * result in C.  Before calling MPDIVX, the arrays mpuu1, and mpuu2 must
   * be initizlied by calling mpinix.  for modest levels of precision, use
   * mpdiv.  debug output starts with MPIDB = 7.

   * This subroutine emplys the following Newton-Raphson iteration, which
   * converges to 1 / B:
   *
   *  X_{k+1} = X_k + (1 - X_k * B) * X_k
   *
   * where the multiplication () * X_k is performed with only half of 
   * the normal level of precision.  These iterations are performed with
   * a maximum precision level MPNW that is dynamically changing with
   * each iteration.  The final iteration is performed as follows (this
   * is due to A. Karp):
   
   * A / B = (A * X_n) + [A - (A * X_n) * B] * X_n (approx.).

   * where the multiplications A * X_n and [] * X_n are performed with
   * only half the final level of precision.
   *
   * One difficulty iwht this procedure is that errors often accumulate
   * in the trailing mantissa words. This error can be controlled by repeating
   * one of the iterations.  The iteration that is repeated is controlled by
   * setting the parameter NIT below : if NIT = 0, the last iteration is
   * repeated (this is the most effective but the most expensive).  If NIT 
   * is 1, then the next-to-last iteration is repeated, etc.
   *
   *
   *  Important note about mpdivx :
   *
   *  It is NOT SAFE to use this routine with the second and third
   * arguments being the same mp_real object, that is, the sequence
   *
   *    mp_real temp;
   *    mpdivx(a, b, temp);
   *    mpeq(temp, b);
   *
   *  Will set b = a/b;   Whereas the sequence
   *
   *    mpdivx(a, b, b);  //Incorrect usage 
   *
   *  Will have undefined results.  This of partucular importance
   *  when attempting to compute the inverse of a number.
   *
   *  
   */

  const double cl2 = 1.442695040889633;
  const int nit = 3;
  const int ncr = 1 << (mpmcrx+2);

  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(c);
    return;
  }
  if(MPIDB >= 7) {
    cout << "\nMPDIVX I";
  }
  int na = MIN(int(ABS(a[1])), mpnw);
  int nb = MIN(int(ABS(b[1])), mpnw);
  

  // Check if precision level of divisor is too low
  // to justify the advanced routine.
  
  if(nb <= ncr) {
    mpdiv(a, b, c);
    return;
  }


  //check if divisor is zero.
  if(nb == 0) {
    if(MPKER[33] != 0) {
      cout << "*** MPDIVX: Divisor is zero.";
      MPIER = 33;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  // check if dividend is zero.
  if(na == 0) {
    zero(c);
    return;
  }


  size_t n6 = (size_t)(mpnw + 6);
  int nws = mpnw;
  mp_real sk0(n6), sk1(n6), sk2(n6), f((size_t)8);

  // Determine the least integer MQ such that 2^MQ >= mpnw.

  int mq = int(cl2 * log(double(mpnw)) + 1.0 - mprxx);

  // Compute the initial approximation of 1 /B to a precision of ncr words.
  mpnw = ncr + 1;
  f[1] = 1.0; f[2] = 0.0; f[3] = 1.0; f[4] = 0.0;
  mpdiv(f, b, c);
  int iq = 0, prec_change = 1, k;
  int nw1=0, nw2=0;
  
  // Perform the Newton-Raphson iterations described above.

  for(k=mpmcrx+2;k<mq; k++) {
    if(prec_change) {
      nw1 = mpnw;
      mpnw = MIN(2*mpnw - 2, nws) + 1;
      nw2 = mpnw;
    } else {
      prec_change = 1;
    }
    mpmulx(b, c, sk0);
    mpsub(f, sk0, sk1);
    mpnw = nw1;
    mpmulx(c, sk1, sk0);
    mpnw = nw2;
    mpadd(c, sk0, c);
    if(k >= mq - nit && !iq) {
      iq = 1;
      prec_change = 0;
      k--;
    }
  }
  
  //Perform last iteration using Karp's trick.
  mpmulx(a, c, sk0);
  nw1 = mpnw;
  mpnw = MIN(2*mpnw - 2, nws) + 1;
  nw2 = mpnw;
  mpmulx(sk0, b, sk1);
  mpsub(a, sk1, sk2);
  mpnw = nw1;
  mpmulx(sk2, c, sk1);
  mpnw = nw2;
  mpadd(sk0, sk1, c);
  
  // Restore original precision level.
  mpnw = nws;
  mproun(c);

  if(MPIDB >= 7) {
    cout << "\nMPDIVIX 0";
  }
  return;
}   

void mp_real::mpcshx(const mp_real& a, const mp_real& pi, 
		     const mp_real& al2, mp_real& x, mp_real& y)
{
  /** 
   * This computes the hyperbolic cosine and sine of the MP
   * number A and returns the two MP results in X and Y,
   * respectively.  PI is the MP value of Pi computed by a previous
   * call to MPPI or MPPIX.   AL2 is the MP value of Log(2),
   * computed by a previous call to MPLOG or MPLOGX.  Before calling
   *  MPCSHX, the arrays mpuu1 and mpuu2 must be initialized by 
   * calling MPINIX.  For modest levels of precision, use MPCSSH.
   */

  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(x);
    zero(y);
    return;
  }
  if(MPIDB >= 5) cout << "\nMPCSHX I";

  size_t n6 = (size_t)(mpnw + 6);
  mp_real sk0(n6), sk1(n6), sk2(n6), f(size_t(8));
  f[1] = 1.0; f[2] = 0.0;  f[3] = 1.0; f[4] = 0.0;

  mpexpx(a, pi, al2, sk0);
  mpdivx(f, sk0, sk1);
  mpadd(sk0, sk1, sk2);
  mpmuld(sk2, 0.5, 0, x);
  mpsub(sk0, sk1, sk2);
  mpmuld(sk2, 0.5, 0, y);
  
  if(MPIDB >= 5)
    cout << "\nMPCSHX 0";
  return;
}

void mp_real::mpnpwx(const mp_real& a, int n, mp_real& b)
{
  /**
   * This computes the N-th power of the MP number A and places
   * the MP result in B.  When N is zero, 1 is returned.  When N is negative,
   * the reciprocal of A ^ |N| is returned.  Before calling MPNPWX, the
   * arrays of mpuu1 and uu2 must be initialized by calling mpinix.
   * For modest levels of precision, use MPNWPR.
   *
   *
   * This routine emplys the normal binary method for exponentiation.
   */
  
  const double cl2 = 1.4426950408889633;// 1/log(2)

  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if(MPIDB >= 6) {
    cout << "\nMPNPWX I";
  }

  int ncr = 1 << mpmcrx;
  int na = MIN(int(ABS(a[1])), mpnw);

  // Check if precision level of A is too low to justify the advanced routine.
  
  if(na < ncr && n >= 0 && n <= 4) {
    mpnpwr(a, n, b);
    return;
  }
  if(na == 0) {
    if(n >= 0) {
      zero(b);
      return;
    } else {
      // error : 0^N, N <= 0.
      if(MPKER[58] != 0) {
	cout <<"\n*** MPNPWX: argument is zero and N is negative or zero.";
	MPIER = 58;
	if(MPKER[MPIER] == 2) mpabrt();
      }
      return;
    }
  }

  size_t n5 = (size_t)(mpnw+5);
  int nn = ABS(n);
  mp_real sk0(n5), sk1(n5), f1(size_t(8));
  //f1 = one.
  f1[1] = 1.0; f1[2] = 0.0; f1[3] = 1.0; f1[4] = 0.0;

  if(nn == 0) {
    mpeq(f1, b);
    return;
  } else if(nn == 1) {
    mpeq(a, b);
  } else if(nn == 2) {
    mpsqx(a, b);
  } else {
    // full binary exponentiation.
    // Determine the least integer mn such that 2 & mn > nn.
    int mn = int(ANINT(cl2 * log(double(nn)) + 1.0 + mprxx));
    mpeq(a, sk0);
    mpeq(f1, b);
    int kn = nn, j, kk;

    for(j=1; j <= mn; j++) {
      kk = kn / 2;
      if(kn != 2 * kk) {
	mpmulx(b, sk0, b);
      }
      kn = kk;
      if(kn && j < mn)
	mpsqx(sk0, sk0);
    }
  }
  
  // Compute the reciprocal if N is negative.
  if(n < 0) {
    mpdivx(f1, b, sk0);
    mpeq(sk0, b);
  }
  return;
}

void mp_real::mpangx(const mp_real& x, const mp_real& y, 
		     const mp_real& pi, mp_real& a)
{
  /**
   * This computes the MP angle A subtended by the MP pair (X, Y)
   * considered as a point in the x-y plane.  This is more usefull than
   * an arctan or arcsin routine, since it places the result correctly in
   * the full circle, i.e. -Pi < A <= Pi.  PI is the MP value of Pi computed
   * by a previous call to MPPI or MPPIX.  Before calling MPANGX, the arrays
   * mpuu1 and mpuu2 must be initialized by calling MPINIX.  For modest
   * levels of precision, use MPANG.  The last word of the result
   * is not reliable.
   *
   * This routine employs a complex arithmetic version of the MPLOGX algorithm.
   */

  const double cpi = 3.141592653589793;

  if(MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(a);
    return;
  }
  if(MPIDB >= 6) {
    cout << "\nMPANGX I";
  }
  
  int ix = SIGN(1, int(x[1]));
  int nx = MIN(int(ABS(x[1])), mpnw);
  int iy = SIGN(1, int(y[1]));
  int ny = MIN(int(ABS(y[1])), mpnw);
  int ncr = 1 << mpmcrx;

  // Check if precision level it too low to justify the advanced routine.
  
  if(mpnw <= ncr) {
    mpang(x, y, pi, a); return;
  }

  // Check if both X and Y are zero.
  if(!nx && !ny) {
    if(MPKER[9] != 0) {
      cout << "\n*** MPANGX: Both arguments are zero.";
      MPIER = 9;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }
  
  // Check if Pi has been precomputed.
  
  double t1;
  int n1;
  mpmdc(pi, t1, n1);
  if(n1 != 0 || ABS(t1 - cpi) > mprx2) {
    if(MPKER[10] != 0) {
      cout << "\n*** MPANGX: PI must be precomputed.";
      MPIER = 10;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  // Check if one of X or Y is zero.
  if(nx == 0) {
    if(iy > 0) 
      mpmuld(pi, 0.5, 0, a);
    else
      mpmuld(pi, -0.5, 0, a);
    return;
  } else if(ny == 0) {
    if(ix > 0) 
      zero(a);
    else
      mpeq(pi, a);
    return;
  }
  
  size_t n6 = (size_t)(mpnw+6), s8 = (size_t)8;
  mp_complex sk0(n6), sk1(n6), sk2(n6);
  mp_complex f1(s8), f4(s8);
  zero(f1.imag);
  zero(f4.imag);
  //f1 = one
  f1.real[1] = 1.0; f1.real[2] = 0.0; f1.real[3] = 1.0; f1.real[4] = 0.0;
  //f4 = four.
  f4.real[1] = 1.0; f4.real[2] = 0.0; f4.real[3] = 4.0; f4.real[4] = 0.0;

  // Multiply the input by a large power of two.

  mpmdc(x, t1, n1);
  int n2 = mpnbt * (mpnw / 2 + 2) - n1;
  mpmuld(x, 1.0, n2, sk0.real);
  mpmuld(y, 1.0, n2, sk0.imag);

  // Perform AGM iterations.

  mp_complex::mpceq(f1, sk1);
  mp_complex::mpcdivx(f4, sk0, sk2);
  mp_complex::mpcagx(sk1, sk2);

  // Compute A = Imag (Pi / (2*Z)), where Z is the limit of the complex
  // AGM.

  mp_complex::mpcmuld(sk1, 2.0, 0, sk0);
  mpeq(pi, sk2.real);
  zero(sk2.imag);
  mp_complex::mpcdivx(sk2, sk0, sk1);
  mpeq(sk1.imag, a);
  
  return;
}


void mp_real::mpcssx(const mp_real& a, const mp_real& pi,
		     mp_real& x, mp_real& y)
{
  /**
   * This computes the cosine and sine of the MP number A
   * and returns the two MP results in X and Y, respectively.
   *  PI is the MP value of Pi computed by a previous call to MPPI
   * or MPPIX.  Before calling MPCSSX, the arrays mpuu1 and
   * mpuu2 must be initialized by calling MPINIX.  For modest levels
   * of precision, use MPCSSN.  The last word of the result is not
   * reliable.
   *
   * This routine emplys a complex arithmetic version of the
   * scheme found in MPEXPX.
   */
  const double cl2 = 1.4426950408889633, cpi = 3.141592653589793;
  const int nit = 1;
  
  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(x);
    zero(y);
    return;
  }
  if(MPIDB >= 5) cout << "\nMPCSSX I";

  int na = MIN(int(ABS(a[1])), mpnw);
  int ncr = 1 << mpmcrx;

  // Check if precision level is too low to justify advanced routine.

  if(mpnw <= ncr) {
    mpcssn(a, pi, x, y); return;
  }
  // Check if input is zero.

  if(!na) {
    zero(x);
    zero(y);
    return;
  }
  
  //Check if Pi has been precomputed.
  
  double t1;
  int n1;
  mpmdc(pi, t1, n1);
  if(n1 != 0 || ABS(t1 - cpi) > mprx2) {
    if(MPKER[30] != 0) {
      cout << "\n*** MPCSSX: PI must be precomputed.";
      MPIER = 30;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  size_t n6 = (size_t)(mpnw+6);
  mp_complex sk0(n6), sk1(n6), sk3(n6), sk2(n6);
  mp_real f1(size_t(6));
  int nws = mpnw;
  f1[1] = 1.0; f1[2] = 0.0; f1[3] = 1.0; f1[4] = 0.0;
  
  // Reduce argument to betwwen -Pi and Pi.

  mpmuld(pi, 2.0, 0, sk0.real);
  mpdivx(a, sk0.real, sk1.real);
  mpnint(sk1.real, sk2.real);
  mpmulx(sk2.real, sk0.real, sk1.real);
  mpsub(a, sk1.real, sk0.real);
  
  // Determine the least integer MQ such that 2 ^ MQ >= mpnw.

  int mq = int(cl2 * log(double(nws)) + 1.0 - mprxx);
  mpeq(f1, sk2.real);
  // Compute initial approximation to [Cos (A), Sin (A)].
  
  mpnw = ncr+1;
  mpcssn(sk0.real, pi, sk3.real, sk3.imag);
  int iq =0, k, prec_change=1;

  // Perform the Newton-Raphson iteration with a dynamically changing precision
  // level mpnw.
  
  for(k=mpmcrx+1; k<= mq; k++) {
    if(prec_change) {
      mpnw = MIN(2*mpnw-2, nws) + 1;
    } else {
      prec_change = 1;
    }
    mpangx(sk3.real, sk3.imag, pi, sk1.real);
    mpsub(sk0.real, sk1.real, sk2.imag);
    mp_complex::mpcmulx(sk3, sk2, sk1);
    mp_complex::mpceq(sk1, sk3);
    if(k >= mq - nit && iq == 0) {
      iq = 1;
      prec_change = 0;
      k--;
    }
  }
  
  // The final (cos, sin) result must be normalized to magnitude 1.
  mpsqx(sk3.real, sk0.real);
  mpsqx(sk3.imag, sk0.imag);
  mpadd(sk0.real, sk0.imag, sk1.real);
  mpsqrtx(sk1.real, sk2.real);
  mpdivx(sk3.real, sk2.real, sk0.real);
  mpdivx(sk3.imag, sk2.real, sk0.imag);

  mpnw = nws;
  mpeq(sk0.real, x);
  mpeq(sk0.imag, y);
  
  if(MPIDB >= 5)
    cout << "\nMPCSSX 0";
}

void mp_real::mpoutx(const mp_real& a, int la, char *b, int& n)
{
  /**
   * Converts the MP number A into character form in the
   * char array B.  N (an output parameter) is the length of the output.
   * In other words, B is contained in B[0]...B[N-1].  The format
   * is analogous to the Fortran exponential format (E format),
   * except that the exponent is placed first.
   * 
   * before calling MPOUTX, the arrays mpuu1 and mpuu2 must be initialized
   * by calling MPINIX.  For modest levels of precision, 
   * use MPOUTC.
   *
   * Space needed in b :   mpnbt * log_10(2) * mpnw + 30 cells
   *
   *
   * The algorithm is to multiply by a large power of ten, then
   * round down to the nearest integer, then print the integer
   * into a string (using mpoutx_help), the use the integer
   * to write the result into b.
   *
   *  or in other words 15.06 * mpnw + 30 cells.
   */
  const double al2 = 0.301029995663981195;

  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    b[0] = ' ';
    b[1] = '\0';
    return;
  }
  if(MPIDB >= 7) 
    cout << "\nMPOUTX I";

  int nws = mpnw;
  int ncr = 1 << (mpmcrx+1);

  if(mpnw < ncr || ((a[2]+1.0 >= ABS(a[1])) && (ABS(a[1]) < ncr))) {
    mpout(a, MIN(la, int(15.06 * ABS(a[1]))+4), b, n);
    return;
  }

  mpnw += 6;
  size_t n6 = (size_t)(mpnw+6);
  mp_real sk0(n6), sk1(n6), sk2(n6), sk3(n6), sk4(n6);

  // Normalize input to an 
  // approximate integer by multiplying by a suitable power of 10.

  double t1 = a[FST_M] + mprdx * a[FST_M+1] + mprx2 * a[FST_M+2];
  double t2 = log10(t1);
  int m1;
  m1 = la - int(mpnbt*al2*a[2]) -int(t2);
  int m2 = int(((ABS(a[1]) - a[2] - 1.0)*mpnbt));
  if(m2 > 0)
    m1 = MIN(m1, m2);
  m1+=2;

  mpdmc(10.0, 0, sk0);
  mpnpwx(sk0, m1, sk2);
  mpmulx(a, sk2, sk1);
  sk1[1] = ABS(sk1[1]);
  mpnint(sk1, sk1);
  if((sk1[1] * al2 * mpnbt) >= la + 50) {
    cout << "\n*** MPOUTX : Exponent Error : sk1 too large";
    mpabrt();
  }

  //now we have an integer, close to 10^m1 * a.
  char *integer_string = new char[la+50];
  mpoutx_help(sk1, integer_string, la+50);
  
  int i=0, j;
  while(integer_string[i] == '0') i++;
  //i holds the index of the first nonzero digit.
  long exponent = la+50 - i - 1 - m1;
  b[0] = '1';
  b[1] = '0';
  b[2] = ' ';
  b[3] = '^';
  sprintf(b+4, "%11ld", exponent);
  b[15] = ' ';
  b[16] = 'x';
  b[17] = ' ';
  b[18] = a[1] >= 0.0 ? ' ' : '-';
  b[19] = integer_string[i++];
  b[20] = '.';
  for(j=i;j<la+50; j++) {
    b[21+j-i] = integer_string[j];
  }
  if(j-i > mpoud) { // got too many digits.
    while(j-i > mpoud) j--;
  }
  b[21+j-i] = ',';
  b[21+j-i+1] = '\0';
  n = 21+j-i+1;
  i = n-2;
  while(b[i] == '9') i--;
  if(i != n-2) {
    if(b[i] == '.') {//nines all the way to the decimal point.
      if(b[i-1] == '9') {//first digit was also nine.
	exponent++;
	sprintf(b+4, "%11ld", exponent);
	b[15] = ' ';
	b[16] = 'x';
	b[17] = ' ';
	b[18] = a[1] >= 0.0 ? ' ' : '-';
	b[i-1] = '1';
	b[i+1] = ',';
	b[i+2] = '\0';
	n = i+2;
      } else {
	b[i-1] += 1;
	b[i+1] = ',';
	b[i+2] = '\0';
	n = i+2;
      }
    } else {
      b[i] += 1;
      b[i+1] = ',';
      b[i+2] = '\0';
      n = i+2;
    }
  } else {
    i = n-2;
    while(b[i] == '0') i--;
    if(i != n-2) {
      b[i+1] = ',';
      b[i+2] = '\0';
      n = i+2;
    }
  }

  delete [] integer_string;
  mpnw = nws;
  return;  
}

void mp_real::mpoutx_help(const mp_real& a, char *b, int n)
{
  /**
   * converts the POSITIVE INTEGER a into base-10 and places the
   * result in b, with length n.
   *
   * leading zeros are placed in the array.
   */
  const double al2 = 0.301029995663981195;

  

  if(a[1] == 0.0) {
    //zero out our section.
    int i;
    for(i=0;i<n;i++) b[i] = '0';
    return;
  }

  int nws = mpnw;
  int ncr = 1 << (mpmcrx+1);

  mpnw = MIN(MAX(int(a[1])+3, int(a[2])+4), mpnw);
  //Check if actual precision level of argument is too low to 
  //justify the advanced routine.
  
  if(mpnw < ncr || ((a[2]+1.0 >= ABS(a[1])) && (ABS(a[1]) < ncr))) {
    char *temp_string = new char[n+200];
    int curr_output_prec;
    int i, j, n2= n;
    curr_output_prec = mpoud;
    mpoud = MIN(mpoud, n+10);
    //mpoutc has output of the form 10 ^ # x D.########...
    // where # represents one or more digits, and D represents
    // a single digit

    mpoutc(a, temp_string, n2);
    if(n2 >= n+200) {
      cout << "\n*** MPOUTX HELPER: non-integer or other bad input to helper";
      mpabrt();
    }
    if(n2 < n+100) {
      // add a comma.  sometimes mpout doesn't put one on.
      temp_string[n2] = ',';
      n2++;
      temp_string[n2] = '\0';
    }
    //now strip out the exponent.
    i=0;
    while(i<n+200 && temp_string[i++] != '^');
    j = i;
    while(j<n+200 && temp_string[j++] != 'x');
    if(j == n+200 || temp_string[--j] != 'x') {
      cout << "\n*** MPOUTX HELPER: bad data from MPOUTC";
      mpabrt();
    }
    //now temp_string[i] is just after the ^, and
    // temp_string[j] is the x 
    temp_string[j] = '\0';
    long exponent = atol(&temp_string[i]);
    if(exponent > n) {
      cout << "\n*** MPOUTX HELPER: not enough space for base-10 output"<<
	" in small case.";
      mpabrt();
    }
    j++;
    while(j<n+200 && temp_string[j++] != '.');
    if(j == n+200 || temp_string[--j] != '.') {
      cout << "\n*** MPOUTX: bad data from MPOUTC";
      mpabrt();
    }
    // now temp_string[j] is on the decimal point, just
    // after the first digit.
    // We need to decide from the exponent how many leading zeroes
    // to put down.
    int leading_zeros = n - exponent-1;
    for(i=0;i<leading_zeros;i++) b[i] = '0';
    //get first digit.
    b[i] = temp_string[j-1];
    j++; i++;
    for(;i<n;i++, j++) {    
      b[i] = temp_string[j];
      if(b[i] == ',') break;
      if(!isdigit(b[i]))
	b[i] = '0';
    }
    //sometimes mpout prints out integers incorrectly.
    if(j<n2 && 
       isdigit(temp_string[j]) && 
       temp_string[j] >= '5') { //round up.
      int i2 = i-1;
      while(i2>=0 && b[i2] == '9') i2--;
      if(i2 < 0) {
	//all nines - wierd.
	cout <<"\n*** MPOUTX round failed. use mpout.";
	mpabrt();
      }
      b[i2]++;
      i = i2+1;
    }
    //fill in trailing zeros
    for(;i<n;i++, j++) b[i] = '0';

    //we should be done with this recurse.
    mpnw = nws;
    mpoud = curr_output_prec;
    delete [] temp_string;
    return;
  }

  // there are too many digits to efficiently do with
  // mpoutc.  Prepare to recurse.

  mpnw++;
  size_t n6 = (size_t)(mpnw+6);
  mp_real sk0(n6), sk1(n6), sk2(n6), sk3(n6);

  int i1, i2;
  double t1;
  // split large integer into two approximateley equal decimal sections.
  mpmdc(a, t1, i1); 
  i2 = int(log10(t1))+1;
  i2 += int(i1 * al2)+1;
  int m2 = (i2+1) / 2;
  m2++;
  if(m2 > n) {
    cout << "\n*** MPOUTX HELPER: not enough space for base-10 output.";
    mpabrt();
  }
  //do the split into superdigits of base 10^m2
  mpdmc(10.0, 0, sk0);
  mpnpwx(sk0, m2, sk3);

  //perform a mod 10^m2.  division is performed at less precision.
  int nws2 = mpnw;
  mpnw = MIN(mpnw, int(a[2]) - int(sk3[2]) + 4);
  mpnw = MAX(mpnw, 1);
  mpdivx(a, sk3, sk0);
  mpnw = nws2;


  mpinfr(sk0, sk2, sk0); //fractional part is garbage
  mpmulx(sk2, sk3, sk0);
  mpsub(a, sk0, sk0);
  //test for error in division and modulus, and fix it.
  if(sk0[1] < 0.0) {
    mpsub(sk2, mp_real(1.0), sk2);
    mpadd(sk0, sk3, sk0);
  } else if(sk0 >= sk3) {
    mpadd(sk2, mp_real(1.0), sk2);
    mpsub(sk0, sk3, sk0);
  }

  //now sk0 holds the low superdigit, and sk2 holds the high superdigit
  //(superdigits are in base 10^m2.)
  

  // Recursively convert each section.

  mpoutx_help(sk2, b, n-m2);

  //now the other recursion
  mpoutx_help(sk0, b+(n-m2), m2);

  mpnw = nws;
  return;
}

