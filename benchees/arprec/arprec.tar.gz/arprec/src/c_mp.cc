/*
 * src/c_mp.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 * Contains C wrapper function for ARPREC library.
 * This can be used from fortran code.
 * 
 * Last modified: July 9, 2002
 */
#include "config.h"

#include "mp/mpint.h"
#include "mp/mpreal.h"
#include "mp/mpcomplex.h"
#include "mp/c_mp.h"

#ifdef CRAY_STRINGS
#include <fortran.h>
#endif

#define DoubleToComplex(a)  (mp_complex(a, a + mp::fmpwds5))

extern "C" {

void c_mpinit(int mpipl, char *filename, int mpwds, int *mp5,
	      double *mpl02, double *mpl10, double *mppic, double *mpeps) {
  if (filename[0] == ' ') {
    mp::mp_init(mpipl, 0, 0);
  } else {
    mp::mp_init(mpipl, filename, 0);
  }
  mp::fmpwds5 = mpwds + 5;
  *mp5 = mp::mp5;
  //cout << "c_mpinit: mp5 = " << mp::mp5;
  //cout << "  fmpwds5 = " << mp::fmpwds5 << endl;
  
  // Get the constants
  mpl02[0] = mpl10[0] = mppic[0] = mpeps[0] = *mp5;
  mp_real mpl022(mpl02), mpl102(mpl10), mppic2(mppic), mpeps2(mpeps);
  mpl022 = mp::mpl02;
  mpl102 = mp::mpl10;
  mppic2 = mp::mppic;
  mpeps2 = mp::mpeps;
  mpl022.toTempAndDestroy();
  mpl102.toTempAndDestroy();
  mppic2.toTempAndDestroy();
  mpeps2.toTempAndDestroy();
}

void c_mpgetpar(int pnum, int *val)
{
  switch (pnum) {
  case 1: *val = mp::mpoud; break;
  case 2: *val = mp::MPIDB; break;
  case 3: *val = mp::MPNDB; break;
  case 4: *val = mp::MPMCR; break;
  case 5: *val = mp::MPIRD; break;
  case 6: *val = mp::MPIER; break;
  }
}

void c_mpsetpar(int pnum, int val)
{
  switch (pnum) {
  case 1: mp::mpoud = val; break;
  case 2: mp::MPIDB = val; break;
  case 3: mp::MPNDB = val; break;
  case 4: mp::MPMCR = val; break;
  case 5: mp::MPIRD = val; break;
  case 6: mp::MPIER = val; break;
  }
}


/* add */
void c_mpadd(const double *a, const double *b, double *c) {
  mp_real a2(a), b2(b), c2(c);
  mp_real::mpadd(a2, b2, c2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpadd_d(const double *a, double b, double *c) {
  mp_real a2(a), c2(c);
  c2 = (mp_real) (a2 + b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpadd_ji(const double *a, int b, double *c) {
  mp_int a2(a), c2(c);
  c2 = (mp_int) (a2 + b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpadd_jd(const double *a, double b, double *c) {
  mp_real a2(a), c2(c);
  c2 = (mp_real) (a2 + b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpadd_zq(const double *a, const double *b, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5), b2(b), cr(c), ci(c + mp::fmpwds5);
  mp_real::mpadd(ar, b2, cr);
  ci = ai;
  ar.toTempAndDestroy();
  ai.toTempAndDestroy();
  b2.toTempAndDestroy();
  cr.toTempAndDestroy();
  ci.toTempAndDestroy();
}
void c_mpadd_zx(const double *a, double br, double bi, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5);
  mp_real cr(c), ci(c + mp::fmpwds5);
  cr = (mp_real) (ar + br);
  ci = (mp_real) (ai + bi);
  ar.toTempAndDestroy();
  ai.toTempAndDestroy();
  cr.toTempAndDestroy();
  ci.toTempAndDestroy();
}
void c_mpadd_zz(const double *a, const double *b, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5);
  mp_real br(b), bi(b + mp::fmpwds5);
  mp_real cr(c), ci(c + mp::fmpwds5);
  mp_real::mpadd(ar, br, cr);
  mp_real::mpadd(ai, bi, ci);
  ar.toTempAndDestroy(); ai.toTempAndDestroy();
  br.toTempAndDestroy(); bi.toTempAndDestroy(); 
  cr.toTempAndDestroy(); ci.toTempAndDestroy(); 
}

/* sub */
void c_mpsub(const double *a, const double *b, double *c) {
  mp_real a2(a), b2(b), c2(c); 
  mp_real::mpsub(a2, b2, c2); 
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsub_d(const double *a, double b, double *c) {
  mp_real a2(a), c2(c); 
  c2 = (mp_real) (a2 - b); 
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsub_dq(double a, const double *b, double *c) {
  mp_real b2(b), c2(c); 
  c2 = (mp_real) (a - b2); 
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsub_ji(const double *a, int b, double *c) {
  mp_int a2(a), c2(c);
  c2 = (mp_int) (a2 - b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsub_ij(int a, const double *b, double *c) {
  mp_int b2(b), c2(c);
  c2 = (mp_int) (a - b2);
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsub_jd(const double *a, double b, double *c) {
  mp_real a2(a), c2(c);
  c2 = (mp_real) (a2 - b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsub_dj(double a, const double *b, double *c) {
  mp_real b2(b), c2(c);
  c2 = (mp_real) (a - b2);
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsub_zq(const double *a, const double *b, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5), b2(b), cr(c), ci(c + mp::fmpwds5);
  mp_real::mpsub(ar, b2, cr);
  ci = ai;
  ar.toTempAndDestroy();  ai.toTempAndDestroy();
  b2.toTempAndDestroy();
  cr.toTempAndDestroy();  ci.toTempAndDestroy();
}
void c_mpsub_qz(const double *a, const double *b, double *c) {
  mp_real a2(a), br(b), bi(b + mp::fmpwds5), cr(c), ci(c + mp::fmpwds5);
  mp_real::mpsub(a2, br, cr);
#if 0
  ci = mp_real(-bi);  //bug? -- XSL
#else
  ci = bi;
  ci[1] = -ci[1];
#endif
  a2.toTempAndDestroy();
  br.toTempAndDestroy();  bi.toTempAndDestroy();
  cr.toTempAndDestroy();  ci.toTempAndDestroy();
}
void c_mpsub_zx(const double *a, double br, double bi, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5);
  mp_real cr(c), ci(c + mp::fmpwds5);
  cr = (mp_real) (ar - br);
  ci = (mp_real) (ai - bi);
  ar.toTempAndDestroy();  ai.toTempAndDestroy();
  cr.toTempAndDestroy();  ci.toTempAndDestroy();
}
void c_mpsub_xz(double ar, double ai, const double *b, double *c) {
  mp_real br(b), bi(b + mp::fmpwds5);
  mp_real cr(c), ci(c + mp::fmpwds5);
  cr = (mp_real) (ar - br);
  ci = (mp_real) (ai - bi);
  br.toTempAndDestroy();  bi.toTempAndDestroy();
  cr.toTempAndDestroy();  ci.toTempAndDestroy();
}
void c_mpsub_zz(const double *a, const double *b, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5);
  mp_real br(b), bi(b + mp::fmpwds5);
  mp_real cr(c), ci(c + mp::fmpwds5);
  mp_real::mpsub(ar, br, cr);
  mp_real::mpsub(ai, bi, ci);
  ar.toTempAndDestroy();  ai.toTempAndDestroy();
  br.toTempAndDestroy();  bi.toTempAndDestroy();
  cr.toTempAndDestroy();  ci.toTempAndDestroy();
}


/* negation */
void c_mpneg_q(const double *a, double *c) {
  mp_real a2(a), c2(c);
  c2 = (mp_real) -a2;
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpneg_z(const double *a, double *c) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  //c2 = (mp_complex) -DoubleToComplex(a);
  c2 = (mp_complex) -(a2);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}

/* mul */
void c_mpmul(const double *a, const double *b, double *c) {
  mp_real a2(a), b2(b), c2(c); 
  mp_real::mpmulx(a2, b2, c2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpmul_ji(const double *a, int b, double *c) {
  mp_int a2(a), c2(c);
  c2 = (mp_int) (a2 * b); 
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpmul_qi(const double *a, int b, double *c) {
  mp_real a2(a), c2(c);
  c2 = (mp_real) (a2 * (double) b); 
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpmul_qd(const double *a, double b, double *c) {
  mp_real a2(a), c2(c); 
  mp_real::mpmuld(a2, b, 0, c2);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpmul_zq(const double *a, const double *b, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5), b2(b), cr(c), ci(c + mp::fmpwds5);
  mp_real::mpmulx(ar, b2, cr);
  mp_real::mpmulx(ai, b2, ci);
  ar.toTempAndDestroy();  ai.toTempAndDestroy();
  b2.toTempAndDestroy();
  cr.toTempAndDestroy();  ci.toTempAndDestroy();
}
void c_mpmul_zz(const double *a, const double *b, double *c) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  //mp_complex::mpcmulx(DoubleToComplex(a), DoubleToComplex(b), c2);
  mp_complex::mpcmulx(a2, b2, c2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpmul_zd(const double *a, double b, double *c) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  //mp_complex::mpcmuld(DoubleToComplex(a), b, 0, c2);
  mp_complex::mpcmuld(a2, b, 0, c2);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}

/* div */
void c_mpdiv(const double *a, const double *b, double *c) {
  mp_real a2(a), b2(b), c2(c); 
  mp_real::mpdivx(a2, b2, c2); 
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_jj(const double *a, const double *b, double *c) {
  mp_int a2(a), b2(b), c2(c);
  c2 = (mp_int) (a2 / b2); 
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_ji(const double *a, int b, double *c) {
  mp_int a2(a), c2(c);
  c2 = (mp_int) (a2 / b); 
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_ij(int a, const double *b, double *c) {
  mp_int b2(b), c2(c);
  c2 = (mp_int) ( a / b2); 
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_qi(const double *a, int b, double *c) {
  mp_real a2(a), c2(c); 
  mp_real::mpdivd(a, (double) b, 0, c2); 
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_iq(int a, const double *b, double *c) {
  mp_real b2(b), c2(c); 
  c2 = (mp_real) (a / b2); 
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_qd(const double *a, double b, double *c) {
  mp_real a2(a), c2(c); 
  mp_real::mpdivd(a2, b, 0, c2); 
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_dq(double a, const double *b, double *c) {
  mp_real b2(b), c2(c); 
  c2 = (mp_real) (a / b2); 
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_zq(const double *a, const double *b, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5), b2(b), cr(c), ci(c + mp::fmpwds5);
  mp_real::mpdivx(ar, b2, cr);
  mp_real::mpdivx(ai, b2, ci);
  ar.toTempAndDestroy();  ai.toTempAndDestroy();
  b2.toTempAndDestroy();
  cr.toTempAndDestroy();  ci.toTempAndDestroy();
}
void c_mpdiv_qz(const double *a, const double *b, double *c) {
  mp_complex b2(b, b + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  mp_real a2(a);
  //c2 = (mp_complex) (a2 / DoubleToComplex(b));
  c2 = (mp_complex) (a2 / b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_zz(const double *a, const double *b, double *c) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  //mp_complex::mpcdivx(DoubleToComplex(a), DoubleToComplex(b), c2);
  mp_complex::mpcdivx(a2, b2, c2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpdiv_zd(const double *a, double b, double *c) {
  mp_real ar(a), ai(a + mp::fmpwds5), cr(c), ci(c + mp::fmpwds5);
  mp_real::mpdivd(ar, b, 0, cr);
  mp_real::mpdivd(ai, b, 0, ci);
  ar.toTempAndDestroy(); ai.toTempAndDestroy();
  cr.toTempAndDestroy(); ci.toTempAndDestroy();
}
void c_mpdiv_dz(double a, const double *b, double *c) {
  mp_complex b2(b, b + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  //c2 = (mp_complex) (a / DoubleToComplex(b));
  c2 = (mp_complex) (a / b2);
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}

void c_mpdmc(double a, double *b) {
  mp_real b2(b);
  mp_real::mpdmc(a, 0, b2);
  b2.toTempAndDestroy();
}
void c_mpmdc(const double *a, double *b, int *n) {
  mp_real a2(a);
  mp_real::mpmdc(a2, *b, *n);
  a2.toTempAndDestroy();
}

/* assignment */
void c_mpeq(const double *a, double *b) {
#if 0
  mp_real b2(b);
  mp_real::mpeq((mp_real) a, b2); // cause seg. fault on Sun
  b2.toTempAndDestroy();
#else
  mp_real a2(a), b2(b);
  mp_real::mpeq(a2, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
#endif
}
void c_mpeq_int(int a, double *b) {
  mp_real b2(b);
  b2 = a;
  b2.toTempAndDestroy();
}
void c_mpeq_d(double a, double *b) {
  mp_real b2(b);
  b2 = a;
  b2.toTempAndDestroy();
}
void c_mpeq_ji(int a, double *b) {
  mp_int b2(b);
  b2 = a;
  b2.toTempAndDestroy();
}
void c_mpeq_zq(const double *a, double *b) {
  mp_complex b2(b, b + mp::fmpwds5);
  b2 = a;
  b2.toTempAndDestroy();
}
void c_mpeq_zx(double *r, double *i, double *b) {
  mp_complex b2(b, b + mp::fmpwds5);
  b2 = mp_complex(*r, *i);
  b2.toTempAndDestroy();
}
void c_mpeq_zz(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  //b2 = DoubleToComplex(a);
  b2 = a2;
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}


/* power */
void c_mppwr(const double *a, const double *b, double *c) {
  mp_real a2(a), b2(b), c2(c);
  c2 = (mp_real) power((const mp_real &) a2, (const mp_real &) b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mppwr_d(const double *a, double b, double *c) {
  mp_real a2(a), c2(c);
  c2 = (mp_real) power(a2, b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mppwr_qi(const double *a, int b, double *c) {
  mp_real a2(a), c2(c);
  mp_real::mpnpwx(a2, b, c2);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mppwr_jj(const double *a, const double *b, double *c) {
  mp_int a2(a), b2(b), c2(c);
  c2 = (mp_int) power(a2, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mppwr_ji(const double *a, int b, double *c) {
  mp_int a2(a), c2(c);
  c2 = (mp_int) power(a2, b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mppwr_zi(const double *a, int b, double *c) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  //c2 = (mp_complex) power(DoubleToComplex(a), b);
  c2 = (mp_complex) power(a2, b);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mppwr_zq(const double *a, const double *b, double *c) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex c2(c, c + mp::fmpwds5);
  mp_real b2(b);
  // XSL ?? c2 = (mp_complex) power(DoubleToComplex(a), b2);
  //c2 = (mp_complex) power(DoubleToComplex(a), (mp_real) b);
  c2 = (mp_complex) power(a2, (const mp_real &) b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
#if 0
// bug -- XSL ??
void c_mppwr_zz(const double *a, const double *b, double *c) {
  mp_complex c2(c, c + mp::fmpwds5);
  c2 = (mp_complex) power(DoubleToComplex(a), DoubleToComplex(b));
  c2.toTempAndDestroy();
}
#endif

/* equality */
void c_mpcpr(const double *a, const double *b, int *c) {
  mp_real a2(a), b2(b);
  *c = (int) (a2 == b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpcpr_i(const double *a, int b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 == b);
  a2.toTempAndDestroy();
}
void c_mpcpr_d(const double *a, double b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 == b);
  a2.toTempAndDestroy();
}
void c_mpcpr_z(const double *a, const double *b, int *c) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  //c = (int) (DoubleToComplex(a) == DoubleToComplex(b));
  *c = (int) (a2 == b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}

/* less-than-or-equal-to */
void c_mplet(const double *a, const double *b, int *c) {
  mp_real a2(a), b2(b);
  *c = (int) (a2 <= b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mplet_i(const double *a, int b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 <= b);
  a2.toTempAndDestroy();
}
void c_mplet_d(const double *a, double b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 <= b);
  a2.toTempAndDestroy();
}

/* greater-than-or-equal-to */
void c_mpget(const double *a, const double *b, int *c) {
  mp_real a2(a), b2(b);
  *c = (int) (a2 >= b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpget_i(const double *a, int b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 <= b);
  a2.toTempAndDestroy();
}
void c_mpget_d(const double *a, double b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 >= b);
  a2.toTempAndDestroy();
}

/* less-than */
void c_mpltt(const double *a, const double *b, int *c) {
  mp_real a2(a), b2(b);
  *c = (int) (a2 < b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpltt_i(const double *a, int b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 < b);
  a2.toTempAndDestroy();
}
void c_mpltt_d(const double *a, double b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 < b);
  a2.toTempAndDestroy();
}

/* greater-than */
void c_mpgtt(const double *a, const double *b, int *c) {
  mp_real a2(a), b2(b);
  *c = (int) (a2 > b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpgtt_i(const double *a, int b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 > b);
  a2.toTempAndDestroy();
}
void c_mpgtt_d(const double *a, double b, int *c) {
  mp_real a2(a);
  *c = (int) (a2 > b);
  a2.toTempAndDestroy();
}

void c_mpabs(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) abs(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpabs_z(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_real b2(b);
  //b2 = (mp_real) abs(DoubleToComplex(a));
  b2 = (mp_real) abs(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}

void c_mparg(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_real b2(b);
  //b2 = (mp_real) arg(DoubleToComplex(a));
  b2 = (mp_real) arg(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}

/* trigonometric functions */
void c_mpacos(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) acos(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpasin(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) asin(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpatan(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) atan(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpatan2(const double *a, const double *b, double *c) {
  mp_real a2(a), b2(b), c2(c);
  c2 = (mp_real) atan2(a2, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpcos(const double *a, double *b) {
  mp_real a2(a), b2(b), junk;
  mp_real::mpcssx(a2, mp::mppic, b2, junk);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpcos_z(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  //b2 = (mp_complex) cos(DoubleToComplex(a));
  b2 = (mp_complex) cos(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpdble(const double *a, double *b) {
  mp_real a2(a);
  *b = dble(a2);
  a2.toTempAndDestroy();
}
void c_mpcosh(const double *a, double *b) {
  mp_real a2(a), b2(b), junk;
  mp_real::mpcshx(a2, mp::mppic, mp::mpl02, b2, junk);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpexp(const double *a, double *b) {
  mp_real a2(a), b2(b);
  mp_real::mpexpx(a2, mp::mppic, mp::mpl02, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpexp_z(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  //b2 = (mp_complex) exp(DoubleToComplex(a));
  b2 = (mp_complex) exp(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}

void c_mpaint(const double *a, double *b) {
  mp_real a2(a), b2(b), junk(0);
  mp_real::mpinfr(a2, b2, junk, 0);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpnint(const double *a, double *b) {
  mp_real a2(a), b2(b);
  mp_real::mpnint(a2, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}

void c_mplog(const double *a, double *b) {
  mp_real a2(a), b2(b);
  mp_real::mplogx(a2, mp::mppic, mp::mpl02, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mplog_z(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  b2 = (mp_complex) log(a2);
  //b2 = (mp_complex) log(DoubleToComplex(a));
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mplog10(const double *a, double *b) {
  mp_real a2(a), b2(b);
  mp_real::mplogx(a2, mp::mppic, mp::mpl02, b2);
  mp_real::mpdivx(b2, mp::mpl10, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpsin(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) sin(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpsin_z(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  b2 = (mp_complex) sin(a2);
  //b2 = (mp_complex) sin(DoubleToComplex(a));
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpsinh(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) sinh(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpnrt(const double *a, int *b, double *c) {
  mp_real a2(a), c2(c);
  mp_real::mpnrtx(a2, *b, c2);
  a2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpsqrt(const double *a, double *b) {
  mp_real a2(a), b2(b);
  mp_real::mpsqrtx(a2, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mpsqrt_z(const double *a, double *b) {
  mp_complex a2(a, a + mp::fmpwds5);
  mp_complex b2(b, b + mp::fmpwds5);
  mp_complex::mpcsqrtx(a2, b2);
  //  mp_complex::mpcsqrtx(DoubleToComplex(a), b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}

void c_mptan(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) tan(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}
void c_mptanh(const double *a, double *b) {
  mp_real a2(a), b2(b);
  b2 = (mp_real) tanh(a2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
}

void c_mpmod(const double *a, const double *b, double *c) {
  mp_real a2(a), b2(b), c2(c);
  c2 = (mp_real) fmod(a2, b2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpcsshf(const double *a, double *b, double *c) {
  mp_real a2(a), b2(b), c2(c);
  mp_real::mpcshx(a2, mp::mppic, mp::mpl02, b2, c2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}
void c_mpcssnf(const double *a, double *b, double *c) {
  mp_real a2(a), b2(b), c2(c);
  mp_real::mpcssx(a2, mp::mppic, b2, c2);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}

void c_mprand(double *a) {
  mp_real a2(a);
  mp_real::mprand(a2);
  a2.toTempAndDestroy();
}

void c_mpswrite(const double *a, int *la, char *s, int *l) {
  mp_real a2(a);
  mp_real::mpout(a2, *la, s, *l);
  a2.toTempAndDestroy();
}

void c_ovcheck(const double *a) {
  mp_int a2(a);
  mp_int::ovcheck(a2);
  a2.toTempAndDestroy();
}

void c_mpinfr(const double *a, double *b, double *c) {
  mp_real a2(a), b2(b), c2(c);
  mp_real::mpinfr(a2, b2, c2, 1);
  a2.toTempAndDestroy();
  b2.toTempAndDestroy();
  c2.toTempAndDestroy();
}

/* Input */
void c_mpinp(const double *q) {
  mp_real q2(q);
  std::cin >> q2;
  q2.toTempAndDestroy();
}

/* Output */
#if 0
void c_mpout(const double *q) {
  mp_real q2(q);
  cout << q2 << endl;
  q2.toTempAndDestroy();
}
#endif
void c_mpout(const double *q, char *c, int *l) {
  mp_real q2(q);
  //mp_real::mpoutx(q2, mp::mpoud, c, l);
  mp_real::mpoutc(q2, c, *l);
  q2.toTempAndDestroy();
}

void c_mpout_z(const double *q) {
  mp_real q2(2), q3(q + mp::fmpwds5);
  cout << "Real:" << q2 << endl;
  cout << "Imag:" << q3 << endl;
  q2.toTempAndDestroy();
  q3.toTempAndDestroy();
}


void c_mpdotd(int *n, int *isa, double *a, int *isb, const double *db,
	      double *c)
{
  int i;
  mp_real c2(c);
#if 0
  mp_real *a2 = new mp_real[n];
#else
  mp_real *a2 = (mp_real *) malloc(*n * sizeof(mp_real));
#endif

#if 0
  for (i = 0; i < n; ++i) a2[i] = (mp_real) &a[i*isa];
#else
  for (i = 0; i < *n; ++i) a2[i].mpr = &a[i * *isa];
#endif

  mp_real::mpdotd(*n, 1, a2, *isb, db, c2);

#if 0
  for (i = 0; i < n; ++i) a2[i].toTempAndDestroy();
  delete [] a2;
#else
  free(a2);
#endif
  c2.toTempAndDestroy();
}

void c_mpsetoutputprec(int *num_digits) {
  mp::mpsetoutputprec(*num_digits);
}

void c_mpgetoutputprec(int *num_digits) {
  *num_digits = mp::mpgetoutputprec();
}

void c_mpsetprec(int *num_digits) {
  mp::mpsetprec(*num_digits);
}

void c_mpgetprec(int *num_digits) {
  *num_digits = mp::mpgetprec();
}

void c_mpsetprecwords(int *num_words) {
  mp::mpsetprecwords(*num_words);
}

void c_mpgetprecwords(int *num_words) {
  *num_words = mp::mpgetprecwords();
}



}  // end extern
