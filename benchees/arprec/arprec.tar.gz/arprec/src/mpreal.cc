/*
 * src/mpreal.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 */
#include "mp/mpreal.h"
#include <time.h>

void mp_real::mpadd(const mp_real &a, const mp_real &b, mp_real& c)
{
  /**
   * This routine adds MP numbers A and B to yield the MP sum C. It attempts
   * to include all significance of A and B in the result, up to the maximum
   * mantissa length MPNW.  Debug output starts with MPIDB = 9. 
   * This is a new simplified version.
   *
   * D contains the intermediate results of addition before normalization.
   * The first 3 words of D have special meanings:
   *     d[0] : not accessed
   *     d[1] : sign and number of words in D
   *     d[2] : exponent
   * Before normalization, each word of D may have up to 53 bits and may be
   * negative. After normalization, each word is in [0, 2^mpnbt-1]
   */
  double db;
  int i, ia, ib, ish, ixa, ixb, ixd, na, nb;
  int m1, m2, m3, m4, m5, nsh;
  double *d;
  int nd; // number of actual words in d[]

  if (MPIER != 0) {
    zero(c);
    return;
  }

  if (MPIDB >= 9) {
    print_mpreal((char*)"MPADD a ", a);
    print_mpreal((char*)"MPADD b ", b);
  }
  
  ia = a[1] >= 0 ? 1 : -1;
  ib = b[1] >= 0 ? 1 : -1;
  na = MIN ((int)ABS (a[1]), mpnw); // number of words in A
  nb = MIN ((int)ABS (b[1]), mpnw); // number of words in B

  /* Check for zero inputs. */

  if (na == 0) {
    /* A is zero -- the result is B. */
    int num_words = MIN(nb, int(c[0])-FST_M);
    c[1] = ib > 0 ? num_words : -num_words;
    for (i = 2; i < num_words + FST_M; ++i) c[i] = b[i];
    return;
  } else if (nb == 0) {
    /* B is zero -- the result is A. */
    int num_words = MIN(na, int(c[0])-FST_M);
    c[1] = ia >= 0 ? num_words : -num_words; 
    for (i = 2; i < num_words + FST_M; ++i) c[i] = a[i];
    return;
  }

  // get ready for main part of routine.
  d = new double[mpnw+7];

  if (ia == ib) db = 1.0; //same signs - add
  else db = -1.0; // different signs - subtract

  ixa = (int) a[2];
  ixb = (int) b[2];
  ish = ixa - ixb;

  d[1] = 0.0;
  d[2] = 0.0;

  if (ish >= 0) { // |A| >= |B|
    // A has greater exponent than B, so B must be shifted to the right
    // to line up the radix point.
    
    m1 = MIN (na, ish);
    m2 = MIN (na, nb + ish);
    m3 = na;
    m4 = MIN (MAX (na, ish), mpnw + 1);
    m5 = MIN (MAX (na, nb + ish), mpnw + 1);
    //assert(m1<=m2 && m2<=m3 && m3<=m4 && m4<=m5);
    
    for (i = FST_M; i < m1 + FST_M; ++i)
      d[i] = a[i];
    
    if(db > 0) {//Addition
      for (i = m1 + FST_M; i < m2 + FST_M; ++i)
        d[i] = a[i] + b[i-ish];
      
      for (i = m2 + FST_M; i < m3 + FST_M; ++i)
        d[i] = a[i];
    
      for (i = m3 + FST_M; i < m4 + FST_M; ++i)
        d[i] = 0.0;
      
      for (i = m4 + FST_M; i < m5 + FST_M; ++i)
        d[i] = b[i-ish];
    } else {//Subtraction
      for (i = m1 + FST_M; i < m2 + FST_M; ++i)
        d[i] = a[i] - b[i-ish];
      
      for (i = m2 + FST_M; i < m3 + FST_M; ++i)
        d[i] = a[i];
    
      for (i = m3 + FST_M; i < m4 + FST_M; ++i)
        d[i] = 0.0;
      
      for (i = m4 + FST_M; i < m5 + FST_M; ++i)
        d[i] = - b[i-ish];
    }
    nd = m5;
    ixd = ixa;
    d[nd+3] = 0.0;
    d[nd+4] = 0.0;

  } else {
    // B has greater exponent than A, so A must be shifted to the right
    // to line up the radix point.
    
    nsh = -ish;
    m1 = MIN (nb, nsh);
    m2 = MIN (nb, na + nsh);
    m3 = nb;
    m4 = MIN (MAX (nb, nsh), mpnw + 1);
    m5 = MIN (MAX (nb, na + nsh), mpnw + 1);
    //assert(m1<=m2 && m2<=m3 && m3<=m4 && m4<=m5);
    
    if(db > 0) {//Addition
      for (i = FST_M; i < m1 + FST_M; ++i)
        d[i] = b[i];
      
      for (i = m1 + FST_M; i < m2 + FST_M; ++i)
        d[i] = a[i-nsh] + b[i];
      
      for (i = m2 + FST_M; i < m3 + FST_M; ++i)
        d[i] = b[i];

    } else {//Subtraction
      for (i = FST_M; i < m1 + FST_M; ++i)
        d[i] = - b[i];
      
      for (i = m1 + FST_M; i < m2 + FST_M; ++i)
        d[i] = a[i-nsh]  - b[i];
      
      for (i = m2 + FST_M; i < m3 + FST_M; ++i)
        d[i] = - b[i];
    }

    for (i = m3 + FST_M; i < m4 + FST_M; ++i)
      d[i] = 0.0;
    
    for (i = m4 + FST_M; i < m5 + FST_M; ++i)
      d[i] = a[i-nsh];
    
    nd = m5;
    ixd = ixb;
    d[nd+3] = 0.0;
    d[nd+4] = 0.0;
  }
  

  // Call mpnorm to fix up result and store in c.
  d[1] = ia >= 0 ? nd : -nd;
  d[2] = ixd;
  mpnorm(d, c);

  delete [] (d);

  if (MPIDB >= 9) print_mpreal((char*)"MPADD O: c ", c);
  return;
}

void mp_real::mpang(const mp_real& x, const mp_real& y, 
                    const mp_real& pi, mp_real& a)
{
  /**
   * This computes the MP angle A subtended by the MP pair (x, y)
   * considered as a point in the x-y plane.  This is more useful than
   * an arctan or arcsin routine, since it places the result correctly
   * in the full circle, i.e. -Pi < A <= Pi.  PI is the MP value of
   * Pi computed by a precious call to MPPI.  For extra high levels of
   * precision, use MPANGX.  The last word of the result is not reliable.
   * Debug output starts with MPIDB == 5.
   *
   * Space required for A : mpnw + 4 (double) cells.
   *
   * The Taylor series for ArcSin converges much more slowly than that
   * of Sin.  Thus this routine does not empoly Taylor series, but instead
   * computes Arccos or Arcsin by solving Cos(a) = x or Sin(a) = y 
   * using one of the following Newton iterations, both of which
   * converge to a :
   * 
   *  z_{k=1} = z_k - [x - Cos (z_k)] / Sin (z_k)
   *  z_{k+1} = z_k + [y - Sin (z_k)] / Cos (z_k)
   *
   * The first is selected if Abs (x) <= Abs (y); otherwise the second is 
   * used.  These iterations are performed with a maximum precision level
   * mpnw that is dynamically changed, approximately doubling with each 
   * iteration.
   * See the comment about the parameter NIT in MPDIVX.
   */
  const double cl2 = 1.4426950408889633, cpi = 3.141592653589793;
  const int nit = 3;
  double ix, iy, t1, t2;
  int nx, ny, n1, n2;
  
  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(a);
    return;
  }
  if (MPIDB >= 5)
    cout <<"\nMPANG : x = "<<x<<", y = "<<y;

  ix = SIGN(1.0, x[1]);
  nx = MIN(int(ABS(x[1])), mpnw);
  iy = SIGN(1.0, y[1]);
  ny = MIN(int(ABS(y[1])), mpnw);
  
  //  Check if both x and y are zero.
  if(!nx && !ny) {
    if(MPKER[7] != 0) {
      cout <<"\n*** MPANG : Both arguments are zero.";
      MPIER = 7;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }
  
  // Check if Pi has been precomputed
  
  mpmdc(pi, t1, n1);
  if(n1 != 0 || ABS(t1 - cpi) > mprx2) {
    if(MPKER[8] != 0) {
      cout << "\n*** MPANG: Pi must be precomputed.";
      MPIER = 8;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }
  
  // Check if one of x or y is zero
  if(!nx) {
    if (iy > 0.0) 
      mpmuld(pi, 0.5, 0, a);
    else
      mpmuld(pi, -0.5, 0, a);
    return;
  } else if(!ny) {
    if (ix > 0.0) 
      zero(a);
    else
      mpeq(pi, a);
    return;
  }
  
  int nws = mpnw;
  mpnw++;
  size_t n5 = (size_t)(mpnw+5);
  mp_real 
    sk0(n5),
    sk1(n5),
    sk2(n5),
    sk3(n5),
    sk4(n5);
  int mq, k, kk;
  int iq, prec_change;
  double t3;

  // Determine the least integer mq such that 2^mq >= mpnw
  
  t1 = double(nws);
  mq = int(cl2*log(t1) + 1.0 -mprxx);
  
  // Normalize x and y so that x^2 + y^2 == 1.

  mpmul(x, x, sk0);
  mpmul(y, y, sk1);
  mpadd(sk0, sk1, sk2);
  mpsqrt(sk2, sk3);
  mpdiv(x, sk3, sk1); // sk1 holds scaled x
  mpdiv(y, sk3, sk2); // sk2 holds scaled y

  // Compute initial approximation of the angle.
  mpmdc(sk1, t1, n1);
  mpmdc(sk2, t2, n2);
  n1 = MAX(n1, -66);
  n2 = MAX(n2, -66);
  t1 *= pow(2.0, n1);
  t2 *= pow(2.0, n2);
  t3 = atan2(t2, t1);
  mpdmc(t3, 0, a);
  
  // The smaller of x or y will be used from now on to measure convergence.
  //This selects the Newton iteration of the two listed above that has
  // The largest denominator.
  
  if (ABS(t1) <= ABS(t2)) {
    kk = 1;
    mpeq(sk1, sk0);
  } else {
    kk = 2;
    mpeq(sk2, sk0);
  }
  
  mpnw = 3;
  iq = 0;
  prec_change = 0; 
  
  // Perform the Newton-Raphson iteration described above with a dynamically
  // changing precision level mpnw (one greater than powers of 2).

  for(k=1;k<=mq;k++) {
    if(prec_change) 
      mpnw = MIN(2*mpnw-2, nws) + 1;
    else
      prec_change = 1;
    //most work done here.
    mpcssn(a, pi, sk1, sk2);

    if(kk == 1) {
      mpsub(sk0, sk1, sk3);
      mpdiv(sk3, sk2, sk4);
      mpsub(a, sk4, sk1);
    } else {
      mpsub(sk0, sk2, sk3);
      mpdiv(sk3, sk1, sk4);
      mpadd(a, sk4, sk1);
    }
    mpeq(sk1, a);
    if(k == mq - nit && !iq) {
      iq = 1; 
      prec_change = 0;
      k--;
    }
  }
  
  // restore original precision level.
  mpnw = nws;
  mproun(a);
  
  if(MPIDB >= 5) cout << "\nMPANG: done :"<< a;
  return;
}

int mp_real::mpcpr(const mp_real& a, const mp_real& b)
{
  /**
   * This routine compares the MP numbers A and B and returns
   * -1, 0, or 1, depending on whether A < B, A = B, or A > B
   * respectively. Debug begins with MPIDB = 9.
   */
  int ia, ib;

  if(MPIER != 0) {
    if(MPIER == 99)
      mpabrt();
    return 0;
  }
  if(MPIDB >= 9) {
    cout <<"\nComparing mp_real...";
  }
  ia = a[1] == 0.0 ? 0 : int(SIGN(1.0, a[1]));
  ib = b[1] == 0.0 ? 0 : int(SIGN(1.0, b[1]));
  
  if(ia != ib) 
    return ia > ib ? 1 : -1;
  
  // The signs are the same. Compare exponents.
  double ma = a[2], mb = b[2]; // grab exponents
  if(ma != mb) 
    return int(ia * SIGN(1.0, ma - mb));

  // This signs and exponents are the same.  Compare mantissas
  int na = MIN(int(ABS(a[1])), mpnw);
  int nb = MIN(int(ABS(b[1])), mpnw);

  for(int i=FST_M; i< MIN(na, nb) + FST_M; i++) {
    if(a[i] != b[i])
      return ia * int(SIGN(1.0, a[i] - b[i]));
  }
  
  // The mantissas are the same to the common length.
  if(na != nb)
    return ia * SIGN(1, na - nb);

  //else they are the same!
  return 0;
}

void mp_real::mpcssh(const mp_real& a, 
                     const mp_real& al2, /* log of 2 */
                     mp_real& x,
                     mp_real& y)
{
  /**
   * This computes the hyperbolic cosine and sine of the
   * argument a, and returns the two MP results in x and y,
   * respectively.  AL2 is the MP value of Log (2) computed
   * by a previous call to MPLOG.  For extra high levels of precision,
   * use MPCSHX.  The last word of the result is not reliable.
   * Debug starts with MPIDB == 5.
   * 
   *
   */
  
  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(x); zero(y); return;
  }
  
  int nws = mpnw;
  mpnw++;
  size_t n6 = (size_t)(mpnw+6); 
  mp_real sk0(n6), 
    sk1(n6), 
    sk2(n6), 
    sk3(n6), 
    f((size_t)(8));
  f[1] = 1.0; f[2] = 0.0; f[3] = 1.0; f[4] = 0.0;

  mpexp(a, al2, sk0);
  mpdiv(f, sk0, sk1);
  mpadd(sk0, sk1, sk2);
  mpmuld(sk2, 0.5, 0, sk3);
  mpeq(sk3, x);
  mpsub(sk0, sk1, sk2);
  mpmuld(sk2, 0.5, 0, sk3);
  mpeq(sk3, y);
  
  //Restore original precision level.
  
  mpnw = nws;
  mproun(x);
  mproun(y);
}


void mp_real::mpcssn(const mp_real& a, const mp_real& pi, mp_real &x,
            mp_real &y)
{
  /**
   * This computes the cosine and sine of the MP number A and returns
   * the two MP results in X and Y, respectively.  Pi is the MP value
   * of Pi computed by a previous call to MPPI.  For extra high
   * levels of precision, use MPCSSX.  The last word of the result
   * is not reliable.  Debug output starts with MPIDB == 6.
   *
   * This routine uses the conventional Taylor's series for Sin (s) :
   *  
   * Sin (s) = s - s^3 / 3! + s ^5 / 5! - s^7 / 7! ...
   *  
   * where s = t - a * pi / 2 - b * pi / 16 and the integers a and b
   * are chosen to minimize the absolute value of s.  We can then
   * compute:
   * 
   * Sin (t) = Sin (s + a * pi / 2 + b * pi / 256)
   * Cos (t) = Cos (s + a * pi / 2 + b * pi / 256)
   * 
   * by applying elementary trig identities for sums.  The sine and
   * cosine of b * pi / 16 are of the form
   *
   *        1/2 * Sqrt {2 +- Sqrt [2 +- Sqrt(2)]}.
   *
   * Reducing t in this manner insures that -Pi / 512 < s <= Pi / 512,
   * which accelerates convergence in the above series.
   *
   * The sines and cosines for values (b * pi / 256) where b in
   * an integer are stored in the two tables below.
   */
  static mp_real *pi_over_256_sine_table[129] = 
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0};
  static mp_real *pi_over_256_cosine_table[129] = 
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0};
  const double cpi = 3.141592653589793;
  int nq = 4;
  double t1, t2;
  int n1, na, neg=0;
  
  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(x); zero(y); return;
  }
  if (MPIDB >= 6) cout << "\nMPVSSN I";

  na = MIN(int(ABS(a[1])), mpnw);
  if(na == 0) {
    //x = 1.0, y = zero.
    x[1] = 1.0; x[2] = 0.0; x[3] = 1.0;
    zero(y);
    return;
  }

  // Check is Pi has been precomputed.
  
  mpmdc (pi, t1, n1);
  if(n1 != 0 || ABS(t1 - cpi) > mprx2) {
    if(MPKER[28] != 0) {
      cout <<"\n***MPCSSN: PI must be precomputed.";
      MPIER = 28;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  int nws = mpnw;
  mpnw++;
  size_t n5 = (size_t)(mpnw+5);
  int ka, kb, kc;
  mp_real sk0((n5)),
    sk1((n5)),
    sk2((n5)),
    sk3((n5)),
    sk4((n5)),
    sk5((n5)),
    sk6((n5)), 
    f((size_t)(6));
  // f = 1.0;
  f[1] = 1.0; f[2] = 0.0; f[3] = 1.0; f[4] = 0.0;

  //        Reduce to between -Pi and Pi.

  mpmuld(pi, 2.0, 0, sk0);
  mpdiv(a, sk0, sk1);
  mpnint(sk1, sk2);
  mpsub(sk1, sk2, sk3);
  
  // Determine rearest multiple of Pi / 2, and within a quadrant, the
  // nearest multiple of Pi / 256.  Through most of the rest of this
  // subroutine, KA and KB are the integers a and b of the algorithm
  // above.

  mpmdc(sk3, t1, n1);
  if(n1 >= -mpnbt) {
    t1 *= pow(2.0, n1);
    t2 = 4.0 * t1;
    t1 = anint (double(t2));
    ka = int(t1);
    kb = int(anint (128.0 * (t2 - ka)));
  } else {
    ka = 0;
    kb = 0;
  }
  t1 = (128 * ka + kb) / 512.0;
  mpdmc(t1, 0, sk1);
  mpsub(sk3, sk1, sk2);
  mpmul(sk2, sk0, sk1);

  // compute consine and sine of the reduced argument s.

  if(sk1[1] == 0.0) { // if sk1 == zero
    zero(sk0);
    nq = 0;
  } else {
    //Divide by 2^nq (possibly), fix after series has converged.
    if(sk1.mpr[2] < -1 || sk1.mpr[3] < mpbdx/4096.0) {
      nq = 0;
    } else {
      mpdivd(sk1, 1.0, nq, sk1);
    }

    // Compute the Taylor's series now.
    mpeq(sk1, sk0);
    mpmul(sk0, sk0, sk2);
    
    int l1=0; //iteration count.
    int term_prec;
    
    neg = sk1.mpr[1] < 0.0 ? 1 : 0;
    do {
      l1++;
      t2 = - (2.0 * l1) * (2.0 * l1 + 1.0);

        // compute this term with term_prec words of precision only.
      term_prec = MIN(nws+1, nws+int(sk2.mpr[2]+sk1.mpr[2]-sk0.mpr[2])+2);
      mpnw = MAX(0, term_prec); 
      mpmul(sk1, sk2, sk3);
      mpdivd(sk3, t2, 0, sk1);
      mpnw = nws+1; // full precision to add term in.
      mpadd(sk1, sk0, sk0);
      //the above line needs to change if mpadd is not safe for 
      // same variable input/output.
      
      // Check for convergence of the series in the loop condition
    } while(l1 < 10000 &&
            (sk1[1] != 0.0 && sk1[2] >= sk0[2] - mpnw));

    if(l1 >= 10000) {
      if(MPKER[29] != 0) {
        cout <<"\n*** MPCSSN: Iteration limit exceeded.";
        MPIER = 29;
        if(MPKER[MPIER] == 2) mpabrt();
        mpnw = nws;
        return;
      }
    }
    //answer needs to end up in sk0.
    if(nq) {
      // Perform double angle formulas, 
      // Cos (s) = 1 - 2 * Sin^2(s/2) = 2 * Cos^2(s/2) - 1 
      mpmul(sk0, sk0, sk1);
      mpmuld(sk1, 2.0, 0, sk2);
      mpsub(f, sk2, sk0);
      for(int i=1;i<nq;i++) {
        mpmul(sk0, sk0, sk1);
        mpmuld(sk1, 2.0, 0, sk2);
        mpsub(sk2, f, sk0);
      }
    }      
  }

  if(nq) {
    // sk0 currently holds Cos(s).
    // Compute Sin (s) = Sqrt( 1 - Cos^2(s));
    //mpeq(sk0, sk1);
    mpmul(sk0, sk0, sk2);
    mpsub(f, sk2, sk3);
    mpsqrt(sk3, sk1);
    if(neg) {
      sk1.mpr[1] = -sk1.mpr[1];
    }
  } else {
    // sk0 currently holds Sin(s).
    // Compute Cos (s) = Sqrt( 1 - Sin^2(s));
    mpeq(sk0, sk1);
    mpmul(sk0, sk0, sk2);
    mpsub(f, sk2, sk3);
    mpsqrt(sk3, sk0);
  }    

  // Now sk0 holds Cos(s), sk1 holds Sin(s).

  // Compute cosine and sine of b * Pi / 512; or, 
  //   get it from the table.  
  
  kc = ABS(kb);
  if(pi_over_256_sine_table[kc] && 
     (pi_over_256_sine_table[kc]->mpr[0] >= sk0.mpr[0])) {
    mpeq(*pi_over_256_cosine_table[kc], sk2);
    mpeq(*pi_over_256_sine_table[kc], sk3);
  } else {
    f[FST_M] = 2.0; // f = 2.0

    if(kc == 0) {
      sk2[1] = 1.0; sk2[2] = 0.0; sk2[3] = 1.0;// sk2 = 1.0;
      zero(sk3);
    } else {
      switch(kc % 8) {
      case 0:
        //sk4 = 2.0 == 2*cos(0) 
        sk4[1] = 1.0; sk4[2] = 0.0; sk4[3] = 2.0;
        break;
      case 7:
      case 1:
        mpsqrt(f, sk4);
        mpadd(f, sk4, sk5);
        mpsqrt(sk5, sk4);
        break;
      case 6:
      case 2:
        mpsqrt(f, sk4);
        break;
      case 5: 
      case 3:
        mpsqrt(f, sk4);
        mpsub(f, sk4, sk5);
        mpsqrt(sk5, sk4);
        break;
      case 4:
        zero(sk4);
      }
      // if kc * Pi/8 is on the negative half of the unit circle...
      if(((kc+4)/8) & 0x1) sk4[1] = -sk4[1];
      // now sk4 holds 2 * Cos (kc * Pi / 8)
      mpadd(f, sk4, sk5);
      mpsqrt(sk5, sk4);
      if(((kc+8)/16) & 0x1) sk4[1] = -sk4[1];
      // now sk4 holds 2 * Cos (kc * Pi / 16)
      mpadd(f, sk4, sk5);
      mpsqrt(sk5, sk4);
      if(((kc+16)/32) & 0x1) sk4[1] = -sk4[1];
      // now sk4 holds 2 * Cos (kc * Pi / 32)
      mpadd(f, sk4, sk5);
      mpsqrt(sk5, sk4);
      if(((kc+32)/64) & 0x1) sk4[1] = -sk4[1];
      // now sk4 holds 2 * Cos (kc * Pi / 64)

      mpadd(f, sk4, sk5);
      mpsqrt(sk5, sk4);
      // now sk4 holds 2 * Cos (kc * Pi / 128)

      // do for all kc != 0 
      mpadd(f, sk4, sk5);
      mpsqrt(sk5, sk3);
      mpmuld(sk3, 0.5, 0, sk2);
      mpsub(f, sk4, sk5);
      mpsqrt(sk5, sk4);
      mpmuld(sk4, 0.5, 0, sk3);
    }
    mp_real *new_sine, *new_cosine;
    new_cosine = new mp_real(sk2);
    new_sine = new mp_real(sk3);
    if(pi_over_256_sine_table[kc]) {
      //Required precision may have increased,
      // Throw away old table members.
      delete pi_over_256_sine_table[kc];
      delete pi_over_256_cosine_table[kc];
    }
    pi_over_256_sine_table[kc] = new_sine;
    pi_over_256_cosine_table[kc] = new_cosine;
  }
  if (kb < 0) sk3[1] = -sk3[1];
  // Now sk2 holds Cos (b * Pi / 256), 
  // sk3 holds Cos (b * Pi / 256).


  // Apply the trig summation identities to compute cosine and sine
  // of s + b * Pi / 256;  

  mpmul (sk0, sk2, sk4);
  mpmul(sk1, sk3, sk5);
  mpsub(sk4, sk5, sk6);
  mpmul(sk1, sk2, sk4);
  mpmul(sk0, sk3, sk5);
  mpadd(sk4, sk5, sk1);
  mpeq(sk6, sk0);
  

  // This code in effect applies the trig summation identities for
  // (s + b * Pi / 256) + a * Pi / 2.
  
  switch(ka) {
  case 0: 
    mpeq(sk0, x);
    mpeq(sk1, y);
    break;
  case 1:
    mpeq(sk1, x);
    x[1] = - x[1];
    mpeq(sk0, y);
    break;
  case -1:
    mpeq(sk1, x);
    mpeq(sk0, y);
    y[1] = -y[1];
    break;
  case 2:
  case -2:
    mpeq(sk0, x);
    x[1] = -x[1];
    mpeq(sk1, y);
    y[1] = -y[1];
    break;
  }
  
  // Restore original precision level.
  
  mpnw = nws;
  mproun(x);
  mproun(y);
  
  if(MPIDB >= 6) cout << "\nMPCSSN done : sin = "<<x<<"\t cos = "<<y;

  return;
}


void mp_real::mpdiv(const mp_real& a, const mp_real& b, mp_real& c)
{
  /**
   * This divides the MP number A by the MP number B to yield the MP 
   * quotient C.  For extra high levels of precision, use MPDIVX.
   * Debug output starts with MPIDB = 8.
   *
   * The algorithm is by long division.
   */

  int i, ia, ib, ij, is, i2, i3=0, j, j3, na, nb, nc, BreakLoop;
  double rb, ss, t0, t1, t2, t[2];
  double* d;
  
  if (MPIER != 0) {
    if (MPIER == 99) mpabrt();
    zero(c);
    return;
  }
  
  if (MPIDB >= 8) {
    print_mpreal((char*)"MPDIV a ", a);
    print_mpreal((char*)"MPDIV b ", b);
  }
  
  ia = (a[1] >= 0 ? 1 : -1); 
  ib = (b[1] >= 0 ? 1 : -1); 
  na = MIN (int(ABS(a[1])), mpnw);
  nb = MIN (int(ABS(b[1])), mpnw);
  
  //  Check if dividend is zero.
  if (na == 0) {
    zero(c);
    if (MPIDB >= 8) print_mpreal((char*)"MPDIV O ", c);
    return;
  }
  
  if (nb == 1 && b[FST_M] == 1.) {
    // Divisor is 1 or -1 -- result is A or -A.
    c[1] = SIGN(na, ia * ib);
    c[2] = a[2] - b[2];
    for (i = FST_M; i < na+FST_M; ++i) c[i] = a[i];
    
    if (MPIDB >= 8) print_mpreal((char*)"MPDIV O ", c);
    return;
  }
  
  //  Check if divisor is zero.
  if (nb == 0) {
    if (MPKER[31] != 0) {
      cerr << "*** MPDIV: Divisor is zero.\n";
      MPIER = 31;
      if (MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }
  
  //need the scratch space now...
  d = new double[mpnw+9];
  int d_add=0;
  d++; d_add--;

  // Initialize trial divisor and trial dividend.
  t0 = mpbdx * b[3];
  if (nb >= 2) t0 = t0 + b[4];
  if (nb >= 3) t0 = t0 + mprdx * b[5];
  rb = 1.0 / t0;
  d[0]  = d[1] = 0.0;
  
  for (i = 2; i < na+2; ++i) d[i] = a[i+1];
  for (/*i = na+2*/; i <= mpnw+7; ++i) d[i] = 0.0;

  // Perform ordinary long division algorithm.  First compute only the first
  // NA words of the quotient.
  for (j = 2; j <= na+1; ++j) {
    t1 = mpbx2 * d[j-1] + mpbdx * d[j] + d[j+1];
    t0 = AINT (rb * t1); // trial quotient, approx is ok.
    j3 = j - 3;
    i2 = MIN (nb, mpnw + 2 - j3) + 2;
    ij = i2 + j3;
    for (i = 3; i <= i2; ++i) {
      i3 = i + j3;
      t[0] = mp_two_prod(t0, b[i], t[1]);
      d[i3-1] -= t[0];   // >= -(2^mpnbt-1), <= 2^mpnbt-1
      d[i3] -= t[1];
    }
    
      // Release carry to avoid overflowing the exact integer capacity
      // (2^52-1) of a floating point word in D.
    if(!(j & (mp::mpnpr-1))) { // assume mpnpr is power of two
      t2 = 0.0;
      for(i=i3;i>j+1;i--) {
        t1 = t2 + d[i];
        t2 = int (t1 * mprdx);     // carry <= 1
        d[i] = t1 - t2 * mpbdx;   // remainder of t1 * 2^(-mpnbt)
      }
      d[i] += t2;
    }
    
    d[j] += mpbdx * d[j-1];
    d[j-1] = t0; // quotient
  }
  
  // Compute additional words of the quotient, as long as the remainder
  // is nonzero.  
  BreakLoop = 0;
  for (j = na+2; j <= mpnw+3; ++j) {
    t1 = mpbx2 * d[j-1] + mpbdx * d[j];
    if (j < mpnw + 3) t1 += d[j+1];
    t0 = AINT (rb * t1); // trial quotient, approx is ok.
    j3 = j - 3;
    i2 = MIN (nb, mpnw + 2 - j3) + 2;
    ij = i2 + j3;
    ss = 0.0;
    
    for (i = 3; i <= i2; ++i) {
      i3 = i + j3;
      t[0] = mp_two_prod(t0, b[i], t[1]);
      d[i3-1] -= t[0];   // >= -(2^mpnbt-1), <= 2^mpnbt-1
      d[i3] -= t[1];
      
      //square to avoid cancellation when d[i3] or d[i3-1] are negative
      ss += sqr (d[i3-1]) + sqr (d[i3]); 
    }
      // Release carry to avoid overflowing the exact integer capacity
      // (2^mpnbt-1) of a floating point word in D.
    if(!(j & (mp::mpnpr-1))) { // assume mpnpr is power of two
      t2 = 0.0;
      for(i=i3;i>j+1;i--) {
        t1 = t2 + d[i];
        t2 = int (t1 * mprdx);     // carry <= 1
        d[i] = t1 - t2 * mpbdx;   // remainder of t1 * 2^(-mpnbt)
      }
      d[i] += t2;
    }

    d[j] += mpbdx * d[j-1];
    d[j-1] = t0;
    if (ss == 0.0) {
      BreakLoop = 1;
      break;
    }
    if (ij <= mpnw+1) d[ij+3] = 0.0;
  } 

  // Set SIGN and exponent, and fix up result.
  if(!BreakLoop) j--;
  d[j] = 0.0;
  
  if (d[1] == 0.0) {
    is = 1;
    d--; d_add++;
  } else {
    is = 2;
    d-=2; d_add+=2;
    //for (i = j+1; i >= 3; --i) d[i] =  d[i-2];
  }

  nc = MIN( (int(c[0])-FST_M-2), MIN (j-1, mpnw));
  

  d[1] = ia+ib ? nc : -nc;//SIGN(nc, ia * ib);
  d[2] = a[2] - b[2] + is - 2;  
  
  mpnorm(d, c);
  delete [] (d+d_add);
  
  if (MPIDB >= 8) print_mpreal((char*)"MPDIV O ", c);
  return;
}

void mp_real::mpdivd(const mp_real& a, double b, int n, mp_real& c)
{
  /**
   * This routine divides the MP number A by the DPE number (B, N) to yield
   * the MP quotient C.   Debug output starts with MPIDB = 9.
   *
   */
  int ia, ib, i, j, k, na, nc, n1, n2, d_add;
  double bb, br, dd, t0, t[2];
  double* d;
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(c);
    return;
  }
  if (MPIDB >= 9) {
    print_mpreal((char*)"MPDIVD a ", a);
    cout << " MIDIVD b " << b << "\t n " << n << endl;
  }

  ia = (a[1] >= 0 ? 1 : -1);
  na = MIN (int(ABS(a[1])), mpnw);
  ib = (b >= 0 ? 1 : -1);
    
  // Check if divisor is zero.
  if (b == 0.0) {
    if (MPKER[32] != 0) {
      cerr << "*** MPDIVD: Divisor is zero.\b.n";     
      MPIER = 32;
      if (MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }


  // Check if dividend is zero.
  if (na == 0) {
    zero(c);
    if (MPIDB >= 9) print_mpreal((char*)"MPDIVD O ", c);
    return;
  }

  if(n) {
    n1 = n / mpnbt;
    n2 = n - mpnbt * n1;   // n = mpnbt*n1+n2
    bb = fabs (b) * pow(2.0, n2);
  } else {
    n1 = n2 = 0;
    bb = fabs(b);
  }

  //  Reduce BB to within 1 and MPBDX.
  if (bb >= mpbdx) {
    for (k = 1; k <= 100; ++k) {
      bb = mprdx * bb;
      if (bb < mpbdx) {
        n1 += k;
        break;
      }
    }
  } else if (bb < 1.0) {
    for (k = 1; k <= 100; ++k) {
      bb = mpbdx * bb;
      if (bb >= 1.0) {
        n1 -= k;
        break;
      }
    }
  }
  
  // If B cannot be represented exactly in a single mantissa word, use MPDIV.
  if (bb != floor(bb)) {
    mp_real f((size_t)(9));
    bb = SIGN(bb, b);
    mpdmc(bb , n1*mpnbt, f);
    mpdiv(a, f, c);
    if (MPIDB >= 9) print_mpreal((char*)"MPDIVD O ", c);
    return;
  }
  
  //Allocate scratch space.
  d  = new double[mpnw+6];  
  d_add = 0;

  br = 1.0 / bb;
  for (i = FST_M; i < na + FST_M; ++i) d[i] = a[i];
  for (/*i = na+FST_M*/; i <= mpnw+FST_M+2 ; i++) d[i] = 0.0;
  d[2] = 0.;

  // Perform short division (not vectorizable at present).
  // Continue as long as the remainder remains nonzero.
  for (j = FST_M; j <= mpnw+FST_M+1; ++j) {
    dd = mpbdx * d[j-1];
    if (j < na + FST_M)
      dd += d[j];
    else {
      if (dd == 0.0) {
               break;
      }
    }
    t0 = AINT (br * dd); // [0, 2^mpnbt-1], trial quotient.
    t[0] = mp_two_prod(t0, bb, t[1]); // t[0], t[1] non-overlap, <= 2^mpnbt-1
    d[j-1] -= t[0];
    d[j] -= t[1];
    d[j] += mpbdx * d[j-1];

    d[j-1] = t0; // quotient
  }
  
  //  Set SIGN and exponent of result.
  j--;
  if(AINT(d[j] * br)  != 0.0) {
    if(AINT(d[j] * br) >= 0.0)
      d[j-1] += 1.0;
    else
      d[j-1] -= 1.0;
  }

  d[j] = 0.;
  if ( d[2] != 0. ) {
    --n1;
    d--;d_add++;
    j++;
    //roughly equivelent slower version is commented out:
    //for (i = j; i >= FST_M; --i) d[i] = d[i-1];
  }
  
  nc = j-FST_M;
  //Quotient result is negative if exactly one of {ia, ib} is -1
  d[1] = ia+ib ? nc : -nc; 
  d[2] = a[2] - n1 -1;
  
  mpnorm(d, c);
  delete [] (d+d_add);
  if (MPIDB >= 9) print_mpreal((char*)"MPDIVD O ", c);
  return; 
}

void mp_real::mpdmc(double a, int n, mp_real& b)
{
  /**
   * This routine converts the DPE number (A, N) to MP form in B.  All bits of
   * A are recovered in B.  However, note for example that if A = 0.1D0 and N
   * is 0, then B will NOT be the multiprecision equivalent of 1/10.  Debug
   * output starts with MPIDB = 9.
   *
   */
  int i, k, n1, n2;
  double aa;
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(b);
    return;
  }
  
  if (MPIDB >= 9) {
    cout << " MPDMC I: a = " << a << '\t';
    cout << "n = " << n << endl;
  }
  
  //  Check for zero.
  if (a == 0.0) {
    zero(b);
    if (MPIDB >= 9) print_mpreal((char*)"MPDMC O ", b);
    return;
  }
  
  if(n) {
    n1 = n / mpnbt;      // n = mpnbt*n1+n2
    n2 = n - mpnbt * n1;
    double t = pow(2.0, n2);
    aa = fabs(a) * t;
  } else {
    n1 = n2 = 0;
    aa = fabs(a);
  }

  //  Reduce AA to within 1 and MPBDX.
  if (aa >= mpbdx) {
    for (k = 1; k <= 100; ++k) {
      aa = mprdx * aa;
      if (aa < mpbdx) {
        n1 = n1 + k;
        break;
      }
    }
  } else if (aa < 1.0) {
    for (k = 1; k <= 100; ++k) {
      aa = mpbdx * aa;
      if (aa >= 1.0) {
        n1 = n1 - k;
        break;
      }
    } 
  }
  
  //  Store successive sections of AA into B.
  double d[8];

  d[2] = n1;
  d[3] = FLOOR_POSITIVE(aa);
  aa = mpbdx * (aa - d[3]);
  d[4] = FLOOR_POSITIVE(aa);
  aa = mpbdx * (aa - d[4]);
  d[5] = FLOOR_POSITIVE(aa);
  d[6] = 0.;
  d[7] = 0.;
  
  for (i = 5; i >= FST_M; --i)
    if (d[i] != 0.) break;
    
  aa = i - 2;
  aa = MIN(aa, (b[0])-5);
  b[1] = SIGN(aa, a);
  for(i=2;i<int(aa)+FST_M;i++)
    b[i] = d[i];
    
  if (MPIDB >= 9) print_mpreal((char*)"MPDMC O ", b);  
}

void mp_real::mpexp(const mp_real& a, const mp_real& al2, mp_real& b)
{
  /**
   * This computes the exponential function of the MP number a and
   * returns the MP result in B.  al2 is the MP value of log(2),
   * produced by a prior call to MPLOG.  for extra high levels of precision,
   * use MPEXPX.  The last word of the result is not reliable.
   * Debug output starts with MPIDB = 7. 
   *  
   * This routine uses a modification of the Taylor's series for Exp(t):
   * 
   * Exp(t) = (1 + r + r^2 / 2! + r^3 / 3! + r^4 / 4! ...) ^ q  *  2^n
   * 
   * where q = 256, r = t' / q, t' = t - n Log(2), and where n is 
   * chosen so that -0.5 Log(2) < t' <= 0.5 Log(2).  Reducing t mod Log(2)
   * and dividing by 256 insures that -0.001 < r <=0.001, which accelerates
   * convergence in the above series.
   *
   * Note that as the taylor series progresses, each successive term
   * is smaller in magnitude. This means that few mantissa words
   * of precision are needed for the later taylor series terms.
   * the computation of the taylor's series takes this into account 
   * (see below - term_prec), reducing the total amount of computation
   * by nearly half.
   */
  
  const double alt = 0.693147180559945309;
  const int nq = 8;
  double t1, t2;
  int n1, n2;
  
  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if(MPIDB >= 7) cout << "\nMPEXP I "<<a;
  
  mpmdc(a, t1, n1);
  if(n1 != 0)
    t1 *= pow(2.0, n1);
  
  // Unless the argument is near log(2), log(2) must be precomputed. This
  // Exception is necessary because MPLOG calls MPEXP to initialize Log(2).
  
  if(ABS(t1 - alt) > mprdx) {
    mpmdc(al2, t2, n2);
    if(n2 != -mpnbt || (ABS(t2 * mprdx - alt) > mprx2)) {
      if(MPKER[34] != 0) {
        cout << "\n*** MPEXP: LOG (2) must be precomputed.";
        MPIER = 34;
        if(MPKER[MPIER] == 2) mpabrt();
      }
      return;
    }
  }
  
  // Check for overflows and underflows.
  // The constant is roughly (2^26 * mpnbt)* log(2),
  // Which allows a result with (word) exponent up to 2^26.
  if(ABS(t1) > 2325815993.0) {
    if(t1 > 0.0) {
      if(MPKER[35] != 0) {
        cout <<"\n*** MPEXP : Argument is too large : "<<a;
        MPIER = 35;
        if(MPKER[MPIER] == 2) mpabrt();
      }
      return;
    } else {
      // argument is very negative, the result would be
      // too small, so just return zero.
      zero(b);
      return;
    }
  }
  
  size_t n6 = (size_t)(mpnw + 6);
  mp_real sk0(n6), sk1(n6), sk2(n6),
    sk3(n6);
  int nws = mpnw, nz, tl;
  mpnw++;
  mp_real f(size_t(8));
  // f = 1.0;
  f[1] = 1.0; f[2] = 0.0; f[3] = 1.0; f[4] = 0.0;
  
  //        Compute the reduced argument A' = A - Log(2) * nint(A / Log(2)).
  //        Save NZ = nint(A / Log(2)) for correcting the exponent of the final
  //         result.

  if(ABS(t1 - alt) > mprdx) {
    //It is unnecessary to compute much of fractional part of the following
    //division.
    mpnw = MIN(mpnw, int(a[2]) - int(al2[2]) + 3);
    mpnw = MAX(mpnw, 1);
    mpdiv(a, al2, sk0);
    mpnw = nws+1;
    mpnint(sk0, sk1);
    mpmdc(sk1, t1, n1);
    nz = int(t1 * pow(2.0, n1) + SIGN(mprxx, t1));
    mpmul(sk1, al2, sk2);
    mpsub(a, sk2, sk0);
  } else {
    mpeq(a, sk0);
    nz = 0;
  }
  
  tl = int(sk0[2]) - mpnw;


  // Check if the reduced argument is zero

  if(sk0[1] == 0.0) {
    sk0[1] = 1.0;
    sk0[2] = 0.0;
    sk0[3] = 1.0;
    mpmuld(sk0, 1.0, nz, sk1);
    mpeq(sk1, b);
    mpnw = nws;
    mproun(b);
    return;
  }

  // Divide the reduced argument by 2^nq.

  mpdivd(sk0, 1.0, nq, sk1);
  
  // Compute Exp using the usual Taylor series.
  
  mpeq(f, sk2);
  mpeq(f, sk3);
  const int max_iteration_count = 10000;
  int l1 = 0; //iteration number.
  int not_there_yet = 1;
  int term_prec;
  int i;

  while(not_there_yet && l1 < max_iteration_count) {
    l1++;
    t2 = l1;
    //get term precision from exponents of components of term, subtracting
    // exponent of current sum
    term_prec = MIN(nws+1, nws+int(sk2[2]+sk1[2]-sk3[2])+2);
    term_prec = MAX(term_prec, 0);
    if(term_prec <= 0) {
      mpnw = nws+1;
      break;
    }
    mpnw = term_prec;
    mpmul(sk2, sk1, sk0);
    mpdivd(sk0, t2, 0, sk2);
    mpnw = nws+1; // full precision to add term in.
    mpadd(sk3, sk2, sk3);
    //the above line needs relies on mpadd being safe 
    //for use when the first and third arguments are the same object.

    // Check for convergence of the series.
    if(sk2[1] != 0.0 && sk2[2] > tl) {
      //keep going.
    } else {
      not_there_yet = 0;
    }
  }
  //check if exceeded iteration bound.
  if(l1 > max_iteration_count) {
    if(MPKER[36] != 0) {
      cout <<"\n*** MPEXP: Iteration limit exceeded.";
      MPIER = 36;
      if(MPKER[MPIER] == 2) mpabrt();
      mpnw = nws;
      return;
    }
  }
  //Result of taylor series stored in sk3.

  //         Raise to the (2^NQ)-th power.

  for(i=0;i<nq;i++) {
    mpmul(sk3, sk3, sk3);
  }
  
  // Multiply by 2^NZ.
  if(nz) {
    mpmuld(sk3, 1.0, nz, b);
  } else {
    mpeq(sk3, b);
  }
  //restore original precision level.
  mpnw = nws;
  mproun(b);
  
  return;
}

void mp_real::mpinfr (const mp_real& a, mp_real& b, mp_real& c, 
                      int want_frac /*=1*/) 
{
  /*
   *  mpinfr sets B to the integer part of A, and C to the
   *  fractional part of A.  Note that if A = -3.3, then B = -3, 
   *  and C = -0.3.
   *  Debug output starts with MPIDB == 9.
   *
   *  The input argument want_frac is optional.  It defaults to 1. if
   *  frational part is not desired, pass in 0 for want_frac.
   *
   *  Required space for B and C: mpnw+4 cells each.
   */
  double ma;
  int na, nb, nc=0, ia;
  
  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(b); zero(c);
    return;
  }
  if(MPIDB >= 9) {
    cout <<"\nMPINFR I : A = "<<a;
  }
  
  // Check if A is zero.
  ia = SIGN(1, int(a[1]));
  na = MIN(int(ABS(a[1])), mpnw);
  ma = a[2];
  if(na == 0) {
    zero(b); zero(c);
    return;
  }
  
  if(ma > mpnw - 1) {
    //The input is alreay an integer.  
    //Any fractional part has been lost due to insufficient precision.
    if(MPKER[40] != 0) {
      cout << "\n***MPINFR: Argument is too large.";
      MPIER = 40;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    //don't return here, Since the user might want the answer anyway,
    //such as in mpoutx_helper.
  }
  
  // Place integer part in B.
  nb = MIN(MAX(int(ma)+1, 0), na);
  if(nb == 0) {
    zero(b);
  } else {
    int nb2 = MIN(nb, int(b[0])-FST_M-2);
    b[1] = SIGN(nb2, ia);
    b[2] = ma;
    b[nb2+FST_M] = b[nb2+FST_M+1] = 0.0;
    int nb3 = MIN(nb2+1, nb);
    for(int i = FST_M;i <= nb3 + 2; i++)
      b[i] = a[i];
  }
  
  // Place fractional part in C.
  
  if(want_frac) {
    nc = na - nb;
    if(nc <= 0) {
      zero(c);
    } else {
      int nc2 = MIN(nc, int(c[0])-FST_M-2);
      c[1] = SIGN(nc2, ia);
      c[2] = ma - nb;
      c[nc2+FST_M] = c[nc2+FST_M+1] = 0.0;
      int nc3 = MIN(nc2+1, nc);
      for(int i = FST_M; i <=  nc3+2; i++) {
        c[i] = a[i+nb];
      }
    }
  
    // Fix up results. B may have trailing zeros and C may have
    // Leading zeros.
    mproun(c);
  }
  // Fix up results. B may have trailing zeros and C may have
  // Leading zeros.
  mproun(b);
  
  if(MPIDB >=9) {
    cout << "\nMPINFR 0 : nb = "<<nb<<", nc = "<<nc;
  }
  return;
} 
  


void mp_real::mplog(const mp_real& a, const mp_real& al2, mp_real& b, 
                    int nit/* = 3*/)
{
  /**
   * This function computest the natural logarithm of the MP number a
   * and puts the result in B.  AL2 is the MP value of log(2), 
   * produced by a prior call to mplog.  For extra high levels of precision, 
   * use mplogx. 
   * 
   * For this routine, the last word of the result is not reliable.
   * debug output starts with MPIDB >= 7.
   * 
   * The Taylor series for Log converges more slowly than that of exp.
   * thus this routine does not employ taylor series, but instead computes
   * logarithms by solving exp(b) = a, using the following newton iteration,
   * which converges to log(a) == b.
   * 
   * x_{k+1} = x_k + [a - exp(x_k)] / exp(x_k);
   * 
   * These iterations are performed with a maximum precision level mpnw
   * that is dynamically changed, approximately doubling with each iteration.
   * 
   * See the comment about the int NIT in mpdiv.
   * NIT is an optional argument.  In general it should not be used.
   * The argument is only set (to zero) when creating Log(2) for the 
   * first time. This increases the precision of the computation of Log(2).
   */
  const double alt = 0.693147180559945309;
  const double cl2 = 1.4426950408889633;
  double ia;
  int na, n1, n2;
  double t1, t2;

  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    zero(b);
    return;
  }
  if(MPIDB >= 6) cout <<"\nMPLOG I"<<a;
  
  ia = SIGN(1.0, a[1]);
  na = MIN(int(ABS(a[1])), mpnw);
  
  if(ia < 0 || na == 0) { // negative or zero.
    if(MPKER[50] != 0) {
      cout << "\n*** MPLOG: Argument is less than or equal to zero.";
      MPIER = 50;
      if(MPKER[MPIER] == 2) mpabrt();
    }
    return;
  }

  //        Unless the input is close to 2, log(2) must have been
  //        Initialized previously.
  
  mpmdc(a, t1, n1);
  if((ABS(t1 - 2.0) > 0.001)  || (n1 != 0)) {
    mpmdc(al2, t2, n2);
    if(n2 != -mpnbt || (ABS(t2 * mprdx - alt) > mprx2)) {
      if(MPKER[51] != 0) {
        cout << "\n*** MPLOG: LOG (2) must be precomputed.";
        MPIER = 51;
        if(MPKER[MPIER] == 2) mpabrt();
      }
      return;
    }
  }
  
  // Check if input is exactly one.
  if((a[1] == 1.0)  && (a[2] == 0.0) && (a[3] == 1.0)) {
    zero(b);
    return;
  }
  
  size_t n6 = (size_t)(mpnw + 6);
  int nws = mpnw;
  int iq = 0;
  int prec_change = 0, mq, k;
  mp_real sk0(n6);
  mp_real sk1(n6), sk2(n6);
  
  //         Determine the lest integer MQ such that 2 ^ MQ >= mpnw.
  
  t2 = nws;
  mq = int(cl2 * log(t2) + 1.0 -mprxx);
  
  // Compute initial approximation of LOG(A);
  
  t1 = log(t1) + n1*alt;
  mpdmc(t1, 0, b);
  mpnw = 3;

  //cerr << "A" << endl;

  //        Perform the Newton-Raphson iteration described above, 
  //        Changing precision level mpnw dynamically. (mpnw =
  //        one greater than powers of two)
  
  for(k=1;k<=mq;k++) {
    if(prec_change)
      mpnw = MIN(2*mpnw - 2, nws)+1;
    else
      prec_change = 1;
    mpexp(b, al2, sk0);
    mpsub(a, sk0, sk1);
    mpdiv(sk1, sk0, sk2);
    mpadd(b, sk2, sk1);
    mpeq(sk1, b);
    if((k == mq-nit) && !iq) {
      iq = 1;
      k--;
      prec_change = 0;
      if(nit == 0) //used only for computing log(2) from mpinit.
        k-= 3; //This gives additional iterations. 3 was arbitrary.
    }
  } // end for;
  //cerr << "B" << endl;
  
  //        Restore original precision level.
  
  mpnw = nws;
  //cerr << "C" << endl;
  //cerr << "sk1[0] = " << sk1[0] << endl;
  //cerr << "b[0] = " << b[0] << endl;
  //cerr << "sk1[1] = " << sk1[1] << endl;
  //cerr << "b[1] = " << b[1] << endl;
  if (sk1[1] > b[1])
    mproun(b);
  //cerr << "D" << endl;
  return;
} // End MPLOG.

void mp_real::mpmdc(const mp_real&a, double &b, int &n)
{
  /**
   * This procedure takes the mp_real A, and splits it into 
   * a double, b, and a exponent, n. 
   *
   * On exit, the following should be roughly true: 
   *
   *       a ==(roughly) b*2^n
   */

  double aa;
  if(MPIER != 0) {
    if(MPIER == 99) mpabrt();
    b = 0.0;
    n = 0;
    return;
  }
  if(MPIDB >= 9) {
    int no = MIN(int(ABS(a[1])), MPNDB) + 2;
    cout << "\nMPMDC I\t"<< no;
  }
  if(a[1] == 0.0) {
    b = 0.0;
    n = 0;
    return;
  }

  int na = int(ABS(a[1]));
  aa = a[FST_M];
  if(na >= 2) aa += mprdx * a[FST_M+1];
  if(na >= 3) aa += mprx2 * a[FST_M+2];
  if(na >= 4) aa += mprx2 * mprdx * a[FST_M+3];

  n = int(mpnbt * a[2]); 
  b = SIGN(aa, a[1]);
  
  if(MPIDB >= 9) cout << "\nMPMDC 0 "<<b<<", "<<n;
  return;
}

void mp_real::mpmulacc(const mp_real &a, const mp_real &b, mp_real &c) {
  /**
   * This routine computes
   *
   *      C  <--  C  +  A * B
   *
   * If one of the multiplicand has a much higher level or precision than
   * the other, this routine is more efficient if A has the lower level of
   * precision.  
   * starts with MPIDB = 8.
   *
   * This routine returns up to MPNW mantissa words of the product.  If the
   * complete double-long product of A and B is desired (for example in large
   * integer applications), then MPNW must be at least as large as the sum of
   * the mantissa lengths of A and B.  In other words, if the precision levels
   * of A and B are both 64 words, then MPNW must be at least 128 words to
   * obtain the complete double-long product in C.
   */
  int i, j, j3, jd, ia, ib, na, nb, nc, n2;
  double d2, t1, t2, t[2], a_val;
  double* d;
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(c);
    return;
  }
  if (MPIDB >= 8) {
    print_mpreal((char*)"MPMUL a ", a);
    print_mpreal((char*)"MPMUL b ", b);
  }
  
  ia = int(SIGN(1.0, a[1]));
  ib = int(SIGN(1.0, b[1]));
  na = MIN (int(ABS(a[1])), mpnw);
  nb = MIN (int(ABS(b[1])), mpnw);
  
  // One of the inputs is zero -- the result is unchanged.
  if (na == 0 || nb == 0) {
    if (MPIDB >= 8) print_mpreal((char*)"MPMUL O ", c);
    return;
  }

  // One of the inputs is 1 or -1.
  if(na == 1) {
    if (a[3] == 1.) {
      int ic = ia * ib;
      if (ic == 1)
        c += b;
      else
        c -= b;
      return;
    }
  } else if (nb == 1) {
    if(b[3] == 1.) {
      int ic = ia * ib;
      if (ic == 1)
        c += a;
      else
        c -= a;
      return;
    }
  }

  // ok. ready for main part of routine
  d = new double[mpnw+5+FST_M];  // accumulator

  nc = MIN(int(c.mpr[0])-5, MIN (na + nb, mpnw));
  d2 = a[2] + b[2]; // exponent
  //for (i = 1; i < mpnw+4+FST_M; ++i) d[i] = 0.0;

  int ic = (c[1] >= 0.0) ? 1 : -1;
  int iab = ia * ib;
  double c_exp = c[2];
  double ab_exp = d2;
  int delta;
  int n_c = (int) ABS(c[1]);
  /*
  cout << "ab_exp = " << ab_exp << endl;
  cout << "c_exp = " << c_exp << endl;
  cout << "n_c = " << n_c << endl;
  cout << "nc = " << nc << endl;
  cout << "na = " << na << endl;
  cout << "nb = " << nb << endl;
  cout << "mpnw = " << mpnw << endl;
  */
  d[0] = 0.0;
  if (ab_exp >= c_exp) {
    d[2] = d[1] = 0.0;
    delta = (int) (ab_exp - c_exp);
    for (i = 3; i < 3 + delta; i++) d[i] = 0.0;
    int lim = 3 + delta + n_c;
    lim = MIN(lim, mpnw+4+FST_M);
    if (ic == iab)
      for (i = 3 + delta; i < lim; i++) d[i] = c[i-delta];
    else
      for (i = 3 + delta; i < lim; i++) d[i] = -c[i-delta];
    for (i = lim; i < mpnw+4+FST_M; i++) d[i] = 0.0;
    /*
    for (i = 1; i < mpnw+4+FST_M; i++) 
      cout << "d[" << i << "] = " << d[i] << endl;
    for (i = 3; i < 3 + n_c; i++)
      cout << "c[" << i << "] = " << c[i] << endl;
      */
    delta = 0;
  } else {
    d[2] = d[1] = 0.0;
    delta = (int) (c_exp - ab_exp);
    int lim = MIN(n_c + 3, mpnw+4+FST_M);
    if (ic == iab)
      for (i = 3; i < lim; i++) d[i] = c[i];
    else
      for (i = 3; i < lim; i++) d[i] = -c[i];
    for (i = lim; i < mpnw+4+FST_M; i++) d[i] = 0.0;
    /*
    for (i = 1; i < mpnw+4+FST_M; i++) 
      cout << "d[" << i << "] = " << d[i] << endl;
    for (i = 3; i < 3 + n_c; i++)
      cout << "c[" << i << "] = " << c[i] << endl;
      */
    //c += a * b;
    //return;
  }
  //for (i = 1; i < mpnw+4+FST_M; ++i) d[i] = 0.0;

  // Perform ordinary long multiplication algorithm. Accumulate at most 
  //  MPNW+5-FST+1 == (max j possible)-FST_M+1
  // mantissa words of the product.

  int last = 1;
  for (j = FST_M; j < na + FST_M; ++j, ++last) {
    a_val = a[j];
    j3 = j - FST_M;
    n2 = MIN (nb + FST_M, mpnw + 5 - j3 - delta);
    
    jd = j + delta;
    for(i = FST_M; i < n2; ++i) {
      t[0] = mp_two_prod_positive(a_val, b[i], t[1]); 
                // t[0], t[1] non-overlap, <= 2^mpnbt-1
      d[jd-1] += t[0];
      d[jd] += t[1];
      ++jd;
    }

      // Release carry to avoid overflowing the exact integer capacity
      // (2^mpnbt-1) of a floating point word in D.
    if (last >= mp::mpnpr-2) {
      last = 1;
      for(i= jd-1;i>=j;i--) {
          t1 = d[i];
            t2 = int (t1 * mprdx);     // carry <= 1
            d[i] = t1 - t2 * mpbdx;   // remainder of t1 * 2^(-mpnbt)
          d[i-1] += t2;
      }
    }
  }
  int d_add = 0;
  /*
  for (i = 0; i < 3 + mpnw+4+FST_M; i++)
    cout << "d[" << i << "] = " << d[i] << endl;
    */

  //for (i = 1; i < mpnw+4+FST_M; ++i) d[i] = 0.0;
 
  // If D[1] is nonzero, shift the result two words right.
  //if (delta == 0) {
    if (d[1] != 0.0) {
      // this case shouldn't really happen.
      assert(0);
      d2 += 2.0;
      for (i = nc + 4; i >= FST_M; --i)
        d[i] = d[i-2];    
    } else if (d[2] != 0.0 || (d[3] >= mpbdx && (d[2] = 0.0, 1))) {
    // If D[2] is nonzero, shift the result one word right.
      d2 += 1.0;  // exponent
      d--; d_add++;
    }
  //} else {
    d2 += delta;
  //}
  d[1] = (iab == -1) ? -nc : nc;
  //d[1] = ia+ib ? nc : -nc;
  // Result is negative if one of {ia, ib} is negative.
  d[2] = d2;

  /*
  for (i = 0; i < mpnw+4+FST_M; i++)
    cout << d[i] << " ";
  cout << endl;
  */
  //  Fix up result, since some words may be negative or exceed MPBDX.
  mpnorm(d, c);
  /*
  for (i = 0; i < c[0]; i++)
    cout << c[i] << " ";
  cout << endl;
  */
  delete [] (d +  d_add);
  
  if (MPIDB >= 8) print_mpreal((char*)"MPMUL O ", c);
  return;
}

void mp_real::mpmul(const mp_real& a, const mp_real&b, mp_real& c)
{
  /**
   * This routine multiplies MP numbers A and B to yield the MP product C.
   * When one of the arguments has a much higher level of precision than the
   * other, this routine is slightly more efficient if A has the lower level of
   * precision.  For extra high levels of precision, use MPMULX.  Debug output
   * starts with MPIDB = 8.
   *
   * This routine returns up to MPNW mantissa words of the product.  If the
   * complete double-long product of A and B is desired (for example in large
   * integer applications), then MPNW must be at least as large as the sum of
   * the mantissa lengths of A and B.  In other words, if the precision levels
   * of A and B are both 64 words, then MPNW must be at least 128 words to
   * obtain the complete double-long product in C.
   */
  int i, j, j3, jd, ia, ib, na, nb, nc, n2;
  double d2, t1, t2, t[2], a_val;
  double* d;
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(c);
    return;
  }
  if (MPIDB >= 8) {
    print_mpreal((char*)"MPMUL a ", a);
    print_mpreal((char*)"MPMUL b ", b);
  }
  
  ia = int(SIGN(1.0, a[1]));
  ib = int(SIGN(1.0, b[1]));
  na = MIN (int(ABS(a[1])), mpnw);
  nb = MIN (int(ABS(b[1])), mpnw);
  
  // One of the inputs is zero -- result is zero.
  if (na == 0 || nb == 0) {
    zero(c);
    if (MPIDB >= 8) print_mpreal((char*)"MPMUL O ", c);
    return;
  }

  // One of the inputs is 1 or -1.
  if(na == 1) {
    if (a[3] == 1.) {
      // A is 1 or -1 -- result is B or -B.
      nc = MIN(nb, (int(c[0])-FST_M-2));
      c[1] = SIGN(nc, ia * ib);
      c[2] = a[2] + b[2];
      
      for (i = FST_M; i < nc + FST_M; ++i) c[i] = b[i];
      if(nc < nb) {
        //round..
        c[FST_M+nc] = b[FST_M+nc];
        c[FST_M+nc+1] = 0.0;
        mproun(c);
      } else {
        c[FST_M+nc] = c[FST_M+nc+1] = 0.0;
      }    
      if (MPIDB >= 8) print_mpreal((char*)"MPMUL O ", c);
      return;
    } else {
      //a has only one mantissa word, just use mpmuld
      double a2 = a[2];
      mpmuld(b, ia * a[FST_M], 0, c);
      c[2] += a2;
      return;
    }
  } else if (nb == 1) {
    if(b[3] == 1.) {
      // B is 1 or -1 -- result is A or -A.
      nc = MIN(na, (int(c[0])-FST_M-2));
      c[1] = SIGN(nc, ia * ib);
      c[2] = a[2] + b[2];
      
      for (i = FST_M; i < nc + FST_M; ++i) c[i] = a[i];
      if(nc < na) {
        //round..
        c[FST_M+nc] = a[FST_M+nc];
        c[FST_M+nc+1] = 0.0;
        mproun(c);
      } else {
        c[FST_M+nc] = c[FST_M+nc+1] = 0.0;
      }
      
      if (MPIDB >= 8) print_mpreal((char*)"MPMUL O ", c);
      return;
    } else {
      //b has only one mantissa word, just use mpmuld
      double b2 = b[2];
      mpmuld(a, ib * b[FST_M], 0, c);
      c[2] += b2;
      return;
    }
  }
  // ok. ready for main part of routine
  d = new double[mpnw+5+FST_M];  // accumulator

  nc = MIN(int(c.mpr[0])-5, MIN (na + nb, mpnw));
  d2 = a[2] + b[2]; // exponent
  for (i = 1; i < mpnw+4+FST_M; ++i) d[i] = 0.0;


  // Perform ordinary long multiplication algorithm. Accumulate at most 
  //  MPNW+5-FST+1 == (max j possible)-FST_M+1
  // mantissa words of the product.

  for (j = FST_M; j < na + FST_M; ++j) {
    a_val = a[j];
    j3 = j - FST_M;
    n2 = MIN (nb + FST_M, mpnw + 5 - j3);
    
    jd = j;
    for(i = FST_M; i < n2; ++i) {
      t[0] = mp_two_prod_positive(a_val, b[i], t[1]); 
                // t[0], t[1] non-overlap, <= 2^mpnbt-1
      d[jd-1] += t[0];
      d[jd] += t[1];
      ++jd;
    }

      // Release carry to avoid overflowing the exact integer capacity
      // (2^mpnbt-1) of a floating point word in D.
    if(!((j-2) & (mp::mpnpr-1))) { // assume mpnpr is power of two
      for(i= jd-1;i>=j;i--) {
          t1 = d[i];
            t2 = int (t1 * mprdx);     // carry <= 1
            d[i] = t1 - t2 * mpbdx;   // remainder of t1 * 2^(-mpnbt)
          d[i-1] += t2;
      }
    }
  }
  int d_add = 0;
 
  // If D[1] is nonzero, shift the result two words right.
  if (d[1] != 0.0) {
    // this case shouldn't really happen.
    assert(0);
    d2 += 2.0;
    for (i = nc + 4; i >= FST_M; --i)
      d[i] = d[i-2];    
  } else if (d[2] != 0.0 || (d[3] >= mpbdx && (d[2] = 0.0, 1))) {
  // If D[2] is nonzero, shift the result one word right.
    d2 += 1.0;  // exponent
    d--; d_add++;
  }
  // Result is negative if one of {ia, ib} is negative.
  d[1] = ia+ib ? nc : -nc;
  d[2] = d2;

  //  Fix up result, since some words may be negative or exceed MPBDX.
  mpnorm(d, c);
  delete [] (d +  d_add);
  
  if (MPIDB >= 8) print_mpreal((char*)"MPMUL O ", c);
  return;
}

void mp_real::mpmuld(const mp_real& a, double b, int n, mp_real& c)
{
  /**
   * This routine multiplies the MP number A by the DPE number (B, N) to yield
   * the MP product C.  Debug output starts with MPIDB = 9.
   *
   * Here, DPE means double precision + exponent, so (B, N) = b * 2^n
   */

  int i, ia, ib, k, na, n1, n2, d_add;
  double bb, t[2];
  double* d;
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(c);
    return;
  }
  
  if (MPIDB >= 9) {
    print_mpreal((char*)"MPMULD a ", a);
    cout << " MPMULD b " << b;
    cout << '\t' << n << endl; 
  }
  
  // Check for zero inputs.
  ia = int(SIGN(1.0, a[1]));
  na = MIN (int(ABS(a[1])), mpnw);
  ib = int(SIGN(1.0, b));
  if (na == 0 || b == 0.0) {
    zero(c);
    if (MPIDB >= 9) print_mpreal((char*)"MPMULD O ", c);
    return;
  }
  if(n) {
    n1 = n / mpnbt;      // n = mpnbt*n1+n2
    n2 = n - mpnbt * n1;
    bb = fabs(b) * pow(2.0, n2);
  } else {
    n1 = n2 = 0;
    bb = fabs(b);
  }

  // Reduce BB to within 1 and MPBDX.
  if (bb >= mpbdx) {
    for (k = 1; k <= 100; ++k) {
      bb = mprdx * bb;
      if (bb < mpbdx) {
        n1 = n1 + k;
        break;
      }
    }
  } else if (bb < 1.0) {
    for (k = 1; k <= 100; ++k) {
      bb = mpbdx * bb;
      if (bb >= 1.0) {
        n1 = n1 - k;
        break;
      }
    }
  }

  // BB is now between 1 and MPBDX (and positive)
  // If BB cannot be represented exactly in a single mantissa word, use MPMUL.
  if (bb != floor(bb)) {
    mp_real f((size_t)(9));
    mpdmc(b, n, f);
    mpmul(f, a, c);
    if (MPIDB >= 9) print_mpreal((char*)"MPMULD O ", c);
    return; 
  }
  
  d = new double[mpnw+6];
  d_add = 0;

  // Perform short multiply operation.
  d[2] = 0.;
  for (i = FST_M; i < na + FST_M; ++i) {
    t[0] = mp_two_prod_positive(a[i], bb, t[1]); 
        // t[0], t[1] non-overlap, <= 2^mpnbt-1
    d[i-1] += t[0];  // exact, <= 2^53-2
    d[i] = t[1];
  }
  
  // If carry is nonzero, shift the result one word right.
  if (d[2] != 0.0) {
    ++n1;  // exponent
    ++na;//number of words

    d--;d_add++;// "shift" the array one to the right.
    // This has the same effect as the following commented out loop:
    //for (i = na + FST_M; i >= FST_M; --i) d[i] = d[i-1];
  }

  // Set the exponent and fix up the result.
  d[1] = ia+ib ? na : -na;//same as SIGN (na, ia * ib);
  d[2] = a[2] + n1;
  d[na+3] = 0.0;
  d[na+4] = 0.0;
  
  //  Fix up result, since some words may be negative or exceed MPBDX.
  mpnorm(d, c);
  delete [] (d + d_add);

  if (MPIDB >= 9) print_mpreal((char*)"MPMULD O ", c);
  return;
}

void mp_real::mpnint(const mp_real& a, mp_real& b)
{
  /**
   * Rounds to nearest integer.  If mpnw is low, 
   * so that an integer cannot be represented in 
   * fully, this may return incorrect results.
   * In other words, in large integer applications,
   * care must be given to setting mpnw sufficiently high.
   * if mpnw is too low, do not expect mpnint to produce
   * the correctly rounded integer.
   *
   * 
   */
  int na = int(ABS(a[1]));
  int nb = MIN(int(b[0])-5, MIN(mpnw, na));
  double mag_up = 0.0;
  double exp = a[2];
  double sgn = SIGN(1.0, a[1]);
  if(na == 0 || nb == 0) {
    zero(b);
    return;
  }
  
  if(exp - na +1 < 0) {
    // we must truncate to exp+1 words
    int nout = MIN(nb, int(exp)+1);
    if(nout < 0) {
      // magnitude far less than 1.
      zero(b);
      return;
    }
    if(!nout) {
      // might round up to one.
      if(a[FST_M] >= mpbdx/2.0) {
        b[1] = sgn * 1.0;
        b[2] = 0.0;
        b[3] = 1.0;
        b[4] = 0.0;
        return;
      } else {
        zero(b);
        return;
      }
    }
    if(na > nout) {
      // rounding required
      if(a[FST_M + nout] >= mpbdx/2.0) {
        mag_up = 1.0;
      }
    }
    nb = nout;
  }
  b[nb+FST_M] = b[nb + FST_M+1] = 0.0;
  for(int i = nb+FST_M-1; i >= FST_M; i--) b[i] = a[i];
  b[1] = sgn * nb;
  b[2] = a[2];
  if(mag_up == 1.0) {
    // add one (or subtract one if negative).
    mp_real sk0,f;
    f[1] = 1;
    f[2] = 0;
    f[3] = 1;
    f[4] = 0;
    if(sgn > 0)
      mpadd(b, f, sk0);
    else
      mpsub(b, f, sk0);
    mpeq(sk0, b);
  }
  return;
}

void mp_real::mpnpwr(const mp_real& a, int n, mp_real& b)
{
  /**
   * This computes the N-th power of the MP number A and returns the MP result
   * in B.  When N is zero, 1 is returned.  When N is negative, the reciprocal
   * of A ^ |N| is returned.  For extra high levels of precision, use MPNPWX.
   * Debug output starts with MPIDB = 7.
   *
   * This routine employs the binary method for exponentiation.
   */

  int kk, kn, n5, na, nn, nws, skip;
  //const double cl2 = 1.4426950408889633;  // log2(e)
  mp_real f1(size_t(9)), sk0((size_t(mpnw+6))), sk1((size_t(mpnw+6)));
  
  if (MPIER != 0) {
    if (MPIER == 99)  mpabrt();
    zero(b);
    return;
  }
  if (MPIDB >= 7) print_mpreal((char*)"MPNPWR I ", a);
  
  na = MIN (int(ABS(a[1])), mpnw);
  if (na == 0) {
    if (n >= 0) {
      zero(b);
      if (MPIDB >= 7) print_mpreal((char*)"MPNPWR O ", b);
      return;
    } else {
      if (MPKER[57] != 0) {
        cerr << "*** MPNPWR: Argument is zero and N is negative or zero.\n";
        MPIER = 57;
        if (MPKER[MPIER] == 2) mpabrt();
      }
      return;
    }
  }

  n5 = mpnw + 5;
  nws = mpnw;
  mpnw = mpnw + 1;
  nn = ABS (n);
  f1[1] = 1.; // f1 = 1.0
  f1[2] = 0.;
  f1[3] = 1.;
  f1[4] = 0.;
  
  skip = 0;
  if (nn == 0) {
    mpeq(f1, b);
    mpnw = nws;
    if (MPIDB >= 7) print_mpreal((char*)"MPNPWR O ", b);
    return;
  } else if (nn == 1) {
    mpeq(a, b);
    skip = 1;
  } else if (nn == 2) {
    mpmul(a, a, sk0);
    mpeq(sk0, b);
    skip = 1;
  }

  if ( skip == 0 ) {
    // nn has the power at beginning
    mpeq (a, sk0);
    mpeq (f1, b);
    kn = nn;
    
    // Compute B ^ N using the binary rule for exponentiation.
    while(kn) {
      kk = kn / 2;
      if (kn != 2 * kk) { // kn is odd
        mpmul(b, sk0, sk1);
        mpeq(sk1, b);
      }
      kn = kk;
      if (kn) {
        mpmul(sk0, sk0, sk1);
        mpeq(sk1, sk0);
      }
    }
  }
  
  // Compute reciprocal if N is negative.
  if (n < 0) {
    mpdiv(f1, b, sk0);
    mpeq(sk0, b);
  }
  
  // Restore original precision level.
  mpnw = nws;
  mproun(b);
  
  if (MPIDB >= 7) print_mpreal((char*)"MPNPWR O ", b);

}


void mp_real::mpsqrt(const mp_real& a, mp_real& b)
{
  /**
   * This computes the square root of the MP number A and places
   * the result in B.  For extra high levels of precision,
   * use MPSQRTX. Debug output starts with MPIDB =7.
   *  
   * Space suggested for B: mpnw+FST_M+2.
   *  
   * This subroutine employs the following Newton-Raphson
   * iteration, which converges to Sqrt(a):
   *
   *  X_{k+1} = X_k + 0.5 * (A - X_k^2) / X_k;
   *  
   * where the division () / X_k is performed with half normal
   * precision.  These iterations are performed with a maximum
   * precsion level of mpnw, with the precision dynamically changing,
   * doubling for each iteration.
   *
   * The precision doubling technique is efficient, but can cause
   * errors to build up in trailing mantissa words.  This error
   * can be controlled by repeating one of the iterations.
   * Iteration that is repieated is controlled by the input parameter
   * nit.  if nit == 0, the last iteration is repeated.  This
   * is the most effective, but the most expensive. if nit == 1, 
   * the second to last iteration is repeated instead, etc.
   *
   * Note that square roots of numbers with large
   * exponent magnitude, (base 2 exponent > 2^31), square roots
   * will be incorrect.  at present the library does not support
   * such large (or small) numbers.
   *
   * IMPORTANT - please note that mpsqrt is not safe for
   * use with the input variable the same as the output variable.
   * never call with mpsqrt(a, a).  This will lead to incorrect results.
   */
  const double cl2 = 1.4426950408889633; // == log_2(e) ==  1/log(2)
  const int nit = 3;

  if(MPIER != 0) {
    if(MPIER == 00) mpabrt();
    zero(b);
    return; 
  }
  if(MPIDB >= 7 ) {
    cout << "\nRunnung mpsqrt";
  }
  
  int ia = SIGN(1, int(a[1]));
  int na = MIN(int(ABS(a[1])), mpnw);
  
  if(na == 0) {
    zero(b);
    return;
  }
  if(ia < 0.0) {//negative radicand!
    if(MPKER[70] != 0) {
      cerr << "*** MPSQRT: Argument is negative.";
      MPIER = 70;
      if(MPKER[MPIER] == 2)
        mpabrt();
    }
    return;
  } // end negative radicand check

  int nws = mpnw;
  int k, mq, n, n2, iq=0;
  double t1, t2;
  int nw1, nw2, prec_change=0;
  size_t n7 = (size_t)(mpnw+7);
  mp_real sk0(n7), sk1(n7);

  // Determine the least integer MQ such that 2 ^ MQ >= mpnw.

  t1 = mpnw;
  mq = int(cl2 * log(t1) + 1.0 - mp::mprxx);
  
  //        Compute the initial approximation of Sqrt(A) using double
  //        precision.

  mpmdc(a, t1, n);
  n2 = n / 2;
  t2 = sqrt((n2*2 == n) ? t1 : t1 * 2.0);
  t1 = t2;
  mpdmc(t1, n2, b);
  
  nw1 = nw2 = mpnw = 3;
  iq = 0;
  
  //         Perform the Newton-Raphson iteration described above by
  //         changing the precision level MPNW (one greater than powers of two).
  for(k=2;k <= mq;k++) {
    if(prec_change) {
      nw1 = mpnw;
      mpnw = MIN(2*mpnw-2, nws)+1; 
      nw2 = mpnw;
    } else {
      k--;
      prec_change = 1;
    }
    mpmul(b, b, sk0);
    mpsub(a, sk0, sk1);
    mpnw = nw1;
    mpdiv(sk1, b, sk0);
    mpmuld(sk0, 0.5, 0, sk1);
    mpnw = nw2;
    mpadd(b, sk1, b);
    //the above line needs to change if mpadd is not safe for 
    // same variable input/output.

    if(k == mq - nit && iq == 0) {
      iq = 1;
      prec_change = 0;
    }
  } // end for


  // Restore original precision level
  mpnw = nws;
  mproun(b);

  if(MPIDB >= 7) {
    cout <<"MPSQRT done.";
  } 
  return;
}

ostream& operator<<(ostream& s, const mp_real& ja)
{
  char *az = new char[mp::mpipl + 100];
  int i, nd;
  mp_real::mpoutx(ja, mp::mpoud, az, nd);
  for (i = 0; i < nd; i++) {
    s << az[i];
    if( (i+1)%78 == 0 ) s<< endl;
  }
        
  s << endl;
  s.flush();
  delete [] az;
  return s;
}


