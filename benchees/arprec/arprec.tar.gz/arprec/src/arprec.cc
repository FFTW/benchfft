/*
 * src/mpreal2.cc
 *
 * This software is provided for research purposes only.
 * Commercial usage requires license agreement.
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2002
 *
 */
#include "mp/mpreal.h"
#include "mp/mpcomplex.h"
#include "mp/mpint.h"
#include "mp/fpu.h"

#if (ARPREC_HAVE_STD)
#include <fstream>
using std::ofstream;
using std::ifstream;
#else
#include <fstream.h>
#endif

#if !(ARPREC_INLINE)
#include "mp/mp_inline.h"
#include "mp/mp_complex_inline.h"
#include "mp/mp_int_inline.h"
#endif

// initializing static variables
const double mp::mpbbx = 16777216.0;//33554432.0;  // 2^25
const double mp::mpbdx = mp::mpbbx * mp::mpbbx;// 2^50
const double mp::mpbx2 = mp::mpbdx * mp::mpbdx; 
const double mp::mprbx = 1.0 / mp::mpbbx;
const double mp::mprdx = 1.0 / mp::mpbdx; // 2^(-50)
const double mp::mprx2 = mp::mprdx * mp::mprdx; 
const double mp::mprxx = 16.0 * mp::mprx2;


const int mp::mpnbt = 48, //bits ber word
  mp::mpnpr = 16,//4, //half the number of words added before forcing carry
  
  mp::mpmcrx = 7, // advanced routines start at roughly 2^mpmcrx 
  mp::mpnrow = 16,//32
  mp::mpnsp1 = 3, //3
  mp::mpnsp2 = 9; //17


//This variable is never used, but needs to be here
//so that the startup code in mp_init will run.
//Constants wil not be computed until a user calls mp_init directly.
const int mp::initial_mpipl  = mp_init(2005, 0, -1);

int mp::MPIDB=0,
  mp::MPNDB=22,
  mp::MPMCR=mp::mpmcrx,
  mp::MPIRD=1,
  mp::MPIER=99,
  mp::MPKER[79+1] = {0,2,2,2,2,2,2,2,2,2,2,2,2,2,
			    2,2,2,2,2,2,2,2,2,2,
			    2,2,2,2,2,2,2,2,2,2,
			    2,2,2,2,2,2,2,2,2,2,
			    2,2,2,2,2,2,2,2,2,2,
			    2,2,2,2,2,2,2,2,2,2,
			    2,2,2,2,2,2,2,2,2,2,
                            2,2,2,2,2,2};

int mp::mpwds;
int mp::mpnw,    // all these get set later in mp_init
  mp::mpoud,
  mp::mp2,
  mp::mp5,
  mp::mpiep,
  mp::mp21,
  mp::mpiou,
  mp::mpipl;

int mp::fmpwds5; // the static word size used in Fortran 90 wrapper,
                 // fmpwds5 >= mp5, and is set by c_mpinit() in c_mp.cc.

mp_real mp::mppic;
mp_real  mp::mpl02;
mp_real  mp::mpl10;
mp_real  mp::mpeps;
double *mp::mpuu1 = 0;
double *mp::mpuu2 = 0;
double *mp::mpuu3 = 0;

unsigned int mp::old_cw = 0;

/**
 * The following routine mp_init needs to be called by the
 * user in order to use the library.  
 * The user specifies in the first argument the precision
 * in base 10 digits that is desired.  All subsequent operations
 * then should satify an error bound based on this given value.
 * 
 * If the second argument 'filename' is present, the multi-precision
 * constants will be read from the file, instead of being re-computed.
 * 
 * The third argument 'new_all' is not meant to be used by the user.
 * It is only used when mp_init is called internally to set up the 
 * default values. 
 *     new_all = -1:  Just to run the startup code, but the constants are
 *                    not be computed until a user calls mp_init directly.
 *     new_all =  0:  Constants need not be re-computed if they were
 *                    computed before and the new precision level
 *                    is not greater than the previous precision level.
 */
int mp::mp_init(int new_mpipl, char *filename, int new_all)
{
  fpu_fix_start(&mp::old_cw);
  const double digits_per_word = mp::mpnbt * log(2.0)/log(10.0);
  int skip;
  static int constants_computed=0;

  if(!constants_computed || new_all || new_mpipl > mpipl)
    skip = 0;
  else skip = 1;

  mpipl = new_mpipl;
  mpiou = new_all ? 56 : MIN(mpiou, new_mpipl);
  mpiep = (50 - mpipl);
  mpwds = int((mpipl-1) / digits_per_word + 2);
  mpnw = mpwds;
  mp5 = mpnw + 5;

  mp::mpoud = mpiou;
  mp::mp2 = mpwds + 2;
  mp::mp21 = mp::mp2 + 1;

  //This lets other procedures know that the library is ready.
  MPIER = 0;
  if(!skip && new_all != -1) {
    if(mpnw > (1<<(mpmcrx-1))) 
      mp_real::mpinix(mpnw+8);
    //set mpeps.
    memcpy(&mp::mpeps, &mp::init_mpeps(), sizeof(mp_real));

    if(filename) { //get constants from a file.
      ifstream infile(filename);
      if(!infile) {
	cerr << "\nCould not open MP initialization file "<<(filename);
	mpabrt();
      }
      int temp;
      infile >> temp;
      if(temp < mpipl) {
	cerr << "\nMP Initialization file incorrect or does not "
	     << "have sufficient precision.";
	mpabrt();
      }
      infile.ignore(); //get rid of newline.
      memcpy(&mp::mppic, new mp_real(size_t(mpnw+8)), sizeof(mp_real));
      memcpy(&mp::mpl02, new mp_real(size_t(mpnw+8)), sizeof(mp_real));
      memcpy(&mp::mpl10, new mp_real(size_t(mpnw+8)), sizeof(mp_real));
      mp_real::read_mp_real(infile, mp::mppic);
      mp_real::read_mp_real(infile, mp::mpl02);
      mp_real::read_mp_real(infile, mp::mpl10);
      double t1;
      int n1;
      mp_real::mpmdc(mp::mppic, t1, n1);
      if(n1 != 0 || ABS(t1 - 3.141592653589793) > mprx2) {
	cout << "\n*** MPINIT: Pi is wrong in file "<<(filename);
	mpabrt();
      }
      mp_real::mpmdc(mp::mpl02, t1, n1);
      if(n1 != -mpnbt || (ABS(t1 * mprdx - 0.693147180559945309) > mprx2)) {
	cout << "\n*** MPINIT: Log(2) is wrong in file "<<(filename);
	mpabrt();
      }
      mp_real::mpmdc(mp::mpl10, t1, n1);
      if(n1 != 0 || ABS(t1 - 2.3025850929940459) > mprx2) {
	cout << "\n*** MPINIT: Log(10) is wrong in file "<<(filename);
	mpabrt();
      }
    } else {
      memcpy(&mp::mppic, &mp::init_mppic(), sizeof(mp_real));
      memcpy(&mp::mpl02, &mp::init_mpl02(), sizeof(mp_real));
      memcpy(&mp::mpl10, &mp::init_mpl10(), sizeof(mp_real));
    }
    constants_computed = 1;
  }
  return new_mpipl;
}

void mp::mp_finalize() {
  fpu_fix_end(&mp::old_cw);
}

void mp::mpsetoutputprec(int num_digits)
{
  mpoud = mpiou = MIN(mpipl-2, MAX(1, num_digits));
  if(mpoud != num_digits) {
    cout <<"\nRequest for output of "<<num_digits<<
      " did not succeed.  MPINIT must first be called with at least "<<
      num_digits+2<<
      "\nof precision.  Defaulting to output of "<<mpoud<<" digits.";
  }
}

void mp::mpsetprec(int num_digits)
{
  const double digits_per_word = mp::mpnbt * log(2.0)/log(10.0);
  mpsetprecwords(int((num_digits-1)/digits_per_word)+2);
}

int mp::mpgetprec()
{
  const double digits_per_word = mp::mpnbt * log(2.0)/log(10.0);
  return int((mpnw - 1) * digits_per_word) + 1; 
}

void mp::mpsetprecwords(int num_words)
{
  mpnw = MAX(0, MIN(mpwds+1, num_words));
  mp5 = mpnw + 5;
}



void mp::mpabrt()
{
  if (MPIER == 99) 
    cerr << "*** The ARPREC library has not been initialized. \n";
  else
    cerr << "*** mpabrt: execution terminated, error code =" << MPIER << endl;
  exit(-1);
}

void mp_real::print_mpreal(char* functionName, const mp_real& mpr)
{
  int nm, nw, w;
  
  nw = (int) mpr[0];
  nm = (int) ABS(mpr[1]);
  cout << " " << functionName << "nw = " << nw << endl;
  cout << " " << functionName << "nm = " << nm << endl;
  cout << " " << functionName << "exp = " << mpr[2] << endl;
  cout.precision(20);
  for(w = FST_M; w < ABS(mpr[1]) + FST_M; ++w)
    cout << "\t" <<" w=" << w <<"  "<< mpr[w] << endl;
  cout.precision(0);
}


mp_real& mp::init_mppic()
{
  // other stuff
  MPIER = 0;
#if 1  
  mpnw+=4;
  mp_real *temp = new mp_real(size_t(mpnw+6));
  mp_real::mppix(*temp);
  mpnw-=4;
  return *temp;
#else 
  return *(new mp_real(size_t(5)));
#endif
}

mp_real& mp::init_mpl02()
{
#if 1
  // mpl02
  mp_real *t1 = new mp_real(size_t(mp21+6)), t2(size_t(6));
  //set t1 = 3.0, far more than log2.
  (*t1)[1] = 1.0;
  (*t1)[2] = 0.0;
  (*t1)[3] = 3.0;
  (*t1)[4] = 0.0;
  mp_real::mpnw+=4;
  mp_real::mpdmc(2.0, 0, t2);
  // fourth optional "hidden" nit argument set to zero for greater accuracy
  // users should not call mplog with four arguments, only 3.
  if(mpnw < (1<<(mpmcrx-2))) {
    mp_real::mplog(t2, *t1, *t1, 0); 
  } else {
    mp_real::mplogx(t2, mppic, *t1, *t1);
  }
  mp_real::mpnw-=4;
  return *t1;
#else 
  return *(new mp_real(size_t(5)));
#endif
}

mp_real& mp::init_mpl10()
{
#if 1
  mp_real::mpnw+=4;
  mp_real *t1 = new mp_real(size_t(mpnw+5));
  mp_real t2(size_t(8));
  mp_real::mpdmc(10.0, 0, t2);
  mp_real::mplogx(t2, mppic, mpl02, *t1);
  mp_real::mpnw-=4;
  return *t1;
#else 
  return *(new mp_real(size_t(5)));
#endif
}

mp_real& mp::init_mpeps()
{
#if 1
  mp_real *t1 = new mp_real(size_t(100)), t2(size_t(6));
  //mp_real::mpdmc(10.0, 0.0, t2);
  t2[1] = 1.0; t2[2] = 0.0; t2[3] = 10.0; t2[4] = 0.0;
  mp_real::mpnw+=4;
  mp_real::mpnpwx(t2, mpiep, *t1);
  mp_real::mpnw-=4;
  return *t1;
#else 
  return *(new mp_real(size_t(5)));
#endif
}


void mp::mp_output_init(char *filename)
{
  ofstream outfile(filename);
  if(!outfile) {
    cerr << "\nCannot output initialization file "<<filename;
    return;
  }
  //else, ok.
  outfile << mp::mpipl << endl;
  mp_real::write_mp_real(outfile, mp::mppic);
  mp_real::write_mp_real(outfile, mp::mpl02);
  mp_real::write_mp_real(outfile, mp::mpl10);
  outfile.close();
}
