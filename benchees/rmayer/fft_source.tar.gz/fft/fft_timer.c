#define ITERATION_FACTOR 512

#define REAL double

static REAL real[140001];
static REAL imag[140001];
static REAL rsav[140001];
static REAL isav[140001];

#include "time.h"
#include <math.h>

#ifdef FFT_MAYER
static char fft_algorithm[] = "mayer-rad4";
extern char trig_algorithm[];
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define FFT(n,r,i)  fft((n),(r),(i))
#define IFFT(n,r,i) ifft((n),(r),(i))
#define SCALE
#define REAL_OUTPUT(i) real[i]
#define IMAG_OUTPUT(i) imag[i]
#endif

#ifdef FFT_MAYER_REAL
static char fft_algorithm[] = "mayer-real";
extern char trig_algorithm[];
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define FFT(n,r,i)  realfft((n),(r))
#define IFFT(n,r,i) realifft((n),(r))
#define SCALE
#define REAL_OUTPUT(i) ((i<n/2)?   real[i]:real[n-i])
#define IMAG_OUTPUT(i) ((i<n/2)?-imag[n-i]:imag[i])
#endif

#ifdef FFT_MAYER_FHT
static char fft_algorithm[] = "mayer-fht";
extern char trig_algorithm[];
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define FFT(n,r,i)  fht((r),(n),1)
#define IFFT(n,r,i) fht((r),(n),1)
#define SCALE for (j=0;j<n;j++)  {real[j]*=scale;}
#define REAL_OUTPUT(i) ((i==0 || i==n/2)?real[i]:((real[i]+real[n-i])/2))
#define IMAG_OUTPUT(i) ((i==0 || i==n/2)?0      :((real[i]-real[n-i])/2))
#endif

#ifdef FFT_BUNEMAN_FHT
static char fft_algorithm[] = "bune-fht";
static char trig_algorithm[] = "Buneman";
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define FFT(n,r,i)  fht((r),(n))
#define IFFT(n,r,i) fht((r),(n))
#define SCALE
#define REAL_OUTPUT(i) ((i==0 || i==n/2)?real[i]:((real[i]+real[n-i])/2))
#define IMAG_OUTPUT(i) ((i==0 || i==n/2)?0      :((real[i]-real[n-i])/2))
#endif

#ifdef FFT_SORENSEN_REAL
static char fft_algorithm[] = "sorensen-r";
static char trig_algorithm[] = "simple";
#define FFT(n,r,i)  rsrfft(r,logn);
#define IFFT(n,r,i) rsrfft(r,logn);
#define SCALE for (j=0;j<n;j++)  {real[j]*=scale;}
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define REAL_OUTPUT(i) ((i<n/2)?   real[i]: real[n-i])
#define IMAG_OUTPUT(i) ((i<n/2)? imag[n-i]:-imag[i])
#endif

#ifdef FFT_DUHAMEL
char fft_algorithm[] = "duhamel";
char trig_algorithm[] = "c_lib";
#define FFT(n,r,i)  dfft((r),(i),(n))
#define IFFT(n,r,i) dfft((r),(i),(n))
#define SCALE for (j=0;j<n;j++)  {real[j]*=scale;imag[j]*=scale;}
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define REAL_OUTPUT(i) real[i]
#define IMAG_OUTPUT(i) imag[i]
#endif

#ifdef FFT_FOUREA
char fft_algorithm[] = "fourea";
char trig_algorithm[] = "c_lib";
#define FFT(n,r,i)  fft_bidir_complex_radix2((n),(r),(i),(-1))
#define IFFT(n,r,i) fft_bidir_complex_radix2((n),(r),(i),(1));
#define SCALE
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define REAL_OUTPUT(i) real[i]*n
#define IMAG_OUTPUT(i) imag[i]*n
#endif

#ifdef FFT_FOUREA_REAL
static double scratch[65536];
char fft_algorithm[] = "fourea-real";
char trig_algorithm[] = "c_lib";
#define FFT(n,r,i)  fft_fwd_real_radix2((n),(r),(scratch))
#define IFFT(n,r,i) fft_inv_real_radix2((n),(r),(scratch));
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define REAL_OUTPUT(i) real[i]*n
#define IMAG_OUTPUT(i) imag[i]*n
#define SCALE
#endif

#ifdef FFT_SING
char fft_algorithm[] = "sing";
char trig_algorithm[] = "sing";
#define FFT(n,r,i)  sing((r),(i),(n),(n),(n),-1);
#define IFFT(n,r,i) sing((r),(i),(n),(n),(n),1);
#define SCALE for (j=0;j<n;j++)  {real[j]*=scale;imag[j]*=scale;}
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define REAL_OUTPUT(i) real[i]
#define IMAG_OUTPUT(i) imag[i]
#endif

#ifdef FFT_SING_REAL
double saver,savei;
char fft_algorithm[] = "sing_real";
char trig_algorithm[] = "sing";
#define FFT(n,r,i)  saver=(r)[(n)/2];savei=(i)[(n)/2];  \
                    sing((r),(i),(n/2),(n/2),(n/2),-1); \
                    realtr((r),(i),(n/2),-1);
#define IFFT(n,r,i) realtr((r),(i),(n/2),1);            \
                    sing((r),(i),(n/2),(n/2),(n/2),1);  \
                    (r)[(n)/2]=saver;(i)[(n)/2]=savei;
#define SCALE for (j=0;j<n/2;j++)  {real[j]*=scale*0.5;imag[j]*=scale*0.5;}
#define REAL_INPUT(i) (*((i&1)?(rsav+i/2):(isav+i/2)))
#define IMAG_INPUT(i) isav[i+n]
#define REAL_OUTPUT(i) real[i]
#define IMAG_OUTPUT(i) imag[i]
#endif

#ifdef FFT_WANG
int status;
char fft_algorithm[] = "wang";
char trig_algorithm[] = "sing";
#define FFT(n,r,i)  fft((r),(i),(n),(n),(n),-1,&status);
#define IFFT(n,r,i) fft((r),(i),(n),(n),(n),1,&status);
#define SCALE for (j=0;j<n;j++)  {real[j]*=scale;imag[j]*=scale;}
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) isav[i]
#define REAL_OUTPUT(i) real[i]
#define IMAG_OUTPUT(i) imag[i]
#endif

#ifdef FFT_NUMREC
char fft_algorithm[] = "numrec";
char trig_algorithm[] = "numrec";
#define FFT(n,r,i)   four1((r),(n),1);
#define IFFT(n,r,i)  four1((r),(n),-1);
#define SCALE for (j=1;j<=n*2;j++)  {real[j]*=scale;}
#define REAL_INPUT(i) rsav[(i)*2+1]
#define IMAG_INPUT(i) rsav[(i)*2+2]
#define REAL_OUTPUT(i) real[(i)*2+1]
#define IMAG_OUTPUT(i) real[(i)*2+2]
#endif



#ifdef FFT_NUMREC_REAL
char fft_algorithm[] = "nrec_real";
char trig_algorithm[] = "numrec";
#define FFT(n,r,i)   realft((r),(n/2),1);
#define IFFT(n,r,i)  realft((r),(n/2),-1);
#define SCALE for (j=1;j<=n;j++)  {real[j]*=scale*2;}
#define REAL_INPUT(i) rsav[i+1]
#define IMAG_INPUT(i) isav[i+1]
#define REAL_OUTPUT(i) ((i<n/2) ? real[(i)*2+1] : real[(n-i)*2+1])
#define IMAG_OUTPUT(i) ((i<n/2) ? real[(i)*2+2] : -real[(i)*2+2])
#endif


#ifdef FFT_DOLBY
short bswitch = 1;
char fft_algorithm[] = "dolby";
char trig_algorithm[] = "tables";
#define FFT(n,r,i)   cifft(real);
#define IFFT(n,r,i)  cifft(real);
#define SCALE
#define REAL_INPUT(i) rsav[i]
#define IMAG_INPUT(i) rsav[128+i]
#define REAL_OUTPUT(i) real[i]
#define IMAG_OUTPUT(i) real[128+i]
#endif


#define PI2 6.2831853071795864769252867665590057683936
#define PI 6.2831853071795864769252867665590057683936/2

nothing(){;}

main(argc,argv)
int argc;
char **argv;
{
 int n=0,iterations,i,k,j,logn;
 double t1,t2,toverhead,re,im;
 REAL ssq_errors=0;
 REAL scale;

 if (argc>1) n=atoi(argv[1]);   else n=256;

 REAL_INPUT(0)=17;
 REAL_INPUT(n/2)=1;
 for (i=1;i<n/2;i++)
    {
     REAL_INPUT(i)  =sin(17*PI*i/n)/sin(PI*i/n);
     REAL_INPUT(n-i)=sin(17*PI*i/n)/sin(PI*i/n);
    }

#define EXPECTED_REAL_OUTPUT(i) ((i<9 || i>n-9)? n:0);
#define EXPECTED_IMAG_OUTPUT(i) (0);

 iterations = 2+ITERATION_FACTOR*256/n;
 scale = 1.0/n;
 for ( logn=0 ; (1<<logn)<n ; logn++ );
 t1 = dtime();
 for (k=0;k<iterations;k++)
     {
      for (i=0;i<n*2;i++) {real[i]=rsav[i];imag[i]=isav[i];}
      nothing(n,real,imag);
     }
 t2 = dtime();
 toverhead=t2-t1;

 t1 = dtime();
      FFT(n,real,imag);
 t2 = dtime();

 t1 = dtime();
 for (k=0;k<iterations;k++)
     {
      for (i=0;i<n*2;i++) {real[i]=rsav[i];imag[i]=isav[i];}
      FFT(n,real,imag);
     }
 t2 = dtime();

 for (ssq_errors=0,i=0;i<n;i++)
    {
     double a,b;
/*
     a=REAL_OUTPUT(i);
     b=EXPECTED_REAL_OUTPUT(i);
     printf("%d\t%g\t%g\n",i,b,a);
*/
     re=REAL_OUTPUT(i)-EXPECTED_REAL_OUTPUT(i);
     im=IMAG_OUTPUT(i)-EXPECTED_IMAG_OUTPUT(i);
     ssq_errors+=(re*re+im*im);
    }

 for ( i=0 ; (1<<i)<n ; i++ );
 if (ssq_errors < 1)
     printf("%-12s;%-8s %5d :  %-#8.3g  %-#8.3g\n",
	    fft_algorithm,trig_algorithm,n,
	    1000000*(t2-t1-toverhead)/iterations/n/i,
	    ssq_errors/iterations);
 else
     printf("%-12s;%-8s %5d :  %-#8.3g  n/a\n",
	    fft_algorithm,trig_algorithm,n,
	    1000000*(t2-t1-toverhead)/iterations/n/i,
	    ssq_errors/iterations);
}
