/* functions to perform fourier transforms and associated functions */


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <float.h>
#include <malloc.h>

#include "d:\libs\fftlib.h"

#define PI (float)3.1415926536


/* calculate bidirectional complex fourier transform   */
/* for any of data points                              */
/* adapted from Holmes,J.T.,Naval Ordnance Test Lab    */
/* Report NOTLR 72-299 October 1972 ADSATIS AD-754 393 */

void fft_bidir_complex_any(int size,float *real,float *imag,int dirn)
{
  int i,j,k,l,f,a,n,c,r,w,q,b,p,s,d,t,*fact;
  float sign,expo,theta,sintheta,costheta,temp,*work;
  fact=(int *)malloc(256);
  work=(float *)malloc(8*size);
  if(fact==NULL||work==NULL) fft_fatal_error("Insufficient memory for fft");
  if(dirn>0) sign=(float)1;
  else sign=(float)(-1);
  f=0;
  a=1;
  c=size;
  do
  {
    f++;
    n=c;
    expo=sign*PI*((float)2/(float)n);
    r=2;
    if(f>=2) r=fact[f-2];
    while((n%r)!=0) r++;
    fact[f-1]=r;
    c=n/r;
    for(l=0;l<a;l++)
    {
      b=l*n;
      for(j=0;j<c;j++)
      {
	for(i=0;i<r;i++)
	{
	  work[2*i]=(float)0;
	  work[2*i+1]=(float)0;
	  p=b+j;
	  for(k=0;k<r;k++)
	  {
	    w=(i*(k*c+j))%n;
	    theta=expo*(float)w;
	    sintheta=(float)sin(theta);
	    costheta=(float)cos(theta);
	    work[2*i]+=real[p]*costheta-imag[p]*sintheta;
	    work[2*i+1]+=real[p]*sintheta+imag[p]*costheta;
	    p+=c;
	  }
	}
	for(i=0;i<r;i++)
	{
	  p=b+i*c+j;
	  real[p]=work[2*i];
	  imag[p]=work[2*i+1];
	}
      }
    }
    a*=r;
  }
  while(c!=1);
  if(dirn<0)
  {
    for(i=0;i<size;i++)
    {
      real[i]/=(float)size;
      imag[i]/=(float)size;
    }
  }
  for(d=0;d<size;d++)
  {
    s=d;
    do
    {
      n=size;
      q=s;
      s=0;
      for(i=0;i<f;i++)
      {
	t=q/fact[i];
	r=q-fact[i]*t;
	q=t;
	n/=fact[i];
	s+=n*r;
      }
    }
    while(s<d);
    temp=real[d];
    real[d]=real[s];
    real[s]=temp;
    temp=imag[d];
    imag[d]=imag[s];
    imag[s]=temp;
  }
  free(fact);
  free(work);
}

/* calculate forward transform of complex data for any number of points */

void fft_fwd_complex_any(int size,float *real,float *imag)
{
  fft_bidir_complex_any(size,real,imag,-1);
}

/* calculate inverse transform of complex data for any number of points */

void fft_inv_complex_any(int size,float *real,float *imag)
{
  fft_bidir_complex_any(size,real,imag,1);
}

/* calculate forward transform of real data for any number of points */

void fft_fwd_real_any(int size,float *real,float *imag)
{
  int i;
  for(i=0;i<size;i++) imag[i]=(float)0;
  fft_fwd_complex_any(size,real,imag);
}

/* calculate inverse transform of real data for any number of points */

void fft_inv_real_any(int size,float *real,float *imag)
{
  int i,j,spectrumsize;
  spectrumsize=fft_freq_domain_size(size);
  for(i=1;i<spectrumsize;i++)
  {
    j=size-i;
    real[j]=real[i];
    imag[j]= -imag[i];
  }
  fft_inv_complex_any(size,real,imag);
}

