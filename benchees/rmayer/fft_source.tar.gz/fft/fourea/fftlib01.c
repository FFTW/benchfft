/* functions to perform fourier transforms and associated functions */


#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <math.h>

#include "d:\libs\fftlib.h"

#define SUCCESS 1
#define FAILURE 0

#define PI (float)3.1415926536

#define SQUARE(x) ((x)*(x))


/* fatal error exit */

void fft_fatal_error(char *message)
{
  puts(message);
  exit(1);
}

/* calculate array size from spectrum size */

int fft_time_domain_size(int freq_domain_size)
{
  int size;
  size=2*(freq_domain_size-1);
  return size;
}

/* calculate spectrum size from array size */

int fft_freq_domain_size(int time_domain_size)
{
  int size;
  size=time_domain_size/2+1;
  return size;
}

/* test for radix 2 up to power of 15 */

int fft_test_radix2(int time_domain_size)
{
  register int i,j;
  j=1;
  for(i=1;i<=15;i++)
  {
    j*=2;
    if(j==time_domain_size) return SUCCESS;
  }
  return FAILURE;
}

/* convert from polar to rectangular coordinates */

void fft_rect(int size,float *ampl,float *phas,float *real,float *imag)
{
  int i;
  float rtemp,itemp;
  for(i=0;i<size;i++)
  {
    rtemp=ampl[i]*cos(phas[i]);
    itemp=ampl[i]*sin(phas[i]);
    real[i]=rtemp;
    imag[i]=itemp;
  }
}

/* convert from rectangular to polar coordinates */

void fft_polar(int size,float *real,float *imag,float *ampl,float *phas)
{
  int i;
  float atemp,ptemp;
  for(i=0;i<size;i++)
  {
    atemp=(float)sqrt(SQUARE(real[i])+SQUARE(imag[i]));
    if((real[i]==(float)0)&&(imag[i]==(float)0)) ptemp=(float)0;
      else ptemp=(float)atan2(imag[i],real[i]);
    ampl[i]=atemp;
    phas[i]=ptemp;
  }
}

/* calculate amplitude spectrum */

void fft_ampl(int size,float *real,float *imag,float *ampl)
{
  int i;
  for(i=0;i<size;i++) ampl[i]=(float)sqrt(SQUARE(real[i])+SQUARE(imag[i]));
}

/* calculate phase spectrum */

void fft_phase(int size,float *real,float *imag,float *phas)
{
  int i;
  for(i=0;i<size;i++)
  {
    if((real[i]==(float)0)&&(imag[i]==(float)0)) phas[i]=(float)0;
      else phas[i]=(float)atan2(imag[i],real[i]);
  }
}

/* calculate minimum and maximum values of data */

void fft_min_max_value(int size,float *array,float *min,float *max)
{
  register int i;
  *min=array[0];
  *max=array[0];
  for(i=1;i<size;i++)
  {
    if(array[i]>*max) *max=array[i];
      else if(array[i]<*min) *min=array[i];
  }
}

/* calculate absolute maximum value of data */

void fft_max_abs_value(int size,float *array,float *maxabs)
{
  register int i;
  *maxabs=(float)fabs(array[0]);
  for(i=1;i<size;i++)
  {
    if((float)fabs(array[i])>*maxabs) *maxabs=(float)fabs(array[i]);
  }
}

/* double amplitude of spectrum except at dc */

void fft_double(int size,float *ampl)
{
  register int i;
  for(i=1;i<size;i++) ampl[i]*=(float)2;
}

/* convert from radians to degrees */

void fft_degrees(int size,float *phas)
{
  register int i;
  for(i=0;i<size;i++) phas[i]*=(float)180/PI;
}

/* convert from degrees to radians */

void fft_radians(int size,float *phas)
{
  register int i;
  for(i=0;i<size;i++) phas[i]*=PI/(float)180;
}

/* convert amplitude to decibels */

void fft_decibels(int size,float *ampl,float reference,float minimum)
{
  int i;
  for(i=0;i<size;i++)
  {
    if(ampl[i]==(float)0) ampl[i]=minimum;
      else ampl[i]=(float)20*(float)log10(ampl[i]/reference);
    if(ampl[i]<minimum) ampl[i]=minimum;
  }
}

