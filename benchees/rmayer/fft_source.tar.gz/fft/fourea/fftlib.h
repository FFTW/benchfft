#ifdef ANSI
/* functions to perform fourier transforms and associated functions */


/* fftlib01 */

void fft_fatal_error(char *message);
int  fft_time_domain_size(int size);
int  fft_freq_domain_size(int size);
int  fft_test_radix2(int size);
void fft_rect(int size,double *ampl,double *phas,double *real,double *imag);
void fft_polar(int size,double *real,double *imag,double *ampl,double *phas);
void fft_ampl(int size,double *real,double *imag,double *ampl);
void fft_phase(int size,double *real,double *imag,double *phas);
void fft_min_max_value(int size,double *data,double *min,double *max);
void fft_max_abs_value(int size,double *data,double *max);
void fft_double(int size,double *ampl);
void fft_degrees(int size,double *phas);
void fft_radians(int size,double *phas);
void fft_decibels(int size,double *ampl,double ref,double min);

/* fftlib02 */

void fft_bidir_complex_any(int size,double *real,double *imag,int dirn);
void fft_fwd_complex_any(int size,double *real,double *imag);
void fft_inv_complex_any(int size,double *real,double *imag);
void fft_fwd_real_any(int size,double *real,double *imag);
void fft_inv_real_any(int size,double *real,double *imag);

/* fftlib03 */

void fft_bidir_complex_radix2(int size,double *real,double *imag,int dirn);
void fft_fwd_complex_radix2(int size,double *real,double *imag);
void fft_inv_complex_radix2(int size,double *real,double *imag);
void fft_fwd_real_radix2(int size,double *real,double *imag);
void fft_inv_real_radix2(int size,double *real,double *imag);
void fft_hilbert_real_radix2(int size,double *real,double *imag);

/* fftlib04 */

void fft_blackman_harris(int size,double *wind);
void fft_hanning(int size,double *wind);
void fft_hamming(int size,double *wind);

/* fftlib05 */

void fft_interp_real_any(int old,int new,double *real,double *imag);
void fft_interp_complex_any(int old,int new,double *real,double *imag);

/* fftlib06 */

void fft_interp_real_radix2(int old,int new,double *real,double *imag);
void fft_interp_complex_radix2(int old,int new,double *real,double *imag);

#endif
