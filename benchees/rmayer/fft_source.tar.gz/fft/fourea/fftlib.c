/* functions to perform fourier transforms and associated functions */


/*#include <stdlib.h>*/
#include <stdio.h>
#include <math.h>
#include "fftlib.h"

#define SUCCESS 1
#define FAILURE 0

#define PI (double)3.1415926536

#define SQUARE(x) ((x)*(x))

/* fatal error exit */

void fft_fatal_error(message)
char *message;
{
  puts(message);
  exit(1);
}

/* calculate array size from spectrum size */

int fft_time_domain_size(freq_domain_size)
int freq_domain_size;
{
  int size;
  size=2*(freq_domain_size-1);
  return size;
}

/* calculate spectrum size from array size */

int fft_freq_domain_size(time_domain_size)
int time_domain_size;
{
  int size;
  size=time_domain_size/2+1;
  return size;
}

/* test for radix 2 up to power of 15 */

int fft_test_radix2(time_domain_size)
int time_domain_size;
{
  int i,j;
  j=1;
  for(i=1;i<=15;i++)
  {
    j*=2;
    if(j==time_domain_size) return SUCCESS;
  }
  return FAILURE;
}

/* calculate bidirectional fourier transform of complex data radix 2 */
/* adapted from subroutine FOUREA listed in                          */
/* Programs for Digital Signal Processing                            */
/* edited by Digital Signal Processing Committee                     */
/* IEEE Acoustics Speech and Signal Processing Committee             */
/* Chapter 1 Section 1.1 Page 1.1-4,5                                */
/* direct -1 forward +1 reverse                                      */

void fft_bidir_complex_radix2(size,real,imag,direct)
int size;double *real;double *imag;int direct;
{
  int i,j,m,mmax,istep;
  double c,s,treal,timag,theta;

  /* compute transform */

  j=1;
  for(i=1;i<=size;i++)
  {
    if(i<j)
    {
      treal=real[j-1];
      timag=imag[j-1];
      real[j-1]=real[i-1];
      imag[j-1]=imag[i-1];
      real[i-1]=treal;
      imag[i-1]=timag;
    }
    m=size/2;
    while(j>m)
    {
      j-=m;
      m=(m+1)/2;
    }
    j+=m;
  }
  mmax=1;
  while(size>mmax)
  {
    istep=2*mmax;
    for(m=1;m<=mmax;m++)
    {
      theta=PI*(double)direct*(double)(m-1)/(double)mmax;
      c=(double)cos(theta);
      s=(double)sin(theta);
      for(i=m;i<=size;i+=istep)
      {
	j=i+mmax;
	treal=real[j-1]*c-imag[j-1]*s;
	timag=imag[j-1]*c+real[j-1]*s;
	real[j-1]=real[i-1]-treal;
	imag[j-1]=imag[i-1]-timag;
	real[i-1]+=treal;
	imag[i-1]+=timag;
      }
    }
    mmax=istep;
  }

  /* for forward transform divide by size */

  if(direct<0)
  {
    for(i=0;i<size;i++)
    {
      real[i]/=(double)size;
      imag[i]/=(double)size;
    }
  }
}

/* calculate forward fourier transform of complex data radix 2 */

void fft_fwd_complex_radix2(size,real,imag)
int size;double *real;double *imag;
{
  fft_bidir_complex_radix2(size,real,imag,-1);
}

/* calculate inverse fourier transform of complex data radix 2 */

void fft_inv_complex_radix2(size,real,imag)
int size;double *real;double *imag;
{
  fft_bidir_complex_radix2(size,real,imag,1);
}

/* calculate forward fourier transform of real data radix 2 */

void fft_fwd_real_radix2(size,real,imag)
int size;double *real;double *imag;
{
  register int i;
  for(i=0;i<size;i++) imag[i]=(double)0;
  fft_fwd_complex_radix2(size,real,imag);
}

/* calculate inverse fourier transform of real data radix 2 */

void fft_inv_real_radix2(size,real,imag)
int size;double *real;double *imag;
{
  register int i;
  int j,spectrumsize;
  spectrumsize=fft_freq_domain_size(size);
  for(i=2;i<=spectrumsize;i++)
  {
    j=size+2-i;
    real[j-1]=real[i-1];
    imag[j-1]= -imag[i-1];
  }
  fft_inv_complex_radix2(size,real,imag);
}
#ifdef UTILS
/* convert from polar to rectangular coordinates */

void fft_rect(size,ampl,phas,real,imag)
int size;double *ampl;double *phas;double *real;double *imag;
{
  register int i;
  double rtemp,itemp;
  for(i=0;i<size;i++)
  {
    rtemp=ampl[i]*cos(phas[i]);
    itemp=ampl[i]*sin(phas[i]);
    real[i]=rtemp;
    imag[i]=itemp;
  }
}

/* convert from rectangular to polar coordinates */

void fft_polar(size,real,imag,ampl,phas)
int size;double *real;double *imag;double *ampl;double *phas;
{
  int i;
  double atemp,ptemp;
  for(i=0;i<size;i++)
  {
    atemp=(double)sqrt(SQUARE(real[i])+SQUARE(imag[i]));
    if((real[i]==(double)0)&&(imag[i]==(double)0)) ptemp=(double)0;
      else ptemp=(double)atan2(imag[i],real[i]);
    ampl[i]=atemp;
    phas[i]=ptemp;
  }
}

/* calclate amplitude spectrum */

void fft_ampl(int size,double *real,double *imag,double *ampl)
{
  int i;
  for(i=0;i<size;i++) ampl[i]=(double)sqrt(SQUARE(real[i])+SQUARE(imag[i]));
}

/* calculate phase spectrum */

void fft_phase(int size,double *real,double *imag,double *phas)
{
  int i;
  for(i=0;i<size;i++)
  {
    if((real[i]==(double)0)&&(imag[i]==(double)0)) phas[i]=(double)0;
      else phas[i]=(double)atan2(imag[i],real[i]);
  }
}

/* calculate minimum and maximum values of data */

void fft_min_max_value(int size,double *array,double *min,double *max)
{
  int i;
  *min=array[0];
  *max=array[0];
  for(i=1;i<size;i++)
  {
    if(array[i]>*max) *max=array[i];
      else if(array[i]<*min) *min=array[i];
  }
}

/* calculate absolute maximum value of data */

void fft_max_abs_value(int size,double *array,double *maxabs)
{
  int i;
  *maxabs=(double)fabs(array[0]);
  for(i=1;i<size;i++)
  {
    if((double)fabs(array[i])>*maxabs) *maxabs=(double)fabs(array[i]);
  }
}

/* calculate hilbert transform of real data radix 2 */

void fft_hilbert_real_radix2(int size,double *real,double *imag)
{
  int i,spectrumsize;

  /* calculate forward fourier transform of real data */

  fft_fwd_real_radix2(size,real,imag);

  /* determine spectrum size */

  spectrumsize=fft_freq_domain_size(size);

  /* zero negative frequency half of spectrum */

  for(i=spectrumsize;i<size;i++)
  {
    real[i]=(double)0;
    imag[i]=(double)0;
  }

  /* double positive frequency half of spectrum */

  for(i=1;i<spectrumsize;i++)
  {
    real[i]*=(double)2;
    imag[i]*=(double)2;
  }

  /* calculate inverse fourier transform of complex data */

  fft_inv_complex_radix2(size,real,imag);
}

/* double amplitude of spectrum except at dc */

void fft_double(int size,double *ampl)
{
  int i;
  for(i=1;i<size;i++) ampl[i]*=(double)2;
}

/* convert from radians to degrees */

void fft_degrees(int size,double *phas)
{
  int i;
  for(i=0;i<size;i++) phas[i]*=(double)180/PI;
}

/* convert from degrees to radians */

void fft_radians(int size,double *phas)
{
  int i;
  for(i=0;i<size;i++) phas[i]*=PI/(double)180;
}

/* convert amplitude to decibels */

void fft_decibels(int size,double *ampl,double reference,double minimum)
{
  int i;
  for(i=0;i<size;i++)
  {
    if(ampl[i]==(double)0) ampl[i]=minimum;
      else ampl[i]=(double)20*(double)log10(ampl[i]/reference);
    if(ampl[i]<minimum) ampl[i]=minimum;
  }
}

/* calculate blackman-harris four term weighting function */

void fft_blackman_harris(int size,double *wind)
{
  int i,middle;
  double a1=(double).35875,a2=(double).48829,a3=(double).14128,a4=(double).01168;
  double c;
  middle=size/2;
  wind[0]=(a1-a2+a3-a4)/a1;
  for(i=1;i<=middle;i++)
  {
    c=PI*((double)2*(double)i)/((double)size);
    wind[i]=(a1-a2*cos(c)+a3*cos((double)2*c)-a4*cos((double)3*c))/a1;
    wind[size-i]=wind[i];
  }
}

#endif
