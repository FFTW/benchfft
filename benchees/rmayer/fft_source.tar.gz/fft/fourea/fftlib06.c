/* functions to perform fourier transforms and associated functions */


#include "d:\libs\fftlib.h"


/* interpolate real time domain signal with radix 2 points */

void fft_interp_real_radix2(int old,int new,float *real,float *imag)
{
  int i,old_spec_size,new_spec_size;
  fft_fwd_real_radix2(old,real,imag);
  if(new>old)
  {
    old_spec_size=fft_freq_domain_size(old);
    new_spec_size=fft_freq_domain_size(new);
    for(i=old_spec_size;i<new_spec_size;i++)
    {
      real[i]=(float)0;
      imag[i]=(float)0;
    }
  }
  fft_inv_real_radix2(new,real,imag);
}

/* interpolate complex time domain signal with radix 2 points */

void fft_interp_complex_radix2(int old,int new,float *real,float *imag)
{
  int i;
  fft_fwd_complex_radix2(old,real,imag);
  if(new>old)
  {
    for(i=old;i<new;i++)
    {
      real[i]=(float)0;
      imag[i]=(float)0;
    }
  }
  fft_inv_complex_radix2(new,real,imag);
}

