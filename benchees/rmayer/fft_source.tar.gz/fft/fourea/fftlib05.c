/* functions to perform fourier transforms and associated functions */


#include "d:\libs\fftlib.h"


/* interpolate real time domain signal with any number of points */

void fft_interp_real_any(int old,int new,float *real,float *imag)
{
  int i,old_spec_size,new_spec_size;
  if(fft_test_radix2(old)) fft_fwd_real_radix2(old,real,imag);
  else fft_fwd_real_any(old,real,imag);
  if(new>old)
  {
    old_spec_size=fft_freq_domain_size(old);
    new_spec_size=fft_freq_domain_size(new);
    for(i=old_spec_size;i<new_spec_size;i++)
    {
      real[i]=(float)0;
      imag[i]=(float)0;
    }
  }
  if(fft_test_radix2(new)) fft_inv_real_radix2(new,real,imag);
  else fft_inv_real_any(new,real,imag);
}

/* interpolate complex time domain signal with any number of points */

void fft_interp_complex_any(int old,int new,float *real,float *imag)
{
  int i;
  if(fft_test_radix2(old)) fft_fwd_complex_radix2(old,real,imag);
  else fft_fwd_complex_any(old,real,imag);
  if(new>old)
  {
    for(i=old;i<new;i++)
    {
      real[i]=(float)0;
      imag[i]=(float)0;
    }
  }
  if(fft_test_radix2(new)) fft_inv_complex_radix2(new,real,imag);
  else fft_inv_complex_any(new,real,imag);
}

