/* functions to perform fourier transforms and associated functions */


#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <math.h>

#include "d:\libs\fftlib.h"

#define PI (float)3.1415926536


/* calculate blackman-harris four term weighting function */

void fft_blackman_harris(int size,float *wind)
{
  int i,middle;
  float a1=(float).35875,a2=(float).48829,a3=(float).14128,a4=(float).01168;
  float c;
  middle=size/2;
  wind[0]=(a1-a2+a3-a4)/a1;
  for(i=1;i<=middle;i++)
  {
    c=PI*((float)2*(float)i)/((float)size);
    wind[i]=(a1-a2*cos(c)+a3*cos((float)2*c)-a4*cos((float)3*c))/a1;
    wind[size-i]=wind[i];
  }
}

/* calculate hanning weighting function */

void fft_hanning(int size,float *wind)
{
  int i,middle;
  float common;
  middle=size/2;
  common=PI*((float)2/(float)size);
  wind[0]=(float)0;
  for(i=1;i<=middle;i++)
  {
    wind[i]=((float)1-cos(common*(float)i));
    wind[size-i]=wind[i];
  }
}

/* calculate hamming weighting function */

void fft_hamming(int size,float *wind)
{
  int i,middle;
  float common;
  float a1=(float)0.1,a2=(float)0.54,a3=(float)0.46;
  middle=size/2;
  common=PI*((float)2/(float)size);
  wind[0]=a1/a2;
  for(i=1;i<=middle;i++)
  {
    wind[i]=(a2-a3*cos(common*(float)i))/a2;
    wind[size-i]=wind[i];
  }
}

