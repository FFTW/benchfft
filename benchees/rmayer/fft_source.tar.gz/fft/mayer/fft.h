int fht();
int fft();
int ifft();
int realfft();
int realifft();
int cas2d();
int fht2d();
int conv2d();
