void four1(data,nn,isign)
double data[];
int nn,isign;
{
  printf("Numerical Recipies won't let this be distributed(see README)\n");
}
