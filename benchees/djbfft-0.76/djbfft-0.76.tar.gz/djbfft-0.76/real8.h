#ifndef REAL8_H
#define REAL8_H

typedef double real8;

#endif
