#ifndef COMPLEX8_H
#define COMPLEX8_H

#include "real8.h"

typedef struct {
  real8 re;
  real8 im;
} complex8;

#endif
