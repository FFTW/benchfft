#ifndef REAL4_H
#define REAL4_H

typedef float real4;

#endif
