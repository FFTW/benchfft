#ifndef COMPLEX4_H
#define COMPLEX4_H

#include "real4.h"

typedef struct {
  real4 re;
  real4 im;
} complex4;

#endif
