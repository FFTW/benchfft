#ifndef FFTFREQ_H
#define FFTFREQ_H

extern unsigned int fftfreq_c(unsigned int,unsigned int);
extern void fftfreq_ctable(unsigned int *,unsigned int);

extern unsigned int fftfreq_r(unsigned int,unsigned int);
extern void fftfreq_rtable(unsigned int *,unsigned int);

#endif
