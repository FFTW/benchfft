#include "PRE"

const complex d16[] = {
#include "roots/h16.c"
};

const complex d32[] = {
#include "roots/h32.c"
};

const complex d64[] = {
#include "roots/h64.c"
};

const complex d128[] = {
#include "roots/h128.c"
};

const complex d256[] = {
#include "roots/h256.c"
};
