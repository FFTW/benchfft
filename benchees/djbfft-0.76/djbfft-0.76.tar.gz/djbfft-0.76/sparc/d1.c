#include "PRE"

const complex d512[] = {
#include "roots/h512.c"
};
