#include "PRE"

const complex d4096[] = {
#include "roots/h4096.c"
};
