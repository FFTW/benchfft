#include "PRE"

const complex d512[] = {
#include "roots/512.c"
};
