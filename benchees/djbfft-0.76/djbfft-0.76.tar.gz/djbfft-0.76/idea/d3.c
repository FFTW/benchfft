#include "PRE"

const complex d2048[] = {
#include "roots/h2048.c"
};
