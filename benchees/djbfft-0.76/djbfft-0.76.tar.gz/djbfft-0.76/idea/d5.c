#include "PRE"

const complex d8192[] = {
#include "roots/h8192.c"
};
