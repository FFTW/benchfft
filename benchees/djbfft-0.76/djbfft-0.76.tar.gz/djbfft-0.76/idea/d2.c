#include "PRE"

const complex d1024[] = {
#include "roots/h1024.c"
};
