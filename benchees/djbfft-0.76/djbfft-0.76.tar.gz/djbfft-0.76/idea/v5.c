#include "PRE"

void v8192(register real *a)
{
  u2048((complex *)(a + 4096));
  v4096(a);
  vpassbig(a,d8192,1024);
}
