#include "PRE"

const complex d16[] = {
#include "roots/16.c"
};

const complex d32[] = {
#include "roots/32.c"
};

const complex d64[] = {
#include "roots/64.c"
};

const complex d128[] = {
#include "roots/128.c"
};

const complex d256[] = {
#include "roots/256.c"
};
